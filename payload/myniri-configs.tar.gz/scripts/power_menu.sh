#!/bin/bash
# Redirigir el menú de energía al panel QML unificado
exec bash /home/ismael/scripts/toggle_power.sh
