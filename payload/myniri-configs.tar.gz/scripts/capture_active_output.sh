#!/bin/bash
# Captures only the monitor/output where the cursor/focus is under Niri
set -e

D="$HOME/Imágenes/Screenshots"
F="$D/Screenshot_$(date +%Y%m%d_%H%M%S).png"
mkdir -p "$D"

# Get geometry of the focused output in Niri
GEOM=$(niri msg --json focused-output | jq -r '
    "\(.logical.x),\(.logical.y) \(.logical.width)x\(.logical.height)"
')

if [ -z "$GEOM" ] || [ "$GEOM" == "null,null nullxnull" ]; then
    # Fallback to general grim if focused-output query fails
    grim "$F"
    wl-copy --foreground --type image/png < "$F" &
    notify-send "Captura" "Pantalla completa guardada"
    exit 0
fi

grim -g "$GEOM" "$F"
wl-copy --foreground --type image/png < "$F" &
notify-send "Captura" "Captura de pantalla guardada"
