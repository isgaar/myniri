#!/bin/bash
# battery_info.sh — Imprime datos de batería y perfil de energía en TSV.
# Salida: percent\tstate\ttime_info\thealth\tcapacity_wh\tprofile
# Usado por el panel Quickshell de batería.

# ── Batería (upower) ──────────────────────────────────────────
bat_path=$(upower -e 2>/dev/null | grep -E "(BAT|battery)" | head -1)

if [[ -z "$bat_path" ]]; then
    echo "N/A	no-bat	 	N/A	N/A	balanced"
    exit 0
fi

bat_info=$(upower -i "$bat_path" 2>/dev/null)

percent=$(echo "$bat_info"  | awk '/percentage/{gsub(/%/,"",$2); print $2}')
state=$(echo "$bat_info"    | awk '/^[ \t]*state:/{print $2; exit}')
health=$(echo "$bat_info"   | awk '/^[ \t]*capacity:/{print $2; exit}')
energy=$(echo "$bat_info"   | awk '/energy-full:/{printf "%s %s", $2, $3; exit}')
time_info=$(echo "$bat_info" | grep -i "time to" | awk '{$1=""; $2=""; print}' | xargs)

# ── Perfil activo ─────────────────────────────────────────────
# Prioridad: power-profiles-daemon → tuned → cpupower governor
if command -v powerprofilesctl &>/dev/null; then
    profile=$(powerprofilesctl get 2>/dev/null || echo "balanced")
elif command -v tuned-adm &>/dev/null; then
    tuned_prof=$(tuned-adm active 2>/dev/null | awk '{print $NF}')
    case "$tuned_prof" in
        *powersave*|*battery*)     profile="power-saver"  ;;
        *balanced*)                profile="balanced"      ;;
        *performance*|*throughput*|*latency*) profile="performance" ;;
        *)                         profile="balanced"      ;;
    esac
elif [[ -f /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor ]]; then
    gov=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor)
    case "$gov" in
        powersave|conservative)    profile="power-saver"  ;;
        performance)               profile="performance"  ;;
        *)                         profile="balanced"      ;;
    esac
else
    profile="balanced"
fi

echo "${percent:-N/A}	${state:-unknown}	${time_info}	${health:-N/A}	${energy:-N/A}	${profile}"
