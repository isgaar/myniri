#!/bin/bash

# ── Lock: evita doble ejecución ─────────────────────────────────
_SCRIPT_NAME=$(basename "$0" .sh)
_LOCKFILE="/tmp/${_SCRIPT_NAME}.lock"
if [ -e "$_LOCKFILE" ]; then
  _pid=$(cat "$_LOCKFILE")
  if kill -0 "$_pid" 2>/dev/null; then
    exit 0
  fi
fi
echo $$ > "$_LOCKFILE"
trap "rm -f $_LOCKFILE" EXIT INT TERM

# bt_menu.sh — Panel Bluetooth con iconos Font Awesome 6

# ── Iconos FA6 via printf ──────────────────────────────────────────────────────
BT=$(printf '\uf294')         # fa-bluetooth
BT_OFF=$(printf '\uf293')     # fa-bluetooth (off variant)
HEADPHONES=$(printf '\uf590') # fa-headphones
GAMEPAD=$(printf '\uf11b')    # fa-gamepad
KEYBOARD=$(printf '\uf11c')   # fa-keyboard
MOUSE=$(printf '\uf8cc')      # fa-computer-mouse
PHONE=$(printf '\uf3cd')      # fa-mobile
SPEAKER=$(printf '\uf027')    # fa-volume-low
DEVICE=$(printf '\uf7c0')     # fa-laptop (genérico)
SCAN=$(printf '\uf002')       # fa-search
POWER=$(printf '\uf011')      # fa-power-off
CHECK=$(printf '\uf00c')      # fa-check
PLUS=$(printf '\uf067')       # fa-plus

# ── Tipo de dispositivo por clase/nombre ───────────────────────────────────────
get_device_icon() {
  local name="${1,,}"
  case "$name" in
    *headphone*|*headset*|*buds*|*airpod*|*wh-*|*wf-*|*jbl*|*harman*) echo "$HEADPHONES" ;;
    *gamepad*|*controller*|*control*|*dualshock*|*xbox*|*joystick*)    echo "$GAMEPAD"    ;;
    *keyboard*|*teclado*)                                                echo "$KEYBOARD"   ;;
    *mouse*|*raton*)                                                     echo "$MOUSE"      ;;
    *phone*|*iphone*|*android*|*samsung*|*xiaomi*|*pixel*)              echo "$PHONE"      ;;
    *speaker*|*bocina*|*soundbar*|*bose*|*sonos*)                       echo "$SPEAKER"    ;;
    *)                                                                   echo "$DEVICE"     ;;
  esac
}

# ── Estado bluetooth ──────────────────────────────────────────────────────────
bt_powered=$(bluetoothctl show | grep "Powered:" | awk '{print $2}')

if [[ "$bt_powered" == "yes" ]]; then
  TOGGLE_LABEL="$POWER  Apagar Bluetooth"
  bt_status="ON"
else
  TOGGLE_LABEL="$POWER  Encender Bluetooth"
  bt_status="OFF"
fi

# ── Construir menú ────────────────────────────────────────────────────────────
menu_items=""
declare -A action_map

# Toggle encender/apagar
menu_items+="${TOGGLE_LABEL}\n"
action_map["$TOGGLE_LABEL"]="toggle"

# Separador visual
SEP="────────────────────────"
menu_items+="${SEP}\n"
action_map["$SEP"]="noop"

if [[ "$bt_status" == "ON" ]]; then
  # Dispositivos pareados
  while IFS= read -r line; do
    mac=$(echo "$line" | awk '{print $2}')
    name=$(echo "$line" | cut -d' ' -f3-)
    icon=$(get_device_icon "$name")

    # ¿Está conectado?
    connected=$(bluetoothctl info "$mac" | grep "Connected:" | awk '{print $2}')
    if [[ "$connected" == "yes" ]]; then
      label="$icon  $name  $CHECK"
    else
      label="$icon  $name"
    fi

    menu_items+="${label}\n"
    action_map["$label"]="connect:$mac:$name:$connected"
  done < <(bluetoothctl devices | grep "Device")

  # Opción escanear
  menu_items+="${SEP}\n"
  action_map["$SEP2"]="noop"
  SCAN_LABEL="$SCAN  Buscar nuevos dispositivos"
  menu_items+="${SCAN_LABEL}\n"
  action_map["$SCAN_LABEL"]="scan"
fi

# ── Mostrar wofi ───────────────────────────────────────────────────────────────
selected=$(printf "%b" "$menu_items" | wofi \
  --dmenu \
  --prompt "$BT  Bluetooth:" \
  --style ~/.config/wofi/audio.css \
  --width 360 \
  --height 280 \
  --hide-search \
  --no-actions \
  --cache-file /dev/null)

[[ -z "$selected" ]] && exit 0

action="${action_map[$selected]}"
[[ -z "$action" || "$action" == "noop" ]] && exit 0

# ── Ejecutar acción ────────────────────────────────────────────────────────────
case "$action" in
  toggle)
    if [[ "$bt_status" == "ON" ]]; then
      bluetoothctl power off
      rfkill block bluetooth
      notify-send --icon=bluetooth --expire-time=2500 "Bluetooth" "Apagado"
    else
      rfkill unblock bluetooth
      bluetoothctl power on
      notify-send --icon=bluetooth --expire-time=2500 "Bluetooth" "Encendido"
    fi
    ;;

  connect:*)
    mac=$(echo "$action"  | cut -d: -f2)
    name=$(echo "$action" | cut -d: -f3)
    conn=$(echo "$action" | cut -d: -f4)
    if [[ "$conn" == "yes" ]]; then
      bluetoothctl disconnect "$mac"
      notify-send --icon=bluetooth --expire-time=2500 "Bluetooth" "Desconectado: $name"
    else
      notify-send --icon=bluetooth --expire-time=2500 "Bluetooth" "Conectando: $name..."
      bluetoothctl connect "$mac"
      if bluetoothctl info "$mac" | grep -q "Connected: yes"; then
        notify-send --icon=bluetooth --expire-time=2500 "Bluetooth" "Conectado: $name"
      else
        notify-send --icon=bluetooth --expire-time=3000 "Bluetooth" "Error al conectar: $name"
      fi
    fi
    ;;

  scan)
    notify-send --icon=bluetooth --expire-time=3000 "Bluetooth" "Escaneando 10s..."
    bluetoothctl --timeout 10 scan on &
    sleep 10

    # Mostrar dispositivos encontrados
    new_devices=""
    declare -A new_map
    while IFS= read -r line; do
      mac=$(echo "$line"  | awk '{print $2}')
      name=$(echo "$line" | cut -d' ' -f3-)
      icon=$(get_device_icon "$name")
      label="$icon  $name"
      new_devices+="${label}\n"
      new_map["$label"]="$mac"
    done < <(bluetoothctl devices | grep "Device")

    new_selected=$(printf "%b" "$new_devices" | wofi \
      --dmenu \
      --prompt "$PLUS  Parear:" \
      --style ~/.config/wofi/audio.css \
      --width 360 \
      --height 280 \
      --hide-search \
      --no-actions \
      --cache-file /dev/null)

    [[ -z "$new_selected" ]] && exit 0
    pair_mac="${new_map[$new_selected]}"
    [[ -z "$pair_mac" ]] && exit 1

    notify-send --icon=bluetooth --expire-time=3000 "Bluetooth" "Pareando: $new_selected..."
    bluetoothctl pair "$pair_mac" && \
      bluetoothctl trust "$pair_mac" && \
      bluetoothctl connect "$pair_mac"
    notify-send --icon=bluetooth --expire-time=2500 "Bluetooth" "Listo: $new_selected"
    ;;
esac

exit 0
