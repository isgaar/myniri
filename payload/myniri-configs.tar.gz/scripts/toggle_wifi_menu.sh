#!/bin/bash
# toggle_wifi_menu.sh
# Abre el menú Wi-Fi standalone

readonly QS_CONFIG="unified"
readonly PID_FILE="/tmp/qs-${QS_CONFIG}.pid"
readonly LOG_FILE="/tmp/qs-${QS_CONFIG}.log"

_ensure_qs_running() {
    if [[ -f "$PID_FILE" ]]; then
        saved_pid=$(cat "$PID_FILE")
        if kill -0 "$saved_pid" 2>/dev/null; then
            return 0
        fi
        rm -f "$PID_FILE"
    fi

    running_pid=$(pgrep -f "^qs -c ${QS_CONFIG}$" | head -1)
    if [[ -n "$running_pid" ]]; then
        echo "$running_pid" > "$PID_FILE"
        return 0
    fi

    nohup qs -c "$QS_CONFIG" >> "$LOG_FILE" 2>&1 &
    new_pid=$!
    echo "$new_pid" > "$PID_FILE"
    disown "$new_pid" 2>/dev/null || true
    sleep 0.8
    return 0
}

_ensure_qs_running

qs ipc -c "$QS_CONFIG" call wifimenu toggle &>/dev/null || true
