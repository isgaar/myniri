#!/usr/bin/env python3
# ~/scripts/read_sway_settings.py
import sys
import os
import json
import re

CONFIG = os.path.expanduser("~/.config/niri/config.kdl")
EFFECTS = os.path.expanduser("~/.config/niri/effects.kdl")

result = {
    "keyboard_layout": "latam",
    "tap_to_click": True,
    "natural_scroll": True,
    "cursor_theme": "breeze_cursors",
    "cursor_size": 24,
    "gap_inner": 12,
    "gap_outer": 12,
    "smart_gaps": False,
    "smart_borders": False,
    "default_terminal": "kitty",
    "default_launcher": "qs",
    "default_browser": "zen",
    "default_file_manager": "dolphin"
}

# 1. Read main config.kdl
if os.path.exists(CONFIG):
    with open(CONFIG, "r", encoding="utf-8") as f:
        config_content = f.read()
        
    # Keyboard layout
    layout_match = re.search(r'layout\s+"([^"]+)"', config_content)
    if layout_match:
        result["keyboard_layout"] = layout_match.group(1)
        
    # Touchpad settings (presence of string implies enabled)
    # Check inside the touchpad block or globally
    result["tap_to_click"] = "tap" in config_content
    result["natural_scroll"] = "natural-scroll" in config_content
    
    # Cursor theme & size
    theme_match = re.search(r'xcursor-theme\s+"([^"]+)"', config_content)
    if theme_match:
        result["cursor_theme"] = theme_match.group(1)
        
    size_match = re.search(r'xcursor-size\s+(\d+)', config_content)
    if size_match:
        result["cursor_size"] = int(size_match.group(1))
        
    # Default terminal (spawn "honey" "kitty" etc.)
    term_match = re.search(r'Mod\+Return\s*\{\s*spawn\s+"honey"\s+"([^"]+)";\s*\}', config_content)
    if term_match:
        result["default_terminal"] = term_match.group(1)
        
    # Default browser (spawn "honey" "/opt/zen/zen" etc.)
    browser_match = re.search(r'Mod\+Z\s*\{\s*spawn\s+"honey"\s+"([^"]+)";\s*\}', config_content)
    if browser_match:
        result["default_browser"] = os.path.basename(browser_match.group(1))
        
    # Default file manager
    fileman_match = re.search(r'Mod\+E\s*\{\s*spawn\s+"honey"\s+"([^"]+)";\s*\}', config_content)
    if fileman_match:
        result["default_file_manager"] = fileman_match.group(1)

# 2. Read effects.kdl
if os.path.exists(EFFECTS):
    with open(EFFECTS, "r", encoding="utf-8") as f:
        effects_content = f.read()
        
    gaps_match = re.search(r'gaps\s+(\d+)', effects_content)
    if gaps_match:
        gaps_val = int(gaps_match.group(1))
        result["gap_inner"] = gaps_val
        result["gap_outer"] = gaps_val

print(json.dumps(result))
