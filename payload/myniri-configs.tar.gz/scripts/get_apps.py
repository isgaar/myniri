#!/usr/bin/env python3
import os
import re
import json
import sys

# Priority order of themes
THEME_PRIORITY = ['breeze', 'breeze-dark', 'hicolor', 'Adwaita', 'pixmaps']

def build_icon_cache():
    cache = {}
    # Scan standard icon directories
    dirs = [
        os.path.expanduser('~/.local/share/icons'),
        '/usr/share/icons',
        '/usr/share/pixmaps'
    ]
    for base_dir in dirs:
        if not os.path.exists(base_dir):
            continue
        if base_dir == '/usr/share/pixmaps':
            for f in os.listdir(base_dir):
                if f.endswith(('.png', '.svg', '.xpm')):
                    name = os.path.splitext(f)[0]
                    path = os.path.join(base_dir, f)
                    if name not in cache:
                        cache[name] = (path, 10, False)
            continue

        for theme in os.listdir(base_dir):
            theme_path = os.path.join(base_dir, theme)
            if not os.path.isdir(theme_path):
                continue
            
            priority = 99
            if theme in THEME_PRIORITY:
                priority = THEME_PRIORITY.index(theme)
            
            for root, _, files in os.walk(theme_path):
                for f in files:
                    if f.endswith(('.png', '.svg', '.xpm')):
                        name = os.path.splitext(f)[0]
                        path = os.path.join(root, f)
                        ext = os.path.splitext(f)[1].lower()
                        is_svg = ext == '.svg'
                        
                        existing = cache.get(name)
                        if not existing:
                            cache[name] = (path, priority, is_svg)
                        else:
                            exist_path, exist_priority, exist_is_svg = existing
                            if priority < exist_priority:
                                cache[name] = (path, priority, is_svg)
                            elif priority == exist_priority:
                                if is_svg and not exist_is_svg:
                                    cache[name] = (path, priority, is_svg)
    return cache

def parse_desktop_file(filepath, icon_cache):
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
    except Exception:
        return None

    in_desktop_entry = False
    props = {}
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('[') and line.endswith(']'):
            if line == '[Desktop Entry]':
                in_desktop_entry = True
            else:
                in_desktop_entry = False
            continue
        
        if in_desktop_entry:
            if '=' in line:
                parts = line.split('=', 1)
                key = parts[0].strip()
                val = parts[1].strip()
                props[key] = val

    # Validate entry
    if props.get('Type') != 'Application':
        return None
    if props.get('NoDisplay') == 'true' or props.get('Hidden') == 'true':
        return None

    name = props.get('Name', '')
    # Prefer Spanish name if available
    name_es = props.get('Name[es]', props.get('Name[es_ES]', ''))
    if name_es:
        name = name_es

    exec_str = props.get('Exec', '')
    if not name or not exec_str:
        return None

    # Clean up exec string field codes
    exec_cleaned = re.sub(r'"?%[fFuUdDnNkkyvci]"?', '', exec_str).strip()
    exec_cleaned = re.sub(r'\s+', ' ', exec_cleaned)

    icon_name = props.get('Icon', '')
    icon_path = ""
    if icon_name:
        if os.path.isabs(icon_name) and os.path.exists(icon_name):
            icon_path = icon_name
        else:
            # Look up in cache (try multiple variations)
            for variant in [icon_name, icon_name.lower(), icon_name.replace("-", "").lower()]:
                cached = icon_cache.get(variant)
                if cached:
                    icon_path = cached[0]
                    break
            if not icon_path:
                # Try hicolor theme directly as fallback
                for ext in ['.svg', '.svgz', '.png', '.xpm']:
                    for size in ['scalable', '48x48', '32x32', '64x64', '128x128', '22x22', '16x16']:
                        for subdir in ['apps', 'actions', 'categories', 'devices', 'emblems', 'mimetypes', 'places', 'status']:
                            p = f'/usr/share/icons/hicolor/{size}/{subdir}/{icon_name}{ext}'
                            if os.path.exists(p):
                                icon_path = p
                                break
                            p = f'/usr/share/icons/hicolor/{size}/{subdir}/{icon_name.lower()}{ext}'
                            if os.path.exists(p):
                                icon_path = p
                                break
                        if icon_path:
                            break
                    if icon_path:
                        break
                if not icon_path:
                    # Last resort: use icon name as theme key (QML will try image://icon/)
                    icon_path = icon_name

    comment = props.get('Comment', '')
    comment_es = props.get('Comment[es]', props.get('Comment[es_ES]', ''))
    if comment_es:
        comment = comment_es

    keywords = props.get('Keywords', '')

    return {
        'name': name,
        'exec': exec_cleaned,
        'icon': icon_path or "",
        'comment': comment,
        'keywords': keywords
    }

def main():
    icon_cache = build_icon_cache()
    
    # Load usage history
    history = {}
    history_path = os.path.expanduser('~/.config/quickshell/launcher_history.json')
    if os.path.exists(history_path):
        try:
            with open(history_path, 'r') as f:
                history = json.load(f)
        except Exception:
            pass
    
    dirs = [
        os.path.expanduser('~/.local/share/applications'),
        '/usr/local/share/applications',
        '/usr/share/applications'
    ]
    
    apps = {}
    for base_dir in dirs:
        if not os.path.exists(base_dir):
            continue
        for root, _, files in os.walk(base_dir):
            for f in files:
                if f.endswith('.desktop'):
                    path = os.path.join(root, f)
                    parsed = parse_desktop_file(path, icon_cache)
                    if parsed:
                        key = parsed['name'].lower()
                        if key not in apps:
                            apps[key] = parsed

    # Add usage count to each app
    for app in apps.values():
        app['usage'] = history.get(app['name'], 0)

    # Sort alphabetically by name first
    sorted_apps = sorted(apps.values(), key=lambda x: x['name'].lower())
    
    # Sort by usage descending
    sorted_apps.sort(key=lambda x: x.get('usage', 0), reverse=True)
    
    # Write to stdout as a single minified line for QML consumption
    print(json.dumps(sorted_apps))

if __name__ == '__main__':
    main()
