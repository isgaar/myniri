#!/usr/bin/env python3
import argparse
import os
import re
import shutil
import subprocess
from pathlib import Path


HOME = Path.home()


def run(cmd):
    try:
        subprocess.run(cmd, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def set_ini_key(path: Path, key: str, value: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    if path.exists():
        lines = path.read_text(encoding="utf-8").splitlines()
    if not any(line.strip() == "[Settings]" for line in lines):
        lines.insert(0, "[Settings]")

    replaced = False
    out = []
    for line in lines:
        if line.startswith(f"{key}="):
            out.append(f"{key}={value}")
            replaced = True
        else:
            out.append(line)
    if not replaced:
        out.append(f"{key}={value}")
    path.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")


def set_kde_key(path: Path, section: str, key: str, value: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    if not any(line.strip() == f"[{section}]" for line in lines):
        if lines and lines[-1].strip():
            lines.append("")
        lines.append(f"[{section}]")

    out = []
    current_section = None
    replaced = False
    inserted = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            if current_section == section and not replaced:
                out.append(f"{key}={value}")
                inserted = True
            current_section = stripped[1:-1]
            out.append(line)
            continue
        if current_section == section and line.startswith(f"{key}="):
            out.append(f"{key}={value}")
            replaced = True
            inserted = True
        else:
            out.append(line)

    if not inserted:
        out.append(f"{key}={value}")
    path.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")


def update_env_file(path: Path, theme: str, size: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    exports = {
        "XCURSOR_THEME": theme,
        "XCURSOR_SIZE": str(size),
        "XCURSOR_PATH": "$HOME/.local/share/icons:$HOME/.icons:/usr/share/icons",
    }
    for key, value in exports.items():
        line = f"export {key}={value}"
        if re.search(rf"^export\s+{key}=.*$", text, flags=re.MULTILINE):
            text = re.sub(rf"^export\s+{key}=.*$", line, text, flags=re.MULTILINE)
        else:
            text = text.rstrip() + "\n" + line + "\n"
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def update_niri_config(path: Path, theme: str, size: int):
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    text = re.sub(
        r"\bXCURSOR_THEME XCURSOR_SIZE\b(?! XCURSOR_PATH)",
        "XCURSOR_THEME XCURSOR_SIZE XCURSOR_PATH",
        text,
    )
    block = f'cursor {{\n    xcursor-theme "{theme}"\n    xcursor-size {size}\n}}'
    if re.search(r"cursor\s*\{[^}]*\}", text, flags=re.DOTALL):
        text = re.sub(r"cursor\s*\{[^}]*\}", block, text, count=1, flags=re.DOTALL)
    else:
        text = text.rstrip() + "\n\n" + block + "\n"
    path.write_text(text, encoding="utf-8")


def update_xsettings(path: Path, theme: str, size: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    settings = {
        "Gtk/CursorThemeName": f'"{theme}"',
        "Gtk/CursorThemeSize": str(size),
    }
    existing = {line.split(" ", 1)[0] for line in lines if " " in line}
    for key, value in settings.items():
        replaced = False
        out = []
        for line in lines:
            if line.startswith(f"{key} "):
                out.append(f"{key} {value}")
                replaced = True
            else:
                out.append(line)
        lines = out
        if not replaced and key not in existing:
            lines.append(f"{key} {value}")
    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def ensure_user_icon_theme(theme: str):
    user_theme = HOME / ".local/share/icons" / theme
    if user_theme.exists():
        return

    for source_base in (Path("/usr/share/icons"), Path("/usr/local/share/icons"), HOME / ".icons"):
        source_theme = source_base / theme
        if source_theme.exists() and source_theme.is_dir():
            user_theme.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(source_theme, user_theme, symlinks=True)
            return


def clean_flatpak_reserved_icon_overrides():
    overrides_dir = HOME / ".local/share/flatpak/overrides"
    if not overrides_dir.exists():
        return

    reserved_entries = {
        "/usr/share/icons",
        "/usr/share/icons:ro",
        "!/usr/share/icons",
        "!/usr/share/icons:ro",
    }
    for override_file in overrides_dir.iterdir():
        if not override_file.is_file():
            continue
        lines = override_file.read_text(encoding="utf-8").splitlines()
        changed = False
        out = []
        for line in lines:
            if line.startswith("filesystems="):
                entries = [entry for entry in line.split("=", 1)[1].split(";") if entry]
                filtered = [entry for entry in entries if entry not in reserved_entries]
                if filtered != entries:
                    changed = True
                line = "filesystems=" + (";".join(filtered) + ";" if filtered else "")
            out.append(line)
        if changed:
            override_file.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")


def apply_flatpak_overrides(theme: str, size: int):
    if not shutil.which("flatpak"):
        return
    clean_flatpak_reserved_icon_overrides()
    cmd = [
        "flatpak", "override", "--user",
        f"--env=XCURSOR_THEME={theme}",
        f"--env=XCURSOR_SIZE={size}",
        f"--env=XCURSOR_PATH={HOME}/.local/share/icons:{HOME}/.icons",
    ]
    for icon_dir in (HOME / ".icons", HOME / ".local/share/icons"):
        if icon_dir.exists():
            cmd.append(f"--filesystem={icon_dir}:ro")
    run(cmd)


def main():
    parser = argparse.ArgumentParser(description="Synchronize cursor theme across Niri, GTK, KDE, XSettings, systemd/dbus and Flatpak.")
    parser.add_argument("--theme", default="breeze_cursors")
    parser.add_argument("--size", type=int, default=24)
    args = parser.parse_args()

    theme = args.theme
    size = args.size
    os.environ["XCURSOR_THEME"] = theme
    os.environ["XCURSOR_SIZE"] = str(size)
    os.environ["XCURSOR_PATH"] = f"{HOME}/.local/share/icons:{HOME}/.icons:/usr/share/icons"

    for gtk_dir in (
        HOME / ".config/gtk-3.0",
        HOME / ".config/gtk-4.0",
        HOME / ".config/niri/xdg-config/gtk-3.0",
        HOME / ".config/niri/xdg-config/gtk-4.0",
    ):
        settings = gtk_dir / "settings.ini"
        set_ini_key(settings, "gtk-cursor-theme-name", theme)
        set_ini_key(settings, "gtk-cursor-theme-size", str(size))

    for kde_file in (
        HOME / ".config/kcminputrc",
        HOME / ".config/niri/xdg-config/kcminputrc",
        HOME / ".config/niri/xdg-config/kdedefaults/kcminputrc",
    ):
        set_kde_key(kde_file, "Mouse", "cursorTheme", theme)
        set_kde_key(kde_file, "Mouse", "cursorSize", str(size))

    update_env_file(HOME / ".config/niri/env.sh", theme, size)
    update_niri_config(HOME / ".config/niri/config.kdl", theme, size)
    update_xsettings(HOME / ".config/xsettingsd/xsettingsd.conf", theme, size)
    ensure_user_icon_theme(theme)

    run(["gsettings", "set", "org.gnome.desktop.interface", "cursor-theme", theme])
    run(["gsettings", "set", "org.gnome.desktop.interface", "cursor-size", str(size)])
    run(["systemctl", "--user", "import-environment", "XCURSOR_THEME", "XCURSOR_SIZE", "XCURSOR_PATH"])
    run(["dbus-update-activation-environment", "--systemd", "XCURSOR_THEME", "XCURSOR_SIZE", "XCURSOR_PATH"])
    apply_flatpak_overrides(theme, size)

    run(["pkill", "-HUP", "xsettingsd"])
    print(f"Cursor theme synchronized: {theme} ({size}px)")


if __name__ == "__main__":
    main()
