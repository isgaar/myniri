#!/usr/bin/env python3
import sys
import os
import json
import re
import subprocess
from extract_color import extract_accent

DARK_PALETTE = {
    "bgMain": "#801a1a1a",
    "bgCard": "#232323",
    "bgTile": "#2a2a2a",
    "bgActive": "#172232",
    "border": "#3a3a3a",
    "textPri": "#f0eee8",
    "textSec": "#918f88",
    "danger": "#e06c6c",
    "warning": "#e67e22"
}

LIGHT_PALETTE = {
    "bgMain": "#80f5f5f7",
    "bgCard": "#ffffff",
    "bgTile": "#e3e3e6",
    "bgActive": "#d1d1d6",
    "border": "#d2d2d7",
    "textPri": "#1d1d1f",
    "textSec": "#86868b",
    "danger": "#e06c6c",
    "warning": "#e67e22"
}

def update_niri_wallpaper(wallpaper_path):
    # Save the wallpaper path in a central file
    wallpaper_file = os.path.expanduser("~/.config/niri/wallpaper.txt")
    os.makedirs(os.path.dirname(wallpaper_file), exist_ok=True)
    with open(wallpaper_file, "w", encoding="utf-8") as f:
        f.write(wallpaper_path)
    
    # Run the set_wallpaper script to apply it instantly
    set_wp_script = os.path.expanduser("~/scripts/set_wallpaper.sh")
    if os.path.exists(set_wp_script):
        subprocess.run([set_wp_script])
    return True

def update_mako_config(mode, accent, corners_enabled=True):
    config_path = os.path.expanduser("~/.config/mako/config")
    if not os.path.exists(config_path):
        return False
        
    with open(config_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        
    if isinstance(corners_enabled, bool):
        radius = 12 if corners_enabled else 0
    elif isinstance(corners_enabled, int):
        radius = corners_enabled
    elif isinstance(corners_enabled, str):
        if corners_enabled.isdigit():
            radius = int(corners_enabled)
        elif corners_enabled.lower() == "true":
            radius = 12
        else:
            radius = 0
    else:
        try:
            radius = int(corners_enabled)
        except Exception:
            radius = 12 if corners_enabled else 0
            
    colors = {
        "dark": {
            None: {
                "background-color": "#191919e6",
                "text-color": "#f0eee8",
                "border-color": "#ffffff1f",
                "progress-color": f"over {accent}55",
                "border-radius": str(radius)
            },
            "urgency=low": {
                "background-color": "#191919df",
                "text-color": "#f0eee8",
                "border-color": "#ffffff16"
            },
            "urgency=normal": {
                "background-color": "#191919e6",
                "text-color": "#f0eee8",
                "border-color": "#ffffff22"
            },
            "urgency=high": {
                "background-color": "#211a1ae8",
                "text-color": "#ffffff",
                "border-color": "#ffffff42"
            }
        },
        "light": {
            None: {
                "background-color": "#f5f5f7e6",
                "text-color": "#1d1d1f",
                "border-color": "#0000001f",
                "progress-color": f"over {accent}55",
                "border-radius": str(radius)
            },
            "urgency=low": {
                "background-color": "#f5f5f7df",
                "text-color": "#1d1d1f",
                "border-color": "#00000016"
            },
            "urgency=normal": {
                "background-color": "#f5f5f7e6",
                "text-color": "#1d1d1f",
                "border-color": "#00000022"
            },
            "urgency=high": {
                "background-color": "#fff0f0e8",
                "text-color": "#ff3b30",
                "border-color": "#ff3b3042"
            }
        }
    }
    
    current_section = None
    new_lines = []
    
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            current_section = stripped[1:-1].strip()
            new_lines.append(line)
        elif "=" in stripped:
            parts = stripped.split("=", 1)
            key = parts[0].strip()
            sec_colors = colors.get(mode, {}).get(current_section, {})
            if key in sec_colors:
                new_lines.append(f"{key}={sec_colors[key]}\n")
            else:
                new_lines.append(line)
        else:
            new_lines.append(line)
            
    with open(config_path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)
        
    subprocess.run(["makoctl", "reload"])
    return True

def get_current_gaps():
    effects_path = os.path.expanduser("~/.config/niri/effects.kdl")
    if os.path.exists(effects_path):
        try:
            with open(effects_path, "r", encoding="utf-8") as f:
                content = f.read()
            m = re.search(r'gaps\s+(\d+)', content)
            if m:
                return int(m.group(1))
        except Exception:
            pass
    return 12

def write_niri_effects(radius, blur_enabled, animations_enabled, blur_radius_val=7, accent="#5aa7de"):
    effects_path = os.path.expanduser("~/.config/niri/effects.kdl")
    gaps = get_current_gaps()
    
    # Clean corners input
    if isinstance(radius, bool):
        radius_val = 12 if radius else 0
    elif isinstance(radius, str):
        if radius.isdigit():
            radius_val = int(radius)
        elif radius.lower() == "true":
            radius_val = 12
        else:
            radius_val = 0
    else:
        try:
            radius_val = int(radius)
        except Exception:
            radius_val = 12
            
    lines = []
    lines.append("// ==============================================================================\n")
    lines.append("// NIRI EFFECTS CONFIGURATION - Módulo de Efectos Dinámicos\n")
    lines.append("// Generado automáticamente. No editar directamente.\n")
    lines.append("// ==============================================================================\n\n")
    
    # 1. Gaps and Shadows
    lines.append("layout {\n")
    lines.append(f"    gaps {gaps}\n\n")
    lines.append("    struts {\n")
    lines.append("        left 12\n")
    lines.append("        right 12\n")
    lines.append("        bottom 12\n")
    lines.append("        top 12\n")
    lines.append("    }\n\n")
    
    lines.append("    focus-ring {\n")
    lines.append("        width 2\n")
    lines.append(f"        active-color \"{accent}\"\n")
    lines.append("        inactive-color \"#50505080\"\n")
    lines.append("    }\n\n")
    
    lines.append("    border {\n")
    lines.append("        off\n")
    lines.append("    }\n\n")
    
    if radius_val > 0:
        lines.append("    shadow {\n")
        lines.append("        on\n")
        lines.append("        softness 10\n")
        lines.append("        spread 0\n")
        lines.append("        offset x=0 y=4\n")
        lines.append("        color \"#0000003f\"\n")
        lines.append("    }\n")
    else:
        lines.append("    shadow {\n")
        lines.append("        off\n")
        lines.append("    }\n")
    lines.append("}\n\n")
    
    # 2. Window Corners
    lines.append("window-rule {\n")
    lines.append(f"    geometry-corner-radius {radius_val}\n")
    lines.append("    clip-to-geometry true\n")
    lines.append("}\n\n")
    
    # 3. Layer Corners (Quickshell, Mako)
    if radius_val > 0:
        lines.append("layer-rule {\n")
        lines.append("    match namespace=\"quickshell\"\n")
        lines.append(f"    geometry-corner-radius {radius_val}\n")
        lines.append("}\n")
        lines.append("layer-rule {\n")
        lines.append("    match namespace=\"mako\"\n")
        lines.append(f"    geometry-corner-radius {radius_val}\n")
        lines.append("}\n\n")
        
    # 4. Blur block
    if blur_enabled:
        # Map blur radius to offset parameter
        offset_val = float(blur_radius_val) / 2.0
        lines.append("blur {\n")
        lines.append("    passes 3\n")
        lines.append(f"    offset {offset_val:.1f}\n")
        lines.append("}\n\n")
        
        lines.append("window-rule {\n")
        lines.append("//    background-effect {\n")
        lines.append("//        blur\n")
        lines.append("//    }\n")
        lines.append("}\n\n")
        
        for ns in ["^waybar$", "^quickshell$", "^quickshell-topbar$", "^mako$"]:
            lines.append("layer-rule {\n")
            lines.append(f"    match namespace=\"{ns}\"\n")
            lines.append("    background-effect {\n")
            lines.append("        blur true\n")
            lines.append("        xray false\n")
            lines.append("    }\n")
            lines.append("}\n\n")
            
    with open(effects_path, "w", encoding="utf-8") as f:
        f.writelines(lines)
        
    # Reload Niri config
    subprocess.run(["niri", "msg", "action", "load-config-file"])

def update_theme_json(accent=None, animations_enabled=None, mode=None, corners_enabled=None, blur_enabled=None, blur_radius=None):
    theme_path = os.path.expanduser("~/.config/quickshell/unified/theme.json")
    data = {}
    
    if os.path.exists(theme_path):
        try:
            with open(theme_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            pass
            
    current_mode = mode if mode else data.get("theme_mode", "dark")
    data["theme_mode"] = current_mode
    
    palette = LIGHT_PALETTE if current_mode == "light" else DARK_PALETTE
    for k, v in palette.items():
        data[k] = v
        
    if "animationsEnabled" not in data:
        data["animationsEnabled"] = True
    if "animationDuration" not in data:
        data["animationDuration"] = 250
    if "cornersEnabled" not in data:
        data["cornersEnabled"] = True
    if "cornerRadius" not in data:
        data["cornerRadius"] = 12
    if "blurEnabled" not in data:
        data["blurEnabled"] = True
    if "blurRadius" not in data:
        data["blurRadius"] = 7
        
    if accent:
        data["accent"] = accent
        data["accentWf"] = accent
        data["accentBt"] = accent
    elif "accent" not in data:
        data["accent"] = "#5aa7de"
        data["accentWf"] = "#4a9fd4"
        data["accentBt"] = "#7c6fc4"
        
    if animations_enabled is not None:
        data["animationsEnabled"] = (animations_enabled.lower() == "true")
    if corners_enabled is not None:
        if corners_enabled.lower() in ["true", "false"]:
            data["cornersEnabled"] = (corners_enabled.lower() == "true")
            if data["cornersEnabled"]:
                if "cornerRadius" not in data or data["cornerRadius"] == 0:
                    data["cornerRadius"] = 12
            else:
                data["cornerRadius"] = 0
        elif corners_enabled.isdigit():
            val = int(corners_enabled)
            data["cornerRadius"] = val
            data["cornersEnabled"] = (val > 0)
    if blur_enabled is not None:
        data["blurEnabled"] = (blur_enabled.lower() == "true")
    if blur_radius is not None:
        try:
            val = int(blur_radius)
            data["blurRadius"] = val
        except Exception:
            pass
        
    with open(theme_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)
        
    subprocess.run(["qs", "ipc", "-c", "unified", "call", "theme", "reload"])

    accent_val = data.get("accent", "#5aa7de")
    anim_val = data.get("animationsEnabled", True)
    corn_val = data.get("cornerRadius", 12) if data.get("cornersEnabled", True) else 0
    blur_val = data.get("blurEnabled", True)
    blur_rad_val = data.get("blurRadius", 7)
    
    update_mako_config(current_mode, accent_val, corn_val)
    update_waybar_css(accent_val, current_mode, corn_val, anim_val)
    write_niri_effects(corn_val, blur_val, anim_val, blur_rad_val, accent_val)

def get_contrast_color(hex_color):
    hex_color = hex_color.lstrip('#')
    if len(hex_color) != 6:
        return "#ffffff"
    try:
        r = int(hex_color[0:2], 16) / 255.0
        g = int(hex_color[2:4], 16) / 255.0
        b = int(hex_color[4:6], 16) / 255.0
        luminance = 0.299 * r + 0.587 * g + 0.114 * b
        return "#111317" if luminance > 0.6 else "#ffffff"
    except Exception:
        return "#ffffff"

def update_waybar_css(accent, mode="dark", corners_enabled=True, animations_enabled=True):
    contrast = get_contrast_color(accent)
    css_path = os.path.expanduser("~/.config/waybar/style-accent.css")
    
    with open(css_path, "w", encoding="utf-8") as f:
        f.write(f"@define-color accent {accent};\n")
        f.write(f"@define-color accent-contrast {contrast};\n")
        
        if mode == "light":
            f.write("@define-color bar-bg rgba(245, 245, 247, 0.82);\n")
            f.write("@define-color text-pri #1d1d1f;\n")
            f.write("@define-color text-sec rgba(29, 29, 31, 0.54);\n")
            f.write("@define-color item-bg rgba(0, 0, 0, 0.06);\n")
            f.write("@define-color item-border rgba(0, 0, 0, 0.06);\n")
            f.write("@define-color item-hover rgba(0, 0, 0, 0.1);\n")
            f.write("@define-color tooltip-bg rgba(255, 255, 255, 0.96);\n")
        else:
            f.write("@define-color bar-bg rgba(25, 25, 25, 0.78);\n")
            f.write("@define-color text-pri #f0eee8;\n")
            f.write("@define-color text-sec rgba(240, 238, 232, 0.54);\n")
            f.write("@define-color item-bg rgba(255, 255, 255, 0.08);\n")
            f.write("@define-color item-border rgba(255, 255, 255, 0.08);\n")
            f.write("@define-color item-hover rgba(255, 255, 255, 0.14);\n")
            f.write("@define-color tooltip-bg rgba(32, 32, 32, 0.94);\n")
            
    subprocess.run(["pkill", "-USR2", "waybar"])

def main():
    if len(sys.argv) < 3:
        print("Usage: update_settings.py <option> <value>")
        sys.exit(1)
        
    option = sys.argv[1]
    value = sys.argv[2]
    
    if option == "--wallpaper":
        resolved_path = os.path.abspath(os.path.expanduser(value))
        if os.path.exists(resolved_path):
            update_niri_wallpaper(resolved_path)
            
            # Check if auto-extraction is active
            theme_path = os.path.expanduser("~/.config/quickshell/unified/theme.json")
            auto_extract = False
            theme_mode = "dark"
            if os.path.exists(theme_path):
                try:
                    with open(theme_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        theme_mode = data.get("theme_mode", "dark")
                        if data.get("accent_mode") == "auto":
                            auto_extract = True
                except Exception:
                    pass
            
            if auto_extract:
                extracted = extract_accent(resolved_path)
                update_theme_json(accent=extracted, mode=theme_mode)
        else:
            print(f"Error: Wallpaper path {resolved_path} does not exist", file=sys.stderr)
            sys.exit(1)
            
    elif option == "--accent":
        accent_color = value
        theme_path = os.path.expanduser("~/.config/quickshell/unified/theme.json")
        data = {}
        theme_mode = "dark"
        if os.path.exists(theme_path):
            try:
                with open(theme_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    theme_mode = data.get("theme_mode", "dark")
            except Exception:
                pass
        
        if accent_color.lower() == "auto":
            data["accent_mode"] = "auto"
            wallpaper_file = os.path.expanduser("~/.config/niri/wallpaper.txt")
            wallpaper = None
            if os.path.exists(wallpaper_file):
                with open(wallpaper_file, "r") as f:
                    wallpaper = f.read().strip()
            if wallpaper and os.path.exists(wallpaper):
                accent_color = extract_accent(wallpaper)
            else:
                accent_color = "#5aa7de"
        else:
            data["accent_mode"] = "manual"
            
        with open(theme_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
            
        update_theme_json(accent=accent_color, mode=theme_mode)
        
    elif option == "--mode":
        theme_mode = value.lower()
        if theme_mode not in ["dark", "light"]:
            print(f"Error: Invalid mode {theme_mode}", file=sys.stderr)
            sys.exit(1)
            
        update_theme_json(mode=theme_mode)
        
    elif option == "--animations":
        update_theme_json(animations_enabled=value)
        
    elif option == "--corners":
        update_theme_json(corners_enabled=value)
        
    elif option == "--blur":
        update_theme_json(blur_enabled=value)
        
    elif option == "--blur-radius":
        update_theme_json(blur_radius=value)

    elif option == "--gaps":
        if len(sys.argv) >= 4:
            inner = sys.argv[2]
            effects_path = os.path.expanduser("~/.config/niri/effects.kdl")
            if os.path.exists(effects_path):
                with open(effects_path, "r") as f:
                    content = f.read()
                content = re.sub(r"gaps\s+\d+", f"gaps {inner}", content)
                with open(effects_path, "w") as f:
                    f.write(content)
                subprocess.run(["niri", "msg", "action", "load-config-file"])
        else:
            print("Error: --gaps requires inner and outer values", file=sys.stderr)
        
    else:
        print(f"Unknown option: {option}", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
