#!/bin/bash
makoctl dismiss -a 2>/dev/null
killall mako 2>/dev/null
nohup mako >/dev/null 2>&1 &
disown
