#!/usr/bin/env python3
import re
import json
import os

CONFIG_PATH = os.path.expanduser("~/.config/niri/config.kdl")

DESC_MAP = {
    "close-window": "Cerrar ventana activa",
    "quit": "Salir de Niri",
    "toggle-window-floating": "Alternar ventana flotante",
    "maximize-column": "Maximizar columna",
    "focus-column-left": "Enfocar columna izquierda",
    "focus-column-right": "Enfocar columna derecha",
    "focus-window-or-workspace-up": "Enfocar ventana/espacio arriba",
    "focus-window-or-workspace-down": "Enfocar ventana/espacio abajo",
    "move-column-left": "Mover columna a la izquierda",
    "move-column-right": "Mover columna a la derecha",
    "move-window-up-or-to-workspace-up": "Mover ventana arriba",
    "move-window-down-or-to-workspace-down": "Mover ventana abajo",
    "reload-config": "Recargar configuración niri",
}

CATEGORY_RULES = [
    ("Sistema y Ventanas", ["close-window", "quit", "toggle-window-floating",
     "maximize-column", "focus-column", "focus-window", "move-column",
     "move-window", "reload-config", "switch-focus", "consume-window",
     "move-to-monitor", "move-workspace-to-monitor"]),
    ("Aplicaciones", ["spawn", "launcher"]),
    ("Escritorios Virtuales", ["focus-workspace", "move-column-to-workspace",
     "move-workspace"]),
    ("Capturas y Utilidades", ["captur", "grim", "slurp", "screenshot", "Print"]),
    ("Audio y Brillo", ["pactl", "wpctl", "brightnessctl", "audio", "volume",
     "mic", "brillo", "XF86Audio", "XF86MonBrightness"]),
]

ICONS = {
    "Sistema y Ventanas": "\uf013",
    "Aplicaciones": "\uf009",
    "Escritorios Virtuales": "\uf24d",
    "Capturas y Utilidades": "\uf030",
    "Audio y Brillo": "\uf028",
}

def extract_binds_block(content):
    """Extract the content of the binds {} block using brace counting."""
    start = content.find("binds {")
    if start == -1:
        start = content.find("binds{")
    if start == -1:
        return ""
    
    start = content.index("{", start) + 1
    depth = 1
    pos = start
    while pos < len(content) and depth > 0:
        if content[pos] == "{":
            depth += 1
        elif content[pos] == "}":
            depth -= 1
        pos += 1
    
    if depth == 0:
        return content[start:pos-1]
    return ""

def parse_binding(line):
    """Parse a single binding line like: Mod+Q { close-window; }"""
    line = line.strip()
    if not line or line.startswith("//"):
        return None
    
    # Match: KeyCombination { action ... }
    m = re.match(r'(\S+)\s*\{', line)
    if not m:
        return None
    
    key_combo = m.group(1)
    
    # Extract action - everything between { and }
    brace_start = line.index("{")
    brace_end = line.rindex("}")
    action_text = line[brace_start+1:brace_end].strip().rstrip(";")
    
    return key_combo, action_text

def format_action(action_text):
    """Convert niri action to human-readable description."""
    action_text = action_text.strip()
    
    # Check exact matches
    if action_text in DESC_MAP:
        return DESC_MAP[action_text]
    
    # spawn actions
    if action_text.startswith("spawn "):
        parts = action_text.split()
        if len(parts) >= 3 and parts[1] == '"honey"':
            app = parts[2].strip('"')
            name_map = {
                "kitty": "Terminal (Kitty)",
                "/opt/zen/zen": "Navegador (Zen)",
                "dolphin": "Explorador (Dolphin)",
                "mako": "Notificaciones (Mako)",
                "qs": "Panel Quickshell",
            }
            return "Abrir " + name_map.get(app, app)
        elif len(parts) >= 2:
            app = parts[1].strip('"')
            return "Ejecutar " + app
    
    # Audio
    if "pactl" in action_text or "wpctl" in action_text:
        if "mute" in action_text:
            return "Silenciar/activar audio"
        if "lower" in action_text or "5%-" in action_text:
            return "Bajar volumen"
        if "raise" in action_text or "5%+" in action_text:
            return "Subir volumen"
        if "source" in action_text or "mic" in action_text:
            return "Silenciar micrófono"
        return "Control de audio"
    
    # Brightness
    if "brightnessctl" in action_text:
        if "5%-" in action_text:
            return "Bajar brillo"
        if "5%+" in action_text:
            return "Subir brillo"
        return "Control de brillo"
    
    # Screenshot
    if "grim" in action_text or "slurp" in action_text:
        if "slurp" in action_text:
            return "Capturar área"
        if "focused-window" in action_text or "ventana activa" in action_text.lower():
            return "Capturar ventana activa"
        if "output" in action_text:
            return "Capturar monitor"
        return "Capturar pantalla"
    
    # Focus/move with numbers
    if "focus-workspace" in action_text:
        parts = action_text.split()
        if len(parts) >= 2 and parts[1].isdigit():
            return f"Espacio de trabajo {parts[1]}"
        if "down" in action_text:
            return "Siguiente espacio"
        if "up" in action_text:
            return "Espacio anterior"
        return "Enfocar espacio"
    
    if "move-column-to-workspace" in action_text:
        parts = action_text.split()
        if len(parts) >= 2 and parts[1].isdigit():
            return f"Mover columna al espacio {parts[1]}"
        return "Mover a espacio"
    
    if "move-workspace" in action_text:
        if "down" in action_text:
            return "Mover espacio abajo"
        if "up" in action_text:
            return "Mover espacio arriba"
        return "Mover espacio"
    
    if "move-window-to-monitor" in action_text:
        return "Mover ventana a otro monitor"
    
    if "move-column-to-monitor" in action_text:
        return "Mover columna a otro monitor"
    
    if "switch-focus-between-floating-and-tiling" in action_text:
        return "Alternar foco flotante/teselado"
    
    if "consume-window-into-column" in action_text:
        return "Consumir ventana en columna"
    
    if action_text.startswith("qs") and "ipc" in action_text:
        if "call" in action_text:
            parts = action_text.split()
            for i, p in enumerate(parts):
                if p == "call" and i + 1 < len(parts):
                    target = parts[i+1]
                    if target == "launcher":
                        return "Abrir lanzador"
                    elif target == "settings":
                        return "Abrir configuración"
                    elif target == "shortcuts":
                        return "Ayuda de atajos"
                    elif target == "panel":
                        return "Abrir panel"
                    elif target == "notifications":
                        return "Abrir notificaciones"
                    elif target == "power":
                        return "Menú de apagado"
                    elif target == "volume":
                        return "Menú de volumen"
                    elif target == "battery":
                        return "Estado de batería"
                    return f"Abrir {target}"
    
    # Generic fallback
    return action_text[:50]

def categorize(items):
    """Sort bindings into categories."""
    result = []
    used = set()
    
    for cat_name, keywords in CATEGORY_RULES:
        cat_items = []
        remaining = []
        for item in items:
            key = item["key"]
            if key in used:
                continue
            action_lower = item["action"].lower()
            matched = False
            for kw in keywords:
                if kw.lower() in action_lower:
                    matched = True
                    break
            if matched:
                used.add(key)
                cat_items.append(item)
            else:
                remaining.append(item)
        
        if cat_items:
            result.append({
                "name": cat_name,
                "icon": ICONS.get(cat_name, "\uf085"),
                "items": [
                    {"desc": item["desc"], "keys": item["key"].replace("+", " + ").split()}
                    for item in cat_items
                ],
            })
        items = remaining
    
    # Uncategorized items
    if items:
        result.append({
            "name": "Otros",
            "icon": "\uf085",
            "items": [
                {"desc": item["desc"], "keys": item["key"].replace("+", " + ").split()}
                for item in items
            ],
        })
    
    return result

def main():
    # Hardcoded fallback
    fallback = [
        {"name": "Sistema y Ventanas", "icon": "\uf013", "items": [
            {"desc": "Cerrar ventana activa", "keys": ["Super", "Q"]},
            {"desc": "Ventana flotante", "keys": ["Super", "Shift", "F"]},
            {"desc": "Recargar configuración", "keys": ["Super", "Shift", "C"]},
            {"desc": "Ayuda de atajos", "keys": ["Ctrl", "Super", "H"]},
            {"desc": "Salir de Niri", "keys": ["Super", "Shift", "Backspace"]},
        ]},
        {"name": "Aplicaciones", "icon": "\uf009", "items": [
            {"desc": "Abrir Terminal (Kitty)", "keys": ["Super", "Return"]},
            {"desc": "Lanzador de Apps", "keys": ["Ctrl", "Space"]},
            {"desc": "Navegador (Zen)", "keys": ["Super", "Z"]},
            {"desc": "Explorador (Dolphin)", "keys": ["Super", "E"]},
        ]},
        {"name": "Escritorios Virtuales", "icon": "\uf24d", "items": [
            {"desc": "Siguiente escritorio", "keys": ["Super", "Ctrl", "Right"]},
            {"desc": "Escritorio anterior", "keys": ["Super", "Ctrl", "Left"]},
            {"desc": "Ir al escritorio [1..10]", "keys": ["Super", "[1..10]"]},
            {"desc": "Mover ventana a [1..10]", "keys": ["Super", "Shift", "[1..10]"]},
        ]},
        {"name": "Capturas y Utilidades", "icon": "\uf030", "items": [
            {"desc": "Capturar pantalla", "keys": ["Print"]},
            {"desc": "Capturar área", "keys": ["Shift", "Print"]},
            {"desc": "Capturar ventana", "keys": ["Ctrl", "Print"]},
        ]},
        {"name": "Audio y Brillo", "icon": "\uf028", "items": [
            {"desc": "Subir volumen", "keys": ["XF86AudioRaiseVolume"]},
            {"desc": "Bajar volumen", "keys": ["XF86AudioLowerVolume"]},
            {"desc": "Silenciar audio", "keys": ["XF86AudioMute"]},
            {"desc": "Silenciar micrófono", "keys": ["XF86AudioMicMute"]},
            {"desc": "Subir brillo", "keys": ["XF86MonBrightnessUp"]},
            {"desc": "Bajar brillo", "keys": ["XF86MonBrightnessDown"]},
        ]},
    ]
    
    if not os.path.exists(CONFIG_PATH):
        print(json.dumps(fallback))
        return
    
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        content = f.read()
    
    binds_text = extract_binds_block(content)
    if not binds_text:
        print(json.dumps(fallback))
        return
    
    # Parse each line
    raw_items = []
    for line in binds_text.split(";"):
        line = line.strip()
        if not line:
            continue
        parsed = parse_binding(line)
        if parsed:
            key, action = parsed
            desc = format_action(action)
            raw_items.append({"key": key, "action": action, "desc": desc})
    
    if not raw_items:
        print(json.dumps(fallback))
        return
    
    categories = categorize(raw_items)
    print(json.dumps(categories))

if __name__ == "__main__":
    main()
