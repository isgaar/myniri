#!/bin/bash
MAC="$1"

bluetoothctl scan on &
sleep 2
kill $! 2>/dev/null || bluetoothctl scan off

if bluetoothctl pair "$MAC" > /dev/null 2>&1; then
    echo "Emparejado"
fi

if bluetoothctl connect "$MAC" > /dev/null 2>&1; then
    notify-send "Bluetooth" "Conectado al dispositivo" -u low
else
    notify-send "Bluetooth" "Fallo al conectar" -u normal
fi
