#!/usr/bin/env python3
import json
import subprocess
import sys
import argparse
import time
import os
import re
import signal

MONITORS_CONFIG_PATH = os.path.expanduser("~/.config/niri/monitors.json")
LOG_FILE_PATH = os.path.expanduser("~/.config/niri/monitor_restore.log")
SATURATION_HELPER_PATH = os.path.expanduser("~/.local/bin/niri-saturation-control")
SATURATION_RUNTIME_DIR = os.path.expanduser("~/.cache/niri-saturation")
SATURATION_LOG_FILE = os.path.expanduser("~/.config/niri/saturation.log")
QUICKSHELL_RESTART_COOLDOWN = 8.0

def log_warning(message):
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        os.makedirs(os.path.dirname(LOG_FILE_PATH), exist_ok=True)
        with open(LOG_FILE_PATH, "a") as f:
            f.write(f"[{timestamp}] {message}\n")
    except Exception:
        pass

def run_niri(args_list):
    try:
        cmd = ["niri", "msg"] + args_list
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            log_warning(f"niri msg {' '.join(args_list)} failed: {result.stderr.strip()}")
        return result.returncode == 0
    except Exception as e:
        log_warning(f"Failed to run niri msg {' '.join(args_list)}: {e}")
        return False

def load_saved_config():
    if os.path.exists(MONITORS_CONFIG_PATH):
        try:
            with open(MONITORS_CONFIG_PATH, "r") as f:
                return json.load(f)
        except Exception as e:
            log_warning(f"Error loading monitor config from file: {e}")
    return {}

def save_config(config):
    try:
        os.makedirs(os.path.dirname(MONITORS_CONFIG_PATH), exist_ok=True)
        tmp_path = MONITORS_CONFIG_PATH + ".tmp"
        with open(tmp_path, "w") as f:
            json.dump(config, f, indent=4)
            f.write("\n")
        os.replace(tmp_path, MONITORS_CONFIG_PATH)
    except Exception as e:
        sys.stderr.write(f"Error saving monitor config: {e}\n")
        log_warning(f"Error saving monitor config: {e}")

def update_saved_monitor(name, **kwargs):
    config = load_saved_config()
    if name not in config:
        config[name] = {}
    config[name].update(kwargs)
    save_config(config)

def safe_output_id(name):
    return re.sub(r"[^A-Za-z0-9_.-]", "_", name)

def saturation_pid_path(name):
    return os.path.join(SATURATION_RUNTIME_DIR, f"{safe_output_id(name)}.pid")

def saturation_backend_available():
    if not os.path.exists(SATURATION_HELPER_PATH):
        return False
    try:
        result = subprocess.run(
            ["wayland-info"],
            capture_output=True,
            text=True,
            timeout=2
        )
        return result.returncode == 0 and "zwlr_gamma_control_manager_v1" in result.stdout
    except Exception as e:
        log_warning(f"Error checking saturation backend: {e}")
        return False

def stop_saturation_helper(name):
    pid_file = saturation_pid_path(name)
    if not os.path.exists(pid_file):
        return
    try:
        with open(pid_file, "r") as f:
            pid = int(f.read().strip())
    except Exception:
        try:
            os.remove(pid_file)
        except Exception:
            pass
        return

    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmdline = f.read().decode("utf-8", "ignore")
        if "niri-saturation-control" not in cmdline or name not in cmdline:
            os.remove(pid_file)
            return
    except FileNotFoundError:
        try:
            os.remove(pid_file)
        except Exception:
            pass
        return
    except Exception as e:
        log_warning(f"Error checking saturation helper pid {pid}: {e}")
        return

    try:
        os.kill(pid, signal.SIGTERM)
        for _ in range(20):
            try:
                os.kill(pid, 0)
                time.sleep(0.05)
            except ProcessLookupError:
                break
        else:
            os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    except Exception as e:
        log_warning(f"Error stopping saturation helper for {name}: {e}")
    try:
        os.remove(pid_file)
    except Exception:
        pass

def start_saturation_helper(name, value):
    os.makedirs(SATURATION_RUNTIME_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(SATURATION_LOG_FILE), exist_ok=True)
    stop_saturation_helper(name)

    with open(SATURATION_LOG_FILE, "a") as log_file:
        proc = subprocess.Popen(
            [SATURATION_HELPER_PATH, name, str(value)],
            stdout=log_file,
            stderr=log_file,
            start_new_session=True
        )

    time.sleep(0.2)
    if proc.poll() is not None:
        raise RuntimeError(f"saturation helper exited with code {proc.returncode}")

    with open(saturation_pid_path(name), "w") as f:
        f.write(str(proc.pid))

def query_connected_outputs():
    try:
        result = subprocess.run(
            ["niri", "msg", "--json", "outputs"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return json.loads(result.stdout)
        else:
            log_warning(f"niri msg outputs failed with code {result.returncode}: {result.stderr.strip()}")
    except Exception as e:
        log_warning(f"Exception querying current outputs: {e}")
    return {}

def output_signature(outputs_dict):
    signature = []
    for name, out in sorted(outputs_dict.items()):
        logical = out.get("logical") or {}
        signature.append((
            name,
            bool(out.get("disabled", False)),
            logical.get("x"),
            logical.get("y"),
            logical.get("width"),
            logical.get("height"),
            logical.get("scale"),
            out.get("max_bpc")
        ))
    return tuple(signature)

def has_active_output(outputs_dict):
    for out in outputs_dict.values():
        if not out.get("disabled", False) and out.get("logical") is not None:
            return True
    return False

def restart_quickshell_unified():
    try:
        log_warning("Restarting Quickshell unified after monitor change")
        subprocess.run(
            ["honey", "qs", "kill", "-c", "unified", "--any-display"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5
        )
    except Exception as e:
        log_warning(f"Error killing Quickshell unified: {e}")

    try:
        subprocess.Popen(
            ["honey", "qs", "-c", "unified", "-d"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
    except Exception as e:
        log_warning(f"Error starting Quickshell unified: {e}")

def save_current_state_as_default():
    try:
        outputs_dict = query_connected_outputs()
        if not outputs_dict:
            return
        
        config = load_saved_config()
        
        # Mark existing configurations as physically not present/connected
        for name in config:
            config[name]["connected"] = False
            
        for name, out in outputs_dict.items():
            logical = out.get("logical")
            disabled = out.get("disabled", False)
            active = logical is not None and not disabled
            
            # Resolve current mode
            modes_raw = out.get("modes", [])
            current_mode_raw = out.get("current_mode")
            mode_data = None
            if active and modes_raw and current_mode_raw is not None:
                if isinstance(current_mode_raw, int) and 0 <= current_mode_raw < len(modes_raw):
                    m = modes_raw[current_mode_raw]
                    mode_data = {
                        "w": m.get("width", 0),
                        "h": m.get("height", 0),
                        "hz": m.get("refresh_rate", 60000)
                    }
                elif isinstance(current_mode_raw, dict):
                    mode_data = {
                        "w": current_mode_raw.get("width", 0),
                        "h": current_mode_raw.get("height", 0),
                        "hz": current_mode_raw.get("refresh_rate", 60000)
                    }
            
            if name not in config:
                config[name] = {}
                
            config[name].update({
                "active": active,
                "connected": True,
                "x": logical.get("x", 0) if logical else 0,
                "y": logical.get("y", 0) if logical else 0
            })
            if mode_data:
                config[name]["mode"] = mode_data
            if active:
                logical_scale = logical.get("scale") if logical else None
                if logical_scale is not None:
                    config[name]["scale"] = logical_scale
                if out.get("max_bpc") is not None:
                    config[name]["max_bpc"] = out.get("max_bpc")
                
        save_config(config)
    except Exception as e:
        sys.stderr.write(f"Error saving current state: {e}\n")
        log_warning(f"Error saving current state: {e}")

def restore_monitors():
    log_warning("Executing restore_monitors()")
    connected_outputs = query_connected_outputs()
    if not connected_outputs:
        log_warning("No connected outputs detected from Niri. Restoring aborted.")
        return

    if not os.path.exists(MONITORS_CONFIG_PATH):
        log_warning("Config file monitors.json not found. Initializing with current state.")
        save_current_state_as_default()
        return

    config = load_saved_config()
    if not config:
        log_warning("Empty monitors.json. Initializing with current state.")
        save_current_state_as_default()
        return

    # Identify if any external monitors are connected
    external_connected = [name for name in connected_outputs if name != "eDP-1"]

    # 1. Turn on/off outputs first
    for name in connected_outputs:
        data = config.get(name, {})
        # Fallback: if eDP-1 is connected, it must ALWAYS be on
        if name == "eDP-1":
            active = True
        else:
            active = data.get("active", True)
            
        cmd = ["niri", "msg", "output", name, "on" if active else "off"]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0:
            log_warning(f"Error setting output {name} to {'on' if active else 'off'}: {res.stderr.strip()}")
            
    # Give Niri a tiny moment to register turned-on outputs
    time.sleep(0.2)
    
    # Re-query connected outputs to make sure they are registered
    connected_outputs = query_connected_outputs()
    
    # 2. Set modes and positions for active outputs
    for name in connected_outputs:
        data = config.get(name, {})
        if name == "eDP-1":
            active = True
        else:
            active = data.get("active", True)
            
        if not active:
            continue

        max_bpc = data.get("max_bpc")
        if max_bpc:
            res = subprocess.run(
                ["niri", "msg", "output", name, "max-bpc", str(max_bpc)],
                capture_output=True,
                text=True
            )
            if res.returncode != 0:
                log_warning(f"Error setting max-bpc for {name} to {max_bpc}: {res.stderr.strip()}")
            
        # Set mode
        mode = data.get("mode")
        if mode:
            w = mode.get("w")
            h = mode.get("h")
            hz = mode.get("hz")
            if w and h:
                try:
                    hz_val = float(hz)
                    if hz_val > 1000:
                        hz_val = hz_val / 1000.0
                    mode_str = f"{w}x{h}@{hz_val:.3f}"
                except Exception:
                    mode_str = f"{w}x{h}"
                cmd = ["niri", "msg", "output", name, "mode", mode_str]
                res = subprocess.run(cmd, capture_output=True, text=True)
                if res.returncode != 0:
                    log_warning(f"Error setting mode for {name} to {mode_str}: {res.stderr.strip()}")

        scale = data.get("scale")
        if scale:
            res = subprocess.run(
                ["niri", "msg", "output", name, "scale", str(scale)],
                capture_output=True,
                text=True
            )
            if res.returncode != 0:
                log_warning(f"Error setting scale for {name} to {scale}: {res.stderr.strip()}")
                
        # Set position
        # Fallback: if no external monitors are connected, eDP-1 is at (0, 0)
        if name == "eDP-1" and not external_connected:
            x, y = 0, 0
        else:
            x = data.get("x")
            y = data.get("y")
            
        if x is not None and y is not None:
            cmd = ["niri", "msg", "output", name, "position", "set", "--", str(x), str(y)]
            res = subprocess.run(cmd, capture_output=True, text=True)
            if res.returncode != 0:
                log_warning(f"Error setting position for {name} to ({x}, {y}): {res.stderr.strip()}")

        saturation = int(data.get("saturation", 0) or 0)
        if saturation > 0 and saturation_backend_available():
            try:
                start_saturation_helper(name, saturation)
            except Exception as e:
                log_warning(f"Error restoring saturation for {name}: {e}")

    # Apply primary monitor configuration & notify Quickshell
    get_outputs()

def get_outputs():
    try:
        primary_file = os.path.expanduser("~/.config/quickshell/primary_monitor.txt")

        result = subprocess.run(
            ["niri", "msg", "--json", "outputs"],
            capture_output=True, text=True, timeout=5
        )
        outputs_dict = json.loads(result.stdout)

        active_outputs = []
        for name, out in outputs_dict.items():
            logical = out.get("logical")
            disabled = out.get("disabled", False)
            if not disabled and logical is not None:
                active_outputs.append(name)

        # Check if we have a saved primary monitor that is currently active
        saved_primary = None
        if os.path.exists(primary_file):
            try:
                with open(primary_file, "r") as f:
                    saved_primary = f.read().strip()
            except Exception:
                pass

        effective_primary = None
        if saved_primary in active_outputs:
            effective_primary = saved_primary
        else:
            # Fallback to focused active monitor
            for name in active_outputs:
                if outputs_dict[name].get("is_focused"):
                    effective_primary = name
                    break
            # Fallback to the first active monitor
            if not effective_primary and active_outputs:
                effective_primary = active_outputs[0]

        if effective_primary and effective_primary != saved_primary:
            os.makedirs(os.path.dirname(primary_file), exist_ok=True)
            with open(primary_file, "w") as f:
                f.write(effective_primary)
            try:
                subprocess.run([
                    "qs", "ipc", "-p",
                    os.path.expanduser("~/.config/quickshell/unified/shell.qml"),
                    "call", "primary_monitor", "update"
                ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

        formatted = []
        saved_config = load_saved_config()
        saturation_supported = saturation_backend_available()
        for name, out in outputs_dict.items():
            modes_raw = out.get("modes", [])

            # Resolve current mode using the original unsorted list
            current_mode_raw = out.get("current_mode")
            current_mode_obj = None
            if isinstance(current_mode_raw, int) and 0 <= current_mode_raw < len(modes_raw):
                current_mode_obj = modes_raw[current_mode_raw].copy() if isinstance(modes_raw[current_mode_raw], dict) else modes_raw[current_mode_raw]
            elif isinstance(current_mode_raw, dict):
                current_mode_obj = current_mode_raw

            # Now sort modes_raw for QML display
            modes_raw.sort(key=lambda m: (m.get("width", 0), m.get("height", 0), m.get("refresh_rate", 0)), reverse=True)

            qml_modes = []
            for m in modes_raw:
                w = m.get("width", 0)
                h = m.get("height", 0)
                refresh_hz = m.get("refresh_rate", 60000) / 1000.0
                qml_modes.append({
                    "label": f"{w}x{h} @ {refresh_hz:.3f}Hz",
                    "w": w, "h": h,
                    "hz": m.get("refresh_rate", 60000)
                })

            logical_raw = out.get("logical")
            active = logical_raw is not None and not out.get("disabled", False)

            logical = logical_raw if logical_raw is not None else {}
            rect = {
                "x": logical.get("x", 0),
                "y": logical.get("y", 0),
                "width": logical.get("width", 0) if active else 0,
                "height": logical.get("height", 0) if active else 0
            }

            saved_output = saved_config.get(name, {})
            saved_max_bpc = saved_output.get("max_bpc")
            reported_max_bpc = out.get("max_bpc")
            effective_max_bpc = reported_max_bpc if reported_max_bpc is not None else saved_max_bpc
            if effective_max_bpc is None:
                effective_max_bpc = 8

            formatted.append({
                "name": name,
                "make": out.get("make", "Unknown"),
                "model": out.get("model", "Unknown"),
                "active": active,
                "dpms": active,
                "primary": name == effective_primary,
                "scale": logical.get("scale", 1.0) if active else 1.0,
                "max_bpc": int(effective_max_bpc),
                "max_bpc_applied": reported_max_bpc is not None,
                "hdr_supported": False,
                "hdr_enabled": False,
                "hdr_status": "Niri no expone un conmutador HDR para esta salida",
                "saturation": int(saved_config.get(name, {}).get("saturation", 0) or 0),
                "saturation_supported": active,
                "saturation_applied": saturation_supported and active,
                "saturation_status": "Ajuste por LUT gamma activo" if saturation_supported else "Valor guardado; falta instalar o habilitar el backend Wayland de saturación",
                "rect": rect,
                "current_mode": current_mode_obj or {},
                "modes": qml_modes
            })
        print(json.dumps(formatted))
    except Exception as e:
        log_warning(f"Error in get_outputs: {e}")
        print(json.dumps([]), file=sys.stderr)

def set_mode(name, w, h, hz):
    try:
        hz_val = float(hz)
        if hz_val > 1000:
            hz_val = hz_val / 1000.0
        mode_str = f"{w}x{h}@{hz_val:.3f}"
    except Exception:
        mode_str = f"{w}x{h}"
    run_niri(["output", name, "mode", mode_str])
    update_saved_monitor(name, mode={"w": int(w), "h": int(h), "hz": float(hz)})

def set_scale(name, scale):
    scale_str = str(scale).strip()
    if scale_str != "auto":
        scale_val = float(scale_str)
        if scale_val < 0.5 or scale_val > 4.0:
            raise ValueError("scale must be between 0.5 and 4.0")
        scale_str = f"{scale_val:.2f}".rstrip("0").rstrip(".")
    if run_niri(["output", name, "scale", scale_str]):
        update_saved_monitor(name, scale=scale_str)

def set_max_bpc(name, max_bpc):
    bpc = int(max_bpc)
    if bpc not in (6, 8, 10, 12, 14, 16):
        raise ValueError("max-bpc must be one of 6, 8, 10, 12, 14, 16")
    if run_niri(["output", name, "max-bpc", str(bpc)]):
        update_saved_monitor(name, max_bpc=bpc)

def set_saturation(name, saturation):
    value = int(round(float(saturation)))
    value = max(0, min(100, value))
    update_saved_monitor(name, saturation=value)
    if not saturation_backend_available():
        log_warning(f"Saturation backend is not available. Saved requested value for {name}: {value}")
        return

    if value == 0:
        stop_saturation_helper(name)
    else:
        start_saturation_helper(name, value)

def set_position(name, x, y):
    run_niri(["output", name, "position", "set", "--", str(x), str(y)])
    update_saved_monitor(name, x=int(x), y=int(y))

def toggle_output(name, enable):
    if not enable:
        try:
            subprocess.run(
                ["python3", "/home/ismael/scripts/move_workspaces_on_disable.py", name],
                capture_output=True, timeout=5
            )
        except Exception as e:
            log_warning(f"Error running move_workspaces_on_disable.py for {name}: {e}")
        update_saved_monitor(name, active=False)
        return
    run_niri(["output", name, "on"])
    update_saved_monitor(name, active=True)

def watch_monitors():
    log_warning("Starting monitor watcher daemon...")
    # Initial restore
    restore_monitors()
    
    last_signature = tuple()
    try:
        outputs = query_connected_outputs()
        last_signature = output_signature(outputs)
    except Exception:
        pass

    # Start event-stream process
    try:
        proc = subprocess.Popen(
            ["niri", "msg", "--json", "event-stream"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
    except Exception as e:
        log_warning(f"Failed to start niri event-stream: {e}. Falling back to pure polling.")
        proc = None

    last_check_time = 0
    last_quickshell_restart = 0
    
    while True:
        try:
            # If we have the event stream, block on reading a line
            if proc:
                line = proc.stdout.readline()
                if not line:
                    log_warning("Event stream closed. Restarting process...")
                    time.sleep(2.0)
                    proc = subprocess.Popen(
                        ["niri", "msg", "--json", "event-stream"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.DEVNULL,
                        text=True
                    )
                    continue
            else:
                # Fallback to pure polling: sleep for 2 seconds
                time.sleep(2.0)

            # Rate limit checks to once per 1.0 second to avoid spamming
            current_time = time.time()
            if current_time - last_check_time < 1.0:
                continue
            last_check_time = current_time

            # Query current outputs
            current_outputs = query_connected_outputs()
            if not current_outputs:
                continue

            current_signature = output_signature(current_outputs)

            if current_signature != last_signature:
                log_warning(f"Outputs changed! Previous: {last_signature}, Current: {current_signature}")
                
                # Apply restoration / layout configuration
                restore_monitors()

                current_outputs = query_connected_outputs()
                current_signature = output_signature(current_outputs)

                if has_active_output(current_outputs):
                    now = time.time()
                    if now - last_quickshell_restart >= QUICKSHELL_RESTART_COOLDOWN:
                        # Let Niri finish recreating layer-shell surfaces after output changes.
                        time.sleep(1.5)
                        restart_quickshell_unified()
                        last_quickshell_restart = time.time()
                    else:
                        log_warning("Skipping Quickshell restart due to cooldown")
                
                last_signature = current_signature
        except KeyboardInterrupt:
            break
        except Exception as e:
            log_warning(f"Error in watcher loop: {e}")
            time.sleep(2.0)

    if proc:
        try:
            proc.terminate()
        except Exception:
            pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manage Niri monitors")
    parser.add_argument("--list", action="store_true", help="List monitors as JSON")
    parser.add_argument("--mode", nargs=4, metavar=("NAME", "W", "H", "HZ"), help="Set monitor mode")
    parser.add_argument("--scale", nargs=2, metavar=("NAME", "SCALE"), help="Set output scale factor")
    parser.add_argument("--max-bpc", nargs=2, metavar=("NAME", "BPC"), help="Set output maximum bits per channel")
    parser.add_argument("--saturation", nargs=2, metavar=("NAME", "VALUE"), help="Set output color boost from 0 to 100")
    parser.add_argument("--position", nargs=3, metavar=("NAME", "X", "Y"), help="Set monitor position")
    parser.add_argument("--enable", metavar="NAME", help="Enable monitor")
    parser.add_argument("--disable", metavar="NAME", help="Disable monitor")
    parser.add_argument("--restore", action="store_true", help="Restore monitors position and mode from saved config")
    parser.add_argument("--watch", action="store_true", help="Watch for monitor hotplug events and restore configurations")

    args = parser.parse_args()

    if args.list:
        get_outputs()
    elif args.mode:
        set_mode(args.mode[0], args.mode[1], args.mode[2], args.mode[3])
        time.sleep(0.5)
    elif args.scale:
        set_scale(args.scale[0], args.scale[1])
        time.sleep(0.5)
    elif args.max_bpc:
        set_max_bpc(args.max_bpc[0], args.max_bpc[1])
        time.sleep(0.5)
    elif args.saturation:
        set_saturation(args.saturation[0], args.saturation[1])
        time.sleep(0.5)
    elif args.position:
        set_position(args.position[0], args.position[1], args.position[2])
        time.sleep(0.5)
    elif args.enable:
        toggle_output(args.enable, True)
        time.sleep(0.5)
    elif args.disable:
        toggle_output(args.disable, False)
        time.sleep(0.5)
    elif args.restore:
        restore_monitors()
        time.sleep(0.5)
    elif args.watch:
        watch_monitors()
    else:
        parser.print_help()
