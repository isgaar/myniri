#!/usr/bin/env python3
import json
import subprocess
import sys
import argparse
import time
import os

MONITORS_CONFIG_PATH = os.path.expanduser("~/.config/niri/monitors.json")
LOG_FILE_PATH = os.path.expanduser("~/.config/niri/monitor_restore.log")

def log_warning(message):
    try:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        os.makedirs(os.path.dirname(LOG_FILE_PATH), exist_ok=True)
        with open(LOG_FILE_PATH, "a") as f:
            f.write(f"[{timestamp}] {message}\n")
    except Exception:
        pass

def run_niri(args_list):
    try:
        cmd = ["niri", "msg"] + args_list
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            log_warning(f"niri msg {' '.join(args_list)} failed: {result.stderr.strip()}")
        return result.returncode == 0
    except Exception as e:
        log_warning(f"Failed to run niri msg {' '.join(args_list)}: {e}")
        return False

def load_saved_config():
    if os.path.exists(MONITORS_CONFIG_PATH):
        try:
            with open(MONITORS_CONFIG_PATH, "r") as f:
                return json.load(f)
        except Exception as e:
            log_warning(f"Error loading monitor config from file: {e}")
    return {}

def save_config(config):
    try:
        os.makedirs(os.path.dirname(MONITORS_CONFIG_PATH), exist_ok=True)
        with open(MONITORS_CONFIG_PATH, "w") as f:
            json.dump(config, f, indent=4)
    except Exception as e:
        sys.stderr.write(f"Error saving monitor config: {e}\n")
        log_warning(f"Error saving monitor config: {e}")

def update_saved_monitor(name, **kwargs):
    config = load_saved_config()
    if name not in config:
        config[name] = {}
    config[name].update(kwargs)
    save_config(config)

def query_connected_outputs():
    try:
        result = subprocess.run(
            ["niri", "msg", "--json", "outputs"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return json.loads(result.stdout)
        else:
            log_warning(f"niri msg outputs failed with code {result.returncode}: {result.stderr.strip()}")
    except Exception as e:
        log_warning(f"Exception querying current outputs: {e}")
    return {}

def save_current_state_as_default():
    try:
        outputs_dict = query_connected_outputs()
        if not outputs_dict:
            return
        
        config = load_saved_config()
        
        # Mark existing configurations as physically not present/connected
        for name in config:
            config[name]["connected"] = False
            
        for name, out in outputs_dict.items():
            logical = out.get("logical")
            disabled = out.get("disabled", False)
            active = logical is not None and not disabled
            
            # Resolve current mode
            modes_raw = out.get("modes", [])
            current_mode_raw = out.get("current_mode")
            mode_data = None
            if active and modes_raw and current_mode_raw is not None:
                if isinstance(current_mode_raw, int) and 0 <= current_mode_raw < len(modes_raw):
                    m = modes_raw[current_mode_raw]
                    mode_data = {
                        "w": m.get("width", 0),
                        "h": m.get("height", 0),
                        "hz": m.get("refresh_rate", 60000)
                    }
                elif isinstance(current_mode_raw, dict):
                    mode_data = {
                        "w": current_mode_raw.get("width", 0),
                        "h": current_mode_raw.get("height", 0),
                        "hz": current_mode_raw.get("refresh_rate", 60000)
                    }
            
            if name not in config:
                config[name] = {}
                
            config[name].update({
                "active": active,
                "connected": True,
                "x": logical.get("x", 0) if logical else 0,
                "y": logical.get("y", 0) if logical else 0
            })
            if mode_data:
                config[name]["mode"] = mode_data
                
        save_config(config)
    except Exception as e:
        sys.stderr.write(f"Error saving current state: {e}\n")
        log_warning(f"Error saving current state: {e}")

def restore_monitors():
    log_warning("Executing restore_monitors()")
    connected_outputs = query_connected_outputs()
    if not connected_outputs:
        log_warning("No connected outputs detected from Niri. Restoring aborted.")
        return

    if not os.path.exists(MONITORS_CONFIG_PATH):
        log_warning("Config file monitors.json not found. Initializing with current state.")
        save_current_state_as_default()
        return

    config = load_saved_config()
    if not config:
        log_warning("Empty monitors.json. Initializing with current state.")
        save_current_state_as_default()
        return

    # Identify if any external monitors are connected
    external_connected = [name for name in connected_outputs if name != "eDP-1"]

    # 1. Turn on/off outputs first
    for name in connected_outputs:
        data = config.get(name, {})
        # Fallback: if eDP-1 is connected, it must ALWAYS be on
        if name == "eDP-1":
            active = True
        else:
            active = data.get("active", True)
            
        cmd = ["niri", "msg", "output", name, "on" if active else "off"]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0:
            log_warning(f"Error setting output {name} to {'on' if active else 'off'}: {res.stderr.strip()}")
            
    # Give Niri a tiny moment to register turned-on outputs
    time.sleep(0.2)
    
    # Re-query connected outputs to make sure they are registered
    connected_outputs = query_connected_outputs()
    
    # 2. Set modes and positions for active outputs
    for name in connected_outputs:
        data = config.get(name, {})
        if name == "eDP-1":
            active = True
        else:
            active = data.get("active", True)
            
        if not active:
            continue
            
        # Set mode
        mode = data.get("mode")
        if mode:
            w = mode.get("w")
            h = mode.get("h")
            hz = mode.get("hz")
            if w and h:
                try:
                    hz_val = float(hz)
                    if hz_val > 1000:
                        hz_val = hz_val / 1000.0
                    mode_str = f"{w}x{h}@{hz_val:.3f}"
                except Exception:
                    mode_str = f"{w}x{h}"
                cmd = ["niri", "msg", "output", name, "mode", mode_str]
                res = subprocess.run(cmd, capture_output=True, text=True)
                if res.returncode != 0:
                    log_warning(f"Error setting mode for {name} to {mode_str}: {res.stderr.strip()}")
                
        # Set position
        # Fallback: if no external monitors are connected, eDP-1 is at (0, 0)
        if name == "eDP-1" and not external_connected:
            x, y = 0, 0
        else:
            x = data.get("x")
            y = data.get("y")
            
        if x is not None and y is not None:
            cmd = ["niri", "msg", "output", name, "position", "set", str(x), str(y)]
            res = subprocess.run(cmd, capture_output=True, text=True)
            if res.returncode != 0:
                log_warning(f"Error setting position for {name} to ({x}, {y}): {res.stderr.strip()}")

    # Apply primary monitor configuration & notify Quickshell
    get_outputs()

def get_outputs():
    try:
        primary_file = os.path.expanduser("~/.config/quickshell/primary_monitor.txt")

        result = subprocess.run(
            ["niri", "msg", "--json", "outputs"],
            capture_output=True, text=True, timeout=5
        )
        outputs_dict = json.loads(result.stdout)

        active_outputs = []
        for name, out in outputs_dict.items():
            logical = out.get("logical")
            disabled = out.get("disabled", False)
            if not disabled and logical is not None:
                active_outputs.append(name)

        # Check if we have a saved primary monitor that is currently active
        saved_primary = None
        if os.path.exists(primary_file):
            try:
                with open(primary_file, "r") as f:
                    saved_primary = f.read().strip()
            except Exception:
                pass

        effective_primary = None
        if saved_primary in active_outputs:
            effective_primary = saved_primary
        else:
            # Fallback to focused active monitor
            for name in active_outputs:
                if outputs_dict[name].get("is_focused"):
                    effective_primary = name
                    break
            # Fallback to the first active monitor
            if not effective_primary and active_outputs:
                effective_primary = active_outputs[0]

        if effective_primary and effective_primary != saved_primary:
            os.makedirs(os.path.dirname(primary_file), exist_ok=True)
            with open(primary_file, "w") as f:
                f.write(effective_primary)
            try:
                subprocess.run([
                    "qs", "ipc", "-p",
                    os.path.expanduser("~/.config/quickshell/unified/shell.qml"),
                    "call", "primary_monitor", "update"
                ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

        formatted = []
        for name, out in outputs_dict.items():
            modes_raw = out.get("modes", [])

            # Resolve current mode using the original unsorted list
            current_mode_raw = out.get("current_mode")
            current_mode_obj = None
            if isinstance(current_mode_raw, int) and 0 <= current_mode_raw < len(modes_raw):
                current_mode_obj = modes_raw[current_mode_raw].copy() if isinstance(modes_raw[current_mode_raw], dict) else modes_raw[current_mode_raw]
            elif isinstance(current_mode_raw, dict):
                current_mode_obj = current_mode_raw

            # Now sort modes_raw for QML display
            modes_raw.sort(key=lambda m: (m.get("width", 0), m.get("height", 0), m.get("refresh_rate", 0)), reverse=True)

            qml_modes = []
            for m in modes_raw:
                w = m.get("width", 0)
                h = m.get("height", 0)
                refresh_hz = m.get("refresh_rate", 60000) / 1000.0
                qml_modes.append({
                    "label": f"{w}x{h} @ {refresh_hz:.3f}Hz",
                    "w": w, "h": h,
                    "hz": m.get("refresh_rate", 60000)
                })

            logical_raw = out.get("logical")
            active = logical_raw is not None and not out.get("disabled", False)

            logical = logical_raw if logical_raw is not None else {}
            rect = {
                "x": logical.get("x", 0),
                "y": logical.get("y", 0),
                "width": logical.get("width", 0) if active else 0,
                "height": logical.get("height", 0) if active else 0
            }

            formatted.append({
                "name": name,
                "make": out.get("make", "Unknown"),
                "model": out.get("model", "Unknown"),
                "active": active,
                "dpms": active,
                "primary": name == effective_primary,
                "scale": out.get("scale", 1.0),
                "rect": rect,
                "current_mode": current_mode_obj or {},
                "modes": qml_modes
            })
        print(json.dumps(formatted))
    except Exception as e:
        log_warning(f"Error in get_outputs: {e}")
        print(json.dumps([]), file=sys.stderr)

def set_mode(name, w, h, hz):
    try:
        hz_val = float(hz)
        if hz_val > 1000:
            hz_val = hz_val / 1000.0
        mode_str = f"{w}x{h}@{hz_val:.3f}"
    except Exception:
        mode_str = f"{w}x{h}"
    run_niri(["output", name, "mode", mode_str])
    update_saved_monitor(name, mode={"w": int(w), "h": int(h), "hz": float(hz)})

def set_position(name, x, y):
    run_niri(["output", name, "position", "set", str(x), str(y)])
    update_saved_monitor(name, x=int(x), y=int(y))

def toggle_output(name, enable):
    if not enable:
        try:
            subprocess.run(
                ["python3", "/home/ismael/scripts/move_workspaces_on_disable.py", name],
                capture_output=True, timeout=5
            )
        except Exception as e:
            log_warning(f"Error running move_workspaces_on_disable.py for {name}: {e}")
        update_saved_monitor(name, active=False)
        return
    run_niri(["output", name, "on"])
    update_saved_monitor(name, active=True)

def watch_monitors():
    log_warning("Starting monitor watcher daemon...")
    # Initial restore
    restore_monitors()
    
    last_connected = set()
    try:
        outputs = query_connected_outputs()
        last_connected = set(outputs.keys())
    except Exception:
        pass

    # Start event-stream process
    try:
        proc = subprocess.Popen(
            ["niri", "msg", "--json", "event-stream"],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
    except Exception as e:
        log_warning(f"Failed to start niri event-stream: {e}. Falling back to pure polling.")
        proc = None

    last_check_time = 0
    
    while True:
        try:
            # If we have the event stream, block on reading a line
            if proc:
                line = proc.stdout.readline()
                if not line:
                    log_warning("Event stream closed. Restarting process...")
                    time.sleep(2.0)
                    proc = subprocess.Popen(
                        ["niri", "msg", "--json", "event-stream"],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.DEVNULL,
                        text=True
                    )
                    continue
            else:
                # Fallback to pure polling: sleep for 2 seconds
                time.sleep(2.0)

            # Rate limit checks to once per 1.0 second to avoid spamming
            current_time = time.time()
            if current_time - last_check_time < 1.0:
                continue
            last_check_time = current_time

            # Query current outputs
            current_outputs = query_connected_outputs()
            if not current_outputs:
                continue

            current_connected = set(current_outputs.keys())

            if current_connected != last_connected:
                log_warning(f"Outputs changed! Previous: {last_connected}, Current: {current_connected}")
                
                # Apply restoration / layout configuration
                restore_monitors()
                
                last_connected = current_connected
        except KeyboardInterrupt:
            break
        except Exception as e:
            log_warning(f"Error in watcher loop: {e}")
            time.sleep(2.0)

    if proc:
        try:
            proc.terminate()
        except Exception:
            pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manage Niri monitors")
    parser.add_argument("--list", action="store_true", help="List monitors as JSON")
    parser.add_argument("--mode", nargs=4, metavar=("NAME", "W", "H", "HZ"), help="Set monitor mode")
    parser.add_argument("--position", nargs=3, metavar=("NAME", "X", "Y"), help="Set monitor position")
    parser.add_argument("--enable", metavar="NAME", help="Enable monitor")
    parser.add_argument("--disable", metavar="NAME", help="Disable monitor")
    parser.add_argument("--restore", action="store_true", help="Restore monitors position and mode from saved config")
    parser.add_argument("--watch", action="store_true", help="Watch for monitor hotplug events and restore configurations")

    args = parser.parse_args()

    if args.list:
        get_outputs()
    elif args.mode:
        set_mode(args.mode[0], args.mode[1], args.mode[2], args.mode[3])
        time.sleep(0.5)
    elif args.position:
        set_position(args.position[0], args.position[1], args.position[2])
        time.sleep(0.5)
    elif args.enable:
        toggle_output(args.enable, True)
        time.sleep(0.5)
    elif args.disable:
        toggle_output(args.disable, False)
        time.sleep(0.5)
    elif args.restore:
        restore_monitors()
        time.sleep(0.5)
    elif args.watch:
        watch_monitors()
    else:
        parser.print_help()
