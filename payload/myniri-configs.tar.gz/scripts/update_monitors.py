#!/usr/bin/env python3
import json
import subprocess
import sys
import argparse
import time

def run_niri(args_list):
    try:
        cmd = ["niri", "msg"] + args_list
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode == 0
    except Exception as e:
        return False

def get_outputs():
    try:
        import os
        primary_name = ""
        primary_file = os.path.expanduser("~/.config/quickshell/primary_monitor.txt")
        if os.path.exists(primary_file):
            with open(primary_file, "r") as f:
                primary_name = f.read().strip()
                
        result = subprocess.run(["niri", "msg", "--json", "outputs"], capture_output=True, text=True)
        outputs = json.loads(result.stdout)
        
        # In Niri, an output is active if it's not disabled (or has logical geometry)
        active_outputs = [o for o in outputs if not o.get("disabled", False) and o.get("logical") is not None]
        
        # Determine effective primary (using focused output in Niri)
        effective_primary = None
        for o in active_outputs:
            if o.get("is_focused"):
                effective_primary = o.get("name")
                break
                
        if not effective_primary and active_outputs:
            effective_primary = active_outputs[0].get("name")
            
        if effective_primary:
            # Save it
            os.makedirs(os.path.expanduser("~/.config/quickshell"), exist_ok=True)
            with open(primary_file, "w") as f:
                f.write(effective_primary)

        # Format the outputs to send to QML
        formatted = []
        for out in outputs:
            modes = out.get("modes", [])
            # Sort modes: width desc, height desc, refresh desc
            modes.sort(key=lambda m: (m.get("width", 0), m.get("height", 0), m.get("refresh", 0)), reverse=True)
            
            # Create a simplified list of modes for QML
            qml_modes = []
            for m in modes:
                w = m.get("width", 0)
                h = m.get("height", 0)
                hz = m.get("refresh", 0) / 1000.0
                qml_modes.append({"label": f"{w}x{h} @ {hz:.2f}Hz", "w": w, "h": h, "hz": m.get("refresh", 0)})
                
            logical = out.get("logical", {}) or {}
            rect = {
                "x": logical.get("x", 0),
                "y": logical.get("y", 0),
                "width": logical.get("width", 0),
                "height": logical.get("height", 0)
            }
            
            active = not out.get("disabled", False) and out.get("logical") is not None
            
            formatted.append({
                "name": out.get("name", "Unknown"),
                "make": out.get("make", "Unknown"),
                "model": out.get("model", "Unknown"),
                "active": active,
                "dpms": not out.get("disabled", False), # Niri off is disabled
                "primary": out.get("name") == effective_primary,
                "scale": out.get("scale", 1.0),
                "rect": rect,
                "current_mode": out.get("current_mode", {}),
                "modes": qml_modes
            })
        print(json.dumps(formatted))
    except Exception as e:
        print(json.dumps([]))

def set_mode(name, w, h, hz):
    # niri msg output <name> mode "<w>x<h>@<hz>"
    # Convert hz back from milli-Hz to float string if needed, or if it is already in Hz
    try:
        hz_val = float(hz)
        if hz_val > 1000:
            hz_val = hz_val / 1000.0
        mode_str = f"{w}x{h}@{hz_val:.2f}"
    except Exception:
        mode_str = f"{w}x{h}"
        
    run_niri(["output", name, "mode", mode_str])

def set_position(name, x, y):
    # niri msg output <name> position x=<x> y=<y>
    run_niri(["output", name, "position", f"x={x}", f"y={y}"])

def toggle_output(name, enable):
    if not enable:
        subprocess.run(["python3", "/home/ismael/scripts/move_workspaces_on_disable.py", name])
        return
    # niri msg output <name> on
    run_niri(["output", name, "on"])

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manage Niri monitors")
    parser.add_argument("--list", action="store_true", help="List monitors as JSON")
    parser.add_argument("--mode", nargs=4, metavar=("NAME", "W", "H", "HZ"), help="Set monitor mode")
    parser.add_argument("--position", nargs=3, metavar=("NAME", "X", "Y"), help="Set monitor position")
    parser.add_argument("--enable", metavar="NAME", help="Enable monitor")
    parser.add_argument("--disable", metavar="NAME", help="Disable monitor")
    
    args = parser.parse_args()
    
    if args.list:
        get_outputs()
    elif args.mode:
        set_mode(args.mode[0], args.mode[1], args.mode[2], args.mode[3])
        time.sleep(0.5)
    elif args.position:
        set_position(args.position[0], args.position[1], args.position[2])
        time.sleep(0.5)
    elif args.enable:
        toggle_output(args.enable, True)
        time.sleep(0.5)
    elif args.disable:
        toggle_output(args.disable, False)
        time.sleep(0.5)
    else:
        parser.print_help()
