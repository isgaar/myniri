#!/bin/bash
python3 /home/ismael/scripts/switch_workspace.py next
