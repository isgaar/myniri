#!/usr/bin/env python3
import json
import sys
import os

def main():
    if len(sys.argv) < 2:
        return
    name = sys.argv[1]
    path = os.path.expanduser('~/.config/quickshell/launcher_history.json')
    
    data = {}
    if os.path.exists(path):
        try:
            with open(path, 'r') as f:
                data = json.load(f)
        except Exception:
            pass
            
    data[name] = data.get(name, 0) + 1
    
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path, 'w') as f:
            json.dump(data, f)
    except Exception as e:
        print(f"Error writing history file: {e}", file=sys.stderr)

if __name__ == '__main__':
    main()
