#!/usr/bin/env python3
import sys
import os
import re
import subprocess

CONFIG_PATH = os.path.expanduser("~/.config/niri/config.kdl")

def read_config():
    if not os.path.exists(CONFIG_PATH):
        return ""
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return f.read()

def write_config(content):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write(content)
    subprocess.run(["niri", "msg", "action", "load-config-file"])

def set_layout(layout_name):
    content = read_config()
    pattern = r'(layout\s+")[^"]*(")'
    if re.search(pattern, content):
        new_content = re.sub(pattern, r'\g<1>' + layout_name + r'\g<2>', content)
        write_config(new_content)
        return True
    return False

def set_touchpad_option(option, enabled):
    content = read_config()
    touchpad_match = re.search(r'(touchpad\s*\{[^}]*\})', content)
    if not touchpad_match:
        return False
    
    block = touchpad_match.group(1)
    
    if enabled:
        if re.search(r'//\s*' + option, block):
            new_block = re.sub(r'//\s*' + option, option, block)
        elif option not in block:
            new_block = block.replace("}", f"    {option}\n    }}")
        else:
            new_block = block
    else:
        if option in block and not re.search(r'//\s*' + option, block):
            new_block = re.sub(r'(\b' + option + r'\b)', r'// \1', block)
        else:
            new_block = block
            
    new_content = content.replace(block, new_block)
    write_config(new_content)
    return True

def set_cursor_option(option_name, val_str, is_quoted=True):
    content = read_config()
    if is_quoted:
        pattern = r'(' + option_name + r'\s+")[^"]*(")'
        replacement = r'\g<1>' + val_str + r'\g<2>'
    else:
        pattern = r'(' + option_name + r'\s+)\d+'
        replacement = r'\g<1>' + val_str
        
    if re.search(pattern, content):
        new_content = re.sub(pattern, replacement, content)
        write_config(new_content)
        return True
    return False

def set_app_launcher(key, app_name):
    content = read_config()
    if key == "terminal":
        term_match = re.search(r'Mod\+Return\s*\{\s*spawn\s+"honey"\s+"([^"]+)";\s*\}', content)
        if not term_match:
            return False
        current_term = term_match.group(1)
        new_content = content.replace(f'spawn "honey" "{current_term}"', f'spawn "honey" "{app_name}"')
        write_config(new_content)
        return True
    elif key == "browser":
        browser_match = re.search(r'Mod\+Z\s*\{\s*spawn\s+"honey"\s+"([^"]+)";\s*\}', content)
        if not browser_match:
            return False
        current_browser = browser_match.group(1)
        new_browser = app_name
        if "/" not in new_browser:
            new_browser = "/usr/bin/" + new_browser
        new_content = content.replace(f'spawn "honey" "{current_browser}"', f'spawn "honey" "{new_browser}"')
        write_config(new_content)
        return True
    elif key == "file-manager":
        fileman_match = re.search(r'Mod\+E\s*\{\s*spawn\s+"honey"\s+"([^"]+)";\s*\}', content)
        if not fileman_match:
            return False
        current_fm = fileman_match.group(1)
        new_content = content.replace(f'spawn "honey" "{current_fm}"', f'spawn "honey" "{app_name}"')
        write_config(new_content)
        return True
    return False

def main():
    if len(sys.argv) < 3:
        print("Usage: update_niri_config.py <option> <value>")
        sys.exit(1)
    option = sys.argv[1]
    val = sys.argv[2]
    
    if option == "--layout":
        set_layout(val)
    elif option == "--tap-to-click":
        set_touchpad_option("tap", val.lower() == "true")
    elif option == "--natural-scroll":
        set_touchpad_option("natural-scroll", val.lower() == "true")
    elif option == "--cursor-theme":
        set_cursor_option("xcursor-theme", val, is_quoted=True)
    elif option == "--cursor-size":
        set_cursor_option("xcursor-size", val, is_quoted=False)
    elif option == "--terminal":
        set_app_launcher("terminal", val)
    elif option == "--browser":
        set_app_launcher("browser", val)
    elif option == "--file-manager":
        set_app_launcher("file-manager", val)
    else:
        print(f"Unknown option: {option}")
        sys.exit(1)

if __name__ == "__main__":
    main()
