#!/usr/bin/env python3
# ~/scripts/update_mako_position.sh (Python port for maximum execution speed and safety)
import sys
import subprocess

def main():
    if len(sys.argv) < 3:
        return
    
    panel_type = sys.argv[1] # "panel", "notifications", "volume", "battery", "bgapps", "power"
    state = sys.argv[2]      # "open" or "closed"

    # All known margin shift modes
    modes = ["panel-open", "notifications-open", "battery-open", "volume-open", "power-open", "bgapps-open"]
    
    # Remove all active open modes first to avoid duplicates or overlaps
    cmd = ["makoctl", "mode"]
    for mode in modes:
        cmd.extend(["-r", mode])
    
    if state == "open":
        cmd.extend(["-a", f"{panel_type}-open"])
        
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

if __name__ == "__main__":
    main()
