#!/usr/bin/env python3
"""Monitor bluetooth Powered status & connected devices, output state whenever it changes."""
import subprocess
import sys
import select
import os
import signal

signal.signal(signal.SIGINT, signal.SIG_DFL)

def get_initial_state():
    try:
        out = subprocess.run(
            ["bluetoothctl", "show"],
            capture_output=True, text=True, timeout=2
        ).stdout
        if "Powered: yes" in out:
            return "yes"
    except:
        pass
    return "no"

def get_connected_device():
    try:
        out = subprocess.run(
            ["bluetoothctl", "devices", "Connected"],
            capture_output=True, text=True, timeout=2
        ).stdout.strip()
        if out:
            for line in out.splitlines():
                parts = line.split(" ", 2)
                if len(parts) >= 3:
                    return parts[2]
    except:
        pass
    return None

# Initial state
powered = get_initial_state()
if powered == "yes":
    device = get_connected_device()
    if device:
        print(f"yes:{device}", flush=True)
    else:
        print("yes", flush=True)
else:
    print("no", flush=True)

# Start dbus-monitor to watch for PropertiesChanged signal on org.bluez path namespace
proc = subprocess.Popen(
    ["dbus-monitor", "--system", "type='signal',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged',path_namespace='/org/bluez'"],
    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True
)

fd = proc.stdout.fileno()
os.set_blocking(fd, False)

buffer = ""
powered_key_seen = False
connected_key_seen = False

while True:
    reads, _, _ = select.select([fd], [], [])
    if fd in reads:
        try:
            chunk = proc.stdout.read()
        except BlockingIOError:
            continue
        
        if not chunk:
            break
            
        buffer += chunk
        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            line_strip = line.strip()
            if line_strip.startswith('string "Powered"'):
                powered_key_seen = True
                connected_key_seen = False
            elif line_strip.startswith('string "Connected"'):
                connected_key_seen = True
                powered_key_seen = False
            elif line_strip.startswith('string "'):
                # Reset if any other property key is seen (e.g. Discoverable, Pairable)
                powered_key_seen = False
                connected_key_seen = False
            elif powered_key_seen:
                if "boolean true" in line_strip:
                    device = get_connected_device()
                    if device:
                        print(f"yes:{device}", flush=True)
                    else:
                        print("yes", flush=True)
                    powered_key_seen = False
                elif "boolean false" in line_strip:
                    print("no", flush=True)
                    powered_key_seen = False
            elif connected_key_seen:
                if "boolean true" in line_strip or "boolean false" in line_strip:
                    # Connection changed (either connected or disconnected)
                    p = get_initial_state()
                    if p == "yes":
                        device = get_connected_device()
                        if device:
                            print(f"yes:{device}", flush=True)
                        else:
                            print("yes", flush=True)
                    else:
                        print("no", flush=True)
                    connected_key_seen = False
