#!/usr/bin/env python3
import json
import subprocess
import os
from collections import OrderedDict

def find_icons(icon_names):
    resolved = {}
    search_dirs = [
        os.path.expanduser('~/.local/share/icons'),
        '/usr/share/icons',
        '/usr/share/pixmaps'
    ]
    for name in icon_names:
        if not name: continue
        if os.path.isabs(name) and os.path.exists(name):
            resolved[name] = name
            continue
    remaining = [n for n in icon_names if n and n not in resolved]
    if not remaining:
        return resolved
    for base_dir in search_dirs:
        if not os.path.exists(base_dir): continue
        for root, _, files in os.walk(base_dir):
            for f in files:
                if f.endswith(('.png', '.svg', '.xpm')):
                    basename = os.path.splitext(f)[0]
                    if basename in remaining:
                        resolved[basename] = os.path.join(root, f)
                        remaining.remove(basename)
                        if not remaining:
                            return resolved
    return resolved

def main():
    try:
        mako_list = json.loads(subprocess.check_output(['makoctl', 'list', '-j'], text=True))
    except Exception:
        mako_list = []
    try:
        mako_history = json.loads(subprocess.check_output(['makoctl', 'history', '-j'], text=True))
    except Exception:
        mako_history = []

    seen = set()
    notifs = []
    for n in mako_list:
        notifs.append(('now', n))
    for n in mako_history[:50]:
        notifs.append(('recent', n))

    icon_names = set()
    for state, n in notifs:
        app = n.get('app_name', '') or ''
        desktop_entry = n.get('desktop_entry') or app
        app_icon = n.get('app_icon') or desktop_entry.lower()
        if app_icon:
            icon_names.add(app_icon)
    resolved_icons = find_icons(icon_names)

    # Group notifications by app + summary key for stacking
    groups = OrderedDict()  # key -> {first, count, items}
    for state, n in notifs:
        nid = str(n.get('id', ''))
        if nid in seen: continue
        seen.add(nid)
        app = n.get('app_name', '') or ''
        summary = n.get('summary', '') or ''
        if not summary: continue
        body = (n.get('body', '') or '').replace('\n', ' ')
        urgency = n.get('urgency', 'normal') or 'normal'
        desktop_entry = n.get('desktop_entry') or app
        app_icon = n.get('app_icon') or desktop_entry.lower()
        icon_path = resolved_icons.get(app_icon, "")

        # Determine if this is a screenshot notification
        label = (summary + " " + body).lower()
        is_screenshot = "captura" in label or "screenshot" in label
        preview = ""
        if is_screenshot:
            try:
                cmd = "find \"$HOME/Imágenes/Capturas de pantalla\" \"$HOME/Imágenes/Screenshots\" \"$HOME/Pictures/Screenshots\" -maxdepth 1 -type f \\( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.webp' \\) -printf '%T@\\t%p\\n' 2>/dev/null | awk -F '\\t' '$1 > newest {newest=$1; path=$2} END {print path}'"
                latest = subprocess.check_output(cmd, shell=True, text=True).strip()
                preview = latest
            except:
                pass

        # Group key: app + is_screenshot (to group screenshots together)
        group_key = (desktop_entry or app, is_screenshot)
        entry = groups.get(group_key)
        if entry:
            entry['count'] += 1
            # Keep most recent notification as the display item
            if state == 'now':
                entry['item'] = (state, nid, app, summary, body, urgency, desktop_entry, preview, icon_path)
        else:
            groups[group_key] = {
                'count': 1,
                'item': (state, nid, app, summary, body, urgency, desktop_entry, preview, icon_path)
            }

    print("CLEAR")
    output = []
    for key, entry in groups.items():
        state, nid, app, summary, body, urgency, desktop_entry, preview, icon_path = entry['item']
        count = entry['count']
        if count > 1:
            summary = f"{summary} (+{count - 1} más)"
        line = "\t".join([state, nid, app, summary, body, urgency, desktop_entry, preview, icon_path, str(count)])
        output.append(line)

    for line in output[:30]:
        print(line)

if __name__ == '__main__':
    main()
