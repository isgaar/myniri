#!/bin/bash

# ── Lock: evita doble ejecución ─────────────────────────────────
_SCRIPT_NAME=$(basename "$0" .sh)
_LOCKFILE="/tmp/${_SCRIPT_NAME}.lock"
if [ -e "$_LOCKFILE" ]; then
  _pid=$(cat "$_LOCKFILE")
  if kill -0 "$_pid" 2>/dev/null; then
    exit 0
  fi
fi
echo $$ > "$_LOCKFILE"
trap "rm -f $_LOCKFILE" EXIT INT TERM

WIFI=$(printf '\uf1eb')
LOCK=$(printf '\uf023')
GLOBE=$(printf '\uf57d')
CHECK=$(printf '\uf00c')
POWER=$(printf '\uf011')
KEY=$(printf '\uf084')

# ── Estado inicial ───────────────────────────────────────────────
wifi_state=$(nmcli radio wifi)

# Captura "sí" o "yes" según idioma del sistema
active_ssid=$(nmcli --escape no -t -f active,ssid dev wifi list --rescan no 2>/dev/null \
    | grep -E '^(sí|yes):' | head -1 | cut -d: -f2-)

[[ "$wifi_state" == "enabled" || "$wifi_state" == "activado" ]] \
    && TOGGLE_LABEL="$POWER  Apagar WiFi" \
    || TOGGLE_LABEL="$POWER  Encender WiFi"

# ── Construir menú ───────────────────────────────────────────────
declare -A action_map ssid_map security_map
menu_items=""

menu_items+="${TOGGLE_LABEL}\n"
action_map["$TOGGLE_LABEL"]="toggle"

SEP="────────────────────────"
menu_items+="${SEP}\n"
action_map["$SEP"]="noop"

if [[ "$wifi_state" == "enabled" || "$wifi_state" == "activado" ]]; then
    declare -A seen
    while IFS=$'\t' read -r ssid signal security; do
        [[ -z "$ssid" || "$ssid" == "--" ]] && continue
        [[ -n "${seen[$ssid]}" ]] && continue
        seen["$ssid"]=1

        [[ "$security" == "--" || -z "$security" ]] \
            && sec_icon="$GLOBE" || sec_icon="$LOCK"

        if [[ "$ssid" == "$active_ssid" ]]; then
            key="$WIFI  $ssid  $CHECK  conectado"
            show="<b><span color='#4caf50'>$WIFI  $ssid  $CHECK  conectado</span></b>"
        else
            key="$WIFI  $ssid  $sec_icon"
            show="$key"
        fi

        menu_items+="${show}\n"
        action_map["$key"]="connect"
        ssid_map["$key"]="$ssid"
        security_map["$key"]="$security"

    done < <(
        nmcli --escape no -t -f ssid,signal,security dev wifi list --rescan yes 2>/dev/null \
        | awk -F: 'NF>=2 {
            sec = $NF; sig = $(NF-1)
            ssid = ""; for(i=1;i<=NF-2;i++) ssid = ssid (i>1?":":"") $i
            print ssid "\t" sig "\t" sec
          }' \
        | sort -t$'\t' -k2 -rn
    )
fi

# ── Mostrar menú ─────────────────────────────────────────────────
selected=$(printf "%b" "$menu_items" | wofi \
    --dmenu \
    --prompt "$WIFI  WiFi:" \
    --style ~/.config/wofi/audio.css \
    --width 380 --height 320 \
    --allow-markup --hide-search --no-actions \
    --cache-file /dev/null)

[[ -z "$selected" ]] && exit 0

selected_k=$(echo "$selected" | sed 's/<[^>]*>//g')

action="${action_map[$selected_k]}"
[[ -z "$action" || "$action" == "noop" ]] && exit 0

ssid="${ssid_map[$selected_k]}"
security="${security_map[$selected_k]}"

# ── Acciones ─────────────────────────────────────────────────────
case "$action" in
    toggle)
        if [[ "$wifi_state" == "enabled" || "$wifi_state" == "activado" ]]; then
            nmcli radio wifi off
            notify-send --icon=network-wireless --expire-time=2500 "WiFi" "Apagado"
        else
            nmcli radio wifi on
            notify-send --icon=network-wireless --expire-time=2500 "WiFi" "Encendido"
        fi
        ;;

    connect)
        if [[ "$ssid" == "$active_ssid" ]]; then
            nmcli dev disconnect wlo1
            notify-send --icon=network-wireless --expire-time=2500 "WiFi" "Desconectado de: $ssid"
            exit 0
        fi

        saved=$(nmcli -t -f name,type connection show 2>/dev/null \
            | grep ":802-11-wireless$" \
            | sed 's/:802-11-wireless$//' \
            | grep -Fx "$ssid")

        ask_pw() {
            printf '\n' | wofi \
                --dmenu \
                --prompt "$KEY  $ssid — contraseña:" \
                --style ~/.config/wofi/prompt.css \
                --width 380 --height 110 \
                --password \
                --cache-file /dev/null
        }

        if [[ -n "$saved" ]]; then
            CHOICE=$(printf "$(printf '\uf00c')  Usar contraseña guardada\n$KEY  Ingresar contraseña nueva" \
                | wofi --dmenu \
                    --prompt "$KEY  $ssid:" \
                    --style ~/.config/wofi/audio.css \
                    --width 380 --height 120 \
                    --hide-search --no-actions \
                    --cache-file /dev/null)
            [[ -z "$CHOICE" ]] && exit 0
            notify-send --icon=network-wireless --expire-time=2500 "WiFi" "Conectando a: $ssid..."
            if [[ "$CHOICE" == *"guardada"* ]]; then
                nmcli con up id "$ssid" ifname wlo1
            else
                pw=$(ask_pw); [[ -z "$pw" ]] && exit 0
                nmcli dev wifi connect "$ssid" password "$pw" ifname wlo1
            fi

        elif [[ "$security" != "--" && -n "$security" ]]; then
            pw=$(ask_pw); [[ -z "$pw" ]] && exit 0
            notify-send --icon=network-wireless --expire-time=2500 "WiFi" "Conectando a: $ssid..."
            nmcli dev wifi connect "$ssid" password "$pw" ifname wlo1

        else
            notify-send --icon=network-wireless --expire-time=2500 "WiFi" "Conectando a: $ssid..."
            nmcli dev wifi connect "$ssid" ifname wlo1
        fi

        sleep 3
        new_ssid=$(nmcli --escape no -t -f active,ssid dev wifi list --rescan no 2>/dev/null \
            | grep -E '^(sí|yes):' | head -1 | cut -d: -f2-)

        if [[ "$new_ssid" == "$ssid" ]]; then
            notify-send --icon=network-wireless --expire-time=2500 "WiFi" "Conectado ✓  $ssid"
        else
            notify-send --icon=network-wireless --expire-time=3000 "WiFi" "Error al conectar: $ssid"
        fi
        ;;
esac
exit 0
