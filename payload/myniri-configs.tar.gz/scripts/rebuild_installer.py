import os
import subprocess
import shutil
import base64

def rebuild():
    # 1. Create a staging directory
    home = os.path.expanduser("~")
    staging = os.path.join(home, "tmp_payload_staging")
    if os.path.exists(staging):
        shutil.rmtree(staging)
    os.makedirs(staging)
    
    # 2. Copy the directories and files
    dirs_to_copy = [
        ".config/waybar",
        ".config/fontconfig",
        ".config/quickshell",
        ".config/niri",
        ".config/mako",
        ".config/fastfetch",
        ".config/gtk-3.0/settings.ini",
        ".config/gtk-4.0/settings.ini",
        ".config/xsettingsd/xsettingsd.conf",
        ".config/kdeglobals",
        "scripts"
    ]
    
    for d in dirs_to_copy:
        src = os.path.join(home, d)
        dst = os.path.join(staging, d)
        if os.path.exists(src):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.isdir(src):
                shutil.copytree(src, dst, symlinks=True)
            else:
                shutil.copy2(src, dst)
            
    # 3. Clean up user-specific state files
    cleanup_files = [
        ".config/quickshell/primary_monitor.txt",
        ".config/quickshell/launcher_history.json",
        ".config/niri/wallpaper.txt"
    ]
    for f in cleanup_files:
        path = os.path.join(staging, f)
        if os.path.exists(path):
            os.remove(path)
            
    pycache_dir = os.path.join(staging, "scripts/__pycache__")
    if os.path.exists(pycache_dir):
        shutil.rmtree(pycache_dir)
        
    # 4. Compress to tar.gz
    repo_dir = os.path.join(home, "Documentos/myniri")
    payload_dir = os.path.join(repo_dir, "payload")
    os.makedirs(payload_dir, exist_ok=True)
    tar_path = os.path.join(payload_dir, "myniri-configs.tar.gz")
    
    subprocess.run([
        "tar", "-czf", tar_path, "-C", staging, ".config", "scripts"
    ], check=True)
    
    # Clean up staging
    shutil.rmtree(staging)
    print("✔ Packaged new myniri-configs.tar.gz successfully.")
    
    # 5. Update installer.sh
    installer_path = os.path.join(repo_dir, "installer.sh")
    with open(installer_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    marker = "__NIRI_PAYLOAD__"
    idx = content.rfind(marker)
    if idx == -1:
        print("❌ Error: __NIRI_PAYLOAD__ marker not found in installer.sh")
        return
        
    header = content[:idx + len(marker)]
    
    # Base64-encode the new tarball
    with open(tar_path, "rb") as f:
        binary_data = f.read()
    b64_data = base64.b64encode(binary_data).decode("utf-8")
    
    # Format base64 to wrap at 76 characters like standard base64 output
    wrapped_b64 = "\n".join(b64_data[i:i+76] for i in range(0, len(b64_data), 76))
    
    new_content = header + "\n" + wrapped_b64 + "\n"
    
    with open(installer_path, "w", encoding="utf-8") as f:
        f.write(new_content)
    print("✔ Updated installer.sh with new base64 payload successfully.")

if __name__ == "__main__":
    rebuild()
