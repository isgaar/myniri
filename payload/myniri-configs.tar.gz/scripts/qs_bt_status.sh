#!/bin/bash
# qs_bt_status.sh — Consulta segura de Bluetooth para Quickshell sin hardcodear el adaptador

# Descubrir el path del adaptador de forma dinámica
ADAPTER_PATH=$(busctl call org.bluez / org.freedesktop.DBus.ObjectManager GetManagedObjects --json=short 2>/dev/null | jq -r '.data[0] | to_entries[] | select(.value["org.bluez.Adapter1"] != null) | .key' | head -n 1)

if [ -z "$ADAPTER_PATH" ]; then
    # Fallback si no se detecta ningún adaptador
    ADAPTER_PATH="/org/bluez/hci0"
fi

# Consultar si el adaptador está encendido
powered=$(busctl get-property org.bluez "$ADAPTER_PATH" org.bluez.Adapter1 Powered 2>/dev/null | awk '{print $2}')

if [ "$powered" = "true" ]; then
    mkdir -p ~/.local/share
    echo "unblocked" > ~/.local/share/bluetooth-state
    
    # Buscar el nombre del primer dispositivo conectado
    device=$(busctl call org.bluez / org.freedesktop.DBus.ObjectManager GetManagedObjects --json=short 2>/dev/null | jq -r '.data[0] | to_entries[] | select(.value["org.bluez.Device1"] != null) | select(.value["org.bluez.Device1"].Connected.data == true) | .value["org.bluez.Device1"].Name.data' | head -n 1)
    
    if [ -n "$device" ]; then
        echo "yes:$device"
    else
        echo "yes"
    fi
else
    mkdir -p ~/.local/share
    echo "blocked" > ~/.local/share/bluetooth-state
    echo "no"
fi
