#!/usr/bin/env python3
import sys
import os
from PIL import Image

def analyze_wallpaper(path):
    if not path:
        return "dark dark"
    
    path = os.path.abspath(os.path.expanduser(path))
    if not os.path.isfile(path):
        return "dark dark"
        
    try:
        with Image.open(path) as img:
            width, height = img.size
            box_height = min(45, height)
            
            # Analyze Left Half (0% to 50% width)
            left_area = img.crop((0, 0, int(width * 0.5), box_height))
            left_1x1 = left_area.resize((1, 1), Image.Resampling.BILINEAR if hasattr(Image, 'Resampling') else Image.BILINEAR)
            pixel_left = left_1x1.getpixel((0, 0))
            if isinstance(pixel_left, int):
                r_l = g_l = b_l = pixel_left
            else:
                r_l, g_l, b_l = pixel_left[:3]
            lum_l = (0.299 * r_l + 0.587 * g_l + 0.114 * b_l) / 255.0
            
            # Analyze Right Half (50% to 100% width)
            right_area = img.crop((int(width * 0.5), 0, width, box_height))
            right_1x1 = right_area.resize((1, 1), Image.Resampling.BILINEAR if hasattr(Image, 'Resampling') else Image.BILINEAR)
            pixel_right = right_1x1.getpixel((0, 0))
            if isinstance(pixel_right, int):
                r_r = g_r = b_r = pixel_right
            else:
                r_r, g_r, b_r = pixel_right[:3]
            lum_r = (0.299 * r_r + 0.587 * g_r + 0.114 * b_r) / 255.0
            
            mode_l = "light" if lum_l > 0.55 else "dark"
            mode_r = "light" if lum_r > 0.55 else "dark"
            return f"{mode_l} {mode_r}"
    except Exception as e:
        return "dark dark"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("dark dark")
        sys.exit(0)
    print(analyze_wallpaper(sys.argv[1]))
