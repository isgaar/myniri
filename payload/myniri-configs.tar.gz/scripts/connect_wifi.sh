#!/bin/bash
SSID="$1"
PASS="${2:-}"

# Si se proporciona una contraseña, intentar conectar con ella
if [ -n "$PASS" ]; then
    if nmcli dev wifi connect "$SSID" password "$PASS" ifname wlo1 > /dev/null 2>&1 || \
       nmcli dev wifi connect "$SSID" password "$PASS" ifname wlan0 > /dev/null 2>&1 || \
       nmcli dev wifi connect "$SSID" password "$PASS" > /dev/null 2>&1; then
        notify-send --icon=network-wireless --expire-time=2500 "Wi-Fi" "Conectado ✓ $SSID"
        exit 0
    else
        notify-send --icon=network-wireless --expire-time=3000 "Wi-Fi" "Error al conectar a $SSID" -u normal
        exit 1
    fi
fi

# Intentar conectar directamente (para redes abiertas o con credenciales guardadas)
if nmcli dev wifi connect "$SSID" ifname wlo1 > /dev/null 2>&1 || \
   nmcli dev wifi connect "$SSID" ifname wlan0 > /dev/null 2>&1 || \
   nmcli dev wifi connect "$SSID" > /dev/null 2>&1; then
    notify-send --icon=network-wireless --expire-time=2500 "Wi-Fi" "Conectado ✓ $SSID"
    exit 0
fi

# Si falla la conexión directa (no guardada o requiere contraseña), retornar código 2
exit 2
