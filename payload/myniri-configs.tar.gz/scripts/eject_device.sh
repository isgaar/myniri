#!/bin/bash
# /home/ismael/scripts/eject_device.sh

DEVICE="$1"

if [ -z "$DEVICE" ]; then
    echo "Uso: $0 <device_path>" >&2
    exit 1
fi

# Verificar si tiene punto de montaje activo
MOUNTED=$(lsblk -no MOUNTPOINT "$DEVICE" 2>/dev/null | tr -d ' ')

if [ -n "$MOUNTED" ]; then
    if ! udisksctl unmount -b "$DEVICE" >/dev/null 2>&1; then
        notify-send --icon=media-removable "Error al expulsar" "No se pudo desmontar el dispositivo de forma segura. Asegúrese de que no esté en uso." -u normal
        exit 1
    fi
fi

# Obtener el disco padre, ej: sdb a partir de /dev/sdb1 y apagar
PARENT_DISK=$(lsblk -no pkname "$DEVICE" | head -n 1 | sed 's/^/\/dev\//')

if [ -n "$PARENT_DISK" ] && [ "$PARENT_DISK" != "/dev/" ]; then
    udisksctl power-off -b "$PARENT_DISK" >/dev/null 2>&1
fi

notify-send --icon=media-removable "Expulsión Exitosa" "El dispositivo se ha extraído con seguridad." -u low
exit 0
