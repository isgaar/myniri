#!/bin/bash

STATE_FILE="$HOME/.local/share/bluetooth-state"

if [ -f "$STATE_FILE" ]; then
    STATE=$(cat "$STATE_FILE")
    if [ "$STATE" = "blocked" ]; then
        bluetoothctl power off >/dev/null 2>&1
        rfkill block bluetooth >/dev/null 2>&1
    elif [ "$STATE" = "unblocked" ]; then
        rfkill unblock bluetooth >/dev/null 2>&1
        bluetoothctl power on >/dev/null 2>&1
    fi
fi
