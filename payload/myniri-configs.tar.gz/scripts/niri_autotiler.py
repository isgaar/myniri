#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import socket
import time
import threading
import signal
import logging
import tomllib

# ── Configuración de Logs ─────────────────────────────────────────────────────
LOG_DIR = os.path.expanduser("~/.local/state")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "niri-autotiler.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)

# ── Configuración por Defecto ─────────────────────────────────────────────────
CONFIG_PATH = os.path.expanduser("~/.config/niri-autotiler/config.toml")
config = {
    "stack_mode": "master_stack",
    "master_ratio": 60,
    "debounce_ms": 150,
    "excluded_app_ids": ["kdialog", "org.kde.kdialog", "floating_kitty"],
    "outputs": []
}

def load_config():
    global config
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "rb") as f:
                loaded = tomllib.load(f)
                config.update(loaded)
                logging.info(f"Configuración cargada correctamente desde {CONFIG_PATH}")
        except Exception as e:
            logging.error(f"Error cargando config.toml: {e}. Usando valores por defecto.")
    else:
        logging.info("Archivo config.toml no encontrado. Usando valores por defecto.")

# ── Resolución del Socket de Niri ─────────────────────────────────────────────
def find_niri_socket():
    # 1. Intentar variable de entorno
    env_path = os.environ.get("NIRI_SOCKET")
    if env_path and os.path.exists(env_path):
        return env_path

    # 2. Intentar buscar en el directorio de ejecución de usuario
    try:
        uid = os.getuid()
        run_dir = f"/run/user/{uid}"
        if os.path.exists(run_dir):
            for f in os.listdir(run_dir):
                if f.startswith("niri") and f.endswith(".sock"):
                    path = os.path.join(run_dir, f)
                    logging.info(f"Socket de Niri encontrado dinámicamente en: {path}")
                    return path
    except Exception as e:
        logging.error(f"Error buscando el socket de Niri: {e}")

    return None

# ── Cliente de IPC para Niri ──────────────────────────────────────────────────
class NiriIPC:
    def __init__(self, socket_path):
        self.socket_path = socket_path
        self._action_sock = None
        self._connect_action()

    def _connect_action(self):
        if self._action_sock:
            try:
                self._action_sock.close()
            except Exception:
                pass
        logging.debug("Conectando socket de acciones...")
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(self.socket_path)
        self._action_sock = s

    def request(self, req_name: str):
        for attempt in range(2):
            try:
                if not self._action_sock:
                    self._connect_action()
                self._action_sock.sendall((json.dumps(req_name) + "\n").encode("utf-8"))
                res = self._action_sock.makefile("r").readline()
                if not res:
                    raise ConnectionResetError("Respuesta vacía desde el socket de peticiones")
                return json.loads(res)
            except (BrokenPipeError, ConnectionResetError, OSError) as e:
                logging.warning(f"Conexión perdida en socket de peticiones ({e}). Reintentando...")
                if attempt == 0:
                    time.sleep(0.1)
                    try:
                        self._connect_action()
                    except Exception as err:
                        logging.error(f"Error de reconexión de petición: {err}")
                else:
                    raise e

    def action(self, action_name: str, **kwargs):
        payload = {"Action": {action_name: kwargs}} if kwargs else {"Action": action_name}
        for attempt in range(2):
            try:
                if not self._action_sock:
                    self._connect_action()
                self._action_sock.sendall((json.dumps(payload) + "\n").encode("utf-8"))
                res = self._action_sock.makefile("r").readline()
                if not res:
                    raise ConnectionResetError("Respuesta vacía desde el socket de acciones")
                return json.loads(res)
            except (BrokenPipeError, ConnectionResetError, OSError) as e:
                logging.warning(f"Conexión perdida en socket de acciones ({e}). Reintentando...")
                if attempt == 0:
                    time.sleep(0.1)
                    try:
                        self._connect_action()
                    except Exception as err:
                        logging.error(f"Error de reconexión de acción: {err}")
                else:
                    raise e

    def event_stream(self):
        while True:
            try:
                logging.info("Conectando socket de stream de eventos...")
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.connect(self.socket_path)
                s.sendall(b'"EventStream"\n')
                f = s.makefile("r")
                for line in f:
                    if line.strip():
                        yield json.loads(line)
            except Exception as e:
                logging.error(f"Error en el stream de eventos ({e}). Reintentando en 2 segundos...")
                time.sleep(2)

# ── Estado del Autotiler ──────────────────────────────────────────────────────
class AutotilerState:
    def __init__(self):
        self.workspaces = {}      # ws_id -> ws_data
        self.windows = {}         # win_id -> win_data
        self.output_widths = {}   # output_name -> width_pixels
        self.focused_workspace_id = None
        self.focused_window_id = None
        self.dirty_workspaces = set()  # Workspaces en segundo plano que cambiaron y necesitan retiling

state = AutotilerState()
ipc = None

def update_state(event_name, event_data):
    if event_name == "WorkspacesChanged":
        state.workspaces = {ws["id"]: ws for ws in event_data["workspaces"]}
        for ws in state.workspaces.values():
            if ws["is_focused"]:
                state.focused_workspace_id = ws["id"]
                
    elif event_name == "WorkspaceActivated":
        if event_data["focused"]:
            state.focused_workspace_id = event_data["id"]
            for ws_id, ws in state.workspaces.items():
                ws["is_focused"] = (ws_id == event_data["id"])
                
    elif event_name == "WindowsChanged":
        state.windows = {w["id"]: w for w in event_data["windows"]}
        for w in state.windows.values():
            if w["is_focused"]:
                state.focused_window_id = w["id"]
                
    elif event_name == "WindowOpenedOrChanged":
        win = event_data["window"]
        state.windows[win["id"]] = win
        if win["is_focused"]:
            state.focused_window_id = win["id"]
            
    elif event_name == "WindowClosed":
        win_id = event_data["id"]
        state.windows.pop(win_id, None)
        
    elif event_name == "WindowFocusChanged":
        win_id = event_data["id"]
        state.focused_window_id = win_id
        for w_id, w in state.windows.items():
            w["is_focused"] = (w_id == win_id)
            
    elif event_name == "WindowLayoutsChanged":
        for win_id, new_layout in event_data["changes"]:
            if win_id in state.windows:
                state.windows[win_id]["layout"] = new_layout

# ── Lógicas de Retiling ───────────────────────────────────────────────────────
def retile_master_stack(workspace_id, tiled_wins):
    master_win = min(tiled_wins, key=lambda w: w["id"])
    master_id = master_win["id"]
    master_col = master_win.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])[0]

    action_sent = False
    for w in tiled_wins:
        if w["id"] == master_id:
            continue

        pos = w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])
        col_idx = pos[0]

        if col_idx == master_col:
            logging.info(f"Espeliendo ventana {w['id']} a la derecha de la columna maestra")
            ipc.action("ConsumeOrExpelWindowRight", id=w["id"])
            action_sent = True
        elif col_idx > master_col + 1:
            logging.info(f"Consumiendo ventana {w['id']} a la izquierda hacia la columna stack")
            ipc.action("ConsumeOrExpelWindowLeft", id=w["id"])
            action_sent = True
        elif col_idx < master_col:
            logging.info(f"Consumiendo ventana {w['id']} a la derecha hacia la columna maestra")
            ipc.action("ConsumeOrExpelWindowRight", id=w["id"])
            action_sent = True

    if action_sent:
        logging.debug("Movimientos pendientes de aplicar. Postergando redimensionado.")
        return

    # Verificar si las proporciones ya son correctas para romper bucles de eventos
    cols = {}
    for w in tiled_wins:
        col = w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])[0]
        if col not in cols:
            cols[col] = w

    if len(cols) == 2:
        total_width = sum(w["layout"]["tile_size"][0] for w in cols.values() if "layout" in w and "tile_size" in w["layout"])
        if total_width > 0:
            master_width = master_win["layout"]["tile_size"][0]
            curr_master_ratio = (master_width / total_width) * 100.0
            if abs(curr_master_ratio - config["master_ratio"]) < 2.0:
                logging.info(f"Las proporciones Master-Stack ya son correctas ({curr_master_ratio:.1f}% vs {config['master_ratio']}%). Omitiendo redimensionado.")
                return

    # Si todo está estructurado, ajustar anchos
    master_ratio = float(config["master_ratio"])
    logging.info(f"Ajustando ancho de columna maestra ({master_id}) a {master_ratio}%")
    ipc.action("FocusWindow", id=master_id)
    ipc.action("SetColumnWidth", change={"SetProportion": master_ratio})

    other_wins = [w for w in tiled_wins if w["id"] != master_id]
    if other_wins:
        stack_win_id = other_wins[0]["id"]
        stack_ratio = 100.0 - master_ratio
        logging.info(f"Ajustando ancho de columna stack ({stack_win_id}) a {stack_ratio}%")
        ipc.action("FocusWindow", id=stack_win_id)
        ipc.action("SetColumnWidth", change={"SetProportion": stack_ratio})

def retile_equal_columns(workspace_id, tiled_wins):
    action_sent = False
    for w in tiled_wins:
        pos = w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])
        row_idx = pos[1]
        if row_idx > 0:
            logging.info(f"Espeliendo ventana {w['id']} a la derecha para hacer columna independiente")
            ipc.action("ConsumeOrExpelWindowRight", id=w["id"])
            action_sent = True

    if action_sent:
        logging.debug("Espulsiones pendientes de aplicar. Postergando redimensionado.")
        return

    # Verificar si las columnas ya están repartidas equitativamente
    cols = {}
    for w in tiled_wins:
        col = w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])[0]
        if col not in cols:
            cols[col] = w

    n = len(tiled_wins)
    if len(cols) == n:
        total_width = sum(w["layout"]["tile_size"][0] for w in cols.values() if "layout" in w and "tile_size" in w["layout"])
        if total_width > 0:
            target_pct = 100.0 / n
            all_correct = True
            for w in cols.values():
                w_pct = (w["layout"]["tile_size"][0] / total_width) * 100.0
                if abs(w_pct - target_pct) >= 2.0:
                    all_correct = False
                    break
            if all_correct:
                logging.info(f"Las proporciones Equal-Columns ya son correctas (todas cercanas a {target_pct:.1f}%). Omitiendo redimensionado.")
                return

    # Ajustar cada una al mismo tamaño
    target_pct = 100.0 / n
    for w in tiled_wins:
        win_id = w["id"]
        logging.info(f"Ajustando ventana {win_id} a ancho equitativo {target_pct:.2f}%")
        ipc.action("FocusWindow", id=win_id)
        ipc.action("SetColumnWidth", change={"SetProportion": target_pct})

def retile(workspace_id: int):
    # Verificación de foco del workspace activo
    if workspace_id != state.focused_workspace_id:
        state.dirty_workspaces.add(workspace_id)
        logging.debug(f"Retile en workspace {workspace_id} abortado. Workspace no activo. Marcado como dirty.")
        return

    state.dirty_workspaces.discard(workspace_id)

    # Filtrado de ventanas tiled válidas
    tiled_wins = []
    for win in state.windows.values():
        if win.get("workspace_id") == workspace_id:
            if not win.get("is_floating", False):
                app_id = win.get("app_id") or ""
                if app_id not in config["excluded_app_ids"]:
                    # Validar exclusión de monitores
                    win_output = state.workspaces.get(workspace_id, {}).get("output", "")
                    if not config["outputs"] or win_output in config["outputs"]:
                        tiled_wins.append(win)

    n = len(tiled_wins)
    logging.info(f"Ejecutando retile en workspace {workspace_id} con {n} ventanas.")

    if n == 0:
        return

    focused_before = state.focused_window_id

    if n == 1:
        win_id = tiled_wins[0]["id"]
        
        # Verificar si la ventana única ya está a pantalla completa (para evitar bucles de eventos)
        win_output = state.workspaces.get(workspace_id, {}).get("output")
        output_width = state.output_widths.get(win_output)
        if output_width:
            col_width = tiled_wins[0].get("layout", {}).get("tile_size", [0, 0])[0]
            if abs(col_width - output_width) < 5:
                logging.info(f"La ventana única {win_id} ya ocupa la anchura completa del monitor ({col_width}px). Omitiendo.")
                return

        logging.info(f"Solo 1 ventana en workspace. Maximizando {win_id}.")
        ipc.action("FocusWindow", id=win_id)
        ipc.action("SetColumnWidth", change={"SetProportion": 100.0})
    elif config["stack_mode"] == "master_stack":
        retile_master_stack(workspace_id, tiled_wins)
    else:
        retile_equal_columns(workspace_id, tiled_wins)

    # Restaurar el foco original
    if focused_before and focused_before in state.windows:
        if state.focused_window_id != focused_before:
            logging.info(f"Restaurando foco original a ventana {focused_before}")
            ipc.action("FocusWindow", id=focused_before)

# ── Debounce y Planificación ──────────────────────────────────────────────────
_retile_timers = {}

def schedule_retile(workspace_id):
    if workspace_id is None:
        return

    if workspace_id != state.focused_workspace_id:
        state.dirty_workspaces.add(workspace_id)
        return

    state.dirty_workspaces.discard(workspace_id)

    if workspace_id in _retile_timers:
        _retile_timers[workspace_id].cancel()

    def run():
        try:
            retile(workspace_id)
        except Exception as e:
            logging.error(f"Error realizando retile en workspace {workspace_id}: {e}", exc_info=True)
        finally:
            _retile_timers.pop(workspace_id, None)

    delay = config["debounce_ms"] / 1000.0
    timer = threading.Timer(delay, run)
    _retile_timers[workspace_id] = timer
    timer.start()

# ── Loop Principal y Manejo de Señales ────────────────────────────────────────
def shutdown(signum, frame):
    logging.info("Apagando autotiler de Niri...")
    for timer in list(_retile_timers.values()):
        timer.cancel()
    sys.exit(0)

def main():
    global ipc
    load_config()

    socket_path = find_niri_socket()
    if not socket_path:
        logging.error("No se pudo resolver el socket UNIX de Niri. Saliendo...")
        sys.exit(1)

    ipc = NiriIPC(socket_path)

    # Registrar señales para apagado limpio
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # Cargar estado inicial
    try:
        out_res = ipc.request("Outputs")
        if "Ok" in out_res and "Outputs" in out_res["Ok"]:
            state.output_widths = {}
            for name, data in out_res["Ok"]["Outputs"].items():
                logical = data.get("logical")
                if logical:
                    state.output_widths[name] = logical.get("width")

        ws_res = ipc.request("Workspaces")
        if "Ok" in ws_res and "Workspaces" in ws_res["Ok"]:
            state.workspaces = {ws["id"]: ws for ws in ws_res["Ok"]["Workspaces"]}
            for ws in state.workspaces.values():
                if ws["is_focused"]:
                    state.focused_workspace_id = ws["id"]

        win_res = ipc.request("Windows")
        if "Ok" in win_res and "Windows" in win_res["Ok"]:
            state.windows = {w["id"]: w for w in win_res["Ok"]["Windows"]}
            for w in state.windows.values():
                if w["is_focused"]:
                    state.focused_window_id = w["id"]

        logging.info(f"Estado inicial cargado: {len(state.workspaces)} workspaces, {len(state.windows)} ventanas, {len(state.output_widths)} monitores.")
        if state.focused_workspace_id:
            logging.info(f"Workspace inicial enfocado: {state.focused_workspace_id}. Programando retileo.")
            schedule_retile(state.focused_workspace_id)
    except Exception as e:
        logging.error(f"Error cargando estado inicial: {e}", exc_info=True)

    # Escuchar eventos
    for event in ipc.event_stream():
        try:
            event_name = list(event.keys())[0]
            event_data = event[event_name]

            # Capturar workspace antes de eliminar la ventana del estado
            closed_win_workspace_id = None
            if event_name == "WindowClosed":
                win_id = event_data["id"]
                if win_id in state.windows:
                    closed_win_workspace_id = state.windows[win_id].get("workspace_id")

            # Actualizar estado interno
            update_state(event_name, event_data)

            # Determinar qué workspace ha cambiado
            ws_id_to_retile = None
            if event_name == "WindowOpenedOrChanged":
                ws_id_to_retile = event_data["window"].get("workspace_id")
            elif event_name == "WindowClosed":
                ws_id_to_retile = closed_win_workspace_id
            elif event_name == "WindowLayoutsChanged":
                if event_data["changes"]:
                    win_id = event_data["changes"][0][0]
                    if win_id in state.windows:
                        ws_id_to_retile = state.windows[win_id].get("workspace_id")
            elif event_name == "WorkspaceActivated":
                if event_data["focused"]:
                    ws_id = event_data["id"]
                    # Si al activar el workspace está marcado como dirty, retilear
                    if ws_id in state.dirty_workspaces:
                        logging.info(f"Workspace {ws_id} activado y marcado como dirty. Procesando retileo...")
                        schedule_retile(ws_id)

            if ws_id_to_retile:
                schedule_retile(ws_id_to_retile)

        except Exception as e:
            logging.error(f"Error procesando evento del stream: {e}", exc_info=True)

if __name__ == "__main__":
    main()
