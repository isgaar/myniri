#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import socket
import time
import threading
import signal
import logging
import tomllib

# ── Configuración de Logs ─────────────────────────────────────────────────────
LOG_DIR = os.path.expanduser("~/.local/state")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "niri-autotiler.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)

# ── Configuración por Defecto ─────────────────────────────────────────────────
CONFIG_PATH = os.path.expanduser("~/.config/niri-autotiler/config.toml")
config = {
    "enabled": True,
    "stack_mode": "master_stack",
    "master_ratio": 60,
    "debounce_ms": 150,
    "ratio_tolerance": 2.0,
    "followup_retile_ms": 120,
    "close_retile_followups": [120, 360, 800],
    "center_visible_after_structural": True,
    "structural_action_cooldown_ms": 500,
    "manual_resize_grace_ms": 1600,
    "single_window_fill": True,
    "single_window_full_threshold_pct": 95.0,
    "excluded_app_ids": ["kdialog", "org.kde.kdialog", "floating_kitty"],
    "excluded_app_id_prefixes": ["quickshell"],
    "outputs": []
}

def load_config():
    global config
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "rb") as f:
                loaded = tomllib.load(f)
                config.update(loaded)
                logging.info(f"Configuración cargada correctamente desde {CONFIG_PATH}")
        except Exception as e:
            logging.error(f"Error cargando config.toml: {e}. Usando valores por defecto.")
    else:
        logging.info("Archivo config.toml no encontrado. Usando valores por defecto.")

    config["enabled"] = bool(config.get("enabled", True))

    if config.get("stack_mode") not in ("master_stack", "equal_columns"):
        logging.warning("stack_mode inválido %r. Usando master_stack.", config.get("stack_mode"))
        config["stack_mode"] = "master_stack"

    try:
        config["master_ratio"] = max(10.0, min(90.0, float(config.get("master_ratio", 60))))
    except (TypeError, ValueError):
        logging.warning("master_ratio inválido %r. Usando 60.", config.get("master_ratio"))
        config["master_ratio"] = 60.0

    try:
        config["debounce_ms"] = max(50, min(2000, int(config.get("debounce_ms", 150))))
    except (TypeError, ValueError):
        logging.warning("debounce_ms inválido %r. Usando 150.", config.get("debounce_ms"))
        config["debounce_ms"] = 150

    try:
        config["ratio_tolerance"] = max(0.5, min(10.0, float(config.get("ratio_tolerance", 2.0))))
    except (TypeError, ValueError):
        logging.warning("ratio_tolerance inválido %r. Usando 2.0.", config.get("ratio_tolerance"))
        config["ratio_tolerance"] = 2.0

    try:
        config["followup_retile_ms"] = max(50, min(1000, int(config.get("followup_retile_ms", 120))))
    except (TypeError, ValueError):
        logging.warning("followup_retile_ms inválido %r. Usando 120.", config.get("followup_retile_ms"))
        config["followup_retile_ms"] = 120

    try:
        config["structural_action_cooldown_ms"] = max(100, min(2000, int(config.get("structural_action_cooldown_ms", 500))))
    except (TypeError, ValueError):
        logging.warning("structural_action_cooldown_ms inválido %r. Usando 500.", config.get("structural_action_cooldown_ms"))
        config["structural_action_cooldown_ms"] = 500

    try:
        config["manual_resize_grace_ms"] = max(0, min(10000, int(config.get("manual_resize_grace_ms", 1600))))
    except (TypeError, ValueError):
        logging.warning("manual_resize_grace_ms inválido %r. Usando 1600.", config.get("manual_resize_grace_ms"))
        config["manual_resize_grace_ms"] = 1600

    config["single_window_fill"] = bool(config.get("single_window_fill", True))
    config["center_visible_after_structural"] = bool(config.get("center_visible_after_structural", True))
    try:
        config["single_window_full_threshold_pct"] = max(80.0, min(100.0, float(config.get("single_window_full_threshold_pct", 95.0))))
    except (TypeError, ValueError):
        logging.warning("single_window_full_threshold_pct inválido %r. Usando 95.0.", config.get("single_window_full_threshold_pct"))
        config["single_window_full_threshold_pct"] = 95.0

    for key in ("excluded_app_ids", "excluded_app_id_prefixes", "outputs"):
        value = config.get(key, [])
        if not isinstance(value, list):
            logging.warning("%s inválido %r. Usando lista vacía.", key, value)
            config[key] = []

    value = config.get("close_retile_followups", [120, 360, 800])
    if not isinstance(value, list):
        value = [120, 360, 800]
    clean_followups = []
    for item in value:
        try:
            clean_followups.append(max(50, min(2500, int(item))))
        except (TypeError, ValueError):
            continue
    config["close_retile_followups"] = clean_followups or [120, 360, 800]

# ── Resolución del Socket de Niri ─────────────────────────────────────────────
def find_niri_socket():
    # 1. Intentar variable de entorno
    env_path = os.environ.get("NIRI_SOCKET")
    if env_path and os.path.exists(env_path):
        return env_path

    # 2. Intentar buscar en el directorio de ejecución de usuario
    try:
        uid = os.getuid()
        run_dir = f"/run/user/{uid}"
        if os.path.exists(run_dir):
            for f in os.listdir(run_dir):
                if f.startswith("niri") and f.endswith(".sock"):
                    path = os.path.join(run_dir, f)
                    logging.info(f"Socket de Niri encontrado dinámicamente en: {path}")
                    return path
    except Exception as e:
        logging.error(f"Error buscando el socket de Niri: {e}")

    return None

# ── Cliente de IPC para Niri ──────────────────────────────────────────────────
class NiriIPC:
    def __init__(self, socket_path):
        self.socket_path = socket_path
        self._action_sock = None
        self._connect_action()

    def _connect_action(self):
        if self._action_sock:
            try:
                self._action_sock.close()
            except Exception:
                pass
        logging.debug("Conectando socket de acciones...")
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(self.socket_path)
        self._action_sock = s

    def request(self, req_name: str):
        for attempt in range(2):
            try:
                if not self._action_sock:
                    self._connect_action()
                self._action_sock.sendall((json.dumps(req_name) + "\n").encode("utf-8"))
                res = self._action_sock.makefile("r").readline()
                if not res:
                    raise ConnectionResetError("Respuesta vacía desde el socket de peticiones")
                return json.loads(res)
            except (BrokenPipeError, ConnectionResetError, OSError) as e:
                logging.warning(f"Conexión perdida en socket de peticiones ({e}). Reintentando...")
                if attempt == 0:
                    time.sleep(0.1)
                    try:
                        self._connect_action()
                    except Exception as err:
                        logging.error(f"Error de reconexión de petición: {err}")
                else:
                    raise e

    def action(self, action_name: str, **kwargs):
        payload = {"Action": {action_name: kwargs}} if kwargs else {"Action": action_name}
        for attempt in range(2):
            try:
                if not self._action_sock:
                    self._connect_action()
                self._action_sock.sendall((json.dumps(payload) + "\n").encode("utf-8"))
                res = self._action_sock.makefile("r").readline()
                if not res:
                    raise ConnectionResetError("Respuesta vacía desde el socket de acciones")
                return json.loads(res)
            except (BrokenPipeError, ConnectionResetError, OSError) as e:
                logging.warning(f"Conexión perdida en socket de acciones ({e}). Reintentando...")
                if attempt == 0:
                    time.sleep(0.1)
                    try:
                        self._connect_action()
                    except Exception as err:
                        logging.error(f"Error de reconexión de acción: {err}")
                else:
                    raise e

    def event_stream(self):
        while True:
            try:
                logging.info("Conectando socket de stream de eventos...")
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.connect(self.socket_path)
                s.sendall(b'"EventStream"\n')
                f = s.makefile("r")
                for line in f:
                    if line.strip():
                        yield json.loads(line)
            except Exception as e:
                logging.error(f"Error en el stream de eventos ({e}). Reintentando en 2 segundos...")
                time.sleep(2)

# ── Estado del Autotiler ──────────────────────────────────────────────────────
class AutotilerState:
    def __init__(self):
        self.workspaces = {}      # ws_id -> ws_data
        self.windows = {}         # win_id -> win_data
        self.output_widths = {}   # output_name -> width_pixels
        self.focused_workspace_id = None
        self.focused_window_id = None
        self.dirty_workspaces = set()  # Workspaces en segundo plano que cambiaron y necesitan retiling
        self.manual_layout_grace_until = {}  # ws_id -> monotonic timestamp
        self.programmatic_layout_until = 0.0

state = AutotilerState()
ipc = None

def _mark_programmatic_layout_change():
    state.programmatic_layout_until = time.monotonic() + 0.45

def _mark_manual_layout_change(workspace_id: int | None):
    if workspace_id is None:
        return
    grace = config["manual_resize_grace_ms"] / 1000.0
    if grace <= 0:
        return
    state.manual_layout_grace_until[workspace_id] = time.monotonic() + grace

def _manual_layout_active(workspace_id: int) -> bool:
    until = state.manual_layout_grace_until.get(workspace_id, 0.0)
    if until <= time.monotonic():
        state.manual_layout_grace_until.pop(workspace_id, None)
        return False
    return True

def _single_window_fill_required(workspace_id: int) -> bool:
    return bool(config["single_window_fill"] and len(_iter_workspace_tiled_windows(workspace_id)) == 1)

def update_state(event_name, event_data):
    if event_name == "WorkspacesChanged":
        state.workspaces = {ws["id"]: ws for ws in event_data["workspaces"]}
        for ws in state.workspaces.values():
            if ws["is_focused"]:
                state.focused_workspace_id = ws["id"]
                
    elif event_name == "WorkspaceActivated":
        if event_data["focused"]:
            state.focused_workspace_id = event_data["id"]
            for ws_id, ws in state.workspaces.items():
                ws["is_focused"] = (ws_id == event_data["id"])
                
    elif event_name == "WindowsChanged":
        state.windows = {w["id"]: w for w in event_data["windows"]}
        for w in state.windows.values():
            if w["is_focused"]:
                state.focused_window_id = w["id"]
                
    elif event_name == "WindowOpenedOrChanged":
        win = event_data["window"]
        state.windows[win["id"]] = win
        if win["is_focused"]:
            state.focused_window_id = win["id"]
            
    elif event_name == "WindowClosed":
        win_id = event_data["id"]
        state.windows.pop(win_id, None)
        
    elif event_name == "WindowFocusChanged":
        win_id = event_data["id"]
        state.focused_window_id = win_id
        for w_id, w in state.windows.items():
            w["is_focused"] = (w_id == win_id)
            
    elif event_name == "WindowLayoutsChanged":
        for win_id, new_layout in event_data["changes"]:
            if win_id in state.windows:
                state.windows[win_id]["layout"] = new_layout

    elif event_name == "OutputsChanged":
        state.output_widths = {}
        for name, data in event_data.get("outputs", {}).items():
            logical = data.get("logical")
            if logical:
                state.output_widths[name] = logical.get("width")

def _is_excluded_app(app_id: str) -> bool:
    if app_id in config["excluded_app_ids"]:
        return True
    return any(app_id.startswith(prefix) for prefix in config["excluded_app_id_prefixes"])

def _is_special_layout_window(win: dict) -> bool:
    return bool(
        win.get("is_floating", False)
        or win.get("is_fullscreen", False)
        or win.get("is_windowed_fullscreen", False)
    )

def _window_sort_key(win: dict):
    layout = win.get("layout", {})
    pos = layout.get("pos_in_scrolling_layout") or [0, 0]
    return (pos[0], pos[1], win.get("id", 0))

def _iter_workspace_tiled_windows(workspace_id: int) -> list[dict]:
    win_output = state.workspaces.get(workspace_id, {}).get("output", "")
    if config["outputs"] and win_output not in config["outputs"]:
        return []

    tiled_wins = []
    for win in state.windows.values():
        if win.get("workspace_id") != workspace_id:
            continue
        if _is_special_layout_window(win):
            continue
        app_id = win.get("app_id") or ""
        if _is_excluded_app(app_id):
            continue
        tiled_wins.append(win)

    return sorted(tiled_wins, key=_window_sort_key)

def _managed_window_signature_by_workspace() -> dict[int, tuple[int, ...]]:
    signatures = {}
    for win in state.windows.values():
        workspace_id = win.get("workspace_id")
        if workspace_id is None:
            continue
        if _is_special_layout_window(win):
            continue
        app_id = win.get("app_id") or ""
        if _is_excluded_app(app_id):
            continue
        signatures.setdefault(workspace_id, []).append(win.get("id"))
    return {workspace_id: tuple(sorted(ids)) for workspace_id, ids in signatures.items()}

def _ratio_is_close(actual: float, expected: float) -> bool:
    return abs(actual - expected) < config["ratio_tolerance"]

def _schedule_followup_retile(workspace_id: int):
    delay = config["followup_retile_ms"] / 1000.0
    timer = threading.Timer(delay, lambda: schedule_retile(workspace_id))
    timer.daemon = True
    timer.start()

def _schedule_structural_followups(workspace_id: int, reason: str):
    for delay_ms in config["close_retile_followups"]:
        delay = delay_ms / 1000.0
        timer = threading.Timer(delay, lambda ws=workspace_id: schedule_retile(ws, force=True, reason=reason))
        timer.daemon = True
        timer.start()

def _center_visible_columns_if_needed(workspace_id: int, reason: str):
    if not config["center_visible_after_structural"]:
        return
    if workspace_id != state.focused_workspace_id:
        return
    logging.info("Centrando columnas visibles en workspace %s tras cambio estructural (%s).", workspace_id, reason)
    _mark_programmatic_layout_change()
    ipc.action("CenterVisibleColumns")

_last_structural_actions = {}

def _send_structural_action(
    workspace_id: int,
    action_key: int,
    action_name: str,
    description: str,
    *,
    action_id: int | None = None,
    focus_id: int | None = None
) -> bool:
    now = time.monotonic()
    cooldown = config["structural_action_cooldown_ms"] / 1000.0
    key = (workspace_id, action_key, action_name)

    # Evita repetir la misma acción mientras Niri aún publica el layout nuevo.
    if now - _last_structural_actions.get(key, 0.0) < cooldown:
        logging.debug("Omitiendo acción estructural repetida para clave %s: %s", action_key, action_name)
        return False

    _last_structural_actions[key] = now
    if len(_last_structural_actions) > 256:
        stale_before = now - max(cooldown * 4, 2.0)
        for stale_key, timestamp in list(_last_structural_actions.items()):
            if timestamp < stale_before:
                _last_structural_actions.pop(stale_key, None)

    logging.info(description)
    if focus_id is not None:
        ipc.action("FocusWindow", id=focus_id)
    if action_id is not None:
        _mark_programmatic_layout_change()
        ipc.action(action_name, id=action_id)
    else:
        _mark_programmatic_layout_change()
        ipc.action(action_name)
    _schedule_followup_retile(workspace_id)
    return True

def _columns_by_position(tiled_wins):
    cols = {}
    for win in tiled_wins:
        col = win.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])[0]
        cols.setdefault(col, []).append(win)
    for wins in cols.values():
        wins.sort(key=_window_sort_key)
    return cols

def _column_width_is_close(workspace_id: int, win: dict, expected_pct: float) -> bool:
    win_output = state.workspaces.get(workspace_id, {}).get("output")
    output_width = state.output_widths.get(win_output)
    col_width = win.get("layout", {}).get("tile_size", [0, 0])[0]
    if not output_width or not col_width:
        return False
    return _ratio_is_close((col_width / output_width) * 100.0, expected_pct)

def _window_width_pct_of_output(workspace_id: int, win: dict) -> float | None:
    win_output = state.workspaces.get(workspace_id, {}).get("output")
    output_width = state.output_widths.get(win_output)
    col_width = win.get("layout", {}).get("tile_size", [0, 0])[0]
    if not output_width or not col_width:
        return None
    return (col_width / output_width) * 100.0

def _set_column_width_if_needed(workspace_id: int, win_id: int, win: dict, expected_pct: float, label: str):
    if _column_width_is_close(workspace_id, win, expected_pct):
        return
    logging.info(f"Ajustando ancho de columna {label} ({win_id}) a {expected_pct}%")
    ipc.action("FocusWindow", id=win_id)
    _mark_programmatic_layout_change()
    ipc.action("SetColumnWidth", change={"SetProportion": expected_pct})

# ── Lógicas de Retiling ───────────────────────────────────────────────────────
def retile_master_stack(workspace_id, tiled_wins):
    master_win = min(tiled_wins, key=lambda w: w["id"])
    master_id = master_win["id"]
    master_col = master_win.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])[0]
    cols = _columns_by_position(tiled_wins)

    for w in tiled_wins:
        if w["id"] == master_id:
            continue

        pos = w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])
        col_idx = pos[0]
        win_id = w["id"]

        if col_idx == master_col:
            if _send_structural_action(
                workspace_id,
                win_id,
                "ConsumeOrExpelWindowRight",
                f"Expeliendo ventana {win_id} a la derecha de la columna maestra",
                action_id=win_id
            ):
                return
        elif col_idx < master_col:
            if _send_structural_action(
                workspace_id,
                win_id,
                "ConsumeOrExpelWindowRight",
                f"Consumiendo ventana {win_id} a la derecha hacia la columna maestra",
                action_id=win_id
            ):
                return

    # Verificar si las proporciones ya son correctas para romper bucles de eventos
    cols = _columns_by_position(tiled_wins)
    col_representatives = {col: wins[0] for col, wins in cols.items()}

    if len(col_representatives) == 2:
        total_width = sum(w["layout"]["tile_size"][0] for w in col_representatives.values() if "layout" in w and "tile_size" in w["layout"])
        if total_width > 0:
            master_width = master_win["layout"]["tile_size"][0]
            curr_master_ratio = (master_width / total_width) * 100.0
            if _ratio_is_close(curr_master_ratio, config["master_ratio"]):
                logging.info(f"Las proporciones Master-Stack ya son correctas ({curr_master_ratio:.1f}% vs {config['master_ratio']}%). Omitiendo redimensionado.")
                return
    elif len(col_representatives) > 2:
        logging.info("Master-Stack con %s columnas: aplicando anchos estables sin fusionar columnas para evitar oscilaciones.", len(col_representatives))

    # Si todo está estructurado, ajustar anchos
    master_ratio = float(config["master_ratio"])
    _set_column_width_if_needed(workspace_id, master_id, master_win, master_ratio, "maestra")

    secondary_cols = [col for col in sorted(col_representatives) if col != master_col]
    stack_ratio = (100.0 - master_ratio) / max(1, len(secondary_cols))
    for col, win in sorted(col_representatives.items()):
        if col == master_col:
            continue
        _set_column_width_if_needed(workspace_id, win["id"], win, stack_ratio, f"stack {col}")

def retile_equal_columns(workspace_id, tiled_wins):
    for w in tiled_wins:
        pos = w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])
        row_idx = pos[1]
        if row_idx > 0:
            win_id = w["id"]
            if _send_structural_action(
                workspace_id,
                win_id,
                "ConsumeOrExpelWindowRight",
                f"Expeliendo ventana {win_id} a la derecha para hacer columna independiente",
                action_id=win_id
            ):
                return

    # Verificar si las columnas ya están repartidas equitativamente
    cols = {}
    for w in tiled_wins:
        col = w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])[0]
        if col not in cols:
            cols[col] = w

    n = len(tiled_wins)
    if len(cols) == n:
        total_width = sum(w["layout"]["tile_size"][0] for w in cols.values() if "layout" in w and "tile_size" in w["layout"])
        if total_width > 0:
            target_pct = 100.0 / n
            all_correct = True
            for w in cols.values():
                w_pct = (w["layout"]["tile_size"][0] / total_width) * 100.0
                if not _ratio_is_close(w_pct, target_pct):
                    all_correct = False
                    break
            if all_correct:
                logging.info(f"Las proporciones Equal-Columns ya son correctas (todas cercanas a {target_pct:.1f}%). Omitiendo redimensionado.")
                return

    # Ajustar cada una al mismo tamaño
    target_pct = 100.0 / n
    for w in tiled_wins:
        win_id = w["id"]
        logging.info(f"Ajustando ventana {win_id} a ancho equitativo {target_pct:.2f}%")
        ipc.action("FocusWindow", id=win_id)
        _mark_programmatic_layout_change()
        ipc.action("SetColumnWidth", change={"SetProportion": target_pct})

def retile(workspace_id: int):
    if not config["enabled"]:
        return

    # Verificación de foco del workspace activo
    if workspace_id != state.focused_workspace_id:
        state.dirty_workspaces.add(workspace_id)
        logging.debug(f"Retile en workspace {workspace_id} abortado. Workspace no activo. Marcado como dirty.")
        return

    state.dirty_workspaces.discard(workspace_id)

    tiled_wins = _iter_workspace_tiled_windows(workspace_id)

    n = len(tiled_wins)

    if n == 0:
        logging.debug(f"Retile en workspace {workspace_id} omitido: no hay ventanas gestionables.")
        return

    logging.info(f"Ejecutando retile en workspace {workspace_id} con {n} ventanas.")

    focused_before = state.focused_window_id

    if n == 1:
        win_id = tiled_wins[0]["id"]

        if not config["single_window_fill"]:
            logging.info(f"Una sola ventana en workspace ({win_id}); preservando ancho actual para permitir redimensionado manual.")
            return
        
        # Verificar por porcentaje para tolerar gaps, struts y monitores 4:3, 16:9 o ultrawide.
        current_pct = _window_width_pct_of_output(workspace_id, tiled_wins[0])
        if current_pct is not None:
            threshold = config["single_window_full_threshold_pct"]
            if current_pct >= threshold:
                logging.info(f"La ventana única {win_id} ya ocupa {current_pct:.1f}% del monitor (umbral {threshold:.1f}%). Omitiendo.")
                return

        logging.info(f"Solo 1 ventana en workspace. Maximizando {win_id}.")
        ipc.action("FocusWindow", id=win_id)
        _mark_programmatic_layout_change()
        ipc.action("SetColumnWidth", change={"SetProportion": 100.0})
    elif config["stack_mode"] == "master_stack":
        retile_master_stack(workspace_id, tiled_wins)
    else:
        retile_equal_columns(workspace_id, tiled_wins)

    # Restaurar el foco original
    if focused_before and focused_before in state.windows:
        if state.focused_window_id != focused_before:
            logging.info(f"Restaurando foco original a ventana {focused_before}")
            ipc.action("FocusWindow", id=focused_before)

# ── Debounce y Planificación ──────────────────────────────────────────────────
_retile_timers = {}
_retile_lock = threading.Lock()

def schedule_retile(workspace_id, force=False, reason=""):
    if workspace_id is None:
        return

    if _manual_layout_active(workspace_id) and not force and not _single_window_fill_required(workspace_id):
        logging.debug("Retile en workspace %s pospuesto: redimensionado manual reciente.", workspace_id)
        return

    if workspace_id != state.focused_workspace_id:
        state.dirty_workspaces.add(workspace_id)
        if reason:
            logging.debug("Retile en workspace %s (%s) marcado dirty: workspace no activo.", workspace_id, reason)
        return

    state.dirty_workspaces.discard(workspace_id)

    if workspace_id in _retile_timers:
        _retile_timers[workspace_id].cancel()

    def run():
        try:
            with _retile_lock:
                retile(workspace_id)
                if force:
                    _center_visible_columns_if_needed(workspace_id, reason or "forced-retile")
        except Exception as e:
            logging.error(f"Error realizando retile en workspace {workspace_id}: {e}", exc_info=True)
        finally:
            _retile_timers.pop(workspace_id, None)

    delay = (min(config["debounce_ms"], 80) if force else config["debounce_ms"]) / 1000.0
    timer = threading.Timer(delay, run)
    _retile_timers[workspace_id] = timer
    timer.start()

# ── Loop Principal y Manejo de Señales ────────────────────────────────────────
def shutdown(signum, frame):
    logging.info("Apagando autotiler de Niri...")
    for timer in list(_retile_timers.values()):
        timer.cancel()
    sys.exit(0)

def main():
    global ipc
    load_config()

    socket_path = find_niri_socket()
    if not socket_path:
        logging.error("No se pudo resolver el socket UNIX de Niri. Saliendo...")
        sys.exit(1)

    ipc = NiriIPC(socket_path)

    # Registrar señales para apagado limpio
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # Cargar estado inicial
    try:
        out_res = ipc.request("Outputs")
        if "Ok" in out_res and "Outputs" in out_res["Ok"]:
            state.output_widths = {}
            for name, data in out_res["Ok"]["Outputs"].items():
                logical = data.get("logical")
                if logical:
                    state.output_widths[name] = logical.get("width")

        ws_res = ipc.request("Workspaces")
        if "Ok" in ws_res and "Workspaces" in ws_res["Ok"]:
            state.workspaces = {ws["id"]: ws for ws in ws_res["Ok"]["Workspaces"]}
            for ws in state.workspaces.values():
                if ws["is_focused"]:
                    state.focused_workspace_id = ws["id"]

        win_res = ipc.request("Windows")
        if "Ok" in win_res and "Windows" in win_res["Ok"]:
            state.windows = {w["id"]: w for w in win_res["Ok"]["Windows"]}
            for w in state.windows.values():
                if w["is_focused"]:
                    state.focused_window_id = w["id"]

        logging.info(f"Estado inicial cargado: {len(state.workspaces)} workspaces, {len(state.windows)} ventanas, {len(state.output_widths)} monitores.")
        if state.focused_workspace_id:
            logging.info(f"Workspace inicial enfocado: {state.focused_workspace_id}. Programando retileo.")
            schedule_retile(state.focused_workspace_id)
    except Exception as e:
        logging.error(f"Error cargando estado inicial: {e}", exc_info=True)

    # Escuchar eventos
    for event in ipc.event_stream():
        try:
            event_name = list(event.keys())[0]
            event_data = event[event_name]
            before_signature = _managed_window_signature_by_workspace()

            # Capturar workspace antes de eliminar la ventana del estado
            closed_win_workspace_id = None
            opened_or_changed_workspace_id = None
            existing_window_change_is_structural = False
            if event_name == "WindowClosed":
                win_id = event_data["id"]
                if win_id in state.windows:
                    closed_win_workspace_id = state.windows[win_id].get("workspace_id")
            elif event_name == "WindowOpenedOrChanged":
                new_win = event_data["window"]
                old_win = state.windows.get(new_win.get("id"))
                opened_or_changed_workspace_id = new_win.get("workspace_id")
                if old_win is None:
                    existing_window_change_is_structural = True
                else:
                    existing_window_change_is_structural = (
                        old_win.get("workspace_id") != new_win.get("workspace_id")
                        or _is_special_layout_window(old_win) != _is_special_layout_window(new_win)
                    )

            # Actualizar estado interno
            update_state(event_name, event_data)
            after_signature = _managed_window_signature_by_workspace()

            structurally_changed_workspaces = set()
            if event_name in ("WindowsChanged", "WindowOpenedOrChanged", "WindowClosed"):
                all_workspace_ids = set(before_signature) | set(after_signature)
                for ws_id in all_workspace_ids:
                    if before_signature.get(ws_id, ()) != after_signature.get(ws_id, ()):
                        structurally_changed_workspaces.add(ws_id)

            # Determinar qué workspace ha cambiado
            ws_id_to_retile = None 
            if event_name == "WindowOpenedOrChanged":
                if existing_window_change_is_structural:
                    ws_id_to_retile = opened_or_changed_workspace_id
                else:
                    logging.debug("WindowOpenedOrChanged no estructural; preservando layout manual.")
            elif event_name == "WindowClosed":
                ws_id_to_retile = closed_win_workspace_id or state.focused_workspace_id
            elif event_name == "WindowsChanged":
                if structurally_changed_workspaces:
                    logging.info("WindowsChanged estructural en workspaces %s. Programando retile forzado.", sorted(structurally_changed_workspaces))
                    for changed_ws_id in structurally_changed_workspaces:
                        schedule_retile(changed_ws_id, force=True, reason="windows-changed")
                        _schedule_structural_followups(changed_ws_id, "windows-changed-followup")
            elif event_name == "WindowLayoutsChanged":
                if time.monotonic() > state.programmatic_layout_until:
                    changed_workspaces = {
                        state.windows[win_id].get("workspace_id")
                        for win_id, _new_layout in event_data["changes"]
                        if win_id in state.windows
                    }
                    for changed_ws_id in changed_workspaces:
                        _mark_manual_layout_change(changed_ws_id)
                    logging.debug("WindowLayoutsChanged manual; activando gracia anti-retile para %s.", changed_workspaces)
                else:
                    logging.debug("WindowLayoutsChanged programático; no se marca como resize manual.")
            elif event_name == "WorkspaceActivated":
                if event_data["focused"]:
                    ws_id = event_data["id"]
                    logging.info(f"Workspace {ws_id} activado. Verificando layout...")
                    schedule_retile(ws_id)
                    # Si al activar el workspace está marcado como dirty, retilear
                    if ws_id in state.dirty_workspaces:
                        logging.info(f"Workspace {ws_id} activado y marcado como dirty. Procesando retileo...")
                        schedule_retile(ws_id)

            if ws_id_to_retile:
                force = event_name in ("WindowClosed",) or ws_id_to_retile in structurally_changed_workspaces
                schedule_retile(ws_id_to_retile, force=force, reason=event_name)
                if force:
                    _schedule_structural_followups(ws_id_to_retile, f"{event_name}-followup")

        except Exception as e:
            logging.error(f"Error procesando evento del stream: {e}", exc_info=True)

if __name__ == "__main__":
    main()
