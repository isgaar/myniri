#!/bin/bash

# ── Lock: evita doble ejecución ─────────────────────────────────
_SCRIPT_NAME=$(basename "$0" .sh)
_LOCKFILE="/tmp/${_SCRIPT_NAME}.lock"
if [ -e "$_LOCKFILE" ]; then
  _pid=$(cat "$_LOCKFILE")
  if kill -0 "$_pid" 2>/dev/null; then
    exit 0
  fi
fi
echo $$ > "$_LOCKFILE"
trap "rm -f $_LOCKFILE" EXIT INT TERM

# audio_menu.sh — Font Awesome 6 via printf codepoints

VOL_HIGH=$(printf '\uf028')   # fa-volume-high
HEADPHONES=$(printf '\uf590') # fa-headphones
BLUETOOTH=$(printf '\uf294')  # fa-bluetooth
DISPLAY=$(printf '\uf26c')    # fa-display
VOL_LOW=$(printf '\uf027')    # fa-volume-low
PLUG=$(printf '\uf1e6')       # fa-plug
MUSIC=$(printf '\uf001')      # fa-music (prompt)

declare -A ICONS=(
  ["jbl"]="$HEADPHONES  JBL / Harman (USB)"
  ["harman"]="$HEADPHONES  JBL / Harman (USB)"
  ["headset"]="$HEADPHONES  Headset (USB)"
  ["bluez"]="$BLUETOOTH  Bluetooth"
  ["bluetooth"]="$BLUETOOTH  Bluetooth"
  ["hdmi"]="$DISPLAY  HDMI / DisplayPort"
  ["dp"]="$DISPLAY  HDMI / DisplayPort"
  ["displayport"]="$DISPLAY  HDMI / DisplayPort"
  ["analog"]="$VOL_LOW  Bocinas integradas"
  ["pci"]="$VOL_LOW  Bocinas integradas"
  ["alc"]="$VOL_LOW  Bocinas integradas"
  ["headphone"]="$PLUG  Audifonos Jack 3.5mm"
  ["jack"]="$PLUG  Audifonos Jack 3.5mm"
)

get_friendly_name() {
  local sink_name="${1,,}"
  for pattern in "${!ICONS[@]}"; do
    if [[ "$sink_name" == *"$pattern"* ]]; then
      echo "${ICONS[$pattern]}"
      return
    fi
  done
  echo "$VOL_HIGH  $1"
}

default_sink=$(pactl get-default-sink)
menu_items=""
declare -A sink_map

while IFS=$'\t' read -r id name _rest; do
  friendly=$(get_friendly_name "$name")
  display="$friendly"
  if [[ "$name" == "$default_sink" ]]; then
    display="$friendly  ·activo·"
  fi
  if [[ -z "${sink_map["$display"]}" ]]; then
    menu_items+="${display}\n"
    sink_map["$display"]="$id"
  fi
done < <(pactl list sinks short | awk '{print $1"\t"$2}')

selected=$(printf "%b" "$menu_items" | wofi \
  --dmenu \
  --prompt "$MUSIC  Audio:" \
  --style ~/.config/wofi/audio.css \
  --width 360 \
  --height 220 \
  --hide-search \
  --no-actions \
  --cache-file /dev/null)

[[ -z "$selected" ]] && exit 0
sink_id="${sink_map[$selected]}"
[[ -z "$sink_id" ]] && exit 1

pactl set-default-sink "$sink_id"
pactl list sink-inputs short \
  | awk '{print $1}' \
  | xargs -r -I{} pactl move-sink-input {} "$sink_id" 2>/dev/null

label="${selected%%  ·*}"
notify-send --icon=audio-headphones --expire-time=2500 "Audio" "Activo: ${label}"
exit 0
