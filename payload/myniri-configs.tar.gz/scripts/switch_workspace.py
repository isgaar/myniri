#!/usr/bin/env python3
import subprocess
import json
import time
import sys

def get_workspace_nodes():
    try:
        tree = json.loads(subprocess.check_output(["swaymsg", "-t", "get_tree"]).decode("utf-8"))
    except Exception as e:
        return {}
    
    focused_ws = None
    
    def find_focused_ws(node):
        nonlocal focused_ws
        if node.get("type") == "workspace" and node.get("focused"):
            focused_ws = node
            return
        for child in node.get("nodes", []) + node.get("floating_nodes", []):
            find_focused_ws(child)
            if focused_ws:
                return

    find_focused_ws(tree)
    if not focused_ws:
        return {}
        
    opacities = {}
    def collect_leaf_opacities(node):
        if node.get("type") in ["con", "floating_con"]:
            if node.get("app_id") or node.get("window_properties") or node.get("name"):
                node_id = node.get("id")
                opacity = node.get("opacity")
                if opacity is None:
                    opacity = 1.0
                opacities[node_id] = opacity
        for child in node.get("nodes", []) + node.get("floating_nodes", []):
            collect_leaf_opacities(child)
            
    collect_leaf_opacities(focused_ws)
    return opacities

def fade_nodes(opacities, direction, steps=6, sleep_time=0.008):
    if not opacities:
        return
    for step in range(steps + 1):
        if direction == "out":
            scale = 1.0 - (step / steps)
        else: # "in"
            scale = step / steps
            
        cmds = []
        for nid, orig in opacities.items():
            val = scale * orig
            val = max(0.0, min(1.0, val))
            cmds.append(f"[con_id={nid}] opacity {val:.2f}")
            
        cmd_str = "; ".join(cmds)
        subprocess.run(["swaymsg", cmd_str], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if step < steps:
            time.sleep(sleep_time)

def get_focused_output():
    try:
        outputs = json.loads(subprocess.check_output(["swaymsg", "-t", "get_outputs"]).decode("utf-8"))
        for o in outputs:
            if o.get("focused"):
                return o["name"]
    except:
        pass
    return None

def switch_workspace(target):
    focused_output = get_focused_output()
    try:
        workspaces = json.loads(subprocess.check_output(["swaymsg", "-t", "get_workspaces"]).decode("utf-8"))
    except:
        workspaces = []

    current_ws = next((ws for ws in workspaces if ws.get("focused")), None)
    current_num = current_ws.get("num") if current_ws else 1

    target_num = None
    if target.isdigit():
        target_num = int(target)
    elif target == "next":
        target_num = current_num + 1
    elif target == "prev":
        target_num = current_num - 1
        if target_num < 1:
            target_num = 1

    if target_num is not None:
        if focused_output:
            for ws in workspaces:
                if ws.get("num") == target_num and ws.get("output") != focused_output:
                    # Move using exact workspace name to avoid mismatches
                    ws_name = ws.get("name")
                    subprocess.run(["swaymsg", f'[workspace="{ws_name}"]', f"move workspace to output {focused_output}"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    break
        subprocess.run(["swaymsg", f"workspace number {target_num}"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif target in ["next_on_output", "prev_on_output"]:
        subprocess.run(["swaymsg", f"workspace {target.replace('_on_output', '')}"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        subprocess.run(["swaymsg", f"workspace {target}"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def main():
    if len(sys.argv) < 2:
        print("Usage: switch_workspace.py <target_workspace>")
        sys.exit(1)
    target = sys.argv[1]
    
    # 1. Collect current windows and fade them out
    current_opacities = get_workspace_nodes()
    fade_nodes(current_opacities, "out", steps=6, sleep_time=0.008)
    
    # 2. Switch workspace
    switch_workspace(target)
    
    # 3. Restore the old workspace's windows opacity immediately in the background
    if current_opacities:
        restore_cmds = [f"[con_id={nid}] opacity {orig:.2f}" for nid, orig in current_opacities.items()]
        subprocess.run(["swaymsg", "; ".join(restore_cmds)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
    # 4. Collect new windows, set to 0.0 opacity immediately, then fade them in
    new_opacities = get_workspace_nodes()
    if new_opacities:
        # Set to 0 opacity instantly
        fade_nodes(new_opacities, "in", steps=0, sleep_time=0.0)
        # Fade in
        fade_nodes(new_opacities, "in", steps=6, sleep_time=0.008)

if __name__ == "__main__":
    main()
