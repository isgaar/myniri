#!/bin/bash
# /home/ismael/scripts/open_files.sh

PATH_TO_OPEN="${1:-$HOME}"

for explorer in nautilus thunar nemo dolphin pcmanfm xdg-open; do
    if which "$explorer" >/dev/null 2>&1; then
        "$explorer" "$PATH_TO_OPEN" >/dev/null 2>&1 &
        exit 0
    fi
done

notify-send --icon=dialog-error "Sin explorador" "No se encontró un explorador de archivos"
exit 1
