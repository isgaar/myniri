#!/bin/bash
# get_clipboard_json.sh - Devuelve un JSON estructurado con el historial de cliphist

if ! command -v cliphist >/dev/null 2>&1; then
    echo "[]"
    exit 0
fi

list=$(cliphist list 2>/dev/null | head -n 30)
if [ -z "$list" ]; then
    echo "[]"
    exit 0
fi

echo "["
first=true

# Leer el listado de cliphist
echo "$list" | while IFS= read -r line; do
    [ -z "$line" ] && continue

    # Extraer el ID (todo antes del primer tab) y el contenido (todo después)
    id=$(echo "$line" | cut -f1)
    content=$(echo "$line" | cut -f2-)

    # Detectar si es imagen o binario
    if [[ "$content" == *"[[ binary data"* ]]; then
        type="image"
        preview="[Imagen]"
    else
        type="text"
        # Escapar caracteres de JSON y limitar a 80 caracteres
        clean_content=$(echo -n "$content" | tr -d '\r' | tr '\n' ' ' | sed 's/\\/\\\\/g' | sed 's/"/\\"/g')
        preview=$(echo -n "$clean_content" | cut -c 1-80)
    fi

    if [ "$first" = true ]; then
        first=false
    else
        echo ","
    fi

    printf '  {"id": "%s", "preview": "%s", "type": "%s"}' "$id" "$preview" "$type"
done
echo ""
echo "]"
