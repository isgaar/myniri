#!/bin/bash
# clipboard_paste.sh - Decodifica una entrada de cliphist, la copia al portapapeles y simula Ctrl+V

if [ -z "${1:-}" ]; then
    echo "Uso: $0 <id>"
    exit 1
fi

id="$1"

# Poner en el portapapeles activo
if ! cliphist decode "$id" | wl-copy; then
    echo "Error al decodificar la entrada $id"
    exit 1
fi

# Esperar 150ms
sleep 0.15

# Intentar simular Ctrl+V
if command -v ydotool >/dev/null 2>&1; then
    ydotool key 29:1 47:1 47:0 29:0
elif command -v wtype >/dev/null 2>&1; then
    wtype -M ctrl -k v -m ctrl
elif command -v xdotool >/dev/null 2>&1; then
    xdotool key ctrl+v
else
    notify-send -t 1500 "Portapapeles" "Pegado (Usa Ctrl+V para pegar)"
fi

exit 0
