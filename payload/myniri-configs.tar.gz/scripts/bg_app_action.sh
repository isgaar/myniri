#!/bin/bash
# ~/scripts/bg_app_action.sh
# Usage: bg_app_action.sh <action> <process> <cmd> <class_or_id>

action=$1
process=$2
cmd=$3
class_or_id=$4

if [ "$action" = "focus" ]; then
    # Convert class_or_id to lowercase for case-insensitive matching
    class_or_id_lower=$(echo "$class_or_id" | tr '[:upper:]' '[:lower:]')
    
    # Intenta obtener el identificador exacto (app_id o class) de la ventana abierta usando jq
    exact_id=$(swaymsg -t get_tree | jq -r '.. | select((.app_id? != null and (.app_id | ascii_downcase | contains("'"$class_or_id_lower"'"))) or (.window_properties?.class? != null and (.window_properties.class | ascii_downcase | contains("'"$class_or_id_lower"'")))) | if .app_id != null then .app_id else .window_properties.class end' | head -n 1)

    if [ -n "$exact_id" ] && [ "$exact_id" != "null" ]; then
        # Enfoca la ventana usando el identificador exacto encontrado
        swaymsg "[app_id=\"$exact_id\"] focus" >/dev/null 2>&1 || swaymsg "[class=\"$exact_id\"] focus" >/dev/null 2>&1
        # Por si estaba en scratchpad, a veces requiere un show
        swaymsg "[app_id=\"$exact_id\"] scratchpad show" >/dev/null 2>&1
        swaymsg "[class=\"$exact_id\"] scratchpad show" >/dev/null 2>&1
    else
        # Si no existe la ventana, se ejecuta el comando de inicio
        swaymsg exec "$cmd" >/dev/null 2>&1
    fi
elif [ "$action" = "kill" ]; then
    pkill -f -i "\\b$process\\b" || killall -I "$process"
fi

exit 0
