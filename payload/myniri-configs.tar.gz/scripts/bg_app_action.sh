#!/bin/bash
# ~/scripts/bg_app_action.sh
# Usage: bg_app_action.sh <action> <process> <cmd> <class_or_id>

action=$1
process=$2
cmd=$3
class_or_id=$4

if [ "$action" = "focus" ]; then
    # Convert class_or_id to lowercase for case-insensitive matching
    class_or_id_lower=$(echo "$class_or_id" | tr '[:upper:]' '[:lower:]')
    
    # Intenta obtener el ID de la ventana abierta usando jq
    exact_win_id=$(niri msg --json windows 2>/dev/null | jq -r ".[] | select(.app_id != null and (.app_id | ascii_downcase | contains(\"$class_or_id_lower\"))) | .id" | head -n 1)

    if [ -n "$exact_win_id" ] && [ "$exact_win_id" != "null" ]; then
        # Enfoca la ventana en Niri
        niri msg action focus-window --id "$exact_win_id" >/dev/null 2>&1
    else
        # Si no existe la ventana, se ejecuta el comando de inicio a través de niri spawn
        niri msg action spawn -- sh -c "$cmd" >/dev/null 2>&1
    fi
elif [ "$action" = "kill" ]; then
    pkill -f -i "\\b$process\\b" || killall -I "$process"
fi

exit 0
