#!/bin/bash
# /home/ismael/scripts/get_eject_devices_json.sh

OUT=$(lsblk -J -o NAME,LABEL,SIZE,MOUNTPOINT,HOTPLUG,TYPE 2>/dev/null)
if [ -n "$OUT" ]; then
    echo "$OUT" | jq -c '[.blockdevices[]? | .. | objects | select(.type? == "part" and .hotplug? == true) | {device: ("/dev/" + .name), name: (if .label != null and .label != "" then .label else ("USB " + .name) end), size: .size, mountpoint: (.mountpoint // "")}]' 2>/dev/null || echo "[]"
else
    echo "[]"
fi
