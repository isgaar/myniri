#!/bin/bash
PRIMARY_FILE="$HOME/.config/quickshell/primary_monitor.txt"
if [ -f "$PRIMARY_FILE" ]; then
    PRIMARY=$(cat "$PRIMARY_FILE")
    # Verify it is active in Niri
    if niri msg --json outputs | jq -e ".[] | select(.name == \"$PRIMARY\")" >/dev/null; then
        echo "$PRIMARY"
        exit 0
    fi
fi
# Fallback to first active in Niri
niri msg --json outputs | jq -r '.[0].name // ""'
