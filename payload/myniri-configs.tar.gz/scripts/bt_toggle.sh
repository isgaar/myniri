#!/bin/bash

if bluetoothctl show 2>/dev/null | grep -q 'Powered: yes'; then
    bluetoothctl power off >/dev/null 2>&1
    rfkill block bluetooth >/dev/null 2>&1
    notify-send --icon=bluetooth "Bluetooth" "Apagado"
else
    rfkill unblock bluetooth >/dev/null 2>&1
    bluetoothctl power on >/dev/null 2>&1
    notify-send --icon=bluetooth "Bluetooth" "Encendido"
fi

pkill -RTMIN+8 waybar 2>/dev/null || true
