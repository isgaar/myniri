#!/bin/bash

STATE_FILE="$HOME/.local/share/bluetooth-state"
mkdir -p "$(dirname "$STATE_FILE")"

if bluetoothctl show 2>/dev/null | grep -q 'Powered: yes'; then
    bluetoothctl power off >/dev/null 2>&1
    rfkill block bluetooth >/dev/null 2>&1
    echo "blocked" > "$STATE_FILE"
    notify-send --icon=bluetooth "Bluetooth" "Apagado"
else
    rfkill unblock bluetooth >/dev/null 2>&1
    bluetoothctl power on >/dev/null 2>&1
    echo "unblocked" > "$STATE_FILE"
    notify-send --icon=bluetooth "Bluetooth" "Encendido"
fi

# NOTA: Se eliminó 'pkill -RTMIN+8 waybar' porque usas una barra QML personalizada.
# Si tu barra QML requiere alguna señal o comando para actualizarse, puedes agregarlo aquí.
