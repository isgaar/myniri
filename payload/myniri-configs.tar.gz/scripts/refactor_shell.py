#!/usr/bin/env python3
import os
import re

def main():
    filepath = "/home/ismael/.config/quickshell/unified/shell.qml"
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # 1. Insert updateNotificationMargin() function after closeAllPopups()
    close_all_popups_end = "if (launcherDialogLoader.active && launcherDialogLoader.item) launcherDialogLoader.item.close()\n    }"
    
    margin_func = """

    function updateNotificationMargin(): void {
        let base = 45
        let loaders = [
            panelLoader, wifimenuLoader, volumeDialogLoader, micDialogLoader,
            calendarLoader, powerDialogLoader, batteryLoader, bgappsLoader, notificationsLoader
        ]
        for (let i = 0; i < loaders.length; i++) {
            let l = loaders[i]
            if (l.active && l.item && l.item.visible) {
                notificationPopup.topMargin = (l.item.margins.top || 0) + l.item.contentHeight + 8
                return
            }
        }
        notificationPopup.topMargin = base
    }"""

    if "function updateNotificationMargin()" not in content:
        idx = content.find(close_all_popups_end)
        if idx != -1:
            insert_pos = idx + len(close_all_popups_end)
            content = content[:insert_pos] + margin_func + content[insert_pos:]
            print("✔ Injected updateNotificationMargin() function.")

    # 2. Add asynchronous: true to loaders and inject updateNotificationMargin() in onLoaded
    # We can match each Loader definition. A loader block looks like:
    # Loader {
    #     id: panelLoader
    #     active: false
    #     ...
    # }
    
    loader_pattern = r'(Loader\s*\{\s*id:\s*(\w+)\s*\n\s*active:\s*false)'
    # We replace with active: false and asynchronous: true
    content = re.sub(loader_pattern, r'\1\n        asynchronous: true', content)
    print("✔ Added asynchronous: true to all loaders.")

    # Let's inject shellRoot.updateNotificationMargin() inside the visibleChanged.connect callback
    # and at the end of onLoaded block of each loader.
    # We can do this safely by matching:
    # visibleChanged.connect(function() {
    #     if (item && !item.visible) ...Loader.unloadTimer.restart()
    #     else if (item && item.visible) ...Loader.unloadTimer.stop()
    # })
    # And replacing the closing brace of connect callback.
    
    connect_pattern = r'(visibleChanged\.connect\(function\(\)\s*\{\s*\n\s*if\s*\(item\s*&&\s*!item\.visible\)\s*\w+Loader\.unloadTimer\.restart\(\)\s*\n\s*else\s*if\s*\(item\s*&&\s*item\.visible\)\s*\w+Loader\.unloadTimer\.stop\(\)\s*\n\s*\})'
    
    # Let's replace the last brace of the connect callback with the call added
    def connect_repl(match):
        orig = match.group(1)
        # remove last '}' and replace with updater and '}'
        if "updateNotificationMargin" not in orig:
            return orig[:-1] + "    shellRoot.updateNotificationMargin()\n            })"
        return orig

    content = re.sub(r'(visibleChanged\.connect\(function\(\)\s*\{\s*[^}]*\n\s*else\s*if\s*\(item\s*&&\s*item\.visible\)\s*[^}]*\n\s*\})', connect_repl, content)
    print("✔ Injected updateNotificationMargin() into visibleChanged connections.")

    # Now let's inject shellRoot.updateNotificationMargin() at the end of onLoaded of each loader.
    # The end of onLoaded is right before the closing brace of onLoaded.
    # We can match:
    #         onLoaded: {
    #             ...
    #         }
    # Let's find onLoaded blocks and inject it right before the closing brace of onLoaded.
    # Wait, instead of general regex, let's do a replace for the known onLoaded blocks.
    # Actually, we can search for the loaders we want to modify.
    
    loaders_to_update = [
        "panelLoader", "notificationsLoader", "batteryLoader", "memoryLoader",
        "bgappsLoader", "wifimenuLoader", "wifiPasswordDialogLoader", "shortcutsDialogLoader",
        "launcherDialogLoader", "polkitDialogLoader", "volumeDialogLoader", "micDialogLoader",
        "calendarLoader", "powerDialogLoader", "settingsWindowLoader"
    ]
    
    for l in loaders_to_update:
        # Match from onLoaded: { to the next } of the loader
        # Let's do a specific search for the closing of onLoaded
        # In panelLoader:
        #             shellRoot.openLoadedItem(item, posXToOpen)
        #             posXToOpen = undefined
        #         }
        # In wifiPasswordDialogLoader:
        #             if (pendingSsid !== "") {
        #                 item.open(pendingSsid, pendingCallback)
        #                 pendingSsid = ""
        #                 pendingCallback = null
        #             }
        #         }
        
        # Let's write a robust parser for onLoaded block
        # We find: id: <loader> ... onLoaded: { <any content> }
        # And inject shellRoot.updateNotificationMargin() right before the last closing brace of onLoaded.
        
        # We can find the start of loader, then find onLoaded: {
        loader_start_idx = content.find(f"id: {l}")
        if loader_start_idx != -1:
            on_loaded_idx = content.find("onLoaded: {", loader_start_idx)
            if on_loaded_idx != -1:
                # Find the matching closing brace for onLoaded
                # Since onLoaded block has nested braces (like visibleChanged.connect and ifs),
                # we count braces to find the end of onLoaded: {
                brace_count = 1
                curr_idx = on_loaded_idx + len("onLoaded: {")
                while brace_count > 0 and curr_idx < len(content):
                    if content[curr_idx] == '{':
                        brace_count += 1
                    elif content[curr_idx] == '}':
                        brace_count -= 1
                    curr_idx += 1
                
                # curr_idx is now right after the closing brace of onLoaded
                end_brace_pos = curr_idx - 1
                
                # Check if it already has the margin update
                on_loaded_block = content[on_loaded_idx:end_brace_pos]
                # Let's count how many times "updateNotificationMargin" appears.
                # It should appear twice: once in visibleChanged.connect, once at the end of onLoaded.
                if on_loaded_block.count("updateNotificationMargin") < 2:
                    # Inject right before the end brace
                    content = content[:end_brace_pos] + "        shellRoot.updateNotificationMargin()\n        " + content[end_brace_pos:]
                    print(f"  ✔ Injected updateNotificationMargin() at end of {l}.onLoaded.")

    # 3. Replace NotificationPopup block at the bottom of shell.qml
    # We search for:
    # NotificationPopup {
    #     id: notificationPopup
    #     topMargin: {
    #         ...
    #     }
    #     onTopMarginChanged: ...
    # }
    
    popup_pattern = r'NotificationPopup\s*\{\s*\n\s*id:\s*notificationPopup\s*\n\s*topMargin:\s*\{\s*\n\s*let\s*base\s*=\s*45[\s\S]*?onTopMarginChanged:[\s\S]*?\}'
    
    replacement_popup = """NotificationPopup {
        id: notificationPopup
        topMargin: 45
    }"""
    
    if "topMargin: 45" not in content:
        content = re.sub(popup_pattern, replacement_popup, content)
        print("✔ Replaced NotificationPopup dynamic binding with static property.")

    # Save the file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print("✔ Refactored shell.qml successfully!")

if __name__ == "__main__":
    main()
