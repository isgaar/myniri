#!/bin/bash
TYPE="$1"
TARGET="$2"
APP_NAME="$3"

if [ "$TYPE" = "screenshot" ]; then
    # Open the screenshot file with default image viewer or file manager
    if command -v gwenview &>/dev/null; then
        gwenview "$TARGET" >/dev/null 2>&1 &
    elif command -v loupe &>/dev/null; then
        loupe "$TARGET" >/dev/null 2>&1 &
    elif command -v eog &>/dev/null; then
        eog "$TARGET" >/dev/null 2>&1 &
    else
        xdg-open "$(dirname "$TARGET")" >/dev/null 2>&1 &
    fi
else
    # Try to focus the app that sent the notification
    APP_ID=$(echo "$TARGET" | sed 's/\.desktop$//')
    
    # 1. Try exact app_id match
    swaymsg "[app_id=\"$APP_ID\"] focus" >/dev/null 2>&1 && exit 0
    
    # 2. Try case-insensitive app_id
    swaymsg "[app_id=\"(?i)$APP_ID\"] focus" >/dev/null 2>&1 && exit 0
    
    # 3. Try class match
    swaymsg "[class=\"(?i)$APP_ID\"] focus" >/dev/null 2>&1 && exit 0
    
    # 4. Try APP_NAME if different from TARGET
    if [ -n "$APP_NAME" ] && [ "$APP_NAME" != "$APP_ID" ]; then
        swaymsg "[app_id=\"(?i)$APP_NAME\"] focus" >/dev/null 2>&1 && exit 0
        swaymsg "[class=\"(?i)$APP_NAME\"] focus" >/dev/null 2>&1 && exit 0
    fi
    
    # 5. Fallback: launch the app via desktop entry
    if command -v gtk-launch &>/dev/null; then
        gtk-launch "$APP_ID" >/dev/null 2>&1 &
    elif command -v dex &>/dev/null; then
        dex "/usr/share/applications/${APP_ID}.desktop" >/dev/null 2>&1 &
    else
        # Last resort: try to run the binary directly
        command "$APP_ID" >/dev/null 2>&1 &
    fi
fi
