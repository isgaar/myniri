#!/bin/bash
TYPE="$1"
TARGET="$2"
APP_NAME="$3"

if [ "$TYPE" = "screenshot" ]; then
    # Open the screenshot file with default image viewer or file manager
    if command -v gwenview &>/dev/null; then
        gwenview "$TARGET" >/dev/null 2>&1 &
    elif command -v loupe &>/dev/null; then
        loupe "$TARGET" >/dev/null 2>&1 &
    elif command -v eog &>/dev/null; then
        eog "$TARGET" >/dev/null 2>&1 &
    else
        xdg-open "$(dirname "$TARGET")" >/dev/null 2>&1 &
    fi
else
    # Try to focus the app that sent the notification
    APP_ID=$(echo "$TARGET" | sed 's/\.desktop$//')
    
    # 1. Try exact app_id match
    WIN_ID=$(niri msg --json windows 2>/dev/null | jq -r ".[] | select(.app_id == \"$APP_ID\") | .id" | head -n 1)
    if [ -n "$WIN_ID" ] && [ "$WIN_ID" != "null" ]; then
        niri msg action focus-window --id "$WIN_ID" >/dev/null 2>&1 && exit 0
    fi
    
    # 2. Try case-insensitive app_id
    WIN_ID=$(niri msg --json windows 2>/dev/null | jq -r ".[] | select(.app_id != null and (.app_id | ascii_downcase) == (\"$APP_ID\" | ascii_downcase)) | .id" | head -n 1)
    if [ -n "$WIN_ID" ] && [ "$WIN_ID" != "null" ]; then
        niri msg action focus-window --id "$WIN_ID" >/dev/null 2>&1 && exit 0
    fi
    
    # 3. Try APP_NAME if different from TARGET
    if [ -n "$APP_NAME" ] && [ "$APP_NAME" != "$APP_ID" ]; then
        WIN_ID=$(niri msg --json windows 2>/dev/null | jq -r ".[] | select(.app_id != null and ((.app_id | ascii_downcase) == (\"$APP_NAME\" | ascii_downcase) or (.title != null and (.title | ascii_downcase | contains(\"$APP_NAME\" | ascii_downcase))))) | .id" | head -n 1)
        if [ -n "$WIN_ID" ] && [ "$WIN_ID" != "null" ]; then
            niri msg action focus-window --id "$WIN_ID" >/dev/null 2>&1 && exit 0
        fi
    fi
    
    # 5. Fallback: launch the app via desktop entry
    if command -v gtk-launch &>/dev/null; then
        gtk-launch "$APP_ID" >/dev/null 2>&1 &
    elif command -v dex &>/dev/null; then
        dex "/usr/share/applications/${APP_ID}.desktop" >/dev/null 2>&1 &
    else
        # Last resort: try to run the binary directly
        command "$APP_ID" >/dev/null 2>&1 &
    fi
fi
