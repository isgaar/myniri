#!/bin/bash
# battery_popup.sh — Info de batería + selector de perfil (imagen 2)
# ── Lock ─────────────────────────────────────────────────
_LOCKFILE="/tmp/battery_popup.lock"
if [ -e "$_LOCKFILE" ]; then
  _pid=$(cat "$_LOCKFILE")
  if kill -0 "$_pid" 2>/dev/null; then exit 0; fi
fi
echo $$ > "$_LOCKFILE"
trap "rm -f $_LOCKFILE" EXIT INT TERM

# ── Datos de batería via upower ───────────────────────────
BAT_PATH=$(upower -e 2>/dev/null | grep -E "(BAT|battery)" | head -1)
if [ -z "$BAT_PATH" ]; then
    notify-send "Batería" "No se encontró batería" --icon=battery
    exit 0
fi

BAT_INFO=$(upower -i "$BAT_PATH" 2>/dev/null)

capacity=$(echo "$BAT_INFO" | awk '/percentage/{gsub(/%/,"",$2); printf "%s", $2}')
health=$(echo "$BAT_INFO"   | awk '/^[ \t]*capacity:/{printf "%s", $2}')
energy_full=$(echo "$BAT_INFO" | awk '/energy-full:/{printf "%s %s", $2, $3; exit}')
state=$(echo "$BAT_INFO"    | awk '/^[ \t]*state:/{print $2; exit}')
time_info=$(echo "$BAT_INFO" | grep -i "time to" | awk '{$1=""; $2=""; print}' | xargs)

# Estado legible
case "$state" in
    charging)       state_label="$(printf '\uf0e7') Cargando" ;;
    discharging)    state_label="$(printf '\uf241') Descargando" ;;
    fully-charged)  state_label="$(printf '\uf240') Carga completa" ;;
    *)              state_label="$state" ;;
esac

# Tiempo hasta lleno / vacío
[ -n "$time_info" ] && time_label=" • $time_info" || time_label=""

# ── Perfil de energía actual ──────────────────────────────
HAS_PROFILES=0
current_profile=""
if command -v powerprofilesctl &>/dev/null; then
    HAS_PROFILES=1
    current_profile=$(powerprofilesctl get 2>/dev/null || echo "balanced")
fi

# ── Construir menú ────────────────────────────────────────
CHECKMARK=$(printf '\uf00c')   # fa-check

mark() {
    [ "$1" = "$current_profile" ] && printf "%s " "$CHECKMARK" || printf "  "
}

# Header informativo (no seleccionable realmente, pero orienta al usuario)
HEADER_TEXT="$(printf '\uf240') ${capacity}%  ${state_label}${time_label}"
DIVIDER="──────────────────────────────"
INFO_LINE="$(printf '\uf21e') Salud: ${health:-N/A}    $(printf '\uf0e7') Cap: ${energy_full:-N/A}"

if [ "$HAS_PROFILES" -eq 1 ]; then
    OPT_SAVER="$(mark power-saver)$(printf '\uf04c')  Power Saver"
    OPT_BAL="$(mark balanced)$(printf '\uf074')  Balanced"
    OPT_PERF="$(mark performance)$(printf '\uf135')  Performance"

    SELECTED=$(printf "%s\n%s\n%s\n%s\n%s\n%s" \
        "$HEADER_TEXT" \
        "$INFO_LINE" \
        "$DIVIDER" \
        "$OPT_SAVER" \
        "$OPT_BAL" \
        "$OPT_PERF" | \
        wofi \
            --dmenu \
            --prompt "$(printf '\uf0e7')  Perfil:" \
            --style ~/.config/wofi/audio.css \
            --width 340 \
            --height 250 \
            --hide-search \
            --no-actions \
            --cache-file /dev/null)
else
    # Sin power-profiles-daemon: solo mostrar info
    notify-send "Batería" \
        "${capacity}%  ${state_label}${time_label}\nSalud: ${health:-N/A} | Capacidad: ${energy_full:-N/A}" \
        --icon=battery --expire-time=4000
    exit 0
fi

[[ -z "$SELECTED" ]] && exit 0
# Ignorar líneas de header/info/divider
[[ "$SELECTED" == "$HEADER_TEXT" || "$SELECTED" == "$INFO_LINE" || "$SELECTED" == "$DIVIDER" ]] && exit 0

# ── Aplicar perfil ────────────────────────────────────────
case "$SELECTED" in
    *"Power Saver"*)
        powerprofilesctl set power-saver
        notify-send "Perfil de energía" "Power Saver activado\nAhorro máximo de batería" \
            --icon=battery-low --expire-time=2500 ;;
    *"Balanced"*)
        powerprofilesctl set balanced
        notify-send "Perfil de energía" "Balanced activado\nRendimiento equilibrado" \
            --icon=battery-good --expire-time=2500 ;;
    *"Performance"*)
        powerprofilesctl set performance
        notify-send "Perfil de energía" "Performance activado\nMáximo rendimiento" \
            --icon=battery-full --expire-time=2500 ;;
esac
