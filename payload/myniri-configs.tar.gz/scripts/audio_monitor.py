#!/usr/bin/env python3
"""Monitor audio sink & source, output VOLUME <level> and MIC <level> [MUTED] lines."""
import subprocess, sys, select, os, signal

signal.signal(signal.SIGINT, signal.SIG_DFL)

def get_volume(sink=True):
    target = "@DEFAULT_AUDIO_SINK@" if sink else "@DEFAULT_AUDIO_SOURCE@"
    try:
        out = subprocess.run(["wpctl", "get-volume", target], capture_output=True, text=True).stdout.strip()
        parts = out.split()
        if len(parts) >= 2:
            return parts[1]
    except: pass
    return "0.0"

def get_mic_muted():
    try:
        out = subprocess.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SOURCE@"], capture_output=True, text=True).stdout.strip()
        return "[MUTED]" if "[MUTED]" in out else ""
    except: return ""

# Initial values
print(f"VOLUME {get_volume(True)}", flush=True)
print(f"MIC {get_volume(False)} {get_mic_muted()}".strip(), flush=True)

# Monitor via pactl subscribe
env = os.environ.copy()
env["LC_ALL"] = "C"
proc = subprocess.Popen(
    ["stdbuf", "-oL", "pactl", "subscribe"],
    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env
)

fd = proc.stdout.fileno()
os.set_blocking(fd, False)

while True:
    reads, _, _ = select.select([fd], [], [])
    if fd in reads:
        try:
            chunk = proc.stdout.read()
        except BlockingIOError:
            continue
        
        if not chunk:
            break
        
        lines = chunk.decode("utf-8", errors="ignore")
        if "sink" in lines:
            print(f"VOLUME {get_volume(True)}", flush=True)
        if "source" in lines:
            print(f"MIC {get_volume(False)} {get_mic_muted()}".strip(), flush=True)
