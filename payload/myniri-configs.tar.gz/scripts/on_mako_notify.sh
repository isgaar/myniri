#!/bin/bash
# Mako event wrapper script
# $id is passed as environment variable by Mako, or as first argument
id="${1:-${mako_id:-${MAKO_ID:-$id}}}"

# Small delay to ensure makoctl has registered the item
env > /tmp/mako-env.log
sleep 0.05

# Check DND mode
if makoctl mode | grep -q "dnd"; then
    exit 0
fi

notif_json=$(makoctl list -j 2>/dev/null | jq -c ".[] | select(.id == $id)" 2>/dev/null)

# Fallback to history if not in active list
if [ -z "$notif_json" ]; then
    notif_json=$(makoctl history -j 2>/dev/null | jq -c ".[] | select(.id == $id)" 2>/dev/null)
fi

if [ -n "$notif_json" ]; then
    summary=$(echo "$notif_json" | jq -r '.summary // ""')
    body=$(echo "$notif_json" | jq -r '.body // ""')
    app=$(echo "$notif_json" | jq -r '.app_name // ""')
    urgency=$(echo "$notif_json" | jq -r '.urgency // "normal"')

    # Construct JSON payload
    payload=$(jq -n \
        --arg sm "$summary" \
        --arg bd "$body" \
        --arg ap "$app" \
        --arg ur "$urgency" \
        '{summary: $sm, body: $bd, app: $ap, urgency: $ur}' 2>/dev/null)

    # Forward to Quickshell
    qs ipc -c unified call notification_popup trigger "$payload" >/tmp/qs-mako-ipc.log 2>&1 || true
fi
