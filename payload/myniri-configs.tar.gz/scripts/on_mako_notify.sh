#!/bin/bash
id="${1:-${mako_id:-${MAKO_ID:-$id}}}"

sleep 0.05

if makoctl mode | grep -q "dnd"; then
    exit 0
fi

# Query mako notification over dbus using helper script
notif_json=$(/home/ismael/scripts/get_notification_by_id.py "$id" 2>/dev/null)

if [ -n "$notif_json" ]; then
    summary=$(echo "$notif_json" | jq -r '.summary // ""')
    body=$(echo "$notif_json" | jq -r '.body // ""')
    app=$(echo "$notif_json" | jq -r '.app_name // ""')
    urgency=$(echo "$notif_json" | jq -r '.urgency // ""')
else
    # Fallback to awk parsing if python script fails
    notif_text=$(makoctl list 2>/dev/null; makoctl history 2>/dev/null)
    summary=$(echo "$notif_text" | awk -v id="$id" '$0 ~ "^Notification " id ":" { sub(/^[^:]+: /, ""); print; exit }')
    body=""
    app=$(echo "$notif_text" | awk -v id="$id" 'BEGIN { found=0 } /^Notification [0-9]+:/ { found = ($2 == id":"); next } found && /^  App name:/ { sub(/^  App name: /, ""); print; exit }')
    urgency=$(echo "$notif_text" | awk -v id="$id" 'BEGIN { found=0 } /^Notification [0-9]+:/ { found = ($2 == id":"); next } found && /^  Urgency:/ { sub(/^  Urgency: /, ""); print; exit }')
fi

if [ -z "$summary" ]; then summary="Notificación"; fi
if [ -z "$app" ]; then app="Sistema"; fi
if [ -z "$urgency" ]; then urgency="normal"; fi

payload=$(jq -n \
    --arg sm "$summary" \
    --arg bd "$body" \
    --arg ap "$app" \
    --arg ur "$urgency" \
    '{summary: $sm, body: $bd, app: $ap, urgency: $ur}' 2>/dev/null)

qs ipc -c unified call notification_popup trigger "$payload" 2>/dev/null || true
