import os
import re

directory = os.path.expanduser("~/.config/quickshell/unified")

def process_file(filepath):
    with open(filepath, 'r') as f:
        content = f.read()

    # If already using WindowSettings, skip
    if "WindowSettings { id: ws }" in content:
        return

    # Check if the file is a popup or panel (we can just inject it at the top level of the component)
    # Most components start with an id like `id: window`, `id: root`, `id: panel`
    
    # Let's manually replace the complex radius strings
    complex_radius_pattern1 = r'radius:\s*\([^)]*cornersEnabled[^)]*\)\s*!==\s*false\s*\?\s*\([^)]*cornerRadius[^)]*\)\s*:\s*0'
    complex_radius_pattern2 = r'radius:\s*\(shellRoot\.themeConfig\s*&&\s*shellRoot\.themeConfig\.cornersEnabled\)\s*!==\s*false\s*\?\s*Math\.min\([^,]+,\s*\([^)]*cornerRadius[^)]*\)\)\s*:\s*0'
    
    if re.search(complex_radius_pattern1, content) or re.search(complex_radius_pattern2, content) or "radius: root.cornersEnabled && !root.fullscreen ? root.cornerRadius : 0" in content:
        print(f"Modifying {filepath} to use WindowSettings")
        # First inject WindowSettings
        # Find the id declaration of the root component
        id_match = re.search(r'id:\s*(\w+)\n', content)
        if id_match:
            insert_pos = id_match.end()
            content = content[:insert_pos] + "\n    WindowSettings { id: ws }\n" + content[insert_pos:]
            
            # Replace complex radius patterns
            content = re.sub(complex_radius_pattern1, r'radius: ws.cornersEnabled ? ws.cornerRadius : 0', content)
            content = re.sub(complex_radius_pattern2, r'radius: ws.cornersEnabled ? Math.min(10, ws.cornerRadius) : 0', content)
            
            with open(filepath, 'w') as f:
                f.write(content)

for filename in os.listdir(directory):
    if filename.endswith(".qml"):
        process_file(os.path.join(directory, filename))
