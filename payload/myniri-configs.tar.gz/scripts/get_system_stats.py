#!/usr/bin/env python3
# ~/scripts/get_system_stats.py
import os
import platform
import time

def get_cpu_model():
    try:
        with open('/proc/cpuinfo', 'r') as f:
            for line in f:
                if 'model name' in line:
                    return line.split(':', 1)[1].strip()
    except Exception:
        pass
    return "Unknown CPU"

def get_cpu_usage():
    try:
        with open('/proc/stat', 'r') as f:
            line = f.readline()
        parts = line.split()
        user, nice, sys, idle, iowait, irq, softirq, steal = map(int, parts[1:9])
        total1 = user + nice + sys + idle + iowait + irq + softirq + steal
        idle1 = idle + iowait

        time.sleep(0.08)

        with open('/proc/stat', 'r') as f:
            line = f.readline()
        parts = line.split()
        user, nice, sys, idle, iowait, irq, softirq, steal = map(int, parts[1:9])
        total2 = user + nice + sys + idle + iowait + irq + softirq + steal
        idle2 = idle + iowait

        total_diff = total2 - total1
        idle_diff = idle2 - idle1
        if total_diff > 0:
            usage = (total_diff - idle_diff) * 100 / total_diff
            return f"{usage:.1f}%"
    except Exception:
        pass
    return "0.0%"

def get_ram_usage():
    try:
        mem_total = 0
        mem_available = 0
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    mem_total = int(line.split()[1])
                elif line.startswith('MemAvailable:'):
                    mem_available = int(line.split()[1])
        if mem_total > 0:
            used = mem_total - mem_available
            return f"{used / 1024 / 1024:.1f} GiB / {mem_total / 1024 / 1024:.1f} GiB"
    except Exception:
        pass
    return "—"

def main():
    kernel = platform.release()
    cpu_model = get_cpu_model()
    ram = get_ram_usage()
    cpu = get_cpu_usage()

    print(kernel)
    print(cpu_model)
    print(ram)
    print(cpu)

if __name__ == "__main__":
    main()
