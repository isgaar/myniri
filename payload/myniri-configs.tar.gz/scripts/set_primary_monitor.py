import sys
import os
import subprocess

def set_primary(name):
    os.makedirs(os.path.expanduser("~/.config/quickshell"), exist_ok=True)
    with open(os.path.expanduser("~/.config/quickshell/primary_monitor.txt"), "w") as f:
        f.write(name)
    try:
        subprocess.run([
            "qs", "ipc", "-p",
            os.path.expanduser("~/.config/quickshell/unified/shell.qml"),
            "call", "primary_monitor", "update"
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

if __name__ == "__main__":
    if len(sys.argv) > 1:
        set_primary(sys.argv[1])
