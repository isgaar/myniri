import sys
import os

def set_primary(name):
    os.makedirs(os.path.expanduser("~/.config/quickshell"), exist_ok=True)
    with open(os.path.expanduser("~/.config/quickshell/primary_monitor.txt"), "w") as f:
        f.write(name)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        set_primary(sys.argv[1])
