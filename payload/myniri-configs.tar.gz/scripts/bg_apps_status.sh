#!/bin/bash
# ~/.scripts/bg_apps_status.sh
# Detect background apps intelligently by reading from get_bg_apps_json.sh
# This ensures that ANY app added to the json script automatically appears here.

json_output=$(bash ~/scripts/get_bg_apps_json.sh)

# Extract all icons into a single string
icons=$(echo "$json_output" | jq -r '.[].icon // empty' | tr -d '\n')

if [ -z "$icons" ]; then
    echo '{"text": "", "tooltip": "Sin aplicaciones en segundo plano"}'
else
    # Add a small spacing between icons for better visual appearance in Waybar
    spaced_icons=$(echo "$icons" | sed 's/./& /g' | sed 's/ $//')
    echo "{\"text\": \"$spaced_icons\", \"tooltip\": \"Apps en segundo plano\"}"
fi
