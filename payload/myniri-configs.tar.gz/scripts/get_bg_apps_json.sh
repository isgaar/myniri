#!/bin/bash
# ~/scripts/get_bg_apps_json.sh
# Outputs a JSON array of background apps for Quickshell

echo -n "["
first=true

check_app() {
    local process=$1
    local name=$2
    local icon=$3
    local cmd=$4
    local class_or_id=$5
    
    if pgrep -f -i "\\b$process\\b" >/dev/null; then
        if [ "$first" = true ]; then
            first=false
        else
            echo -n ","
        fi
        echo -n "{\"app_id\": \"$process\", \"name\": \"$name\", \"icon\": \"$icon\", \"cmd\": \"$cmd\", \"class_or_id\": \"$class_or_id\"}"
    fi
}

if which Discord >/dev/null 2>&1; then
    DISCORD_CMD="Discord"
else
    DISCORD_CMD="discord"
fi

check_app "discord" "Discord" "\uf392" "$DISCORD_CMD" "discord"
# Sometimes discord process is capitalized
if ! pgrep -x -i "discord" >/dev/null; then
    check_app "Discord" "Discord" "\uf392" "$DISCORD_CMD" "discord"
fi

if pgrep -f -i "\\bTelegram\\b" >/dev/null; then
    TELEGRAM_CMD="/home/ismael/Descargas/Telegram/Telegram"
    TELEGRAM_PROC="Telegram"
else
    TELEGRAM_CMD="telegram-desktop"
    TELEGRAM_PROC="telegram-desktop"
fi

check_app "$TELEGRAM_PROC" "Telegram" "\uf2c6" "$TELEGRAM_CMD" "org.telegram.desktop"
check_app "steam" "Steam" "\uf1b6" "steam steam://open/main" "steam"
check_app "spotify" "Spotify" "\uf1bc" "spotify" "spotify"
check_app "PenTablet" "XPPen" "\uf304" "env -u WAYLAND_DISPLAY -u QT_QPA_PLATFORM /usr/lib/pentablet/PenTablet" "PenTablet"

echo "]"
