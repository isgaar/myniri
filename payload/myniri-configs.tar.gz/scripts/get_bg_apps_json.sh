#!/usr/bin/env bash
# Outputs a JSON array of known background apps for Quickshell.

set -u

entries=()

desktop_icon() {
    local desktop_id="$1"
    local file=""

    if [ -f "$HOME/.local/share/applications/$desktop_id.desktop" ]; then
        file="$HOME/.local/share/applications/$desktop_id.desktop"
    elif [ -f "/usr/share/applications/$desktop_id.desktop" ]; then
        file="/usr/share/applications/$desktop_id.desktop"
    else
        file=$(find "$HOME/.local/share/applications" /usr/share/applications \
            -maxdepth 1 -type f -name "$desktop_id*.desktop" 2>/dev/null | head -1)
    fi

    if [ -n "$file" ]; then
        awk -F= '$1=="Icon"{print substr($0, index($0,$2)); exit}' "$file"
    fi
}

add_app() {
    local process="$1"
    local name="$2"
    local cmd="$3"
    local class_or_id="$4"
    local desktop_id="$5"
    local fallback_icon="$6"

    pgrep -f -i "\\b$process\\b" >/dev/null || return 0

    local icon
    icon=$(desktop_icon "$desktop_id")
    [ -n "$icon" ] || icon="$fallback_icon"

    entries+=("$(
        jq -cn \
            --arg app_id "$process" \
            --arg name "$name" \
            --arg cmd "$cmd" \
            --arg class_or_id "$class_or_id" \
            --arg desktop_id "$desktop_id" \
            --arg icon "$icon" \
            '{
                app_id: $app_id,
                name: $name,
                cmd: $cmd,
                class_or_id: $class_or_id,
                desktop_id: $desktop_id,
                icon_name: (if ($icon | startswith("/")) then "" else $icon end),
                icon_path: (if ($icon | startswith("/")) then $icon else "" end)
            }'
    )")
}

if command -v Discord >/dev/null 2>&1; then
    DISCORD_CMD="Discord"
else
    DISCORD_CMD="discord"
fi

add_app "discord" "Discord" "$DISCORD_CMD" "discord" "discord" "discord"
if ! pgrep -x -i "discord" >/dev/null; then
    add_app "Discord" "Discord" "$DISCORD_CMD" "discord" "discord" "discord"
fi

if pgrep -f -i "\\bTelegram\\b" >/dev/null; then
    TELEGRAM_CMD="/home/ismael/Descargas/Telegram/Telegram"
    TELEGRAM_PROC="Telegram"
else
    TELEGRAM_CMD="telegram-desktop"
    TELEGRAM_PROC="telegram-desktop"
fi

add_app "$TELEGRAM_PROC" "Telegram" "$TELEGRAM_CMD" "org.telegram.desktop" "org.telegram.desktop" "org.telegram.desktop"
add_app "steam" "Steam" "steam steam://open/main" "steam" "steam" "steam"
add_app "spotify" "Spotify" "spotify" "spotify" "spotify" "spotify"
add_app "PenTablet" "XPPen" "env -u WAYLAND_DISPLAY -u QT_QPA_PLATFORM /usr/lib/pentablet/PenTablet" "PenTablet" "xppentablet" "/usr/share/icons/hicolor/256x256/apps/xppentablet.png"

if [ "${#entries[@]}" -eq 0 ]; then
    printf '[]\n'
else
    printf '%s\n' "${entries[@]}" | jq -sc '.'
fi
