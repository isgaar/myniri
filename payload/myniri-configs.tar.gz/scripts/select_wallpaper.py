#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys

IMAGE_FILTERS = ("*.png", "*.jpg", "*.jpeg", "*.webp", "*.bmp", "*.svg")


def home_path(*parts):
    return os.path.join(os.path.expanduser("~"), *parts)


def start_dir():
    for path in (
        home_path("Imágenes"),
        home_path("Pictures"),
        home_path("Descargas"),
        home_path("Downloads"),
        os.path.expanduser("~"),
    ):
        if os.path.isdir(path):
            return path
    return os.path.expanduser("~")


def valid_image(path):
    if not path:
        return False
    expanded = os.path.abspath(os.path.expanduser(path))
    if not os.path.isfile(expanded):
        return False
    return expanded.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp", ".svg"))


def run_chooser(command):
    try:
        result = subprocess.run(
            command,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
    except OSError:
        return ""
    if result.returncode != 0:
        return ""
    return result.stdout.strip().splitlines()[0] if result.stdout.strip() else ""


def chooser_commands(directory):
    filters = " ".join(IMAGE_FILTERS)
    return (
        (
            "zenity",
            [
                "zenity",
                "--file-selection",
                "--title=Seleccionar fondo de pantalla",
                f"--filename={directory}/",
                "--file-filter=Imágenes | " + filters,
            ],
        ),
        (
            "yad",
            [
                "yad",
                "--file-selection",
                "--title=Seleccionar fondo de pantalla",
                f"--filename={directory}/",
                "--file-filter=Imágenes | " + filters,
            ],
        ),
        (
            "kdialog",
            [
                "kdialog",
                "--getopenfilename",
                directory,
                "Imágenes (*.png *.jpg *.jpeg *.webp *.bmp *.svg)",
            ],
        ),
        (
            "qarma",
            [
                "qarma",
                "--file-selection",
                "--title=Seleccionar fondo de pantalla",
                f"--filename={directory}/",
            ],
        ),
    )


def main():
    directory = start_dir()
    for binary, command in chooser_commands(directory):
        if not shutil.which(binary):
            continue
        selected = run_chooser(command)
        if valid_image(selected):
            print(os.path.abspath(os.path.expanduser(selected)))
            return 0
        if selected:
            print(f"Archivo no válido: {selected}", file=sys.stderr)
            return 2

    print("No hay selector gráfico instalado. Usa el campo de ruta manual.", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
