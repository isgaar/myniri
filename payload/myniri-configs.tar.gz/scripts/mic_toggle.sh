#!/bin/bash

SOURCE=$(pactl get-default-source)

get_state() {
    pactl get-source-mute "$SOURCE" 2>/dev/null | grep -c "sí\|yes"
}

case "$1" in
    toggle)
        pactl set-source-mute "$SOURCE" toggle
        sleep 0.1
        if [ "$(get_state)" = "1" ]; then
            notify-send "Micrófono" "Silenciado"
        else
            notify-send "Micrófono" "Activo"
        fi
        ;;
    status|*)
        if [ "$(get_state)" = "1" ]; then
            printf "\uf131\n"
        else
            printf "\uf130\n"
        fi
        ;;
esac
