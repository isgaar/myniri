#!/usr/bin/env python3
# ~/scripts/active_app_listener.py
import json
import subprocess
import re
import sys
import os

def format_app_name(app_name, title):
    if not app_name:
        app_name = ""
    if not title:
        title = ""
        
    val = f"{app_name.lower()} {title.lower()}"
    title_lc = title.lower()
    
    if "kitty" in val:
        return "Kitty"
    elif "codium" in val or "visual studio code" in val:
        return "VSCodium"
    elif "firefox" in val:
        return "Firefox"
    elif "brave" in val:
        return "Brave"
    elif "zen" in val:
        return "Zen"
    elif "dolphin" in val:
        return "Dolphin"
    elif "discord" in val:
        return "Discord"
    elif "telegram" in val:
        return "Telegram"
    elif "spotify" in val:
        return "Spotify"
    elif "steam" in val:
        return "Steam"
    elif "okular" in val:
        return "Okular"
    elif "krita" in val:
        return "Krita"
    elif "konsole" in val:
        return "Konsole"
    elif "antigravity" in val:
        return "Antigravity"
    
    if title and title != "null" and title_lc != "focused":
        # clean title
        t = re.sub(r'\s+-\s+.*$', '', title)
        t = re.sub(r'\s+—\s+.*$', '', t)
        t = re.sub(r'\s*\|.*$', '', t)
        if t:
            return t[0].upper() + t[1:]
    
    if app_name and app_name != "null":
        return app_name[0].upper() + app_name[1:]
        
    return "Niri"

def emit_active():
    try:
        windows_data = subprocess.check_output(["niri", "msg", "--json", "windows"], text=True)
        windows = json.loads(windows_data)
        focused_window = next((w for w in windows if w.get("is_focused")), None)
        if focused_window:
            app_id = focused_window.get("app_id")
            title = focused_window.get("title")
            name = format_app_name(app_id, title)
            app_info = {
                "text": name,
                "tooltip": title or name,
                "class": "active"
            }
        else:
            app_info = {"text": "Niri", "tooltip": "Niri", "class": "niri"}
        print(json.dumps(app_info), flush=True)
    except Exception:
        print(json.dumps({"text": "Niri", "tooltip": "Niri", "class": "niri"}), flush=True)

def main():
    emit_active()
    
    # Subscribe to niri event stream
    proc = subprocess.Popen(
        ["niri", "msg", "--json", "event-stream"],
        stdout=subprocess.PIPE,
        text=True
    )
    
    try:
        while True:
            line = proc.stdout.readline()
            if not line:
                break
            try:
                event = json.loads(line.strip())
                # WindowFocusChanged, WindowOpened, WindowClosed, WorkspaceActivated
                if any(k in event for k in ["WindowFocusChanged", "WindowOpened", "WindowClosed", "WorkspaceActivated"]):
                    emit_active()
            except Exception:
                pass
    except KeyboardInterrupt:
        pass
    finally:
        proc.terminate()

if __name__ == "__main__":
    main()
