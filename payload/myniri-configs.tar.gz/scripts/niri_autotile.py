#!/usr/bin/env python3
import subprocess
import json
import sys
import time

def get_niri_state():
    try:
        # Get workspaces
        res = subprocess.run(["niri", "msg", "--json", "workspaces"], capture_output=True, text=True)
        if res.returncode != 0:
            return None, None
        workspaces = json.loads(res.stdout)
        
        # Get windows
        res = subprocess.run(["niri", "msg", "--json", "windows"], capture_output=True, text=True)
        if res.returncode != 0:
            return None, None
        windows = json.loads(res.stdout)
        
        return workspaces, windows
    except Exception as e:
        print(f"Error getting state: {e}", file=sys.stderr)
        return None, None

def adjust_workspace_layout(ws_id, focused_win_id):
    workspaces, windows = get_niri_state()
    if not workspaces or not windows:
        return
        
    # Find active workspace
    active_ws = None
    for ws in workspaces:
        if ws.get("id") == ws_id:
            active_ws = ws
            break
    if not active_ws or not active_ws.get("is_focused", False):
        # Only adjust if it's the currently focused workspace
        return

    # Filter non-floating windows on this workspace
    tiled_wins = [w for w in windows if w.get("workspace_id") == ws_id and not w.get("is_floating", False)]
    if not tiled_wins:
        return

    # Group windows by column index (pos_in_scrolling_layout[0])
    cols = {}
    for win in tiled_wins:
        pos = win.get("layout", {}).get("pos_in_scrolling_layout")
        if pos:
            col_idx = pos[0]
            if col_idx not in cols:
                cols[col_idx] = []
            cols[col_idx].append(win)

    num_cols = len(cols)
    if num_cols == 0:
        return

    # Sort columns by their horizontal position
    sorted_col_keys = sorted(cols.keys())
    
    # Calculate target percentage
    # If 1 column -> 100%, 2 -> 50%, 3 -> 33.3%, 4 -> 25%, etc.
    target_pct = int(100 / num_cols)
    target_width_str = f"{target_pct}%"

    print(f"Adjusting workspace {ws_id}: {num_cols} columns, target width {target_width_str}", flush=True)

    # Determine the window we want to focus for each column (the focused one in that column or the first one)
    cols_to_resize = []
    for col_key in sorted_col_keys:
        wins_in_col = cols[col_key]
        # Find if any window in the column is currently focused or was focused
        focused_in_col = next((w for w in wins_in_col if w.get("id") == focused_win_id), None)
        if focused_in_col:
            cols_to_resize.append(focused_in_col)
        else:
            # Sort windows in column by vertical pos (pos_in_scrolling_layout[1])
            wins_in_col.sort(key=lambda w: w.get("layout", {}).get("pos_in_scrolling_layout", [0, 0])[1])
            cols_to_resize.append(wins_in_col[0])

    # Focus and resize each column
    for win in cols_to_resize:
        win_id = win.get("id")
        # Focus window
        subprocess.run(["niri", "msg", "action", "focus-window", "--id", str(win_id)], capture_output=True)
        # Set column width
        subprocess.run(["niri", "msg", "action", "set-column-width", target_width_str], capture_output=True)

    # Restore focus to the original focused window if it still exists
    if focused_win_id:
        subprocess.run(["niri", "msg", "action", "focus-window", "--id", str(focused_win_id)], capture_output=True)

def main():
    print("Niri Autotile daemon started.", flush=True)
    
    # Initialize workspace column counts
    last_ws_col_counts = {}
    
    # Perform initial layout check/adjustment on startup
    workspaces, windows = get_niri_state()
    if workspaces and windows:
        focused_ws_id = None
        focused_win_id = None
        
        # Find focused window ID
        for win in windows:
            if win.get("is_focused", False):
                focused_win_id = win.get("id")
                break
                
        for ws in workspaces:
            ws_id = ws.get("id")
            if ws.get("is_focused", False):
                focused_ws_id = ws_id
            
            # Count columns
            wins = [w for w in windows if w.get("workspace_id") == ws_id and not w.get("is_floating", False)]
            cols = set()
            for win in wins:
                pos = win.get("layout", {}).get("pos_in_scrolling_layout")
                if pos:
                    cols.add(pos[0])
            last_ws_col_counts[ws_id] = len(cols)
            
        if focused_ws_id:
            adjust_workspace_layout(focused_ws_id, focused_win_id)
            
    # We start niri event stream with stdbuf to prevent block buffering
    proc = subprocess.Popen(
        ["stdbuf", "-oL", "niri", "msg", "--json", "event-stream"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    # Read the event stream line-by-line
    while True:
        line = proc.stdout.readline()
        if not line:
            break
            
        try:
            event = json.loads(line.strip())
        except Exception:
            continue
            
        # We trigger on window list changes
        trigger_keys = ["WindowsChanged", "WorkspacesChanged", "WindowOpenedOrChanged", "WindowClosed"]
        if any(k in event for k in trigger_keys):
            workspaces, windows = get_niri_state()
            if not workspaces or not windows:
                continue
                
            # Group windows by workspace
            ws_windows = {}
            for win in windows:
                if win.get("is_floating", False):
                    continue
                ws_id = win.get("workspace_id")
                if ws_id is not None:
                    if ws_id not in ws_windows:
                        ws_windows[ws_id] = []
                    ws_windows[ws_id].append(win)
            
            # Find focused workspace and check column counts
            focused_ws_id = None
            focused_win_id = None
            
            # Find focused window ID
            for win in windows:
                if win.get("is_focused", False):
                    focused_win_id = win.get("id")
                    break
                    
            for ws in workspaces:
                ws_id = ws.get("id")
                if ws.get("is_focused", False):
                    focused_ws_id = ws_id
                
                # Count columns on this workspace
                wins = ws_windows.get(ws_id, [])
                cols = set()
                for win in wins:
                    pos = win.get("layout", {}).get("pos_in_scrolling_layout")
                    if pos:
                        cols.add(pos[0])
                
                col_count = len(cols)
                old_count = last_ws_col_counts.get(ws_id)
                
                # If column count changed, and this workspace is focused, adjust layout!
                if old_count is not None and col_count != old_count:
                    # Update count
                    last_ws_col_counts[ws_id] = col_count
                    if ws_id == focused_ws_id:
                        # Add a small delay to allow window to map/settle before adjusting
                        time.sleep(0.05)
                        adjust_workspace_layout(ws_id, focused_win_id)
                else:
                    # Just record the count if we didn't track it yet
                    last_ws_col_counts[ws_id] = col_count

if __name__ == '__main__':
    # Add a delay on startup so niri has fully loaded and mapped initial windows
    time.sleep(1.0)
    main()
