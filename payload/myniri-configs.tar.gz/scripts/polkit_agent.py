#!/usr/bin/env python3
import os
import sys
import subprocess
import json
import pwd
import threading
import shutil
import gi
gi.require_version('Polkit', '1.0')
gi.require_version('PolkitAgent', '1.0')
gi.require_version('Gio', '2.0')
gi.require_version('GLib', '2.0')
from gi.repository import Polkit, PolkitAgent, GLib, Gio

import time

XML_INTERFACE = '''
<node>
  <interface name="org.freedesktop.PolicyKit1.AuthenticationAgent">
    <method name="BeginAuthentication">
      <arg type="s" name="action_id" direction="in"/>
      <arg type="s" name="message" direction="in"/>
      <arg type="s" name="icon_name" direction="in"/>
      <arg type="a{ss}" name="details" direction="in"/>
      <arg type="s" name="cookie" direction="in"/>
      <arg type="a(sa{sv})" name="identities" direction="in"/>
    </method>
    <method name="CancelAuthentication">
      <arg type="s" name="cookie" direction="in"/>
    </method>
  </interface>
</node>
'''

FIFO_PATH = '/tmp/qs-polkit.fifo'
QS_BIN = shutil.which("qs") or "/usr/local/bin/qs"

def resolve_session_id():
    session_id = os.getenv("XDG_SESSION_ID")
    if session_id and session_id != "4294967295":
        return session_id

    try:
        with open("/proc/self/sessionid", "r") as f:
            sid = f.read().strip()
            if sid and sid != "4294967295":
                return sid
    except Exception as e:
        print(f"Error reading session ID from proc: {e}", file=sys.stderr)

    try:
        uid = str(os.getuid())
        out = subprocess.check_output(
            ["loginctl", "list-sessions", "--no-legend"],
            text=True,
            stderr=subprocess.DEVNULL
        )
        candidates = []
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[1] == uid:
                candidates.append(parts[0])

        for candidate in candidates:
            props_out = subprocess.check_output(
                ["loginctl", "show-session", candidate, "-p", "Active", "-p", "Class", "-p", "Type"],
                text=True,
                stderr=subprocess.DEVNULL
            )
            props = dict(line.split("=", 1) for line in props_out.splitlines() if "=" in line)
            if props.get("Active") == "yes" and props.get("Class") == "user":
                return candidate

        if candidates:
            return candidates[0]
    except Exception as e:
        print(f"Error resolving session ID with loginctl: {e}", file=sys.stderr)

    return None

def qs_ipc(*args):
    cmd = [QS_BIN, "ipc", "-c", "unified", "call", *args]
    try:
        res = subprocess.run(cmd, text=True, capture_output=True, timeout=3)
        if res.returncode != 0:
            print(f"qs ipc failed ({res.returncode}): {' '.join(cmd)}", flush=True)
            if res.stdout:
                print(res.stdout, flush=True)
            if res.stderr:
                print(res.stderr, flush=True)
        return res.returncode == 0
    except Exception as e:
        print(f"qs ipc exception: {e}", flush=True)
        return False

class DbusPolkitAgent:
    def __init__(self):
        self.bus = None
        self.reg_id = None
        self.active_session = None
        self.active_invocation = None
        self.active_cookie = None
        
        # Keep track of request parameters
        self.cookie = None
        self.identities_map = {} # username -> Polkit.Identity
        self.password = None
        
    def start(self):
        # Create FIFO if it doesn't exist
        if not os.path.exists(FIFO_PATH):
            os.mkfifo(FIFO_PATH)
            os.chmod(FIFO_PATH, 0o600)
            
        session_id = resolve_session_id()
        if not session_id:
            print("Error: could not resolve a usable graphical session id.", file=sys.stderr)
            sys.exit(1)
            
        # Connect to system D-Bus bus (with retries)
        self.bus = None
        for i in range(10):
            try:
                self.bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
                break
            except Exception as e:
                print(f"Error connecting to system bus (attempt {i+1}): {e}", file=sys.stderr, flush=True)
                time.sleep(1)
        if not self.bus:
            print("Failed to connect to system bus after 10 attempts.", file=sys.stderr, flush=True)
            sys.exit(1)
        
        # Parse the interface XML
        node_info = Gio.DBusNodeInfo.new_for_xml(XML_INTERFACE)
        interface_info = node_info.interfaces[0]
        
        # Export the agent D-Bus object
        self.reg_id = self.bus.register_object(
            "/org/freedesktop/PolicyKit1/AuthenticationAgent",
            interface_info,
            self.handle_method_call,
            None,
            None
        )
        print("Exported agent D-Bus object.", flush=True)
        
        # Register with Polkit Authority (with retries)
        locale = os.getenv("LANG", "en_US.UTF-8")
        object_path = "/org/freedesktop/PolicyKit1/AuthenticationAgent"
        params = GLib.Variant('((sa{sv})ss)', (
            ('unix-session', {'session-id': GLib.Variant('s', session_id)}),
            locale,
            object_path
        ))
        
        registered = False
        for i in range(10):
            try:
                self.bus.call_sync(
                    "org.freedesktop.PolicyKit1",
                    "/org/freedesktop/PolicyKit1/Authority",
                    "org.freedesktop.PolicyKit1.Authority",
                    "RegisterAuthenticationAgent",
                    params,
                    None,
                    Gio.DBusCallFlags.NONE,
                    -1,
                    None
                )
                print(f"Registered with Polkit Authority for Session {session_id}!", flush=True)
                registered = True
                break
            except Exception as e:
                print(f"Error registering with Polkit Authority (attempt {i+1}): {e}", file=sys.stderr, flush=True)
                time.sleep(1)
                
        if not registered:
            print("Failed to register with Polkit Authority after 10 attempts.", file=sys.stderr, flush=True)
            sys.exit(1)
            
    def handle_method_call(self, connection, sender, object_path, interface_name, method_name, parameters, invocation, user_data=None):
        if method_name == "BeginAuthentication":
            self.handle_begin_authentication(parameters, invocation)
        elif method_name == "CancelAuthentication":
            self.handle_cancel_authentication(parameters, invocation)

    def handle_begin_authentication(self, parameters, invocation):
        action_id, message, icon_name, details, cookie, identities = parameters.unpack()
        print(f"BeginAuthentication called: action_id={action_id}, message={message}", flush=True)
        
        # Clean up any previous session/invocation
        self.cancel_active_session()
        
        self.active_invocation = invocation
        self.active_cookie = cookie
        self.cookie = cookie
        self.identities_map = {}
        self.password = None
        
        usernames = []
        for identity_type, identity_details in identities:
            if identity_type == 'unix-user':
                uid = identity_details.get('uid')
                if uid is not None:
                    try:
                        username = pwd.getpwuid(uid).pw_name
                        identity = Polkit.UnixUser.new(uid)
                    except Exception:
                        username = f"user {uid}"
                        identity = Polkit.UnixUser.new(uid)
                    self.identities_map[username] = identity
                    usernames.append(username)
                    
        # Determine default username
        current_uid = os.getuid()
        try:
            current_user = pwd.getpwuid(current_uid).pw_name
        except Exception:
            current_user = None
            
        if current_user in usernames:
            default_user = current_user
        elif "root" in usernames:
            default_user = "root"
        elif usernames:
            default_user = usernames[0]
        else:
            default_user = "root"
            
        # Immediately start the PAM session for the default user to satisfy the daemon's cookie expectation
        default_identity = self.identities_map.get(default_user)
        if default_identity:
            print(f"Immediately starting PAM session for default user: {default_user}", flush=True)
            self.start_pam_session(default_identity, default_user)
        else:
            print("Warning: No matching identity found for default user.", flush=True)

        # Send IPC to QML
        payload = {
            "action_id": action_id,
            "message": message,
            "identities": usernames,
            "default_user": default_user
        }
        qs_ipc("polkit", "showPrompt", json.dumps(payload))
        
        # Start reading the FIFO in a background thread to keep D-Bus responsive
        self.start_fifo_read()

    def start_fifo_read(self):
        def read_worker():
            try:
                with open(FIFO_PATH, 'r') as f:
                    data = f.read()
                GLib.idle_add(self.on_fifo_response, data)
            except Exception as e:
                print(f"Error in FIFO read thread: {e}", flush=True)
                GLib.idle_add(self.on_fifo_response, "")
                
        thread = threading.Thread(target=read_worker)
        thread.daemon = True
        thread.start()

    def on_fifo_response(self, data_str):
        if not data_str:
            # Empty response means cancellation
            self.send_dbus_cancelled()
            return
            
        try:
            response = json.loads(data_str)
        except Exception as e:
            print(f"Error parsing QML response JSON: {e}", flush=True)
            self.send_dbus_cancelled()
            return
            
        if response.get("cancelled"):
            self.send_dbus_cancelled()
            return
            
        username = response.get("username")
        password = response.get("password")
        
        selected_identity = self.identities_map.get(username)
        if not selected_identity:
            print(f"Selected username {username} is not an authorized identity.", flush=True)
            self.send_dbus_error("Failed", f"User {username} is not authorized")
            return
            
        if self.active_session is not None:
            if username == self.active_username:
                print(f"Responding to active session for {username}.", flush=True)
                self.active_session.response(password)
            else:
                print(f"User changed identity from {self.active_username} to {username}. Restarting session.", flush=True)
                self.cancel_active_session(dismiss_qml=False)
                self.password = password
                self.start_pam_session(selected_identity, username)
        else:
            print(f"No active session, starting new session for {username}.", flush=True)
            self.password = password
            self.start_pam_session(selected_identity, username)

    def start_pam_session(self, identity, username):
        self.active_username = username
        self.active_session = PolkitAgent.Session.new(identity, self.cookie)
        self.active_session.connect("completed", self.on_session_completed)
        self.active_session.connect("request", self.on_session_request)
        self.active_session.initiate()

    def on_session_request(self, session, request_message, echo_on):
        print(f"on_session_request called: message={request_message}", flush=True)
        # The session requests the password, respond with it
        if self.password is not None:
            print("Password available, submitting response.", flush=True)
            session.response(self.password)
            self.password = None # Clear after use
        else:
            print("Password not available yet, waiting for user input.", flush=True)

    def on_session_completed(self, session, gained_authorization):
        print(f"Session finished. Authorized={gained_authorization}", flush=True)
        if gained_authorization:
            # Tell QML the prompt was successful
            result_payload = {"success": True}
            qs_ipc("polkit", "finishPrompt", json.dumps(result_payload))
            
            # Return success to Polkit
            if self.active_invocation:
                self.active_invocation.return_value(None)
                self.active_invocation = None
            self.active_session = None
        else:
            # Failed auth, notify QML of failure
            result_payload = {"success": False}
            qs_ipc("polkit", "finishPrompt", json.dumps(result_payload))
            
            # Wait for retry from FIFO
            self.active_session = None
            self.start_fifo_read()

    def handle_cancel_authentication(self, parameters, invocation):
        cookie = parameters.unpack()[0]
        print(f"CancelAuthentication called for cookie: {cookie}", flush=True)
        
        if cookie == self.active_cookie:
            self.cancel_active_session()
            
        invocation.return_value(None)

    def cancel_active_session(self, dismiss_qml=True):
        # Cancel PAM session
        if self.active_session is not None:
            try:
                self.active_session.cancel()
            except Exception:
                pass
            self.active_session = None
            
        if dismiss_qml:
            # Dismiss QML
            qs_ipc("polkit", "close")
        
        # Return error to D-Bus
        if self.active_invocation and dismiss_qml:
            try:
                self.active_invocation.return_dbus_error(
                    "org.freedesktop.PolicyKit1.Error.Cancelled",
                    "Authentication agent cancelled by authority"
                )
            except Exception:
                pass
            self.active_invocation = None
            
        self.password = None
        self.active_cookie = None

    def send_dbus_cancelled(self):
        # Dismiss QML
        qs_ipc("polkit", "close")
        
        if self.active_invocation:
            try:
                self.active_invocation.return_dbus_error(
                    "org.freedesktop.PolicyKit1.Error.Cancelled",
                    "Authentication agent dismissed by user"
                )
            except Exception:
                pass
            self.active_invocation = None
        self.active_session = None
        self.password = None
        self.active_cookie = None

    def send_dbus_error(self, name, message):
        # Dismiss QML
        qs_ipc("polkit", "close")
        
        if self.active_invocation:
            try:
                self.active_invocation.return_dbus_error(
                    f"org.freedesktop.PolicyKit1.Error.{name}",
                    message
                )
            except Exception:
                pass
            self.active_invocation = None
        self.active_session = None
        self.password = None
        self.active_cookie = None

def keep_alive():
    return True

def main():
    try:
        log_file = open('/tmp/polkit_agent.log', 'a', buffering=1)
        sys.stdout = log_file
        sys.stderr = log_file
    except Exception as e:
        pass

    agent = DbusPolkitAgent()
    agent.start()
    
    GLib.timeout_add(1000, keep_alive)
    loop = GLib.MainLoop()
    try:
        print("Starting main loop...", flush=True)
        loop.run()
    except KeyboardInterrupt:
        print("\nStopping QML Polkit Agent...")
        sys.exit(0)

if __name__ == '__main__':
    main()
