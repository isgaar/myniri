#!/bin/bash
# Clean up any existing instances of the polkit agent
pkill -f "/home/ismael/scripts/polkit_agent.py" || true

# Wait briefly to ensure the D-Bus registration is fully released
sleep 0.5

# Start the agent in the background and redirect output to the log file
python3 /home/ismael/scripts/polkit_agent.py >> /tmp/polkit_agent.log 2>&1 &
