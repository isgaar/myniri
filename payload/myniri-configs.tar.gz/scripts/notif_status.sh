#!/bin/bash
dnd=false
if makoctl mode 2>/dev/null | grep -q 'dnd'; then
    dnd=true
fi

count=$(makoctl list -j 2>/dev/null | jq 'length' 2>/dev/null)
count=${count:-0}

has_unread=false
if [ "$count" -gt 0 ] 2>/dev/null; then
    has_unread=true
fi

if $dnd; then
    printf '{"text": "\uf0f3", "hasUnread": %s, "class": "dnd", "tooltip": "Modo Concentración"}\n' "$has_unread"
else
    printf '{"text": "\uf0f3", "hasUnread": %s, "class": "normal", "tooltip": "Notificaciones"}\n' "$has_unread"
fi
