import json
import subprocess
import re
import os

def get_outputs():
    try:
        result = subprocess.run(["swaymsg", "-t", "get_outputs"], capture_output=True, text=True)
        return json.loads(result.stdout)
    except Exception:
        return []

def update_sway_config():
    outputs = get_outputs()
    config_path = os.path.expanduser("~/.config/sway/config")
    
    with open(config_path, "r") as f:
        content = f.read()
    
    new_block = "# Configuración de pantallas\n"
    for out in outputs:
        name = out.get("name")
        if out.get("active"):
            mode_str = ""
            current_mode = out.get("current_mode", {})
            if current_mode:
                w = current_mode.get("width")
                h = current_mode.get("height")
                hz = current_mode.get("refresh", 0) / 1000.0
                mode_str = f"    mode {w}x{h}@{hz}Hz\n"
            
            rect = out.get("rect", {})
            pos_str = f"    position {rect.get('x', 0)},{rect.get('y', 0)}\n"
            
            new_block += f"output {name} {{\n{mode_str}{pos_str}    enable\n}}\n"
        else:
            new_block += f"output {name} disable\n"
    
    # Replace the block
    pattern = r"# Configuración de pantallas\n(?:output [^{]+ (?:\{[^}]+\}|disable)\n*)+"
    if re.search(pattern, content):
        new_content = re.sub(pattern, new_block, content)
    else:
        new_content = content + "\n" + new_block
        
    with open(config_path, "w") as f:
        f.write(new_content)

if __name__ == "__main__":
    update_sway_config()
