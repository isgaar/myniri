#!/usr/bin/env bash
set -euo pipefail

sanitize_field() {
    printf '%s' "${1:-}" | tr '\t\r\n' '   ' | sed 's/^ *//; s/ *$//'
}

first_connected_iface() {
    local type="$1"
    nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null \
        | awk -F: -v type="$type" '$2 == type && $3 == "connected" {print $1; exit}' || true
}

default_iface() {
    ip route get 1.1.1.1 2>/dev/null | awk '{for (i = 1; i <= NF; i++) if ($i == "dev") {print $(i + 1); exit}}' || true
}

ipv4_for_iface() {
    local iface="$1"
    ip -4 -o addr show dev "$iface" scope global 2>/dev/null \
        | awk '{split($4, ip, "/"); print ip[1]; exit}' || true
}

wifi_name_for_iface() {
    local iface="$1"
    nmcli --escape no -t -f ACTIVE,SSID dev wifi list ifname "$iface" --rescan no 2>/dev/null \
        | awk -F: '$1 == "yes" || $1 == "si" || $1 == "sí" {ssid=""; for (i = 2; i <= NF; i++) ssid = ssid (i > 2 ? ":" : "") $i; print ssid; exit}' || true
}

wifi_signal_for_iface() {
    local iface="$1"
    nmcli --escape no -t -f ACTIVE,SIGNAL dev wifi list ifname "$iface" --rescan no 2>/dev/null \
        | awk -F: '$1 == "yes" || $1 == "si" || $1 == "sí" {print $2; exit}' || true
}

format_rate() {
    local bytes="$1"
    awk -v bytes="$bytes" 'BEGIN {
        if (bytes >= 1048576) printf "%.1f MB/s", bytes / 1048576;
        else if (bytes >= 1024) printf "%.0f KB/s", bytes / 1024;
        else printf "%d B/s", bytes;
    }'
}

speed_for_iface() {
    local iface="$1"
    local rx_path="/sys/class/net/$iface/statistics/rx_bytes"
    local tx_path="/sys/class/net/$iface/statistics/tx_bytes"
    local state_file="${XDG_RUNTIME_DIR:-/tmp}/honey-network-status-${UID}-${iface}.state"

    if [[ ! -r "$rx_path" || ! -r "$tx_path" ]]; then
        printf '%s' "0 B/s"
        return
    fi

    local now rx tx prev_now prev_rx prev_tx elapsed delta_rx delta_tx total rate
    now=$(date +%s)
    rx=$(<"$rx_path")
    tx=$(<"$tx_path")

    if [[ -r "$state_file" ]]; then
        read -r prev_now prev_rx prev_tx < "$state_file" || true
    fi

    printf '%s %s %s\n' "$now" "$rx" "$tx" > "$state_file" 2>/dev/null || true

    if [[ -z "${prev_now:-}" || -z "${prev_rx:-}" || -z "${prev_tx:-}" ]]; then
        printf '%s' "0 B/s"
        return
    fi

    elapsed=$((now - prev_now))
    if (( elapsed <= 0 )); then
        printf '%s' "0 B/s"
        return
    fi

    delta_rx=$((rx >= prev_rx ? rx - prev_rx : 0))
    delta_tx=$((tx >= prev_tx ? tx - prev_tx : 0))
    total=$((delta_rx + delta_tx))
    rate=$((total / elapsed))
    format_rate "$rate"
}

print_status() {
    local type="$1" name="$2" signal="$3" ip_addr="$4" speed="$5"
    printf '%s\t%s\t%s\t%s\t%s\n' \
        "$(sanitize_field "$type")" \
        "$(sanitize_field "$name")" \
        "$(sanitize_field "$signal")" \
        "$(sanitize_field "$ip_addr")" \
        "$(sanitize_field "$speed")"
}

main() {
    local iface name signal ip_addr speed

    iface=$(first_connected_iface "ethernet")
    if [[ -n "$iface" ]]; then
        ip_addr=$(ipv4_for_iface "$iface")
        speed=$(speed_for_iface "$iface")
        print_status "ethernet" "$iface" "100" "${ip_addr:--}" "$speed"
        return
    fi

    iface=$(first_connected_iface "wifi")
    if [[ -z "$iface" ]]; then
        iface=$(default_iface)
    fi

    if [[ -n "$iface" ]]; then
        name=$(wifi_name_for_iface "$iface")
        if [[ -n "$name" ]]; then
            signal=$(wifi_signal_for_iface "$iface")
            ip_addr=$(ipv4_for_iface "$iface")
            speed=$(speed_for_iface "$iface")
            print_status "wifi" "$name" "${signal:-0}" "${ip_addr:--}" "$speed"
            return
        fi
    fi

    print_status "none" "Sin conexion" "0" "-" "-"
}

main "$@"
