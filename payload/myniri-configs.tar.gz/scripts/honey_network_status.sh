#!/usr/bin/env bash
set -u

export LC_ALL=C

clamp_signal() {
    local value="${1:-0}"
    case "$value" in
        ''|*[!0-9-]*) value=0 ;;
    esac
    if [ "$value" -lt 0 ]; then value=0; fi
    if [ "$value" -gt 100 ]; then value=100; fi
    printf '%s\n' "$value"
}

ip_for_dev() {
    local dev="$1"
    ip -4 -o addr show dev "$dev" scope global 2>/dev/null \
        | awk '{split($4, a, "/"); print a[1]; exit}'
}

fallback_ip() {
    ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}'
}

wifi_signal_for_dev() {
    local dev="$1"
    local connected="${2:-false}"
    local signal=""

    if command -v nmcli >/dev/null 2>&1; then
        signal=$(nmcli -t -f IN-USE,SIGNAL device wifi list ifname "$dev" --rescan no 2>/dev/null \
            | awk -F: '$1=="*"{print $2; exit}')
    fi

    if [ -z "$signal" ] && command -v iw >/dev/null 2>&1; then
        local dbm=""
        dbm=$(iw dev "$dev" link 2>/dev/null | awk '/signal:/{print $2; exit}')
        if [ -n "$dbm" ]; then
            signal=$(awk -v s="$dbm" 'BEGIN{p=((s+90)/60)*100; if(p<0)p=0; if(p>100)p=100; printf "%.0f\n", p}')
        fi
    fi

    if [ -z "$signal" ] && [ "$connected" = "true" ]; then
        signal=50
    fi

    clamp_signal "${signal:-0}"
}

wifi_rate_for_dev() {
    local dev="$1"
    local rate=""

    if command -v nmcli >/dev/null 2>&1; then
        rate=$(nmcli -t -f IN-USE,RATE device wifi list ifname "$dev" --rescan no 2>/dev/null \
            | awk -F: '$1=="*"{print $2; exit}')
    fi

    if [ -z "$rate" ] && command -v iw >/dev/null 2>&1; then
        rate=$(iw dev "$dev" link 2>/dev/null | awk -F': ' '/tx bitrate:/{print $2; exit}')
    fi

    printf '%s\n' "${rate:-—}"
}

if command -v nmcli >/dev/null 2>&1; then
    while IFS=: read -r dev type state connection_rest; do
        [ "$state" = "connected" ] || continue

        case "$type" in
            ethernet)
                ip_addr=$(ip_for_dev "$dev")
                [ -n "$ip_addr" ] || ip_addr=$(fallback_ip)
                speed=$(cat "/sys/class/net/$dev/speed" 2>/dev/null)
                [ -n "$speed" ] && speed="${speed} Mb/s" || speed="—"
                printf 'ethernet\t%s\t100\t%s\t%s\n' "$dev" "${ip_addr:-—}" "$speed"
                exit 0
                ;;
            wifi)
                name="${connection_rest:-—}"
                signal=$(wifi_signal_for_dev "$dev" true)
                ip_addr=$(ip_for_dev "$dev")
                [ -n "$ip_addr" ] || ip_addr=$(fallback_ip)
                rate=$(wifi_rate_for_dev "$dev")
                printf 'wifi\t%s\t%s\t%s\t%s\n' "$name" "$signal" "${ip_addr:-—}" "$rate"
                exit 0
                ;;
        esac
    done < <(nmcli -t -f DEVICE,TYPE,STATE,CONNECTION device status 2>/dev/null)
fi

if command -v iw >/dev/null 2>&1; then
    dev=$(iw dev 2>/dev/null | awk '/Interface/{print $2; exit}')
    if [ -n "${dev:-}" ]; then
        ssid=$(iw dev "$dev" link 2>/dev/null | awk -F': ' '/SSID:/{print $2; exit}')
        if [ -n "$ssid" ]; then
            signal=$(wifi_signal_for_dev "$dev" true)
            ip_addr=$(ip_for_dev "$dev")
            [ -n "$ip_addr" ] || ip_addr=$(fallback_ip)
            rate=$(wifi_rate_for_dev "$dev")
            printf 'wifi\t%s\t%s\t%s\t%s\n' "$ssid" "$signal" "${ip_addr:-—}" "$rate"
            exit 0
        fi
    fi
fi

printf 'none\tSin conexión\t0\t—\t—\n'
