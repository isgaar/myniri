#!/usr/bin/env python3
import subprocess
import sys

def disable_output(output_name):
    # In Niri, we just run: niri msg output <name> off
    # Niri automatically moves all workspaces and windows from the disabled output to another active one!
    subprocess.run(["niri", "msg", "output", output_name, "off"])

if __name__ == "__main__":
    if len(sys.argv) > 1:
        disable_output(sys.argv[1])
