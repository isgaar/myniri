#!/bin/bash
# ~/scripts/set_wallpaper.sh

WALLPAPER_FILE="$HOME/.config/niri/wallpaper.txt"

# Fallback default wallpaper if the file doesn't exist
if [ ! -f "$WALLPAPER_FILE" ]; then
    mkdir -p "$(dirname "$WALLPAPER_FILE")"
    echo "$HOME/Descargas/if-the-mac-finder-icon-can-be-mo.png" > "$WALLPAPER_FILE"
fi

WP_PATH=$(cat "$WALLPAPER_FILE")

# Make sure swaybg is running with the correct wallpaper
killall swaybg 2>/dev/null || true
swaybg -i "$WP_PATH" -m fill &
