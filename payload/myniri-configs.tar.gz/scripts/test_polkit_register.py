import os
import sys
import gi
gi.require_version('Polkit', '1.0')
gi.require_version('PolkitAgent', '1.0')
from gi.repository import Polkit, PolkitAgent, GLib, Gio

class SimpleAgent(PolkitAgent.Listener):
    def __init__(self):
        super().__init__()

    def do_initiate_authentication(self, action_id, message, icon_name, details, cookie, identities, cancellable, callback, user_data):
        print("do_initiate_authentication called")
        callback.trigger()

    def do_initiate_authentication_finish(self, res):
        print("do_initiate_authentication_finish called")
        return True

def main():
    session_id = os.getenv("XDG_SESSION_ID")
    if not session_id:
        print("Error: XDG_SESSION_ID is not set.", file=sys.stderr)
        sys.exit(1)
        
    subject = Polkit.UnixSession.new(session_id)
    listener = SimpleAgent()
    
    try:
        # Register the agent
        # Flags: 0 is NONE
        listener.register(0, subject, "/org/freedesktop/PolicyKit1/AuthenticationAgent", None)
        print("Agent successfully registered on session", session_id)
    except Exception as e:
        print("Error registering agent:", e, file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
