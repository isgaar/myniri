#!/usr/bin/env python3
import sys
import os
import colorsys
from PIL import Image

def extract_accent(image_path):
    try:
        img = Image.open(image_path)
        img = img.resize((100, 100))
        img = img.convert('RGB')
    except Exception as e:
        print(f"Error opening image: {e}", file=sys.stderr)
        return "#5aa7de" # fallback default accent

    colors = img.getdata()
    candidates = []
    
    for r, g, b in colors:
        h, s, v = colorsys.rgb_to_hsv(r/255.0, g/255.0, b/255.0)
        # Filter for moderately vibrant colors (not too dark, light, or grey)
        if 0.20 < s < 0.95 and 0.25 < v < 0.85:
            candidates.append((h, s, v, (r, g, b)))
            
    if not candidates:
        # Fallback to simple average
        r_sum = g_sum = b_sum = 0
        for r, g, b in colors:
            r_sum += r
            g_sum += g
            b_sum += b
        n = len(colors)
        if n == 0:
            return "#5aa7de"
        return f"#{r_sum//n:02x}{g_sum//n:02x}{b_sum//n:02x}"
        
    # Group by Hue bins
    bins = [0] * 12
    for h, s, v, rgb in candidates:
        bin_idx = int(h * 12) % 12
        bins[bin_idx] += 1
        
    best_bin = bins.index(max(bins))
    bin_candidates = [c for c in candidates if int(c[0] * 12) % 12 == best_bin]
    
    # Select candidate with highest combined saturation & value
    bin_candidates.sort(key=lambda x: x[1] * x[2], reverse=True)
    
    r, g, b = bin_candidates[0][3]
    return f"#{r:02x}{g:02x}{b:02x}"

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("#5aa7de")
        sys.exit(0)
    print(extract_accent(sys.argv[1]))
