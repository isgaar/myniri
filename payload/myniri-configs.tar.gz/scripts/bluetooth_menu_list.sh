#!/bin/bash
# bluetooth_menu_list.sh - Devuelve un JSON estructurado de los dispositivos bluetooth conocidos

echo "["
first=true

bluetoothctl devices | while read -r _ mac name; do
    [ -z "$mac" ] && continue
    
    info=$(bluetoothctl info "$mac" 2>/dev/null)
    
    if echo "$info" | grep -q "Connected: yes"; then
        connected="true"
    else
        connected="false"
    fi
    
    icon=$(echo "$info" | grep "Icon:" | awk '{print $2}')
    uuid=$(echo "$info" | grep "UUID:")
    
    type="unknown"
    if [[ "$icon" == *audio* || "$icon" == *headset* || "$uuid" == *Audio* || "$uuid" == *Headset* ]]; then
        type="audio"
    elif [[ "$icon" == *keyboard* || "$uuid" == *Keyboard* ]]; then
        type="input"
    elif [[ "$icon" == *mouse* || "$uuid" == *Mouse* ]]; then
        type="input"
    elif [[ "$icon" == *gamepad* || "$icon" == *gaming* || "$uuid" == *Gamepad* ]]; then
        type="gamepad"
    elif [[ "$icon" == *phone* || "$uuid" == *Phone* ]]; then
        type="phone"
    elif [ -n "$icon" ]; then
        type="$icon"
    fi
    
    # Batería
    battery="null"
    bat_line=$(echo "$info" | grep -i "Battery Percentage:")
    if [ -n "$bat_line" ]; then
        bat_val=$(echo "$bat_line" | grep -o -E '\([0-9]+\)' | tr -d '()')
        [ -z "$bat_val" ] && bat_val=$(echo "$bat_line" | awk '{print $NF}')
        [[ "$bat_val" =~ ^[0-9]+$ ]] && battery="$bat_val"
    fi
    
    if [ "$first" = true ]; then
        first=false
    else
        echo ","
    fi
    
    clean_name=$(echo "$name" | sed 's/"/\\"/g')
    printf '  {"mac": "%s", "name": "%s", "connected": %s, "type": "%s", "battery": %s}' \
        "$mac" "$clean_name" "$connected" "$type" "$battery"
done
echo ""
echo "]"
