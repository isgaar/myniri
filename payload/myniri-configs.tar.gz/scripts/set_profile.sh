#!/bin/bash
# set_profile.sh — Aplica un perfil de energía (power-saver | balanced | performance).
# Compatible con: power-profiles-daemon, tuned-adm, cpupower governor.
# Uso: set_profile.sh <power-saver|balanced|performance>

readonly PROFILE="${1:-balanced}"
PATH="$PATH:/usr/sbin"

# ── Mapas de perfil → herramienta ────────────────────────────
_apply_dbus() {
    dbus-send --system --print-reply --dest=org.freedesktop.UPower.PowerProfiles \
        /org/freedesktop/UPower/PowerProfiles \
        org.freedesktop.DBus.Properties.Set \
        string:org.freedesktop.UPower.PowerProfiles \
        string:ActiveProfile \
        variant:string:"$PROFILE" >/dev/null 2>&1
}

_apply_tlp() {
    case "$PROFILE" in
        power-saver)  pkexec tlp bat ;;
        balanced)     pkexec tlp start ;;
        performance)  pkexec tlp ac  ;;
    esac
}

_apply_ppd() {
    case "$PROFILE" in
        power-saver)  powerprofilesctl set power-saver  ;;
        balanced)     powerprofilesctl set balanced      ;;
        performance)  powerprofilesctl set performance   ;;
    esac
}

_apply_tuned() {
    case "$PROFILE" in
        power-saver)  sudo tuned-adm profile balanced-battery      ;;
        balanced)     sudo tuned-adm profile balanced              ;;
        performance)  sudo tuned-adm profile throughput-performance ;;
    esac
}

_apply_governor() {
    local gov
    case "$PROFILE" in
        power-saver)  gov="powersave"  ;;
        balanced)     gov="schedutil"  ;;
        performance)  gov="performance" ;;
    esac
    # Aplicar a todos los núcleos
    for cpu_gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        echo "$gov" | sudo tee "$cpu_gov" > /dev/null 2>&1
    done
}

# ── Aplicar con la herramienta disponible ─────────────────────
if dbus-send --system --print-reply --dest=org.freedesktop.DBus /org/freedesktop/DBus org.freedesktop.DBus.NameHasOwner string:org.freedesktop.UPower.PowerProfiles 2>/dev/null | grep -q true; then
    _apply_dbus
elif command -v powerprofilesctl &>/dev/null; then
    _apply_ppd
elif command -v tlp &>/dev/null || [ -x /usr/sbin/tlp ]; then
    _apply_tlp
elif command -v tuned-adm &>/dev/null; then
    _apply_tuned
    # Reforzar con cpupower si está disponible
    command -v cpupower &>/dev/null && _apply_governor
else
    _apply_governor
fi

# ── Notificación ──────────────────────────────────────────────
case "$PROFILE" in
    power-saver)
        notify-send "Perfil de energía" "Power Saver activado\nAhorro máximo de batería" \
            --icon=battery-caution --expire-time=2500 ;;
    balanced)
        notify-send "Perfil de energía" "Balanced activado\nRendimiento equilibrado" \
            --icon=battery-good --expire-time=2500 ;;
    performance)
        notify-send "Perfil de energía" "Performance activado\nMáximo rendimiento" \
            --icon=battery-full --expire-time=2500 ;;
esac
