#!/bin/bash
# bt_status.sh — Estado de bluetooth para Waybar (return-type: json)
BT_ON=$(printf '\uf294')   # fa-bluetooth
BT_OFF=$(printf '\uf293')  # fa-bluetooth (off)

if bluetoothctl show 2>/dev/null | grep -q 'Powered: yes'; then
    # Contar dispositivos conectados
    connected=$(bluetoothctl devices Connected 2>/dev/null | wc -l)
    if [ "$connected" -gt 0 ]; then
        printf '{"text": "%s %s", "class": "on", "tooltip": "%s dispositivos conectados"}\n' \
            "$BT_ON" "$connected" "$connected"
    else
        printf '{"text": "%s", "class": "on", "tooltip": "Bluetooth encendido"}\n' "$BT_ON"
    fi
else
    printf '{"text": "%s", "class": "off", "tooltip": "Bluetooth apagado"}\n' "$BT_OFF"
fi
