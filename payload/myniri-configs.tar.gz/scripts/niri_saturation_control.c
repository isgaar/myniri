#define _GNU_SOURCE

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include <wayland-client.h>
#include "wlr-gamma-control-unstable-v1-client-protocol.h"

struct output_state {
    struct wl_output *wl_output;
    char *name;
};

struct app_state {
    struct wl_display *display;
    struct wl_registry *registry;
    struct zwlr_gamma_control_manager_v1 *gamma_manager;
    struct zwlr_gamma_control_v1 *gamma_control;
    struct output_state outputs[64];
    int output_count;
    const char *target_name;
    int saturation;
    uint32_t gamma_size;
    bool failed;
};

static volatile sig_atomic_t keep_running = 1;

static void handle_signal(int signum) {
    (void)signum;
    keep_running = 0;
}

static double clamp01(double value) {
    if (value < 0.0) return 0.0;
    if (value > 1.0) return 1.0;
    return value;
}

static int create_gamma_fd(uint32_t size, int saturation) {
    size_t ramp_bytes = (size_t)size * 3 * sizeof(uint16_t);
    int fd = memfd_create("niri-saturation-gamma", MFD_CLOEXEC);
    if (fd < 0) {
        perror("memfd_create");
        return -1;
    }

    if (ftruncate(fd, (off_t)ramp_bytes) != 0) {
        perror("ftruncate");
        close(fd);
        return -1;
    }

    uint16_t *ramps = mmap(NULL, ramp_bytes, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (ramps == MAP_FAILED) {
        perror("mmap");
        close(fd);
        return -1;
    }

    double amount = clamp01((double)saturation / 100.0);
    double contrast = 1.0 + amount * 0.65;

    for (uint32_t i = 0; i < size; i++) {
        double x = size > 1 ? (double)i / (double)(size - 1) : 0.0;
        double y = clamp01((x - 0.5) * contrast + 0.5);
        uint16_t value = (uint16_t)lrint(y * 65535.0);
        ramps[i] = value;
        ramps[size + i] = value;
        ramps[(size * 2) + i] = value;
    }

    munmap(ramps, ramp_bytes);
    lseek(fd, 0, SEEK_SET);
    return fd;
}

static void gamma_handle_size(void *data, struct zwlr_gamma_control_v1 *control, uint32_t size) {
    struct app_state *state = data;
    state->gamma_size = size;

    int fd = create_gamma_fd(size, state->saturation);
    if (fd < 0) {
        state->failed = true;
        return;
    }

    zwlr_gamma_control_v1_set_gamma(control, fd);
    close(fd);
    wl_display_flush(state->display);
}

static void gamma_handle_failed(void *data, struct zwlr_gamma_control_v1 *control) {
    (void)control;
    struct app_state *state = data;
    state->failed = true;
    keep_running = 0;
}

static const struct zwlr_gamma_control_v1_listener gamma_listener = {
    .gamma_size = gamma_handle_size,
    .failed = gamma_handle_failed,
};

static void output_handle_geometry(void *data, struct wl_output *output, int32_t x, int32_t y,
                                   int32_t physical_width, int32_t physical_height, int32_t subpixel,
                                   const char *make, const char *model, int32_t transform) {
    (void)data; (void)output; (void)x; (void)y; (void)physical_width; (void)physical_height;
    (void)subpixel; (void)make; (void)model; (void)transform;
}

static void output_handle_mode(void *data, struct wl_output *output, uint32_t flags,
                               int32_t width, int32_t height, int32_t refresh) {
    (void)data; (void)output; (void)flags; (void)width; (void)height; (void)refresh;
}

static void output_handle_done(void *data, struct wl_output *output) {
    (void)data; (void)output;
}

static void output_handle_scale(void *data, struct wl_output *output, int32_t factor) {
    (void)data; (void)output; (void)factor;
}

static void output_handle_name(void *data, struct wl_output *output, const char *name) {
    struct app_state *state = data;
    for (int i = 0; i < state->output_count; i++) {
        if (state->outputs[i].wl_output == output) {
            free(state->outputs[i].name);
            state->outputs[i].name = strdup(name);
            return;
        }
    }
}

static void output_handle_description(void *data, struct wl_output *output, const char *description) {
    (void)data; (void)output; (void)description;
}

static const struct wl_output_listener output_listener = {
    .geometry = output_handle_geometry,
    .mode = output_handle_mode,
    .done = output_handle_done,
    .scale = output_handle_scale,
    .name = output_handle_name,
    .description = output_handle_description,
};

static void registry_handle_global(void *data, struct wl_registry *registry, uint32_t name,
                                   const char *interface, uint32_t version) {
    struct app_state *state = data;
    if (strcmp(interface, wl_output_interface.name) == 0) {
        if (state->output_count >= 64) return;
        uint32_t bind_version = version >= 4 ? 4 : version;
        struct wl_output *output = wl_registry_bind(registry, name, &wl_output_interface, bind_version);
        state->outputs[state->output_count].wl_output = output;
        state->outputs[state->output_count].name = NULL;
        state->output_count++;
        wl_output_add_listener(output, &output_listener, state);
    } else if (strcmp(interface, zwlr_gamma_control_manager_v1_interface.name) == 0) {
        state->gamma_manager = wl_registry_bind(
            registry, name, &zwlr_gamma_control_manager_v1_interface, 1);
    }
}

static void registry_handle_global_remove(void *data, struct wl_registry *registry, uint32_t name) {
    (void)data; (void)registry; (void)name;
}

static const struct wl_registry_listener registry_listener = {
    .global = registry_handle_global,
    .global_remove = registry_handle_global_remove,
};

static struct wl_output *find_output(struct app_state *state) {
    for (int i = 0; i < state->output_count; i++) {
        if (state->outputs[i].name && strcmp(state->outputs[i].name, state->target_name) == 0) {
            return state->outputs[i].wl_output;
        }
    }
    return NULL;
}

static void cleanup(struct app_state *state) {
    if (state->gamma_control) {
        zwlr_gamma_control_v1_destroy(state->gamma_control);
    }
    if (state->gamma_manager) {
        zwlr_gamma_control_manager_v1_destroy(state->gamma_manager);
    }
    for (int i = 0; i < state->output_count; i++) {
        if (state->outputs[i].wl_output) wl_output_destroy(state->outputs[i].wl_output);
        free(state->outputs[i].name);
    }
    if (state->registry) wl_registry_destroy(state->registry);
    if (state->display) wl_display_disconnect(state->display);
}

int main(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s OUTPUT SATURATION_0_100\n", argv[0]);
        return 2;
    }

    struct app_state state = {0};
    state.target_name = argv[1];
    state.saturation = atoi(argv[2]);
    if (state.saturation < 0) state.saturation = 0;
    if (state.saturation > 100) state.saturation = 100;

    signal(SIGTERM, handle_signal);
    signal(SIGINT, handle_signal);

    state.display = wl_display_connect(NULL);
    if (!state.display) {
        fprintf(stderr, "Unable to connect to Wayland display\n");
        return 1;
    }

    state.registry = wl_display_get_registry(state.display);
    wl_registry_add_listener(state.registry, &registry_listener, &state);
    wl_display_roundtrip(state.display);
    wl_display_roundtrip(state.display);

    if (!state.gamma_manager) {
        fprintf(stderr, "zwlr_gamma_control_manager_v1 is not available\n");
        cleanup(&state);
        return 1;
    }

    struct wl_output *target = find_output(&state);
    if (!target) {
        fprintf(stderr, "Output not found: %s\n", state.target_name);
        cleanup(&state);
        return 1;
    }

    state.gamma_control = zwlr_gamma_control_manager_v1_get_gamma_control(
        state.gamma_manager, target);
    zwlr_gamma_control_v1_add_listener(state.gamma_control, &gamma_listener, &state);

    while (keep_running && !state.failed && wl_display_dispatch(state.display) != -1) {
    }

    cleanup(&state);
    return state.failed ? 1 : 0;
}
