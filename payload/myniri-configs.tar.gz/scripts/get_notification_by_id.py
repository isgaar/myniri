#!/usr/bin/env python3
import sys
import json
import dbus

def clean_dbus(val):
    if isinstance(val, dict):
        return {str(k): clean_dbus(v) for k, v in val.items()}
    elif isinstance(val, list):
        return [clean_dbus(x) for x in val]
    elif isinstance(val, (dbus.String, dbus.Signature)):
        return str(val)
    elif isinstance(val, (dbus.Byte, dbus.Int16, dbus.UInt16, dbus.Int32, dbus.UInt32, dbus.Int64, dbus.UInt64)):
        return int(val)
    elif isinstance(val, dbus.Double):
        return float(val)
    elif isinstance(val, dbus.Boolean):
        return bool(val)
    return val

def normalize_notif(n):
    urgency_map = {0: 'low', 1: 'normal', 2: 'high'}
    u_val = n.get('urgency', 1)
    if isinstance(u_val, int):
        urgency = urgency_map.get(u_val, 'normal')
    else:
        urgency = str(u_val)
    return {
        'id': n.get('id', 0),
        'app_name': n.get('app-name', ''),
        'app_icon': n.get('app-icon', ''),
        'desktop_entry': n.get('desktop-entry', ''),
        'summary': n.get('summary', ''),
        'body': n.get('body', ''),
        'urgency': urgency
    }

def main():
    if len(sys.argv) < 2:
        sys.exit(1)
    try:
        target_id = int(sys.argv[1])
    except ValueError:
        sys.exit(1)

    try:
        bus = dbus.SessionBus()
        obj = bus.get_object('org.freedesktop.Notifications', '/fr/emersion/Mako')
        iface = dbus.Interface(obj, 'fr.emersion.Mako')
        
        # Check active list first
        mako_list = [normalize_notif(clean_dbus(x)) for x in iface.ListNotifications()]
        for n in mako_list:
            if n['id'] == target_id:
                print(json.dumps(n))
                return
                
        # Check history
        mako_history = [normalize_notif(clean_dbus(x)) for x in iface.ListHistory()]
        for n in mako_history:
            if n['id'] == target_id:
                print(json.dumps(n))
                return
    except Exception as e:
        sys.stderr.write(str(e) + "\n")
        sys.exit(1)

if __name__ == '__main__':
    main()
