#!/bin/bash
# Returns the focused output name in Niri
niri msg --json focused-output | jq -r '.name'
