#!/bin/bash
# /home/ismael/scripts/mount_device.sh

DEVICE="$1"

if [ -z "$DEVICE" ]; then
    echo "Error: No se especificó el dispositivo." >&2
    exit 1
fi

# Ejecutar el montaje capturando stdout y stderr juntos
RESULT=$(udisksctl mount -b "$DEVICE" 2>&1)
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ] && echo "$RESULT" | grep -q "Mounted"; then
    # Extraer el punto de montaje
    MOUNTPOINT=$(echo "$RESULT" | grep -o 'at .*' | sed 's/^at //' | sed 's/\.$//')
    echo "$MOUNTPOINT"
    notify-send --icon=media-removable "Dispositivo montado" "$MOUNTPOINT"
    exit 0
else
    notify-send --icon=media-removable "Error al montar" "$RESULT"
    exit 1
fi
