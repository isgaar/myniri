#!/bin/bash
readonly QS_CONFIG="unified"
readonly PID_FILE="/tmp/qs-${QS_CONFIG}.pid"
readonly LOG_FILE="/tmp/qs-${QS_CONFIG}.log"

_do_toggle() {
    qs ipc -c "$QS_CONFIG" call panel toggle &
}

if [[ -f "$PID_FILE" ]]; then
    saved_pid=$(cat "$PID_FILE")
    if kill -0 "$saved_pid" 2>/dev/null; then
        _do_toggle
        exit 0
    fi
    rm -f "$PID_FILE"
fi

running_pid=$(pgrep -f "^qs -c ${QS_CONFIG}$" | head -1)
if [[ -n "$running_pid" ]]; then
    echo "$running_pid" > "$PID_FILE"
    _do_toggle
    exit 0
fi

nohup qs -c "$QS_CONFIG" >> "$LOG_FILE" 2>&1 &
new_pid=$!
echo "$new_pid" > "$PID_FILE"
disown "$new_pid" 2>/dev/null || true

sleep 0.8
_do_toggle
