#!/usr/bin/env python3
import os

def main():
    filepath = "/home/ismael/.config/quickshell/unified/SettingsWindow.qml"
    
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    # Define ranges (1-indexed line numbers)
    # Note: in Python list, indices are 0-based, so line N is lines[N-1]
    ranges = [
        ("personalizationPageComp", 848, 1416),
        ("generalPageComp", 1421, 1782),
        ("defaultappsPageComp", 1787, 2045),
        ("conexionesPageComp", 2050, 2348),
        ("audioPageComp", 2353, 2548),
        ("monitorsPageComp", 2553, 3197),
        ("systemPageComp", 3202, 3333)
    ]
    
    components_code = []
    
    # Extract blocks
    for name, start, end in ranges:
        block_lines = lines[start-1:end]
        block_text = "".join(block_lines)
        # We can change visible: root.activeTab === "..." to visible: true if we want,
        # but leaving it as is works perfectly and is safer.
        comp_text = f"    Component {{\n        id: {name}\n{block_text}    }}\n\n"
        components_code.append(comp_text)
    
    # We will replace from line 848 (index 847) to line 3333 (index 3332)
    # with the Loader component.
    loader_code = """                    // Cargador dinámico de pestañas (Optimización de Memoria)
                    Loader {
                        id: tabLoader
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        sourceComponent: {
                            if (root.activeTab === "personalization") return personalizationPageComp
                            if (root.activeTab === "general") return generalPageComp
                            if (root.activeTab === "defaultapps") return defaultappsPageComp
                            if (root.activeTab === "conexiones") return conexionesPageComp
                            if (root.activeTab === "audio") return audioPageComp
                            if (root.activeTab === "monitors") return monitorsPageComp
                            if (root.activeTab === "system") return systemPageComp
                            return null
                        }
                    }
"""

    before_pages = lines[:848-1]
    after_pages = lines[3333:] # from index 3333 (which is line 3334) to end
    
    # We need to append components code just before the final closing brace of FloatingWindow
    # Let's find the last non-empty line and closing brace
    # The last lines are:
    # 3338: }
    # 3339: }
    # 3340: (empty)
    # Let's check where the closing brace of FloatingWindow is.
    # FloatingWindow starts at line 9. It's the root item.
    # The last brace of FloatingWindow is the very last brace in the file.
    
    # Let's rebuild the content
    new_lines = before_pages + [loader_code] + after_pages
    
    # Now, find the last closing brace in new_lines
    full_text = "".join(new_lines)
    
    # Let's search from the end for the last '}'
    last_brace_idx = full_text.rfind('}')
    if last_brace_idx == -1:
        print("Error: Could not find closing brace of FloatingWindow.")
        return
        
    components_joined = "".join(components_code)
    
    final_text = full_text[:last_brace_idx] + components_joined + full_text[last_brace_idx:]
    
    # Save the updated file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(final_text)
        
    print("✔ Refactored SettingsWindow.qml successfully with lazy components!")

if __name__ == "__main__":
    main()
