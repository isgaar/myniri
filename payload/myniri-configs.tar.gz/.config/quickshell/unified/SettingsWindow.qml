// SettingsWindow.qml — Aplicación de Ajustes para Niri
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

FloatingWindow {
    id: root

    WindowSettings { id: ws }

    implicitWidth: 800
    implicitHeight: 640
    title: root.activeTitle

    visible: false

    property string activeTab: "personalization"

    property var searchResults: []
    property int searchSelectedIndex: 0

    readonly property var settingsIndex: [
        // Personalización
        { id: "wallpaper", sectionId: "personalization", sectionLabel: "Personalización", label: "Fondo de Pantalla", desc: "Selecciona una imagen de fondo o de la colección local" },
        { id: "accentPreset", sectionId: "personalization", sectionLabel: "Personalización", label: "Acentos del Sistema", desc: "Ajusta la paleta de colores del sistema (azul, verde, naranja, etc.)" },
        { id: "otherAccent", sectionId: "personalization", sectionLabel: "Personalización", label: "Otros Acentos", desc: "Colores de acento personalizados extendidos" },
        { id: "darkMode", sectionId: "personalization", sectionLabel: "Personalización", label: "Modo oscuro", desc: "Esquema oscuro o claro de colores para ventanas y barras" },
        { id: "topbarStyle", sectionId: "personalization", sectionLabel: "Personalización", label: "Diseño de barra superior", desc: "Estilos visuales (Actual, Cupertino, etc.)" },
        { id: "animations", sectionId: "personalization", sectionLabel: "Personalización", label: "Animaciones visuales", desc: "Habilita transiciones y animaciones suaves en ventanas y barra" },
        { id: "corners", sectionId: "personalization", sectionLabel: "Personalización", label: "Esquinas redondeadas", desc: "Bordes curvos para ventanas de Niri, Waybar y Quickshell" },
        { id: "blur", sectionId: "personalization", sectionLabel: "Personalización", label: "Desenfoque de fondo (Blur)", desc: "Habilita el efecto de cristal esmerilado detrás de paneles y barras" },

        // General
        { id: "keyboardLayout", sectionId: "general", sectionLabel: "General", label: "Distribución del teclado", desc: "Configura la distribución del mapa de teclas (latam, us, es, de)" },
        { id: "tapToClick", sectionId: "general", sectionLabel: "General", label: "Tocar para hacer clic", desc: "Habilita tocar el touchpad para hacer clic izquierdo" },
        { id: "naturalScroll", sectionId: "general", sectionLabel: "General", label: "Desplazamiento natural", desc: "Invierte la dirección vertical del desplazamiento (scroll)" },
        { id: "cursorTheme", sectionId: "general", sectionLabel: "General", label: "Tema del cursor", desc: "Cambia el tema visual de los punteros del cursor" },
        { id: "gapInner", sectionId: "general", sectionLabel: "General", label: "Espacio interno (Gaps)", desc: "Espaciado interno entre ventanas en mosaico" },
        { id: "gapOuter", sectionId: "general", sectionLabel: "General", label: "Espacio externo (Gaps)", desc: "Espaciado entre ventanas y los bordes de la pantalla" },

        // Aplicaciones
        { id: "terminal", sectionId: "defaultapps", sectionLabel: "Aplicaciones", label: "Terminal predeterminado", desc: "Emulador de terminal preferido por el sistema (kitty, alacritty, foot, etc.)" },
        { id: "browser", sectionId: "defaultapps", sectionLabel: "Aplicaciones", label: "Navegador Web", desc: "Navegador predeterminado para abrir enlaces (zen, firefox, chrome, etc.)" },
        { id: "fileManager", sectionId: "defaultapps", sectionLabel: "Aplicaciones", label: "Gestor de Archivos", desc: "Gestor de archivos predeterminado (dolphin, nautilus, thunar, xdg-open)" },
        { id: "launcher", sectionId: "defaultapps", sectionLabel: "Aplicaciones", label: "Lanzador de aplicaciones", desc: "Lanzador por defecto (wmenu-run, tofi, rofi, etc.)" },

        // Conexiones
        { id: "ethernet", sectionId: "conexiones", sectionLabel: "Conexiones", label: "Red Cableada (Ethernet)", desc: "Estado y configuración de la conexión por cable ethernet" },
        { id: "wifi", sectionId: "conexiones", sectionLabel: "Conexiones", label: "Red Inalámbrica (Wi-Fi)", desc: "Habilitar Wi-Fi, buscar redes inalámbricas y conectar" },
        { id: "bluetooth", sectionId: "conexiones", sectionLabel: "Conexiones", label: "Bluetooth", desc: "Habilitar bluetooth, emparejar y conectar dispositivos" },

        // Sonido y Volumen
        { id: "audioVolume", sectionId: "audio", sectionLabel: "Sonido y Volumen", label: "Volumen Principal", desc: "Ajuste del volumen maestro y silenciar dispositivo de salida" },
        { id: "audioOutput", sectionId: "audio", sectionLabel: "Sonido y Volumen", label: "Dispositivos de Salida (Sink)", desc: "Selecciona el dispositivo de audio activo para reproducción" },

        // Monitores
        { id: "monitors", sectionId: "monitors", sectionLabel: "Monitores", label: "Monitores y Pantallas", desc: "Resolución, frecuencia de actualización, escalado y orientación del monitor" },

        // Información
        { id: "systemInfo", sectionId: "system", sectionLabel: "Información", label: "Información del Sistema", desc: "Versión de Kernel, CPU, uso de RAM, carga de CPU y versión de distribución" }
    ]

    function updateSearchResults(searchText) {
        let query = searchText.trim().toLowerCase()
        if (query.length === 0) {
            searchResults = []
            searchSelectedIndex = 0
            return
        }
        
        let filtered = []
        for (let i = 0; i < settingsIndex.length; i++) {
            let item = settingsIndex[i]
            if (item.label.toLowerCase().includes(query) || (item.desc && item.desc.toLowerCase().includes(query))) {
                filtered.push(item)
            }
        }
        searchResults = filtered
        if (searchSelectedIndex >= filtered.length) {
            searchSelectedIndex = 0
        }
    }

    function onSettingSelected(result) {
        // 1. Switch active page
        root.activeTab = result.sectionId
        
        // 2. Clear focus and search
        searchField.text = ""
        searchResults = []
        searchField.focus = false
        
        // 3. Navigate and highlight
        Qt.callLater(() => {
            if (tabLoader.item) {
                // Switch subTab for connections page
                if (result.sectionId === "conexiones") {
                    let sub = (result.id === "bluetooth") ? 1 : 0
                    if (tabLoader.item.connectionsSubTabsLayout) {
                        tabLoader.item.connectionsSubTabsLayout.subTab = sub
                    }
                }

                if (tabLoader.item.settingsMap) {
                    let target = tabLoader.item.settingsMap[result.id]
                    if (target) {
                        let row = target.parent
                        let rel = row.mapToItem(detailsScroll.contentItem, 0, 0)
                        let targetY = rel.y - detailsScroll.height / 2 + row.height / 2
                        
                        scrollAnimation.to = targetY
                        scrollAnimation.start()
                        
                        if (target.item) {
                            target.item.trigger()
                        }
                    }
                }
            }
        })
    }

    function selectHighlightedSetting() {
        if (searchResults.length > 0 && searchSelectedIndex >= 0 && searchSelectedIndex < searchResults.length) {
            onSettingSelected(searchResults[searchSelectedIndex])
        }
    }

    Component {
        id: highlightEffectComp
        Rectangle {
            id: highlight
            anchors.fill: parent
            radius: 8
            color: "transparent"
            border.color: "transparent"
            border.width: 1.5
            z: 10
            
            function trigger() {
                pulseAnim.stop()
                pulseAnim.start()
            }
            
            SequentialAnimation {
                id: pulseAnim
                ParallelAnimation {
                    ColorAnimation { target: highlight; property: "color"; to: root.accentSoft; duration: 250 }
                    ColorAnimation { target: highlight; property: "border.color"; to: root.accentBorder; duration: 250 }
                }
                ParallelAnimation {
                    ColorAnimation { target: highlight; property: "color"; to: "transparent"; duration: 600 }
                    ColorAnimation { target: highlight; property: "border.color"; to: "transparent"; duration: 600 }
                }
            }
        }
    }

    NumberAnimation {
        id: scrollAnimation
        target: detailsScroll.contentItem
        property: "contentY"
        duration: 350
        easing.type: Easing.OutQuad
    }

    property string activeTitle: root.activeTab === "general" ? "Configuración General" :
                                 root.activeTab === "personalization" ? "Personalización" :
                                 root.activeTab === "defaultapps" ? "Aplicaciones Predeterminadas" :
                                 root.activeTab === "conexiones" ? "Red y Conectividad" :
                                 root.activeTab === "audio" ? "Control de Sonido" :
                                 root.activeTab === "monitors" ? "Monitores" : "Información del Sistema"
    property string currentWallpaperPath: ""
    property string wallpaperPathInput: ""
    property string wallpaperStatus: ""
    property string username: "ismael"
    property string uptime: "..."
    
    // System metrics
    property string kernelVersion: "..."
    property string cpuModel: "..."
    property string ramUsage: "..."
    property string cpuUsage: "..."

    // General settings
    property string keyboardLayout: "latam"
    property bool tapToClick: true
    property bool naturalScrollEnabled: true
    property string cursorTheme: "breeze_cursors"
    property int cursorSize: 24
    property int gapInner: 2
    property int gapOuter: 1
    property bool smartBorders: false

    // Default applications
    property string defaultTerminal: "kitty"
    property string defaultBrowser: "zen"
    property string defaultFileManager: "dolphin"
    property string defaultLauncher: "wmenu-run"
    property string defaultScreenshot: "grim"
    property var fileManagerOptions: ["xdg-open"]

    // Conexiones state
    property string ethernetState: "unavailable"
    property bool wifiEnabled: false
    property bool bluetoothActive: false
    property string distroName: "Cargando…"

    // Audio state
    property string defaultSink: ""
    property string activeSinkLabel: "Dispositivo de Audio"
    property int audioVolume: 70
    property int pendingVolume: audioVolume
    property bool audioMuted: false
    property string audioTempName: ""
    readonly property color audioDanger: (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e06c6c"

    // Pending states for sliders
    property int tempGapInner: gapInner
    property int tempGapOuter: gapOuter

    function open(tabName) {
        root.visible = true
        activeTab = tabName || "personalization"
        wallpaperReader.running = false
        wallpaperReader.running = true
        systemInfoLoader.running = false
        systemInfoLoader.running = true
        niriCfgReader.running = false
        niriCfgReader.running = true
        if (root.activeTab === "audio") audioRefreshTimer.restart()
        dialogBox.forceActiveFocus()
    }

    onActiveTabChanged: {
        if (root.activeTab === "audio") audioRefreshTimer.restart()
    }

    function close() {
        root.visible = false
    }

    function getContrastColor(c) {
        let r = c.r;
        let g = c.g;
        let b = c.b;
        let luminance = 0.299 * r + 0.587 * g + 0.114 * b;
        return luminance > 0.6 ? "#121212" : "#ffffff";
    }

    function applyWallpaperPath(path) {
        let cleaned = (path || "").trim().replace(/^file:\/\//, "")
        if (!cleaned) {
            root.wallpaperStatus = "Indica una ruta de imagen válida"
            return
        }
        root.wallpaperStatus = "Aplicando fondo..."
        root.wallpaperPathInput = cleaned
        wallpaperUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--wallpaper", cleaned]
        wallpaperUpdater.running = true
    }

    // Theme colors (Translucent premium overrides to enable blur and perfect contrast)
    readonly property color bgMain:   "#ea121316"   // Fondo de la ventana (Negro pizarra profundo, 92% opacidad)
    readonly property color bgSidebar:"#b0191a1d"   // Fondo de la barra lateral (Gris oscuro premium, 69% opacidad)
    readonly property color bgCard:   "#f0202124"   // Fondo de las tarjetas contenedor (94% opacidad)
    readonly property color bgTile:   "#f5292a2d"   // Fondo de inputs y botones (96% opacidad)
    readonly property color border:   "#2d2e31"   // Bordes elegantes (Gris sutil)
    readonly property color textPri:  "#f3f4f6"   // Texto principal (Blanco puro legible)
    readonly property color textSec:  "#9ca3af"   // Texto secundario (Gris suave)
    readonly property color accent:   (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property color accentGn: "#30d158"
    readonly property color accentSoft: Qt.rgba(accent.r, accent.g, accent.b, 0.08)
    readonly property color accentBorder: Qt.rgba(accent.r, accent.g, accent.b, 0.4)
    readonly property bool animEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
    readonly property bool cornersEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false
    readonly property int cornerRadius: (shellRoot.themeConfig && shellRoot.themeConfig.cornerRadius) !== undefined ? shellRoot.themeConfig.cornerRadius : 12
    property int tempCornerRadius: cornerRadius
    readonly property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false
    readonly property int blurRadius: (shellRoot.themeConfig && shellRoot.themeConfig.blurRadius) !== undefined ? shellRoot.themeConfig.blurRadius : 7
    property int tempBlurRadius: blurRadius
    readonly property string topbarStyle: (shellRoot.themeConfig && shellRoot.themeConfig.topbarStyle) || "actual"

    onVisibleChanged: {
        if (visible) {
            syncCornerRadius()
        }
    }

    Connections {
        target: shellRoot
        function onThemeConfigChanged() {
            syncCornerRadius()
        }
    }

    function syncCornerRadius() {
        if (shellRoot.themeConfig) {
            if (shellRoot.themeConfig.cornersEnabled === false) {
                tempCornerRadius = 0;
            } else {
                tempCornerRadius = shellRoot.themeConfig.cornerRadius || 12;
            }
        }
    }

    // Color definitions for picker
    readonly property var colorPresets: [
        { name: "Auto", hex: "auto", displayColor: "transparent", isAuto: true },
        { name: "Azul", hex: "#007aff", displayColor: "#007aff", isAuto: false },
        { name: "Morado", hex: "#7c6fc4", displayColor: "#7c6fc4", isAuto: false },
        { name: "Rosa", hex: "#ff2d55", displayColor: "#ff2d55", isAuto: false },
        { name: "Rojo", hex: "#e06c6c", displayColor: "#e06c6c", isAuto: false },
        { name: "Naranja", hex: "#ff9500", displayColor: "#ff9500", isAuto: false },
        { name: "Amarillo", hex: "#ffcc00", displayColor: "#ffcc00", isAuto: false },
        { name: "Verde", hex: "#5db06a", displayColor: "#5db06a", isAuto: false },
        { name: "Gris", hex: "#8e8e93", displayColor: "#8e8e93", isAuto: false }
    ]

    readonly property var alternativePresets: [
        { name: "Oro", hex: "#e3a83b", displayColor: "#e3a83b", isAuto: false },
        { name: "Verde", hex: "#498183", displayColor: "#498183", isAuto: false },
        { name: "Azul", hex: "#517893", displayColor: "#517893", isAuto: false },
        { name: "Rosa", hex: "#bd3b41", displayColor: "#bd3b41", isAuto: false },
        { name: "Morado", hex: "#5e6995", displayColor: "#5e6995", isAuto: false },
        { name: "Naranja", hex: "#eb7c59", displayColor: "#eb7c59", isAuto: false }
    ]

    readonly property var topbarPresets: [
        { id: "actual", title: "Actual", subtitle: "Diseño translúcido oscuro" },
        { id: "cupertino", title: "Cupertino", subtitle: "Gradiente suave estilo macOS" }
    ]

    // ── Processes ──────────────────────────────────────────────────
    Process {
        id: wallpaperReader
        command: ["cat", "/home/ismael/.config/niri/wallpaper.txt"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let path = data.trim().replace(/^~/, "/home/ismael");
                root.currentWallpaperPath = path;
                if (!root.wallpaperPathInput) root.wallpaperPathInput = path;
            }
        }
    }

    Process {
        id: uptimeReader
        command: ["cat", "/proc/uptime"]
        running: root.visible
        stdout: SplitParser {
            onRead: data => {
                let uptimeSeconds = parseFloat(data.trim().split(" ")[0]);
                if (!isNaN(uptimeSeconds)) {
                    let days = Math.floor(uptimeSeconds / (24 * 3600));
                    let remaining = uptimeSeconds % (24 * 3600);
                    let hours = Math.floor(remaining / 3600);
                    remaining %= 3600;
                    let minutes = Math.floor(remaining / 60);
                    
                    let parts = [];
                    if (days > 0) parts.push(days + (days === 1 ? " day" : " days"));
                    if (hours > 0) parts.push(hours + (hours === 1 ? " hour" : " hours"));
                    if (minutes > 0) parts.push(minutes + (minutes === 1 ? " minute" : " minutes"));
                    root.uptime = parts.join(", ");
                }
            }
        }
    }

    Process {
        id: systemInfoLoader
        command: ["/home/ismael/scripts/get_system_stats.py"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let lines = data.trim().split("\n");
                if (lines.length >= 4) {
                    root.kernelVersion = lines[0].trim();
                    root.cpuModel = lines[1].trim();
                    root.ramUsage = lines[2].trim();
                    root.cpuUsage = lines[3].trim();
                }
            }
        }
    }

    Process {
        id: wallpaperChooser
        command: ["python3", "/home/ismael/scripts/select_wallpaper.py"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let path = data.trim();
                if (path) {
                    root.applyWallpaperPath(path);
                }
            }
        }
        stderr: SplitParser {
            onRead: data => {
                let msg = data.trim();
                if (msg) root.wallpaperStatus = msg;
            }
        }
    }

    Process {
        id: wallpaperUpdater
        command: []
        running: false
        onRunningChanged: {
            if (!running) {
                wallpaperReader.running = false;
                wallpaperReader.running = true;
                if (wallpaperUpdater.command.length > 0) root.wallpaperStatus = "Fondo actualizado"
            }
        }
    }

    Process {
        id: accentUpdater
        command: []
        running: false
    }

    Process {
        id: animationsUpdater
        command: []
        running: false
    }

    Process {
        id: cornersUpdater
        command: []
        running: false
    }

    Timer {
        id: cornersCommitTimer
        interval: 300
        repeat: false
        onTriggered: {
            if (root.tempCornerRadius !== root.cornerRadius) {
                cornersUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--corners", root.tempCornerRadius.toString()]
                cornersUpdater.running = true
            }
        }
    }

    Timer {
        id: blurCommitTimer
        interval: 300
        repeat: false
        onTriggered: {
            if (root.tempBlurRadius !== root.blurRadius) {
                blurUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--blur-radius", root.tempBlurRadius.toString()]
                blurUpdater.running = true
            }
        }
    }

    Process {
        id: blurUpdater
        command: []
        running: false
    }

    Process {
        id: topbarStyleUpdater
        command: []
        running: false
    }

    // ── Niri config reader ──────────────────────────────────────────────
    Process {
        id: niriCfgReader
        command: ["/home/ismael/scripts/read_niri_settings.py"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let cfg = JSON.parse(data.trim())
                    if (cfg.keyboard_layout) root.keyboardLayout = cfg.keyboard_layout
                    if (cfg.tap_to_click !== undefined) root.tapToClick = cfg.tap_to_click
                    if (cfg.natural_scroll !== undefined) root.naturalScrollEnabled = cfg.natural_scroll
                    if (cfg.cursor_theme) root.cursorTheme = cfg.cursor_theme
                    if (cfg.cursor_size) root.cursorSize = parseInt(cfg.cursor_size)
                    if (cfg.gap_inner !== undefined) { root.gapInner = parseInt(cfg.gap_inner); root.tempGapInner = root.gapInner }
                    if (cfg.gap_outer !== undefined) { root.gapOuter = parseInt(cfg.gap_outer); root.tempGapOuter = root.gapOuter }
                    if (cfg.smart_borders !== undefined) root.smartBorders = cfg.smart_borders
                    if (cfg.default_terminal) root.defaultTerminal = cfg.default_terminal
                    if (cfg.default_browser) root.defaultBrowser = cfg.default_browser
                    if (cfg.default_file_manager) root.defaultFileManager = cfg.default_file_manager
                    if (cfg.available_file_managers && cfg.available_file_managers.length > 0) root.fileManagerOptions = cfg.available_file_managers
                } catch(e) { console.log("Error parsing niri config:", e) }
            }
        }
    }

    Process {
        id: niriCfgWriter
        command: []
        running: false
    }

    // ── Audio controls ────────────────────────────────────────────────────
    ListModel { id: sinkModel }

    Process {
        id: audioRefresh
        command: ["bash", "-c", "default=$(pactl get-default-sink); echo \"DEFAULT:$default\"; pactl list sinks | grep -E \"Nombre:|Descripción:\"; pactl get-sink-volume @DEFAULT_SINK@ | grep -oP '\\d+%' | head -1 | tr -d '%'; pactl get-sink-mute @DEFAULT_SINK@ | awk '{print \"MUTE:\"$2}'"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("DEFAULT:")) {
                    root.defaultSink = line.substring(8).trim()
                    sinkModel.clear()
                } else if (line.startsWith("Nombre:")) {
                    root.audioTempName = line.substring(7).trim()
                } else if (line.startsWith("Descripción:")) {
                    let desc = line.substring(12).trim()
                    let name = root.audioTempName
                    let icon = "\uf028"
                    let dl = desc.toLowerCase()
                    let nl = name.toLowerCase()
                    if (dl.includes("headphone") || dl.includes("auricular") || nl.includes("headphone")) icon = "\uf590"
                    if (dl.includes("bluetooth") || dl.includes("bluez") || nl.includes("bluez")) icon = "\uf294"
                    if (dl.includes("hdmi") || dl.includes("dp")) icon = "\uf26c"
                    sinkModel.append({ name: name, label: desc, icon: icon })
                    if (name === root.defaultSink) root.activeSinkLabel = desc
                } else if (line.startsWith("MUTE:")) {
                    let val = line.substring(5).trim().toLowerCase()
                    root.audioMuted = (val === "yes" || val === "sí" || val === "si")
                } else {
                    let v = parseInt(line)
                    if (!isNaN(v)) {
                        root.audioVolume = Math.min(v, 100)
                        root.pendingVolume = root.audioVolume
                    }
                }
            }
        }
    }

    Timer {
        id: audioRefreshTimer
        interval: 100
        repeat: false
        onTriggered: {
            audioRefresh.running = false
            Qt.callLater(() => audioRefresh.running = true)
        }
    }

    Process { id: volumeSetterProcess }
    Process { id: muteProcess }
    Process { id: switchSinkProcess }

    Timer {
        id: volumeCommit
        interval: 15
        repeat: false
        onTriggered: {
            volumeSetterProcess.running = false
            volumeSetterProcess.command = ["bash", "-c", "pactl set-sink-volume @DEFAULT_SINK@ " + root.pendingVolume + "%; pactl set-sink-mute @DEFAULT_SINK@ 0"]
            volumeSetterProcess.running = true
        }
    }

    // ── Conexiones processes ──────────────────────────────────────────
    Process {
        id: wifiStatePoller
        command: ["bash", "-c", "nmcli -t -f WIFI radio 2>/dev/null"]
        running: root.visible && root.activeTab === "conexiones"
        stdout: SplitParser {
            onRead: data => {
                let state = data.trim()
                root.wifiEnabled = (state === "enabled" || state === "activado")
            }
        }
    }

    ListModel { id: btModel }

    Process {
        id: btStatePoller
        command: ["bash", "-c", "bluetoothctl show | grep -q 'Powered: yes' && echo 'on' || echo 'off'; bluetoothctl devices | while read -r _ mac name; do echo \"$mac|$name\"; done"]
        running: root.visible && root.activeTab === "conexiones"
        onRunningChanged: if (running) { btModel.clear() }

        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line === "on") { root.bluetoothActive = true; return }
                if (line === "off") { root.bluetoothActive = false; return }
                if (line.includes("|")) {
                    let parts = line.split("|")
                    let mac = parts[0]; let name = parts.slice(1).join("|")
                    if (mac && name) btModel.append({ mac: mac, label: name })
                }
            }
        }
    }

    Timer {
        id: btPollTimer
        interval: 3000
        running: root.visible && root.activeTab === "conexiones"
        repeat: true
        onTriggered: {
            btStatePoller.running = false
            Qt.callLater(() => btStatePoller.running = true)
        }
    }

    Process { id: btToggleProcess }

    Process {
        id: distroReader
        command: ["bash", "-c", "grep '^PRETTY_NAME=' /etc/os-release | cut -d= -f2- | tr -d '\"'"]
        running: root.visible
        stdout: SplitParser {
            onRead: data => {
                let v = data.trim()
                if (v) root.distroName = v
            }
        }
    }

    function setVolumeFromX(x, width) {
        let clampVal = Math.max(0, Math.min(1, x / width))
        root.pendingVolume = Math.round(clampVal * 100)
        root.audioVolume = root.pendingVolume
        if (root.audioVolume > 0) root.audioMuted = false
        volumeCommit.restart()
    }

    // Timer for gap changes
    Timer {
        id: gapCommitTimer
        interval: 300
        repeat: false
        onTriggered: {
            if (root.tempGapInner !== root.gapInner || root.tempGapOuter !== root.gapOuter) {
                niriCfgWriter.command = ["python3", "/home/ismael/scripts/update_settings.py", "--gaps", root.tempGapInner.toString(), root.tempGapOuter.toString()]
                niriCfgWriter.running = true
            }
        }
    }

    // Timer to poll system stats on Info page
    Timer {
        interval: 3000
        running: root.visible && root.activeTab === "system"
        repeat: true
        onTriggered: {
            systemInfoLoader.running = false
            systemInfoLoader.running = true
        }
    }

    color: "transparent"

    // Settings Box Layout
    Rectangle {
        id: dialogBox
        anchors.fill: parent
        width: 800
        height: 640
        radius: root.cornersEnabled && !root.fullscreen ? root.cornerRadius : 0
        color: "transparent"
        border.color: root.border
        border.width: 1
        focus: true

        scale: 1.0

        Keys.onEscapePressed: root.close()

        // Draggable Top Area (acts as the window title bar)
        MouseArea {
            id: titleBarDragArea
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            height: 50
            z: 0

            onPressed: mouse => {
                root.startSystemMove()
            }

            onDoubleClicked: {
                root.fullscreen = !root.fullscreen
            }
        }

        RowLayout {
            anchors.fill: parent
            spacing: 0

            // ── Sidebar (Left Pane) ─────────────────────────────────
            Rectangle {
                Layout.fillHeight: true
                Layout.preferredWidth: 230
                color: root.bgSidebar
                border.color: root.border
                border.width: 0 // border only on right
                
                // Radius binding for left corners
                topLeftRadius: root.cornersEnabled && !root.fullscreen ? root.cornerRadius : 0
                bottomLeftRadius: root.cornersEnabled && !root.fullscreen ? root.cornerRadius : 0

                Rectangle {
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    width: 1
                    color: root.border
                }

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 14
                    spacing: 12

                    // User profile section
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 12
                        Layout.topMargin: 8
                        Layout.bottomMargin: 8

                        Rectangle {
                            width: 46; height: 46; radius: 23
                            color: root.bgTile
                            border.color: root.border
                            border.width: 1

                            Image {
                                anchors.fill: parent
                                anchors.margins: 2
                                source: "file:///var/lib/AccountsService/icons/" + root.username
                                fillMode: Image.PreserveAspectCrop
                                visible: status === Image.Ready
                            }

                            QsText {
                                anchors.centerIn: parent
                                text: root.username.substring(0, 2).toUpperCase()
                                color: root.accent
                                font.family: "Inter"
                                font.pixelSize: 15
                                font.weight: Font.Medium
                                visible: parent.children[0].status !== Image.Ready
                            }
                        }

                        ColumnLayout {
                            spacing: 1
                            QsText {
                                text: "Ismael"
                                color: root.textPri
                                font.family: "Inter"
                                font.pixelSize: 14
                                font.weight: Font.DemiBold
                            }
                            QsText {
                                text: "up " + root.uptime
                                color: root.textSec
                                font.family: "Inter"
                                font.pixelSize: 10
                            }
                        }
                    }

                    // Search field container
                    Rectangle {
                        id: searchFieldContainer
                        Layout.fillWidth: true
                        height: 30
                        radius: 8
                        color: Qt.rgba(1, 1, 1, 0.03)
                        border.color: searchField.activeFocus ? root.accent : root.border
                        border.width: 1

                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: 8
                            anchors.rightMargin: 8
                            spacing: 6

                            QsText {
                                text: "\uf002"
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 11
                                color: root.textSec
                            }

                            TextField {
                                id: searchField
                                Layout.fillWidth: true
                                height: parent.height
                                placeholderText: "Buscar ajustes..."
                                color: root.textPri
                                placeholderTextColor: root.textSec
                                font.family: "Inter"
                                font.pixelSize: 11
                                selectByMouse: true
                                
                                background: Item {} // Handle styling on container

                                onTextChanged: {
                                    root.updateSearchResults(text)
                                }

                                Keys.onPressed: (event) => {
                                    if (event.key === Qt.Key_Down) {
                                        if (root.searchResults.length > 0) {
                                            root.searchSelectedIndex = (root.searchSelectedIndex + 1) % root.searchResults.length
                                        }
                                        event.accepted = true
                                    } else if (event.key === Qt.Key_Up) {
                                        if (root.searchResults.length > 0) {
                                            root.searchSelectedIndex = (root.searchSelectedIndex - 1 + root.searchResults.length) % root.searchResults.length
                                        }
                                        event.accepted = true
                                    } else if (event.key === Qt.Key_Enter || event.key === Qt.Key_Return) {
                                        root.selectHighlightedSetting()
                                        event.accepted = true
                                    } else if (event.key === Qt.Key_Escape) {
                                        searchField.text = ""
                                        searchResults = []
                                        searchField.focus = false
                                        event.accepted = true
                                    }
                                }
                            }
                        }
                    }



                    // Navigation Category List
                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: 4
                        Layout.topMargin: 8

                        Repeater {
                            model: [
                                { id: "general", label: "General", icon: "\uf013", accent: root.textPri },
                                { id: "personalization", label: "Personalización", icon: "\uf1fc", accent: root.accent },
                                { id: "defaultapps", label: "Aplicaciones", icon: "\uf085", accent: "#30d158" },
                                { id: "conexiones", label: "Conexiones", icon: "\uf1eb", accent: "#4a9fd4" },
                                { id: "audio", label: "Sonido y Volumen", icon: "\uf028", accent: "#5db06a" },
                                { id: "monitors", label: "Monitores", icon: "\uf108", accent: "#d44a7a" },
                                { id: "system", label: "Información", icon: "\uf05a", accent: "#e67e22" }
                            ]

                            delegate: Rectangle {
                                Layout.fillWidth: true
                                height: 34
                                radius: 8
                                color: root.activeTab === modelData.id ? Qt.rgba(255, 255, 255, 0.08) : "transparent"
                                border.color: root.activeTab === modelData.id ? root.border : "transparent"
                                border.width: 1

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 10
                                    anchors.rightMargin: 10
                                    spacing: 10

                                    Rectangle {
                                        width: 22; height: 22; radius: 6
                                        color: root.activeTab === modelData.id ? modelData.accent : Qt.rgba(1, 1, 1, 0.04)
                                        
                                        QsText {
                                            anchors.centerIn: parent
                                            text: modelData.icon
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 11
                                            color: root.activeTab === modelData.id ? root.getContrastColor(modelData.accent) : modelData.accent
                                        }
                                    }

                                    QsText {
                                        text: modelData.label
                                        color: root.activeTab === modelData.id ? root.textPri : Qt.darker(root.textPri, 1.1)
                                        font.family: "Inter"
                                        font.pixelSize: 12
                                        font.weight: root.activeTab === modelData.id ? Font.DemiBold : Font.Normal
                                        Layout.fillWidth: true
                                    }
                                }

                                MouseArea {
                                    anchors.fill: parent
                                    onClicked: root.activeTab = modelData.id
                                }
                            }
                        }
                        Item { Layout.fillHeight: true } // spacer
                    }

                    // Window Controls / Close
                    RowLayout {
                        Layout.fillWidth: true
                        Layout.bottomMargin: 4
                        spacing: 8
                        
                        Button {
                            text: "Cerrar"
                            Layout.fillWidth: true
                            contentItem: QsText {
                                text: parent.text
                                font.family: "Inter"
                                font.pixelSize: 12
                                font.weight: Font.Medium
                                color: root.textPri
                                horizontalAlignment: Text.AlignHCenter
                            }
                            background: Rectangle {
                                implicitHeight: 30
                                radius: 8
                                color: sidebarCloseHover.hovered ? Qt.rgba(255, 255, 255, 0.06) : "transparent"
                                border.color: sidebarCloseHover.hovered ? root.accent : root.border
                                border.width: 1
                                HoverHandler { id: sidebarCloseHover }
                            }
                            onClicked: root.close()
                        }
                    }
                }

                // Results dropdown popup
                Rectangle {
                    id: resultsDropdown
                    anchors.top: parent.top
                    anchors.topMargin: 122
                    anchors.left: parent.left
                    anchors.leftMargin: 14
                    width: 320
                    height: Math.min(240, resultsList.contentHeight + 10)
                    radius: 8
                    color: root.bgSidebar
                    border.color: root.border
                    border.width: 1
                    z: 100

                    visible: searchField.text.trim().length > 0 && searchField.activeFocus && root.searchResults.length > 0

                    ListView {
                        id: resultsList
                        anchors.fill: parent
                        anchors.margins: 4
                        clip: true
                        model: root.searchResults
                        currentIndex: root.searchSelectedIndex

                        onCurrentIndexChanged: {
                            resultsList.positionViewAtIndex(currentIndex, ListView.Contain)
                        }

                        delegate: Rectangle {
                            width: resultsList.width
                            height: 42
                            radius: 6
                            color: (root.searchSelectedIndex === index || resultMouseArea.containsMouse) ? Qt.rgba(255, 255, 255, 0.08) : "transparent"
                            border.color: (root.searchSelectedIndex === index) ? root.accent : "transparent"
                            border.width: 1

                            RowLayout {
                                anchors.fill: parent
                                anchors.leftMargin: 10
                                anchors.rightMargin: 10
                                spacing: 8

                                ColumnLayout {
                                    spacing: 1
                                    Layout.fillWidth: true
                                    QsText {
                                        text: modelData.label
                                        color: root.textPri
                                        font.family: "Inter"
                                        font.pixelSize: 11
                                        font.weight: Font.Medium
                                        elide: Text.ElideRight
                                        Layout.fillWidth: true
                                    }
                                    QsText {
                                        text: modelData.desc || ""
                                        color: root.textSec
                                        font.family: "Inter"
                                        font.pixelSize: 9
                                        elide: Text.ElideRight
                                        Layout.fillWidth: true
                                        visible: text.length > 0
                                    }
                                }

                                Rectangle {
                                    color: Qt.rgba(1, 1, 1, 0.05)
                                    border.color: root.border
                                    border.width: 0.5
                                    radius: 4
                                    implicitWidth: tagText.implicitWidth + 10
                                    implicitHeight: tagText.implicitHeight + 4
                                    QsText {
                                        id: tagText
                                        anchors.centerIn: parent
                                        text: modelData.sectionLabel
                                        color: root.accent
                                        font.family: "Inter"
                                        font.pixelSize: 8
                                        font.weight: Font.DemiBold
                                    }
                                }
                            }

                            MouseArea {
                                id: resultMouseArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    root.onSettingSelected(modelData)
                                }
                            }
                        }
                    }
                }
            }

            // ── Details (Right Pane) ────────────────────────────────
            Rectangle {
                Layout.fillWidth: true
                Layout.fillHeight: true
                color: root.bgCard
                topRightRadius: root.cornersEnabled && !root.fullscreen ? root.cornerRadius : 0
                bottomRightRadius: root.cornersEnabled && !root.fullscreen ? root.cornerRadius : 0

                // Header spacer for dragging (Window Controls are managed by Niri/GTK decorations)
                Item {
                    id: detailsHeader
                    anchors.top: parent.top
                    anchors.left: parent.left
                    anchors.right: parent.right
                    height: 50
                }

                ScrollView {
                    id: detailsScroll
                    anchors.top: detailsHeader.bottom
                    anchors.bottom: parent.bottom
                    anchors.left: parent.left
                    anchors.right: parent.right
                    clip: true
                    leftPadding: 24
                    rightPadding: 24
                    topPadding: 0
                    bottomPadding: 20
                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                    ScrollBar.vertical.interactive: true

                ColumnLayout {
                    width: detailsScroll.availableWidth
                    spacing: 18

                    // ── Active Tab Title ──
                    QsText {
                        text: root.activeTitle
                        color: root.textPri
                        font.family: "Inter"
                        font.pixelSize: 18
                        font.weight: Font.Bold
                        Layout.bottomMargin: 8
                    }

                    // =========================================================
                    // PAGE 1: Personalización
                    // =========================================================
                    // Cargador dinámico de pestañas (Optimización de Memoria)
                    Loader {
                        id: tabLoader
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        sourceComponent: {
                            if (root.activeTab === "personalization") return personalizationPageComp
                            if (root.activeTab === "general") return generalPageComp
                            if (root.activeTab === "defaultapps") return defaultappsPageComp
                            if (root.activeTab === "conexiones") return conexionesPageComp
                            if (root.activeTab === "audio") return audioPageComp
                            if (root.activeTab === "monitors") return monitorsPageComp
                            if (root.activeTab === "system") return systemPageComp
                            return null
                        }
                    }
                }
            }
        }
    }
}
    Component {
        id: personalizationPageComp
                    ColumnLayout {
                        visible: root.activeTab === "personalization"
                        Layout.fillWidth: true
                        spacing: 16

                        property var settingsMap: {
                            "wallpaper": hlWallpaper,
                            "accentPreset": hlAccentPreset,
                            "otherAccent": hlOtherAccent,
                            "darkMode": hlDarkMode,
                            "topbarStyle": hlTopbarStyle,
                            "animations": hlAnimations,
                            "corners": hlCorners,
                            "blur": hlBlur
                        }

                        // Wallpaper Section
                        QsText {
                            text: "Fondo de Pantalla"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: wallpaperLayout.implicitHeight + 24
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            Loader { id: hlWallpaper; anchors.fill: parent; sourceComponent: highlightEffectComp }

                            ColumnLayout {
                                id: wallpaperLayout
                                anchors.fill: parent
                                anchors.margins: 12
                                spacing: 10

                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: 14

                                    Rectangle {
                                        width: 104; height: 64; radius: 8
                                        color: root.bgTile
                                        border.color: root.border
                                        border.width: 1
                                        clip: true

                                        Image {
                                            anchors.fill: parent
                                            source: root.currentWallpaperPath ? "file://" + root.currentWallpaperPath : ""
                                            fillMode: Image.PreserveAspectCrop
                                            visible: status === Image.Ready
                                        }

                                        QsText {
                                            anchors.centerIn: parent
                                            text: "\uf03e"
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 16
                                            color: root.textSec
                                            visible: parent.children[0].status !== Image.Ready
                                        }
                                    }

                                    ColumnLayout {
                                        spacing: 3
                                        Layout.fillWidth: true
                                        QsText {
                                            text: root.currentWallpaperPath ? root.currentWallpaperPath.substring(root.currentWallpaperPath.lastIndexOf("/") + 1) : "Ninguno seleccionado"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.DemiBold
                                            elide: Text.ElideRight
                                            Layout.fillWidth: true
                                        }
                                        QsText {
                                            text: root.currentWallpaperPath || "Selecciona una imagen o pega una ruta local"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                            elide: Text.ElideMiddle
                                            Layout.fillWidth: true
                                        }
                                        QsText {
                                            text: root.wallpaperStatus
                                            color: root.wallpaperStatus.indexOf("actualizado") >= 0 ? root.accent : root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                            visible: root.wallpaperStatus.length > 0
                                            Layout.fillWidth: true
                                        }
                                    }

                                    Button {
                                        text: "Explorar"
                                        contentItem: QsText {
                                            text: parent.text
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            font.weight: Font.DemiBold
                                            color: root.getContrastColor(root.accent)
                                            horizontalAlignment: Text.AlignHCenter
                                            verticalAlignment: Text.AlignVCenter
                                        }
                                        background: Rectangle {
                                            implicitWidth: 88; implicitHeight: 30; radius: 6
                                            color: changeBgHover.hovered ? Qt.lighter(root.accent, 1.1) : root.accent
                                            HoverHandler { id: changeBgHover }
                                        }
                                        onClicked: {
                                            root.wallpaperStatus = ""
                                            wallpaperChooser.running = false
                                            wallpaperChooser.running = true
                                        }
                                    }
                                }

                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: 8

                                    TextField {
                                        id: wallpaperPathField
                                        Layout.fillWidth: true
                                        height: 32
                                        text: root.wallpaperPathInput
                                        placeholderText: "/home/ismael/Imágenes/fondo.png"
                                        selectByMouse: true
                                        color: root.textPri
                                        placeholderTextColor: root.textSec
                                        font.family: "Inter"
                                        font.pixelSize: 11
                                        onTextEdited: root.wallpaperPathInput = text
                                        onAccepted: root.applyWallpaperPath(text)
                                        background: Rectangle {
                                            radius: 7
                                            color: root.bgTile
                                            border.color: wallpaperPathField.activeFocus ? root.accent : root.border
                                            border.width: 1
                                        }
                                    }

                                    Button {
                                        text: "Aplicar"
                                        contentItem: QsText {
                                            text: parent.text
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            font.weight: Font.DemiBold
                                            color: root.textPri
                                            horizontalAlignment: Text.AlignHCenter
                                            verticalAlignment: Text.AlignVCenter
                                        }
                                        background: Rectangle {
                                            implicitWidth: 76; implicitHeight: 30; radius: 6
                                            color: applyBgHover.hovered ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
                                            border.color: root.border
                                            border.width: 1
                                            HoverHandler { id: applyBgHover }
                                        }
                                        onClicked: root.applyWallpaperPath(wallpaperPathField.text)
                                    }
                                }
                            }
                        }

                        // Theme Accent Colors
                        QsText {
                            text: "Tema de Color"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            Layout.topMargin: 6
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: colorCardLayout.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1


                            ColumnLayout {
                                id: colorCardLayout
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 10

                                ColumnLayout {
                                    id: rowAccentPreset
                                    Layout.fillWidth: true
                                    spacing: 2
                                    Loader { id: hlAccentPreset; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    QsText {
                                        text: "Acentos del Sistema"
                                        color: root.textPri
                                        font.family: "Inter"
                                        font.pixelSize: 12
                                        font.weight: Font.Medium
                                    }
                                    QsText {
                                        text: "Actualiza Quickshell y Waybar"
                                        color: root.textSec
                                        font.family: "Inter"
                                        font.pixelSize: 10
                                    }
                                }

                                // Color Preset list
                                RowLayout {
                                    spacing: 10
                                    Layout.alignment: Qt.AlignLeft

                                    Repeater {
                                        model: root.colorPresets

                                        delegate: Rectangle {
                                            width: 28; height: 28; radius: 14
                                            color: modelData.isAuto ? "transparent" : modelData.displayColor
                                            border.color: root.accent === modelData.hex || (modelData.isAuto && (shellRoot.themeConfig && shellRoot.themeConfig.accent_mode) === "auto") ? "#ffffff" : Qt.rgba(255, 255, 255, 0.15)
                                            border.width: root.accent === modelData.hex || (modelData.isAuto && (shellRoot.themeConfig && shellRoot.themeConfig.accent_mode) === "auto") ? 2 : 1

                                            // Draw Multicolor gradient circle for Auto
                                            Rectangle {
                                                visible: modelData.isAuto
                                                anchors.fill: parent
                                                radius: 14
                                                border.color: parent.border.color
                                                border.width: parent.border.width
                                                gradient: Gradient {
                                                    GradientStop { position: 0.0; color: "#ff3b30" }
                                                    GradientStop { position: 0.3; color: "#ffcc00" }
                                                    GradientStop { position: 0.6; color: "#4cd964" }
                                                    GradientStop { position: 1.0; color: "#007aff" }
                                                }
                                            }

                                            // Text for center dot if selected
                                            Rectangle {
                                                anchors.centerIn: parent
                                                width: 8; height: 8; radius: 4
                                                color: "#ffffff"
                                                visible: (modelData.isAuto && (shellRoot.themeConfig && shellRoot.themeConfig.accent_mode) === "auto") || (!modelData.isAuto && root.accent === modelData.hex && (shellRoot.themeConfig && shellRoot.themeConfig.accent_mode) !== "auto")
                                            }

                                            MouseArea {
                                                anchors.fill: parent
                                                onClicked: {
                                                    accentUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--accent", modelData.hex]
                                                    accentUpdater.running = true
                                                }
                                            }

                                            ToolTip.visible: colorPresetsHover.hovered
                                            ToolTip.text: modelData.name
                                            ToolTip.toolTip.background: Rectangle {
                                                color: root.bgCard
                                                border.color: root.border
                                                radius: 6
                                            }
                                            ToolTip.toolTip.contentItem: QsText {
                                                text: ToolTip.text
                                                color: root.textPri
                                                font.family: "Inter"
                                                font.pixelSize: 11
                                                font.weight: Font.Medium
                                            }
                                            HoverHandler { id: colorPresetsHover }
                                        }
                                    }
                                }

                                // Separator between presets
                                Rectangle {
                                    Layout.fillWidth: true
                                    height: 1
                                    color: root.border
                                    Layout.topMargin: 4
                                    Layout.bottomMargin: 4
                                }

                                ColumnLayout {
                                    id: rowOtherAccent
                                    Layout.fillWidth: true
                                    spacing: 2
                                    Loader { id: hlOtherAccent; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    QsText {
                                        text: "Otros Acentos"
                                        color: root.textPri
                                        font.family: "Inter"
                                        font.pixelSize: 12
                                        font.weight: Font.Medium
                                    }
                                    QsText {
                                        text: "Gama de colores de acento adicionales para el sistema"
                                        color: root.textSec
                                        font.family: "Inter"
                                        font.pixelSize: 10
                                    }
                                }

                                // Preset list
                                RowLayout {
                                    spacing: 10
                                    Layout.alignment: Qt.AlignLeft

                                    Repeater {
                                        model: root.alternativePresets

                                        delegate: Rectangle {
                                            width: 28; height: 28; radius: 14
                                            color: modelData.displayColor
                                            border.color: root.accent === modelData.hex && (shellRoot.themeConfig && shellRoot.themeConfig.accent_mode) !== "auto" ? "#ffffff" : Qt.rgba(255, 255, 255, 0.15)
                                            border.width: root.accent === modelData.hex && (shellRoot.themeConfig && shellRoot.themeConfig.accent_mode) !== "auto" ? 2 : 1

                                            // Text for center dot if selected
                                            Rectangle {
                                                anchors.centerIn: parent
                                                width: 8; height: 8; radius: 4
                                                color: "#ffffff"
                                                visible: root.accent === modelData.hex && (shellRoot.themeConfig && shellRoot.themeConfig.accent_mode) !== "auto"
                                            }

                                            MouseArea {
                                                anchors.fill: parent
                                                onClicked: {
                                                    accentUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--accent", modelData.hex]
                                                    accentUpdater.running = true
                                                }
                                            }

                                            ToolTip.visible: alternativePresetsHover.hovered
                                            ToolTip.text: modelData.name
                                            ToolTip.toolTip.background: Rectangle {
                                                color: root.bgCard
                                                border.color: root.border
                                                radius: 6
                                            }
                                            ToolTip.toolTip.contentItem: QsText {
                                                text: ToolTip.text
                                                color: root.textPri
                                                font.family: "Inter"
                                                font.pixelSize: 11
                                                font.weight: Font.Medium
                                            }
                                            HoverHandler { id: alternativePresetsHover }
                                        }
                                    }
                                }
                            }
                        }

                        // Apariencia
                        QsText {
                            text: "Apariencia"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            Layout.topMargin: 6
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: appearanceLayout.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1


                            RowLayout {
                                id: appearanceLayout
                                anchors.fill: parent
                                anchors.margins: 14
                                Loader { id: hlDarkMode; anchors.fill: parent; sourceComponent: highlightEffectComp }

                                ColumnLayout {
                                    spacing: 1
                                    QsText {
                                        text: "Modo oscuro"
                                        color: root.textPri
                                        font.family: "Inter"
                                        font.pixelSize: 12
                                        font.weight: Font.Medium
                                    }
                                    QsText {
                                        text: "Usa un esquema de colores oscuros para ventanas y barras"
                                        color: root.textSec
                                        font.family: "Inter"
                                        font.pixelSize: 10
                                    }
                                }

                                Item { Layout.fillWidth: true }

                                // Custom Switch Toggle
                                SwitchButton {
                                    checked: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "dark"
                                    onToggled: {
                                        let isDark = (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "dark";
                                        let nextMode = isDark ? "light" : "dark";
                                        let scheme = isDark ? "prefer-light" : "prefer-dark";
                                        let cmd = ["bash", "-c",
                                            "gsettings set org.gnome.desktop.interface color-scheme '" + scheme + "' 2>/dev/null; " +
                                            "python3 /home/ismael/scripts/update_settings.py --mode " + nextMode + " 2>/dev/null; true"]
                                        Qt.createQmlObject(
                                            'import Quickshell.Io; Process { command: ' +
                                            JSON.stringify(cmd) + '; running: true }', root)
                                    }
                                }
                            }
                        }

                        QsText {
                            text: "Diseño de barra superior"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            Layout.topMargin: 6
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: topbarDesignLayout.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1


                            ColumnLayout {
                                id: topbarDesignLayout
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 10

                                ColumnLayout {
                                    id: rowTopbarStyle
                                    Layout.fillWidth: true
                                    spacing: 2
                                    Loader { id: hlTopbarStyle; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    QsText {
                                        text: "Estilo visual"
                                        color: root.textPri
                                        font.family: "Inter"
                                        font.pixelSize: 12
                                        font.weight: Font.Medium
                                    }
                                    QsText {
                                        text: "Cambia solo el fondo de la barra; conserva iconos, posiciones y accesos"
                                        color: root.textSec
                                        font.family: "Inter"
                                        font.pixelSize: 10
                                        Layout.fillWidth: true
                                    }
                                }

                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: 10

                                    Repeater {
                                        model: root.topbarPresets

                                        delegate: Rectangle {
                                            Layout.fillWidth: true
                                            implicitHeight: 94
                                            radius: 10
                                            color: root.topbarStyle === modelData.id ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.12) : root.bgTile
                                            border.color: root.topbarStyle === modelData.id ? root.accent : root.border
                                            border.width: root.topbarStyle === modelData.id ? 2 : 1

                                            ColumnLayout {
                                                anchors.fill: parent
                                                anchors.margins: 10
                                                spacing: 8

                                                Rectangle {
                                                    Layout.fillWidth: true
                                                    height: 28
                                                    radius: 5
                                                    color: "transparent"
                                                    clip: true

                                                    Rectangle {
                                                        anchors.fill: parent
                                                        visible: modelData.id === "actual"
                                                        color: root.bgMain
                                                    }

                                                    Rectangle {
                                                        anchors.fill: parent
                                                        visible: modelData.id === "cupertino"
                                                        color: "transparent"
                                                        clip: true

                                                        Rectangle {
                                                            anchors.fill: parent
                                                            gradient: Gradient {
                                                                orientation: Gradient.Vertical
                                                                GradientStop { position: 0.0; color: Qt.rgba(0.02, 0.025, 0.035, 0.62) }
                                                                GradientStop { position: 0.45; color: Qt.rgba(0.02, 0.025, 0.035, 0.30) }
                                                                GradientStop { position: 1.0; color: Qt.rgba(0.02, 0.025, 0.035, 0.035) }
                                                            }
                                                        }
                                                        Rectangle {
                                                            anchors.left: parent.left
                                                            anchors.right: parent.right
                                                            anchors.top: parent.top
                                                            height: 1
                                                            color: "transparent"
                                                        }
                                                        Rectangle {
                                                            anchors.left: parent.left
                                                            anchors.right: parent.right
                                                            anchors.bottom: parent.bottom
                                                            height: 1
                                                            color: Qt.rgba(0, 0, 0, 0.06)
                                                        }
                                                    }

                                                    RowLayout {
                                                        anchors.fill: parent
                                                        anchors.leftMargin: 8
                                                        anchors.rightMargin: 8
                                                        spacing: 6

                                                        Rectangle { width: 18; height: 14; radius: 4; color: "#f0eee8" }
                                                        QsText { text: "App"; color: "#f0eee8"; font.family: "Inter"; font.pixelSize: 10; font.weight: Font.DemiBold }
                                                        Item { Layout.fillWidth: true }
                                                        QsText { text: "\uf1eb"; color: "#f0eee8"; font.family: "Font Awesome 6 Free"; font.pixelSize: 10 }
                                                        QsText { text: "\uf028"; color: "#f0eee8"; font.family: "Font Awesome 6 Free"; font.pixelSize: 10 }
                                                        QsText { text: "80%"; color: "#f0eee8"; font.family: "Inter"; font.pixelSize: 9; font.weight: Font.DemiBold }
                                                    }
                                                }

                                                RowLayout {
                                                    Layout.fillWidth: true
                                                    spacing: 8

                                                    ColumnLayout {
                                                        Layout.fillWidth: true
                                                        spacing: 1
                                                        QsText {
                                                            text: modelData.title
                                                            color: root.textPri
                                                            font.family: "Inter"
                                                            font.pixelSize: 12
                                                            font.weight: Font.DemiBold
                                                        }
                                                        QsText {
                                                            text: modelData.subtitle
                                                            color: root.textSec
                                                            font.family: "Inter"
                                                            font.pixelSize: 10
                                                            elide: Text.ElideRight
                                                            Layout.fillWidth: true
                                                        }
                                                    }

                                                    Rectangle {
                                                        width: 16; height: 16; radius: 8
                                                        color: root.topbarStyle === modelData.id ? root.accent : "transparent"
                                                        border.color: root.topbarStyle === modelData.id ? root.accent : root.border
                                                        border.width: 1
                                                        QsText {
                                                            anchors.centerIn: parent
                                                            visible: root.topbarStyle === modelData.id
                                                            text: "\uf00c"
                                                            color: root.getContrastColor(root.accent)
                                                            font.family: "Font Awesome 6 Free"
                                                            font.pixelSize: 8
                                                            font.weight: Font.Bold
                                                        }
                                                    }
                                                }
                                            }

                                            MouseArea {
                                                anchors.fill: parent
                                                cursorShape: Qt.PointingHandCursor
                                                onClicked: {
                                                    if (root.topbarStyle !== modelData.id) {
                                                        topbarStyleUpdater.running = false
                                                        topbarStyleUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--topbar-style", modelData.id]
                                                        topbarStyleUpdater.running = true
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // System Effects
                        QsText {
                            text: "Efectos del Sistema"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            Layout.topMargin: 6
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: effectsColumn.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1


                            ColumnLayout {
                                id: effectsColumn
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 10

                                // Animaciones
                                RowLayout {
                                    id: rowAnimations
                                    Layout.fillWidth: true
                                    Loader { id: hlAnimations; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    ColumnLayout {
                                        spacing: 1
                                        QsText {
                                            text: "Animaciones visuales"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: "Habilita transiciones y suavizado en ventanas de control y barra"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }

                                    Item { Layout.fillWidth: true }

                                    SwitchButton {
                                        checked: root.animEnabled
                                        onToggled: {
                                            animationsUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--animations", root.animEnabled ? "false" : "true"]
                                            animationsUpdater.running = true
                                        }
                                    }
                                }

                                // Separador
                                Rectangle {
                                    Layout.fillWidth: true
                                    height: 1
                                    color: root.border
                                }

                                // Esquinas Redondeadas
                                ColumnLayout {
                                    id: rowCorners
                                    Layout.fillWidth: true
                                    spacing: 8
                                    Loader { id: hlCorners; anchors.fill: parent; sourceComponent: highlightEffectComp }

                                    RowLayout {
                                        Layout.fillWidth: true
                                        ColumnLayout {
                                            spacing: 1
                                            QsText {
                                                text: "Esquinas redondeadas"
                                                color: root.textPri
                                                font.family: "Inter"
                                                font.pixelSize: 12
                                                font.weight: Font.Medium
                                            }
                                            QsText {
                                                text: "Aplica bordes curvos a ventanas de Niri, Waybar y Quickshell"
                                                color: root.textSec
                                                font.family: "Inter"
                                                font.pixelSize: 10
                                            }
                                        }

                                        Item { Layout.fillWidth: true }

                                        SwitchButton {
                                            checked: root.cornersEnabled
                                            onToggled: {
                                                if (root.cornersEnabled) {
                                                    root.tempCornerRadius = 0
                                                } else {
                                                    root.tempCornerRadius = 12
                                                }
                                                cornersCommitTimer.restart()
                                            }
                                        }
                                    }

                                    // Slider para ajustar el radio de las esquinas
                                    RowLayout {
                                        Layout.fillWidth: true
                                        visible: root.cornersEnabled
                                        spacing: 12
                                        
                                        QsText {
                                            text: root.tempCornerRadius + "px"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            font.weight: Font.Medium
                                            Layout.preferredWidth: 32
                                        }

                                        Item {
                                            Layout.fillWidth: true
                                            height: 24

                                            Rectangle {
                                                id: track
                                                anchors.left: parent.left
                                                anchors.right: parent.right
                                                anchors.verticalCenter: parent.verticalCenter
                                                height: 6
                                                radius: 3
                                                color: root.border

                                                Rectangle {
                                                    width: (Math.max(0, Math.min(30, root.tempCornerRadius)) / 30) * parent.width
                                                    height: parent.height
                                                    radius: parent.radius
                                                    color: root.accent
                                                }
                                            }

                                            MouseArea {
                                                anchors.fill: parent
                                                cursorShape: Qt.PointingHandCursor
                                                onPressed: mouse => {
                                                    let val = Math.round((mouse.x / width) * 30)
                                                    root.tempCornerRadius = Math.max(0, Math.min(30, val))
                                                    cornersCommitTimer.restart()
                                                }
                                                onPositionChanged: mouse => {
                                                    if (pressed) {
                                                        let val = Math.round((mouse.x / width) * 30)
                                                        root.tempCornerRadius = Math.max(0, Math.min(30, val))
                                                        cornersCommitTimer.restart()
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Separador
                                Rectangle {
                                    Layout.fillWidth: true
                                    height: 1
                                    color: root.border
                                }

                                // Desenfoque (Blur)
                                ColumnLayout {
                                    id: rowBlur
                                    Layout.fillWidth: true
                                    spacing: 8
                                    Loader { id: hlBlur; anchors.fill: parent; sourceComponent: highlightEffectComp }

                                    RowLayout {
                                        Layout.fillWidth: true
                                        ColumnLayout {
                                            spacing: 1
                                            QsText {
                                                text: "Desenfoque de fondo (Blur)"
                                                color: root.textPri
                                                font.family: "Inter"
                                                font.pixelSize: 12
                                                font.weight: Font.Medium
                                            }
                                            QsText {
                                                text: "Habilita el efecto de cristal esmerilado detrás de paneles y barras"
                                                color: root.textSec
                                                font.family: "Inter"
                                                font.pixelSize: 10
                                            }
                                        }

                                        Item { Layout.fillWidth: true }

                                        SwitchButton {
                                            checked: root.blurEnabled
                                            onToggled: {
                                                blurUpdater.command = ["python3", "/home/ismael/scripts/update_settings.py", "--blur", root.blurEnabled ? "false" : "true"]
                                                blurUpdater.running = true
                                            }
                                        }
                                    }

                                    // Slider para ajustar la cantidad de blur
                                    RowLayout {
                                        Layout.fillWidth: true
                                        visible: root.blurEnabled
                                        spacing: 12
                                        
                                        QsText {
                                            text: root.tempBlurRadius + "px"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            font.weight: Font.Medium
                                            Layout.preferredWidth: 32
                                        }

                                        Item {
                                            Layout.fillWidth: true
                                            height: 24

                                            Rectangle {
                                                id: blurTrack
                                                anchors.left: parent.left
                                                anchors.right: parent.right
                                                anchors.verticalCenter: parent.verticalCenter
                                                height: 6
                                                radius: 3
                                                color: root.border

                                                Rectangle {
                                                    width: (Math.max(1, Math.min(10, root.tempBlurRadius)) / 10) * parent.width
                                                    height: parent.height
                                                    radius: parent.radius
                                                    color: root.accent
                                                }
                                            }

                                            MouseArea {
                                                anchors.fill: parent
                                                cursorShape: Qt.PointingHandCursor
                                                onPressed: mouse => {
                                                    let val = Math.round((mouse.x / width) * 10)
                                                    root.tempBlurRadius = Math.max(1, Math.min(10, val))
                                                    blurCommitTimer.restart()
                                                }
                                                onPositionChanged: mouse => {
                                                    if (pressed) {
                                                        let val = Math.round((mouse.x / width) * 10)
                                                        root.tempBlurRadius = Math.max(1, Math.min(10, val))
                                                        blurCommitTimer.restart()
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
    }

    Component {
        id: generalPageComp
                    ColumnLayout {
                        visible: root.activeTab === "general"
                        Layout.fillWidth: true
                        spacing: 16

                        property var settingsMap: {
                            "keyboardLayout": hlKbdLayout,
                            "tapToClick": hlTapToClick,
                            "naturalScroll": hlNaturalScroll,
                            "gapInner": hlGapInner,
                            "gapOuter": hlGapOuter,
                            "cursorTheme": hlCursorTheme
                        }

                        // Keyboard Layout
                        QsText {
                            text: "Teclado y Entrada"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: generalInputLayout.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            ColumnLayout {
                                id: generalInputLayout
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 12

                                // Keyboard layout
                                RowLayout {
                                    id: rowKeyboardLayout
                                    Layout.fillWidth: true
                                    Loader { id: hlKbdLayout; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    ColumnLayout {
                                        spacing: 1
                                        QsText {
                                            text: "Distribución del teclado"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: "Distribución XKB: " + root.keyboardLayout
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                    RowLayout {
                                        spacing: 6
                                        Repeater {
                                            model: ["latam", "us", "es", "de"]
                                            delegate: Rectangle {
                                                implicitWidth: Math.max(46, kbdText.implicitWidth + 16); height: 28; radius: 6
                                                color: root.keyboardLayout === modelData ? root.accent : (kbdHover.hovered ? Qt.rgba(1,1,1,0.06) : "transparent")
                                                border.color: root.keyboardLayout === modelData ? "transparent" : root.border
                                                border.width: 1
                                                QsText {
                                                    id: kbdText
                                                    anchors.centerIn: parent
                                                    text: modelData
                                                    font.family: "Inter"
                                                    font.pixelSize: 11
                                                    font.weight: root.keyboardLayout === modelData ? Font.Bold : Font.Medium
                                                    color: root.keyboardLayout === modelData ? root.getContrastColor(root.accent) : root.textPri
                                                }
                                                HoverHandler { id: kbdHover }
                                                MouseArea {
                                                    anchors.fill: parent
                                                    cursorShape: Qt.PointingHandCursor
                                                    onClicked: {
                                                        root.keyboardLayout = modelData
                                                        niriCfgWriter.command = ["python3", "/home/ismael/scripts/update_niri_config.py", "--layout", modelData]
                                                        niriCfgWriter.running = true
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Separator
                                Rectangle {
                                    Layout.fillWidth: true
                                    height: 1
                                    color: root.border
                                }

                                // Tap to click
                                RowLayout {
                                    id: rowTapToClick
                                    Layout.fillWidth: true
                                    Loader { id: hlTapToClick; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    ColumnLayout {
                                        spacing: 1
                                        QsText {
                                            text: "Tocar para hacer clic"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: "Habilita clic al tocar el touchpad"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                    SwitchButton {
                                        checked: root.tapToClick
                                        onToggled: {
                                            root.tapToClick = !root.tapToClick
                                            niriCfgWriter.command = ["python3", "/home/ismael/scripts/update_niri_config.py", "--tap-to-click", root.tapToClick ? "true" : "false"]
                                            niriCfgWriter.running = true
                                        }
                                    }
                                }

                                // Natural scroll
                                RowLayout {
                                    id: rowNaturalScroll
                                    Layout.fillWidth: true
                                    Loader { id: hlNaturalScroll; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    ColumnLayout {
                                        spacing: 1
                                        QsText {
                                            text: "Desplazamiento natural"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: "Invierte la dirección del scroll"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                    SwitchButton {
                                        checked: root.naturalScrollEnabled
                                        onToggled: {
                                            root.naturalScrollEnabled = !root.naturalScrollEnabled
                                            niriCfgWriter.command = ["python3", "/home/ismael/scripts/update_niri_config.py", "--natural-scroll", root.naturalScrollEnabled ? "true" : "false"]
                                            niriCfgWriter.running = true
                                        }
                                    }
                                }
                            }
                        }

                        // Gaps
                        QsText {
                            text: "Espaciado de Ventanas"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            Layout.topMargin: 6
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: gapsLayout.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            ColumnLayout {
                                id: gapsLayout
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 14

                                // Inner gaps
                                ColumnLayout {
                                    id: rowGapInner
                                    Layout.fillWidth: true
                                    spacing: 6
                                    Loader { id: hlGapInner; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    RowLayout {
                                        Layout.fillWidth: true
                                        QsText {
                                            text: "Espaciado interno"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        Item { Layout.fillWidth: true }
                                        QsText {
                                            text: root.tempGapInner + "px"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                    }
                                    Item {
                                        Layout.fillWidth: true
                                        height: 24
                                        Rectangle {
                                            id: gapInnerTrack
                                            anchors.left: parent.left
                                            anchors.right: parent.right
                                            anchors.verticalCenter: parent.verticalCenter
                                            height: 6; radius: 3
                                            color: root.border
                                            Rectangle {
                                                width: (Math.max(0, Math.min(20, root.tempGapInner)) / 20) * parent.width
                                                height: parent.height; radius: parent.radius
                                                color: root.accent
                                            }
                                        }
                                        MouseArea {
                                            anchors.fill: parent
                                            cursorShape: Qt.PointingHandCursor
                                            onPressed: mouse => {
                                                root.tempGapInner = Math.round((mouse.x / width) * 20)
                                                gapCommitTimer.restart()
                                            }
                                            onPositionChanged: mouse => {
                                                if (pressed) {
                                                    root.tempGapInner = Math.round((mouse.x / width) * 20)
                                                    gapCommitTimer.restart()
                                                }
                                            }
                                        }
                                    }
                                }

                                // Outer gaps
                                ColumnLayout {
                                    id: rowGapOuter
                                    Layout.fillWidth: true
                                    spacing: 6
                                    Loader { id: hlGapOuter; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    RowLayout {
                                        Layout.fillWidth: true
                                        QsText {
                                            text: "Espaciado externo"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        Item { Layout.fillWidth: true }
                                        QsText {
                                            text: root.tempGapOuter + "px"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                    }
                                    Item {
                                        Layout.fillWidth: true
                                        height: 24
                                        Rectangle {
                                            id: gapOuterTrack
                                            anchors.left: parent.left
                                            anchors.right: parent.right
                                            anchors.verticalCenter: parent.verticalCenter
                                            height: 6; radius: 3
                                            color: root.border
                                            Rectangle {
                                                width: (Math.max(0, Math.min(20, root.tempGapOuter)) / 20) * parent.width
                                                height: parent.height; radius: parent.radius
                                                color: root.accent
                                            }
                                        }
                                        MouseArea {
                                            anchors.fill: parent
                                            cursorShape: Qt.PointingHandCursor
                                            onPressed: mouse => {
                                                root.tempGapOuter = Math.round((mouse.x / width) * 20)
                                                gapCommitTimer.restart()
                                            }
                                            onPositionChanged: mouse => {
                                                if (pressed) {
                                                    root.tempGapOuter = Math.round((mouse.x / width) * 20)
                                                    gapCommitTimer.restart()
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Cursor
                        QsText {
                            text: "Cursor del Ratón"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            Layout.topMargin: 6
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: cursorLayout.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            ColumnLayout {
                                id: cursorLayout
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 12

                                RowLayout {
                                    id: rowCursorTheme
                                    Layout.fillWidth: true
                                    Loader { id: hlCursorTheme; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    ColumnLayout {
                                        spacing: 1
                                        QsText {
                                            text: "Tema del cursor"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: root.cursorTheme
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                    RowLayout {
                                        spacing: 6
                                        Repeater {
                                            model: ["breeze_cursors", "Adwaita", "DMZ-White", "Vanilla-DMZ"]
                                            delegate: Rectangle {
                                                implicitWidth: Math.max(46, cursorText.implicitWidth + 16); height: 28; radius: 6
                                                color: root.cursorTheme === modelData ? root.accent : (curHover.hovered ? Qt.rgba(1,1,1,0.06) : "transparent")
                                                border.color: root.cursorTheme === modelData ? "transparent" : root.border
                                                border.width: 1
                                                QsText {
                                                    id: cursorText
                                                    anchors.centerIn: parent
                                                    text: modelData
                                                    font.family: "Inter"
                                                    font.pixelSize: 10
                                                    font.weight: root.cursorTheme === modelData ? Font.Bold : Font.Medium
                                                    color: root.cursorTheme === modelData ? root.getContrastColor(root.accent) : root.textPri
                                                }
                                                HoverHandler { id: curHover }
                                                MouseArea {
                                                    anchors.fill: parent
                                                    cursorShape: Qt.PointingHandCursor
                                                    onClicked: {
                                                        root.cursorTheme = modelData
                                                        niriCfgWriter.command = ["python3", "/home/ismael/scripts/update_niri_config.py", "--cursor-theme", modelData]
                                                        niriCfgWriter.running = true
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
    }

    Component {
        id: defaultappsPageComp
                    ColumnLayout {
                        visible: root.activeTab === "defaultapps"
                        Layout.fillWidth: true
                        spacing: 16

                        property var settingsMap: {
                            "terminal": hlTerminal,
                            "browser": hlBrowser,
                            "fileManager": hlFileManager,
                            "launcher": hlLauncher
                        }

                        QsText {
                            text: "Aplicaciones del sistema"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: appsLayout.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            ColumnLayout {
                                id: appsLayout
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 4

                                // Terminal
                                RowLayout {
                                    id: rowTerminal
                                    Layout.fillWidth: true
                                    Loader { id: hlTerminal; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    Layout.preferredHeight: 42
                                    spacing: 12
                                    Rectangle {
                                        width: 32; height: 32; radius: 8
                                        color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.12)
                                        QsText {
                                            anchors.centerIn: parent
                                            text: "\uf120"
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 14
                                            color: root.accent
                                        }
                                    }
                                    ColumnLayout {
                                        spacing: 1
                                        Layout.fillWidth: true
                                        QsText {
                                            text: "Terminal"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: root.defaultTerminal
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                    RowLayout {
                                        spacing: 6
                                        Repeater {
                                            model: ["kitty", "alacritty", "foot", "gnome-terminal"]
                                            delegate: Rectangle {
                                                implicitWidth: 54; height: 28; radius: 6
                                                color: root.defaultTerminal === modelData ? root.accent : (appHover.hovered ? Qt.rgba(1,1,1,0.06) : "transparent")
                                                border.color: root.defaultTerminal === modelData ? "transparent" : root.border
                                                border.width: 1
                                                QsText {
                                                    anchors.centerIn: parent
                                                    text: modelData
                                                    font.family: "Inter"
                                                    font.pixelSize: 10
                                                    font.weight: root.defaultTerminal === modelData ? Font.Bold : Font.Medium
                                                    color: root.defaultTerminal === modelData ? root.getContrastColor(root.accent) : root.textPri
                                                }
                                                HoverHandler { id: appHover }
                                                MouseArea {
                                                    anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                                    onClicked: {
                                                        root.defaultTerminal = modelData
                                                        niriCfgWriter.command = ["python3", "/home/ismael/scripts/update_niri_config.py", "--terminal", modelData]
                                                        niriCfgWriter.running = true
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Browser
                                RowLayout {
                                    id: rowBrowser
                                    Layout.fillWidth: true
                                    Loader { id: hlBrowser; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    Layout.preferredHeight: 42
                                    spacing: 12
                                    Rectangle {
                                        width: 32; height: 32; radius: 8
                                        color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.12)
                                        QsText {
                                            anchors.centerIn: parent
                                            text: "\uf269"
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 14
                                            color: root.accent
                                        }
                                    }
                                    ColumnLayout {
                                        spacing: 1
                                        Layout.fillWidth: true
                                        QsText {
                                            text: "Navegador web"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: root.defaultBrowser + " (xdg-settings)"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                    RowLayout {
                                        spacing: 6
                                        Repeater {
                                            model: ["zen", "firefox", "brave-browser", "google-chrome"]
                                            delegate: Rectangle {
                                                implicitWidth: 54; height: 28; radius: 6
                                                color: root.defaultBrowser === modelData ? root.accent : (bwHover.hovered ? Qt.rgba(1,1,1,0.06) : "transparent")
                                                border.color: root.defaultBrowser === modelData ? "transparent" : root.border
                                                border.width: 1
                                                QsText {
                                                    anchors.centerIn: parent
                                                    text: modelData
                                                    font.family: "Inter"
                                                    font.pixelSize: 10
                                                    font.weight: root.defaultBrowser === modelData ? Font.Bold : Font.Medium
                                                    color: root.defaultBrowser === modelData ? root.getContrastColor(root.accent) : root.textPri
                                                }
                                                HoverHandler { id: bwHover }
                                                MouseArea {
                                                    anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                                    onClicked: {
                                                        root.defaultBrowser = modelData
                                                        niriCfgWriter.command = ["bash", "-c", "xdg-settings set default-web-browser " + modelData + ".desktop 2>/dev/null; python3 /home/ismael/scripts/update_niri_config.py --browser " + modelData]
                                                        niriCfgWriter.running = true
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // File Manager
                                RowLayout {
                                    id: rowFileManager
                                    Layout.fillWidth: true
                                    Loader { id: hlFileManager; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    Layout.preferredHeight: 42
                                    spacing: 12
                                    Rectangle {
                                        width: 32; height: 32; radius: 8
                                        color: Qt.rgba(48/255, 209/255, 88/255, 0.12)
                                        QsText {
                                            anchors.centerIn: parent
                                            text: "\uf07c"
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 14
                                            color: "#30d158"
                                        }
                                    }
                                    ColumnLayout {
                                        spacing: 1
                                        Layout.fillWidth: true
                                        QsText {
                                            text: "Gestor de archivos"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: "Abrir con " + root.defaultFileManager
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                    Item { Layout.fillWidth: true }
                                    RowLayout {
                                        spacing: 6
                                        Repeater {
                                            model: root.fileManagerOptions
                                            delegate: Rectangle {
                                                implicitWidth: Math.max(62, fmLabel.implicitWidth + 18); height: 28; radius: 6
                                                color: root.defaultFileManager === modelData ? root.accent : (fmHover.hovered ? Qt.rgba(1,1,1,0.06) : "transparent")
                                                border.color: root.defaultFileManager === modelData ? "transparent" : root.border
                                                border.width: 1
                                                QsText {
                                                    id: fmLabel
                                                    anchors.centerIn: parent
                                                    text: modelData
                                                    font.family: "Inter"
                                                    font.pixelSize: 10
                                                    font.weight: root.defaultFileManager === modelData ? Font.Bold : Font.Medium
                                                    color: root.defaultFileManager === modelData ? root.getContrastColor(root.accent) : root.textPri
                                                }
                                                HoverHandler { id: fmHover }
                                                MouseArea {
                                                    anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                                    onClicked: {
                                                        root.defaultFileManager = modelData
                                                        niriCfgWriter.command = ["python3", "/home/ismael/scripts/update_niri_config.py", "--file-manager", modelData]
                                                        niriCfgWriter.running = true
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Launcher
                                RowLayout {
                                    id: rowLauncher
                                    Layout.fillWidth: true
                                    Loader { id: hlLauncher; anchors.fill: parent; sourceComponent: highlightEffectComp }
                                    Layout.preferredHeight: 42
                                    spacing: 12
                                    Rectangle {
                                        width: 32; height: 32; radius: 8
                                        color: Qt.rgba(255/255, 159/255, 10/255, 0.12)
                                        QsText {
                                            anchors.centerIn: parent
                                            text: "\uf0ae"
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 14
                                            color: "#ff9f0a"
                                         }
                                    }
                                    ColumnLayout {
                                        spacing: 1
                                        Layout.fillWidth: true
                                        QsText {
                                            text: "Lanzador de aplicaciones"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                            font.weight: Font.Medium
                                        }
                                        QsText {
                                            text: "Lanzador QML integrado (Quickshell)"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                        }
                                    }
                                }
                            }
                        }
                    }
    }

    Component {
        id: conexionesPageComp
                    ColumnLayout {
                        id: connectionsPageRoot
                        visible: root.activeTab === "conexiones"
                        Layout.fillWidth: true
                        spacing: 12

                        property alias connectionsSubTabsLayout: connectionsSubTabsLayout

                        property var settingsMap: {
                            "ethernet": hlEthernet,
                            "wifi": hlWifi,
                            "bluetooth": hlBluetooth
                        }

                        // Sub-tabs: Wi-Fi/Ethernet | Bluetooth
                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: 36
                            radius: 10
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            RowLayout {
                                id: connectionsSubTabsLayout
                                anchors.fill: parent
                                anchors.margins: 4
                                spacing: 4

                                property int subTab: 0  // 0 = Wi-Fi | 1 = Bluetooth

                                Rectangle {
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true
                                    radius: 8
                                    color: parent.subTab === 0 ? Qt.rgba(1,1,1,0.06) : "transparent"

                                    RowLayout {
                                        anchors.centerIn: parent
                                        spacing: 6
                                        QsText { text: "\uf1eb"; font.family: "Font Awesome 6 Free"; font.pixelSize: 11; color: parent.parent.parent.subTab === 0 ? root.accent : root.textSec }
                                        QsText { text: "Wi-Fi / Ethernet"; color: root.textPri; font.family: "Inter"; font.pixelSize: 11; font.weight: parent.parent.parent.subTab === 0 ? Font.DemiBold : Font.Normal }
                                    }

                                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: parent.parent.subTab = 0 }
                                }

                                Rectangle {
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true
                                    radius: 8
                                    color: parent.subTab === 1 ? Qt.rgba(1,1,1,0.06) : "transparent"

                                    RowLayout {
                                        anchors.centerIn: parent
                                        spacing: 6
                                        QsText { text: "\uf294"; font.family: "Font Awesome 6 Free"; font.pixelSize: 11; color: parent.parent.parent.subTab === 1 ? "#7c6fc4" : root.textSec }
                                        QsText { text: "Bluetooth"; color: root.textPri; font.family: "Inter"; font.pixelSize: 11; font.weight: parent.parent.parent.subTab === 1 ? Font.DemiBold : Font.Normal }
                                    }

                                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: parent.parent.subTab = 1 }
                                }
                            }
                        }

                        // Wi-Fi / Ethernet pane
                        Rectangle {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1
                            visible: parent.children[1].subTab === 0
                            clip: true

                            ColumnLayout {
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 10

                                // Ethernet status
                                Process {
                                    id: ethernetPoller
                                    command: ["bash", "-c", "nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null | grep -E '^[^:]+:ethernet:' | head -1"]
                                    running: root.activeTab === "conexiones"
                                    stdout: SplitParser {
                                        onRead: data => {
                                            let parts = data.trim().split(":")
                                            root.ethernetState = parts.length >= 3 ? parts[2] : "unavailable"
                                        }
                                    }
                                }

                                RowLayout {
                                    id: rowEthernet
                                    Layout.fillWidth: true
                                    spacing: 10
                                    Loader { id: hlEthernet; anchors.fill: parent; sourceComponent: highlightEffectComp }

                                    Rectangle {
                                        width: 36; height: 36; radius: 10
                                        color: Qt.rgba(74/255, 159/255, 212/255, 0.12)
                                        QsText { anchors.centerIn: parent; text: "\uf796"; font.family: "Font Awesome 6 Free"; font.pixelSize: 16; color: "#4a9fd4" }
                                    }

                                    ColumnLayout {
                                        spacing: 1
                                        QsText { text: "Cableada (Ethernet)"; color: root.textPri; font.family: "Inter"; font.pixelSize: 12; font.weight: Font.Medium }
                                        QsText { text: root.ethernetState === "connected" ? "Conectado" : root.ethernetState === "connecting" ? "Conectando…" : "No conectado"; color: root.ethernetState === "connected" ? "#30d158" : root.textSec; font.family: "Inter"; font.pixelSize: 10 }
                                    }

                                    Item { Layout.fillWidth: true }

                                    Rectangle {
                                        width: 10; height: 10; radius: 5
                                        color: root.ethernetState === "connected" ? "#30d158" : root.border
                                    }
                                }

                                Rectangle {
                                    Layout.fillWidth: true; height: 1; color: root.border
                                }

                                ColumnLayout {
                                    id: rowWifi
                                    Layout.fillWidth: true
                                    spacing: 6
                                    Loader { id: hlWifi; anchors.fill: parent; sourceComponent: highlightEffectComp }

                                    RowLayout {
                                        spacing: 10
                                        Rectangle {
                                            width: 36; height: 36; radius: 10
                                            color: Qt.rgba(74/255, 159/255, 212/255, 0.12)
                                            QsText { anchors.centerIn: parent; text: "\uf1eb"; font.family: "Font Awesome 6 Free"; font.pixelSize: 16; color: "#4a9fd4" }
                                        }
                                        ColumnLayout {
                                            spacing: 1
                                            QsText { text: "Redes Inalámbricas"; color: root.textPri; font.family: "Inter"; font.pixelSize: 12; font.weight: Font.Medium }
                                            QsText { text: root.wifiEnabled ? "Wi-Fi activo" : "Wi-Fi apagado"; color: root.textSec; font.family: "Inter"; font.pixelSize: 10 }
                                        }
                                    }

                                    ScrollView {
                                        Layout.fillWidth: true
                                        Layout.preferredHeight: Math.min(320, networkList.implicitHeight + 8)
                                        clip: true
                                        ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                                        ScrollBar.vertical.policy: ScrollBar.AsNeeded

                                        PanelNetworkList {
                                            id: networkList
                                            width: parent.width
                                            visible: root.activeTab === "conexiones"
                                            bgCard: root.bgCard
                                            bgActive: Qt.rgba(1,1,1,0.04)
                                            border: root.border
                                            borderHi: root.border
                                            textPri: root.textPri
                                            textSec: root.textSec
                                            accent: root.accent
                                            accentWf: "#4a9fd4"
                                            activeTab: 1
                                        }
                                    }
                                }
                            }
                        }

                        // Bluetooth pane
                        Rectangle {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1
                            visible: parent.children[1].subTab === 1
                            clip: true

                            ColumnLayout {
                                anchors.fill: parent
                                spacing: 0

                                // Bluetooth state header
                                Rectangle {
                                    Layout.fillWidth: true
                                    Layout.preferredHeight: 68
                                    color: "transparent"

                                    RowLayout {
                                        id: rowBluetooth
                                        anchors.fill: parent
                                        anchors.margins: 14
                                        spacing: 12
                                        Loader { id: hlBluetooth; anchors.fill: parent; sourceComponent: highlightEffectComp }

                                        Rectangle {
                                            width: 40; height: 40; radius: 12
                                            color: Qt.rgba(124/255, 111/255, 196/255, 0.12)
                                            QsText { anchors.centerIn: parent; text: "\uf294"; font.family: "Font Awesome 6 Free"; font.pixelSize: 18; color: "#7c6fc4" }
                                        }

                                        ColumnLayout {
                                            spacing: 2
                                            Layout.fillWidth: true
                                            QsText { text: "Bluetooth"; color: root.textPri; font.family: "Inter"; font.pixelSize: 14; font.weight: Font.DemiBold }
                                            QsText { text: root.bluetoothActive ? "Activo · Visible" : "Inactivo"; color: root.bluetoothActive ? "#30d158" : root.textSec; font.family: "Inter"; font.pixelSize: 11 }
                                        }

                                        Item { Layout.fillWidth: true }

                                        // Custom switch
                                        Rectangle {
                                            width: 44; height: 24; radius: 12
                                            color: root.bluetoothActive ? "#7c6fc4" : root.border

                                            Rectangle {
                                                width: 20; height: 20; radius: 10
                                                color: "#ffffff"
                                                x: root.bluetoothActive ? 22 : 2
                                                y: 2
                                                Behavior on x { NumberAnimation { duration: 120 } }
                                            }

                                            MouseArea {
                                                anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                                onClicked: {
                                                    root.bluetoothActive = !root.bluetoothActive
                                                    btToggleProcess.command = ["bash", "-c", root.bluetoothActive ? "bluetoothctl power on" : "bluetoothctl power off"]
                                                    btToggleProcess.running = true
                                                }
                                            }
                                        }
                                    }
                                }

                                // Bluetooth devices list
                                ScrollView {
                                    Layout.fillWidth: true
                                    Layout.fillHeight: true
                                    clip: true
                                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                                    ScrollBar.vertical.policy: ScrollBar.AsNeeded
                                    leftPadding: 14; rightPadding: 14; bottomPadding: 14

                                    Item {
                                        width: parent.width
                                        implicitHeight: btListContent.implicitHeight

                                        ColumnLayout {
                                            id: btListContent
                                            width: parent.width
                                            spacing: 8

                                            QsText {
                                                text: "Dispositivos emparejados"
                                                color: root.textSec
                                                font.family: "Inter"
                                                font.pixelSize: 10
                                                font.weight: Font.Medium
                                                font.capitalization: Font.AllUppercase
                                                visible: btModel.count > 0
                                            }

                                            Repeater {
                                                model: btModel
                                                delegate: Rectangle {
                                                    Layout.fillWidth: true
                                                    height: 36
                                                    radius: 8
                                                    color: active ? Qt.rgba(124/255, 111/255, 196/255, 0.08) : Qt.rgba(1,1,1,0.03)
                                                    border.color: active ? "#7c6fc4" : "transparent"
                                                    border.width: active ? 1 : 0

                                                    RowLayout {
                                                        anchors.fill: parent; anchors.margins: 10
                                                        spacing: 8

                                                        Rectangle {
                                                            width: 8; height: 8; radius: 4
                                                            color: active ? "#30d158" : root.border
                                                        }

                                                        QsText {
                                                            text: label
                                                            color: root.textPri
                                                            font.family: "Inter"; font.pixelSize: 11
                                                            elide: Text.ElideRight; Layout.fillWidth: true
                                                        }

                                                        QsText {
                                                            text: active ? "Conectado" : ""
                                                            color: "#30d158"
                                                            font.family: "Inter"; font.pixelSize: 10
                                                        }
                                                    }
                                                }
                                            }

                                            QsText {
                                                text: btModel.count === 0 ? "Ningún dispositivo emparejado" : ""
                                                color: root.textSec
                                                font.family: "Inter"; font.pixelSize: 11
                                                horizontalAlignment: Text.AlignHCenter
                                                Layout.fillWidth: true
                                                Layout.topMargin: 20
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
    }

    Component {
        id: audioPageComp
                    ColumnLayout {
                        visible: root.activeTab === "audio"
                        Layout.fillWidth: true
                        spacing: 12

                        property var settingsMap: {
                            "audioVolume": hlAudioVolume,
                            "audioOutput": hlAudioOutput
                        }

                        // ── Volume slider card ──
                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: sliderCard.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            Loader { id: hlAudioVolume; anchors.fill: parent; sourceComponent: highlightEffectComp }

                            ColumnLayout {
                                id: sliderCard
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 10

                                QsText {
                                    text: root.activeSinkLabel
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 14
                                    font.weight: Font.DemiBold
                                    elide: Text.ElideRight
                                    Layout.fillWidth: true
                                }

                                RowLayout {
                                    Layout.fillWidth: true
                                    spacing: 12

                                    QsText {
                                        text: root.audioMuted ? "\uf6a9" : "\uf027"
                                        font.family: "Font Awesome 6 Free"
                                        font.weight: Font.Black
                                        font.pixelSize: 15
                                        color: root.audioMuted ? root.audioDanger : root.textSec
                                        Layout.preferredWidth: 20
                                        horizontalAlignment: Text.AlignHCenter

                                        TapHandler {
                                            onTapped: {
                                                muteProcess.running = false
                                                muteProcess.command = ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]
                                                muteProcess.running = true
                                                root.audioMuted = !root.audioMuted
                                                audioRefreshTimer.restart()
                                            }
                                        }
                                    }

                                    Item {
                                        Layout.fillWidth: true
                                        height: 24

                                        Rectangle {
                                            id: volTrack
                                            anchors.left: parent.left
                                            anchors.right: parent.right
                                            anchors.verticalCenter: parent.verticalCenter
                                            height: 8; radius: 4
                                            color: root.border

                                            Rectangle {
                                                width: (root.audioVolume / 100) * parent.width
                                                height: parent.height; radius: parent.radius
                                                color: root.audioMuted ? root.textSec : root.accentGn
                                            }
                                        }

                                        MouseArea {
                                            anchors.fill: parent
                                            cursorShape: Qt.PointingHandCursor
                                            onPressed: mouse => root.setVolumeFromX(mouse.x, width)
                                            onPositionChanged: mouse => { if (pressed) root.setVolumeFromX(mouse.x, width) }
                                        }
                                    }

                                    QsText {
                                        text: "\uf028"
                                        font.family: "Font Awesome 6 Free"
                                        font.pixelSize: 15
                                        color: root.textSec
                                        Layout.preferredWidth: 20
                                        horizontalAlignment: Text.AlignHCenter
                                    }
                                }

                                QsText {
                                    text: root.audioVolume + "%"
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 11
                                    horizontalAlignment: Text.AlignHCenter
                                    Layout.fillWidth: true
                                }
                            }
                        }

                        // ── Sink selector card ──
                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: sinkCard.implicitHeight + 28
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            Loader { id: hlAudioOutput; anchors.fill: parent; sourceComponent: highlightEffectComp }

                            ColumnLayout {
                                id: sinkCard
                                anchors.fill: parent
                                anchors.margins: 14
                                spacing: 8

                                QsText {
                                    text: "Dispositivos de salida"
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 10
                                    font.weight: Font.Medium
                                    font.capitalization: Font.AllUppercase
                                }

                                ColumnLayout {
                                    Layout.fillWidth: true
                                    spacing: 6

                                    Repeater {
                                        model: sinkModel

                                        delegate: Rectangle {
                                            Layout.fillWidth: true
                                            height: 38
                                            radius: 8
                                            color: model.name === root.defaultSink ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.12) : Qt.rgba(1, 1, 1, 0.03)
                                            border.color: model.name === root.defaultSink ? root.accent : root.border
                                            border.width: 1

                                            RowLayout {
                                                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                                                spacing: 8

                                                QsText {
                                                    text: model.icon
                                                    font.family: "Font Awesome 6 Free"
                                                    font.pixelSize: 12
                                                    color: model.name === root.defaultSink ? root.accent : root.textSec
                                                }

                                                QsText {
                                                    text: model.label
                                                    color: root.textPri
                                                    font.family: "Inter"
                                                    font.pixelSize: 11
                                                    font.weight: model.name === root.defaultSink ? Font.DemiBold : Font.Normal
                                                    elide: Text.ElideRight
                                                    Layout.fillWidth: true
                                                }

                                                QsText {
                                                    visible: model.name === root.defaultSink
                                                    text: "\uf00c"
                                                    font.family: "Font Awesome 6 Free"
                                                    font.pixelSize: 11
                                                    color: root.accent
                                                }
                                            }

                                            HoverHandler { id: sinkItemHover }
                                            Rectangle {
                                                anchors.fill: parent; radius: parent.radius
                                                color: sinkItemHover.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                                            }

                                            TapHandler {
                                                onTapped: {
                                                    let sname = model.name
                                                    let cmd = ["bash", "-c",
                                                        "pactl set-default-sink " + sname +
                                                        "; pactl list sink-inputs short | awk '{print $1}' | xargs -r -I{} pactl move-sink-input {} " + sname]
                                                    switchSinkProcess.running = false
                                                    switchSinkProcess.command = cmd
                                                    switchSinkProcess.running = true
                                                    root.defaultSink = sname
                                                    audioRefreshTimer.restart()
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
    }

    Component {
        id: monitorsPageComp
                    ColumnLayout {
                        id: monitorsPage
                        visible: root.activeTab === "monitors"
                        Layout.fillWidth: true
                        spacing: 14

                        property var settingsMap: {
                            "monitors": hlMonitors
                        }

                        Item {
                            id: hlMonitors
                            width: 0
                            height: 0
                            function trigger() {}
                        }

                        function getSnappedPosition(draggedName, targetX, targetY, draggedW, draggedH) {
                            let staticMonitors = [];
                            for (let i = 0; i < monitorsPage.monitorsArray.length; i++) {
                                let m = monitorsPage.monitorsArray[i];
                                if (m.name !== draggedName && m.active) {
                                    staticMonitors.push({
                                        x: m.rect.x,
                                        y: m.rect.y,
                                        w: m.rect.width,
                                        h: m.rect.height
                                    });
                                }
                            }
                            
                            if (staticMonitors.length === 0) {
                                return { x: targetX, y: targetY };
                            }

                            // Dynamic snap threshold based on mini-map scale (e.g. 24 pixels on mini-map)
                            let threshold = 24 / mapContainer.mapScale;

                            function overlapsAny(cx, cy) {
                                for (let j = 0; j < staticMonitors.length; j++) {
                                    let s = staticMonitors[j];
                                    let overlapX = (cx < s.x + s.w - 2) && (cx + draggedW > s.x + 2);
                                    let overlapY = (cy < s.y + s.h - 2) && (cy + draggedH > s.y + 2);
                                    if (overlapX && overlapY) return true;
                                }
                                return false;
                            }

                            function touchesAny(cx, cy) {
                                for (let j = 0; j < staticMonitors.length; j++) {
                                    let s = staticMonitors[j];
                                    let touchLeft = Math.abs((cx + draggedW) - s.x) < 5 && (cy < s.y + s.h) && (cy + draggedH > s.y);
                                    let touchRight = Math.abs(cx - (s.x + s.w)) < 5 && (cy < s.y + s.h) && (cy + draggedH > s.y);
                                    let touchTop = Math.abs((cy + draggedH) - s.y) < 5 && (cx < s.x + s.w) && (cx + draggedW > s.x);
                                    let touchBottom = Math.abs(cy - (s.y + s.h)) < 5 && (cx < s.x + s.w) && (cx + draggedW > s.x);
                                    if (touchLeft || touchRight || touchTop || touchBottom) return true;
                                }
                                return false;
                            }

                            // 1. Try independent axis snapping
                            let bestX = targetX;
                            let minDiffX = threshold;
                            let bestY = targetY;
                            let minDiffY = threshold;

                            for (let i = 0; i < staticMonitors.length; i++) {
                                let s = staticMonitors[i];

                                // X Candidates
                                let xCandidates = [
                                    s.x - draggedW,            // Touch left
                                    s.x + s.w,                 // Touch right
                                    s.x,                       // Align left
                                    s.x + s.w - draggedW,      // Align right
                                    s.x + (s.w - draggedW) / 2 // Align center X
                                ];

                                for (let j = 0; j < xCandidates.length; j++) {
                                    let cx = xCandidates[j];
                                    let diff = Math.abs(cx - targetX);
                                    if (diff < minDiffX) {
                                        minDiffX = diff;
                                        bestX = cx;
                                    }
                                }

                                // Y Candidates
                                let yCandidates = [
                                    s.y - draggedH,            // Touch top
                                    s.y + s.h,                 // Touch bottom
                                    s.y,                       // Align top
                                    s.y + s.h - draggedH,      // Align bottom
                                    s.y + (s.h - draggedH) / 2 // Align center Y
                                ];

                                for (let j = 0; j < yCandidates.length; j++) {
                                    let cy = yCandidates[j];
                                    let diff = Math.abs(cy - targetY);
                                    if (diff < minDiffY) {
                                        minDiffY = diff;
                                        bestY = cy;
                                    }
                                }
                            }

                            // If independent snapping results in a valid contiguous placement, return it
                            if (!overlapsAny(bestX, bestY) && touchesAny(bestX, bestY)) {
                                return { x: bestX, y: bestY };
                            }

                            // 2. Generate a comprehensive candidate list for cross-monitor alignment and touch
                            let candidates = [];
                            for (let i = 0; i < staticMonitors.length; i++) {
                                let s1 = staticMonitors[i];

                                let xLeft = s1.x - draggedW;
                                let xRight = s1.x + s1.w;
                                let yClampedS1 = Math.max(s1.y - draggedH + 1, Math.min(s1.y + s1.h - 1, targetY));

                                candidates.push({ x: xLeft, y: yClampedS1 });
                                candidates.push({ x: xRight, y: yClampedS1 });

                                let yTop = s1.y - draggedH;
                                let yBottom = s1.y + s1.h;
                                let xClampedS1 = Math.max(s1.x - draggedW + 1, Math.min(s1.x + s1.w - 1, targetX));

                                candidates.push({ x: xClampedS1, y: yTop });
                                candidates.push({ x: xClampedS1, y: yBottom });

                                for (let k = 0; k < staticMonitors.length; k++) {
                                    let s2 = staticMonitors[k];

                                    // Touch s1 left/right, align y with s2 top/bottom/center
                                    candidates.push({ x: xLeft, y: s2.y });
                                    candidates.push({ x: xLeft, y: s2.y + s2.h - draggedH });
                                    candidates.push({ x: xLeft, y: s2.y + (s2.h - draggedH) / 2 });

                                    candidates.push({ x: xRight, y: s2.y });
                                    candidates.push({ x: xRight, y: s2.y + s2.h - draggedH });
                                    candidates.push({ x: xRight, y: s2.y + (s2.h - draggedH) / 2 });

                                    // Touch s1 top/bottom, align x with s2 left/right/center
                                    candidates.push({ x: s2.x, y: yTop });
                                    candidates.push({ x: s2.x + s2.w - draggedW, y: yTop });
                                    candidates.push({ x: s2.x + (s2.w - draggedW) / 2, y: yTop });

                                    candidates.push({ x: s2.x, y: yBottom });
                                    candidates.push({ x: s2.x + s2.w - draggedW, y: yBottom });
                                    candidates.push({ x: s2.x + (s2.w - draggedW) / 2, y: yBottom });
                                }
                            }

                            // Filter candidates to find only valid (non-overlapping and contiguous) positions
                            let validCandidates = [];
                            for (let i = 0; i < candidates.length; i++) {
                                let c = candidates[i];
                                if (!overlapsAny(c.x, c.y) && touchesAny(c.x, c.y)) {
                                    validCandidates.push(c);
                                }
                            }

                            if (validCandidates.length > 0) {
                                let best = validCandidates[0];
                                let minDistSq = Infinity;
                                for (let i = 0; i < validCandidates.length; i++) {
                                    let c = validCandidates[i];
                                    let dx = c.x - targetX;
                                    let dy = c.y - targetY;
                                    let distSq = dx * dx + dy * dy;
                                    if (distSq < minDistSq) {
                                        minDistSq = distSq;
                                        best = c;
                                    }
                                }
                                return best;
                            }

                            // Ultimate fallback
                            return { x: targetX, y: targetY };
                        }

                        QsText {
                            text: "Configuración de Pantallas"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Bold
                            font.capitalization: Font.AllUppercase
                        }

                        // Mini-map para posicionar monitores
                        Rectangle {
                            id: mapContainer
                            Layout.fillWidth: true
                            height: 260
                            radius: 10
                            color: root.bgTile
                            border.color: root.border
                            border.width: 1
                            clip: true

                            // Compute active monitor bounds and scaling factors dynamically
                            property real mapMinX: {
                                let val = 0;
                                let first = true;
                                for (let i = 0; i < monitorsPage.monitorsArray.length; i++) {
                                    let m = monitorsPage.monitorsArray[i];
                                    if (m.active) {
                                        if (first || m.rect.x < val) { val = m.rect.x; first = false; }
                                    }
                                }
                                return val;
                            }
                            property real mapMinY: {
                                let val = 0;
                                let first = true;
                                for (let i = 0; i < monitorsPage.monitorsArray.length; i++) {
                                    let m = monitorsPage.monitorsArray[i];
                                    if (m.active) {
                                        if (first || m.rect.y < val) { val = m.rect.y; first = false; }
                                    }
                                }
                                return val;
                            }
                            property real mapMaxX: {
                                let val = 0;
                                let first = true;
                                for (let i = 0; i < monitorsPage.monitorsArray.length; i++) {
                                    let m = monitorsPage.monitorsArray[i];
                                    if (m.active) {
                                        if (first || (m.rect.x + m.rect.width) > val) { val = m.rect.x + m.rect.width; first = false; }
                                    }
                                }
                                return val;
                            }
                            property real mapMaxY: {
                                let val = 0;
                                let first = true;
                                for (let i = 0; i < monitorsPage.monitorsArray.length; i++) {
                                    let m = monitorsPage.monitorsArray[i];
                                    if (m.active) {
                                        if (first || (m.rect.y + m.rect.height) > val) { val = m.rect.y + m.rect.height; first = false; }
                                    }
                                }
                                return val;
                            }

                            property real mapWidth: mapMaxX - mapMinX
                            property real mapHeight: mapMaxY - mapMinY

                            property real mapScale: {
                                if (mapWidth <= 0 || mapHeight <= 0) return 0.05;
                                let padding = 40;
                                let availableW = mapContainer.width - padding * 2;
                                let availableH = mapContainer.height - padding * 2;
                                let scaleX = availableW / mapWidth;
                                let scaleY = availableH / mapHeight;
                                return Math.min(scaleX, scaleY, 0.10); // cap max scale so a single monitor isn't too huge
                            }

                            property real offsetX: (mapContainer.width - mapWidth * mapScale) / 2
                            property real offsetY: (mapContainer.height - mapHeight * mapScale) / 2

                            // Fondo de cuadrícula decorativo
                            Grid {
                                anchors.fill: parent
                                rows: 10; columns: 20
                                Repeater {
                                    model: 200
                                    Rectangle {
                                        width: parent.width / 20; height: parent.height / 10
                                        color: "transparent"
                                        border.color: Qt.rgba(1, 1, 1, 0.03)
                                        border.width: 1
                                    }
                                }
                            }

                            QsText {
                                text: "Arrastra para organizar"
                                color: root.textSec
                                font.family: "Inter"
                                font.pixelSize: 10
                                anchors.top: parent.top
                                anchors.left: parent.left
                                anchors.margins: 10
                                z: 10
                            }

                            Rectangle {
                                width: 60; height: 24; radius: 12
                                color: root.accent
                                anchors.top: parent.top
                                anchors.right: parent.right
                                anchors.margins: 10
                                z: 10
                                QsText {
                                    anchors.centerIn: parent
                                    text: "Hecho"
                                    color: root.getContrastColor(root.accent)
                                    font.family: "Inter"
                                    font.pixelSize: 11
                                    font.weight: Font.DemiBold
                                }
                                MouseArea {
                                    anchors.fill: parent
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: {
                                        root.activeTab = "personalization"
                                    }
                                }
                            }

                            // Active monitors representation mapped dynamically
                            Repeater {
                                model: monitorsPage.monitorsArray
                                delegate: Rectangle {
                                    id: mapMonitorDelegate
                                    visible: modelData.active
                                    width: modelData.rect.width * mapContainer.mapScale
                                    height: modelData.rect.height * mapContainer.mapScale
                                    x: mapContainer.offsetX + (modelData.rect.x - mapContainer.mapMinX) * mapContainer.mapScale
                                    y: mapContainer.offsetY + (modelData.rect.y - mapContainer.mapMinY) * mapContainer.mapScale
                                    color: modelData.primary ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.15) : Qt.rgba(1, 1, 1, 0.05)
                                    border.color: modelData.primary ? root.accent : root.border
                                    border.width: modelData.primary ? 2 : 1
                                    radius: 6


                                    Behavior on x { enabled: !mouseArea.drag.active; NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
                                    Behavior on y { enabled: !mouseArea.drag.active; NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
                                    Behavior on width { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
                                    Behavior on height { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }

                                    QsText {
                                        anchors.centerIn: parent
                                        width: parent.width - 12
                                        text: modelData.name + "\n" + modelData.rect.width + "x" + modelData.rect.height
                                        font.family: "Inter"
                                        font.pixelSize: 10
                                        color: root.textPri
                                        font.weight: Font.DemiBold
                                        horizontalAlignment: Text.AlignHCenter
                                        elide: Text.ElideRight
                                        wrapMode: Text.Wrap
                                    }

                                    MouseArea {
                                        id: mouseArea
                                        anchors.fill: parent
                                        drag.target: parent
                                        drag.axis: Drag.XAndYAxis
                                        cursorShape: Qt.PointingHandCursor
                                        onReleased: {
                                            let relativeX = (parent.x - mapContainer.offsetX) / mapContainer.mapScale + mapContainer.mapMinX
                                            let relativeY = (parent.y - mapContainer.offsetY) / mapContainer.mapScale + mapContainer.mapMinY
                                            
                                            // Magnet snapping!
                                            let snapped = monitorsPage.getSnappedPosition(modelData.name, relativeX, relativeY, modelData.rect.width, modelData.rect.height);
                                            
                                            let newX = Math.round(snapped.x)
                                            let newY = Math.round(snapped.y)
                                            monitorAction.run(["python3", "/home/ismael/scripts/update_monitors.py", "--position", modelData.name, String(newX), String(newY)])
                                            
                                            // Restore bindings destroyed by the drag target operation
                                            parent.x = Qt.binding(function() { return mapContainer.offsetX + (modelData.rect.x - mapContainer.mapMinX) * mapContainer.mapScale })
                                            parent.y = Qt.binding(function() { return mapContainer.offsetY + (modelData.rect.y - mapContainer.mapMinY) * mapContainer.mapScale })
                                        }
                                    }
                                }
                            }
                        }

                        property var monitorsArray: []

                        function updateMonitorField(name, field, value) {
                            let next = []
                            for (let i = 0; i < monitorsPage.monitorsArray.length; i++) {
                                let monitor = monitorsPage.monitorsArray[i]
                                if (monitor.name === name)
                                    monitor[field] = value
                                next.push(monitor)
                            }
                            monitorsPage.monitorsArray = next
                        }

                        Process {
                            id: monitorsReader
                            command: ["python3", "/home/ismael/scripts/update_monitors.py", "--list"]
                            running: root.activeTab === "monitors"
                            stdout: SplitParser {
                                onRead: data => {
                                    try {
                                        let parsed = JSON.parse(data.trim())
                                        parsed.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()))
                                        monitorsPage.monitorsArray = parsed
                                    } catch(e) {}
                                }
                            }
                        }

                        Process {
                            id: monitorAction
                            onExited: monitorsReader.running = true
                            function run(args) {
                                command = args
                                running = true
                            }
                        }

                        Timer {
                            interval: 5000
                            running: root.activeTab === "monitors"
                            repeat: true
                            onTriggered: monitorsReader.running = true
                        }

                        Repeater {
                            model: monitorsPage.monitorsArray
                            delegate: Rectangle {
                                id: monitorDelegate
                                property var monitorInfo: modelData
                                property int localSaturation: Number(modelData.saturation || 0)
                                Layout.fillWidth: true
                                implicitHeight: 322 + (comboRect.isExpanded ? comboRect.height - 32 : 0)
                                Layout.preferredHeight: implicitHeight
                                z: comboRect.isExpanded ? 10 : 0
                                radius: 10
                                color: "transparent"
                                border.color: root.border
                                border.width: 1

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.margins: 16
                                    spacing: 16

                                    // Monitor Icon
                                    Rectangle {
                                        width: 48; height: 48; radius: 24
                                        color: Qt.rgba(212/255, 74/255, 122/255, 0.15)
                                        QsText {
                                            anchors.centerIn: parent
                                            text: "\uf108"
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 20
                                            color: "#d44a7a"
                                        }
                                    }

                                    ColumnLayout {
                                        Layout.fillWidth: true
                                        spacing: 4

                                        QsText {
                                            text: monitorInfo.name + " (" + monitorInfo.make + " " + monitorInfo.model + ")"
                                            color: root.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 14
                                            font.weight: Font.DemiBold
                                        }

                                        QsText {
                                            text: monitorInfo.active ? "Resolución actual: " + monitorInfo.rect.width + "x" + monitorInfo.rect.height : "Desactivado"
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 12
                                        }

                                        RowLayout {
                                            spacing: 10
                                            Layout.topMargin: 8

                                            QsText {
                                                text: "Estado:"
                                                color: root.textPri
                                                font.family: "Inter"
                                                font.pixelSize: 12
                                            }

                                            // Toggle Switch
                                            Rectangle {
                                                width: 36; height: 20; radius: 10
                                                color: monitorInfo.active ? root.accentGn : root.border
                                                
                                                Rectangle {
                                                    anchors.fill: parent
                                                    radius: parent.radius
                                                    color: Qt.rgba(1, 1, 1, 0.08)
                                                    visible: switchHover.hovered
                                                }
                                                HoverHandler { id: switchHover }

                                                Rectangle {
                                                    width: 16; height: 16; radius: 8
                                                    color: root.bgCard
                                                    y: 2
                                                    x: monitorInfo.active ? 18 : 2
                                                    Behavior on x { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
                                                }
                                                MouseArea {
                                                    anchors.fill: parent
                                                    cursorShape: Qt.PointingHandCursor
                                                    onClicked: {
                                                        let cmd = monitorInfo.active ? "--disable" : "--enable"
                                                        monitorAction.run(["python3", "/home/ismael/scripts/update_monitors.py", cmd, monitorInfo.name])
                                                    }
                                                }
                                            }

                                            // Espacio
                                            Item { width: 20; height: 1 }

                                            // Checkbox Principal
                                            RowLayout {
                                                spacing: 6
                                                visible: monitorsPage.monitorsArray.filter(m => m.active).length > 1 && monitorInfo.active
                                                
                                                Rectangle {
                                                    width: 18; height: 18; radius: 4
                                                    color: monitorInfo.primary ? root.accent : "transparent"
                                                    border.color: monitorInfo.primary ? "transparent" : root.textSec
                                                    border.width: 1
                                                    
                                                    Rectangle {
                                                        anchors.fill: parent
                                                        radius: parent.radius
                                                        color: Qt.rgba(1, 1, 1, 0.08)
                                                        visible: checkHover.hovered
                                                    }
                                                    HoverHandler { id: checkHover }

                                                    QsText {
                                                        anchors.centerIn: parent
                                                        text: "\uf00c"
                                                        color: root.getContrastColor(root.accent)
                                                        font.family: "Font Awesome 6 Free"
                                                        font.pixelSize: 10
                                                        font.weight: Font.Bold
                                                        visible: monitorInfo.primary
                                                    }
                                                    
                                                    MouseArea {
                                                        anchors.fill: parent
                                                        cursorShape: Qt.PointingHandCursor
                                                        onClicked: {
                                                            if (!monitorInfo.primary) {
                                                                monitorAction.run(["python3", "/home/ismael/scripts/set_primary_monitor.py", monitorInfo.name])
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                QsText {
                                                    text: "Pantalla principal"
                                                    color: monitorInfo.primary ? root.textPri : root.textSec
                                                    font.family: "Inter"
                                                    font.pixelSize: 12
                                                }
                                            }
                                        }

                                        // Expandable ComboBox
                                        RowLayout {
                                            spacing: 10
                                            Layout.topMargin: 8
                                            Layout.alignment: Qt.AlignTop

                                            QsText {
                                                text: "Resolución y Tasa:"
                                                color: root.textPri
                                                font.family: "Inter"
                                                font.pixelSize: 12
                                            }

                                            Rectangle {
                                                id: comboRect
                                                width: 220
                                                height: isExpanded ? Math.min(200, 32 + (monitorInfo.modes ? monitorInfo.modes.length * 32 : 0)) : 32
                                                Layout.preferredHeight: height
                                                radius: 6
                                                color: root.bgCard
                                                border.color: root.border
                                                border.width: 1
                                                property bool isExpanded: false
                                                z: isExpanded ? 10 : 0
                                                clip: true

                                                Behavior on height { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }

                                                Rectangle {
                                                    id: comboHeader
                                                    width: parent.width
                                                    height: 32
                                                    color: comboHeaderHover.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                                                    radius: 6
                                                    HoverHandler { id: comboHeaderHover }

                                                    QsText {
                                                        text: monitorInfo.active && monitorInfo.current_mode && monitorInfo.current_mode.width ? (monitorInfo.current_mode.width + "x" + monitorInfo.current_mode.height + " @ " + (monitorInfo.current_mode.refresh_rate/1000).toFixed(2) + "Hz") : "Seleccionar"
                                                        color: root.textPri
                                                        font.family: "Inter"
                                                        font.pixelSize: 11
                                                        anchors.verticalCenter: parent.verticalCenter
                                                        anchors.left: parent.left
                                                        anchors.leftMargin: 10
                                                    }

                                                    QsText {
                                                        text: comboRect.isExpanded ? "▲" : "▼"
                                                        color: root.textSec
                                                        font.pixelSize: 10
                                                        anchors.verticalCenter: parent.verticalCenter
                                                        anchors.right: parent.right
                                                        anchors.rightMargin: 10
                                                    }

                                                    MouseArea {
                                                        anchors.fill: parent
                                                        cursorShape: Qt.PointingHandCursor
                                                        onClicked: comboRect.isExpanded = !comboRect.isExpanded
                                                    }
                                                }

                                                ListView {
                                                    id: modesListView
                                                    anchors.top: comboHeader.bottom
                                                    anchors.left: parent.left
                                                    anchors.right: parent.right
                                                    anchors.bottom: parent.bottom
                                                    model: monitorInfo.modes
                                                    boundsBehavior: Flickable.StopAtBounds
                                                    clip: true
                                                    delegate: Rectangle {
                                                        width: modesListView.width
                                                        height: 32
                                                        color: mouseHover.hovered ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.2) : "transparent"

                                                        QsText {
                                                            text: modelData.label
                                                            color: root.textPri
                                                            font.family: "Inter"
                                                            font.pixelSize: 11
                                                            anchors.verticalCenter: parent.verticalCenter
                                                            anchors.left: parent.left
                                                            anchors.leftMargin: 10
                                                        }

                                                        HoverHandler { id: mouseHover }

                                                        MouseArea {
                                                            anchors.fill: parent
                                                            cursorShape: Qt.PointingHandCursor
                                                            onClicked: {
                                                                comboRect.isExpanded = false
                                                                monitorAction.run(["python3", "/home/ismael/scripts/update_monitors.py", "--mode", monitorInfo.name, String(modelData.w), String(modelData.h), String(modelData.hz)])
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        Rectangle {
                                            Layout.fillWidth: true
                                            height: 1
                                            color: root.border
                                            Layout.topMargin: 8
                                            visible: monitorInfo.active
                                        }

                                        ColumnLayout {
                                            Layout.fillWidth: true
                                            spacing: 8
                                            visible: monitorInfo.active

                                            RowLayout {
                                                Layout.fillWidth: true
                                                spacing: 10

                                                ColumnLayout {
                                                    spacing: 1
                                                    Layout.fillWidth: true
                                                    QsText {
                                                        text: "Escalado de imagen"
                                                        color: root.textPri
                                                        font.family: "Inter"
                                                        font.pixelSize: 12
                                                        font.weight: Font.Medium
                                                    }
                                                    QsText {
                                                        text: "Actual: " + Number(monitorInfo.scale || 1).toFixed(2) + "x"
                                                        color: root.textSec
                                                        font.family: "Inter"
                                                        font.pixelSize: 10
                                                    }
                                                }

                                                RowLayout {
                                                    spacing: 6
                                                    Repeater {
                                                        model: ["1", "1.25", "1.5", "2", "auto"]
                                                        delegate: Rectangle {
                                                            property bool selected: modelData !== "auto" && Math.abs(Number(monitorInfo.scale || 1) - Number(modelData)) < 0.01
                                                            implicitWidth: Math.max(42, scaleLabel.implicitWidth + 16)
                                                            height: 26
                                                            radius: 6
                                                            color: selected ? root.accent : (scaleHover.hovered ? Qt.rgba(1, 1, 1, 0.06) : "transparent")
                                                            border.color: selected ? "transparent" : root.border
                                                            border.width: 1
                                                            QsText {
                                                                id: scaleLabel
                                                                anchors.centerIn: parent
                                                                text: modelData === "auto" ? "Auto" : modelData + "x"
                                                                color: parent.selected ? root.getContrastColor(root.accent) : root.textPri
                                                                font.family: "Inter"
                                                                font.pixelSize: 10
                                                                font.weight: Font.DemiBold
                                                            }
                                                            HoverHandler { id: scaleHover }
                                                            MouseArea {
                                                                anchors.fill: parent
                                                                cursorShape: Qt.PointingHandCursor
                                                                onClicked: monitorAction.run(["python3", "/home/ismael/scripts/update_monitors.py", "--scale", monitorInfo.name, modelData])
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            RowLayout {
                                                Layout.fillWidth: true
                                                spacing: 10

                                                ColumnLayout {
                                                    spacing: 1
                                                    Layout.fillWidth: true
                                                    QsText {
                                                        text: "Profundidad de color"
                                                        color: root.textPri
                                                        font.family: "Inter"
                                                        font.pixelSize: 12
                                                        font.weight: Font.Medium
                                                    }
                                                    QsText {
                                                        text: "Actual: " + (monitorInfo.max_bpc || 8) + " bpc"
                                                        color: root.textSec
                                                        font.family: "Inter"
                                                        font.pixelSize: 10
                                                        elide: Text.ElideRight
                                                        Layout.fillWidth: true
                                                    }
                                                }

                                                RowLayout {
                                                    spacing: 6
                                                    Repeater {
                                                        model: [8, 10, 12, 16]
                                                        delegate: Rectangle {
                                                            property bool selected: Number(monitorInfo.max_bpc || 8) === modelData
                                                            implicitWidth: 42
                                                            height: 26
                                                            radius: 6
                                                            color: selected ? root.accent : (bpcHover.hovered ? Qt.rgba(1, 1, 1, 0.06) : "transparent")
                                                            border.color: selected ? "transparent" : root.border
                                                            border.width: 1
                                                            QsText {
                                                                anchors.centerIn: parent
                                                                text: modelData + "b"
                                                                color: parent.selected ? root.getContrastColor(root.accent) : root.textPri
                                                                font.family: "Inter"
                                                                font.pixelSize: 10
                                                                font.weight: Font.DemiBold
                                                            }
                                                            HoverHandler { id: bpcHover }
                                                            MouseArea {
                                                                anchors.fill: parent
                                                                cursorShape: Qt.PointingHandCursor
                                                                onClicked: {
                                                                    monitorsPage.updateMonitorField(monitorInfo.name, "max_bpc", modelData)
                                                                    monitorAction.run(["python3", "/home/ismael/scripts/update_monitors.py", "--max-bpc", monitorInfo.name, String(modelData)])
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            RowLayout {
                                                Layout.fillWidth: true
                                                visible: monitorInfo.hdr_supported === true
                                                spacing: 10

                                                ColumnLayout {
                                                    spacing: 1
                                                    Layout.fillWidth: true
                                                    QsText {
                                                        text: "HDR"
                                                        color: root.textPri
                                                        font.family: "Inter"
                                                        font.pixelSize: 12
                                                        font.weight: Font.Medium
                                                    }
                                                    QsText {
                                                        text: monitorInfo.hdr_enabled === true ? "Activo" : "Inactivo"
                                                        color: root.textSec
                                                        font.family: "Inter"
                                                        font.pixelSize: 10
                                                        elide: Text.ElideRight
                                                        Layout.fillWidth: true
                                                    }
                                                }

                                                SwitchButton {
                                                    checked: monitorInfo.hdr_enabled === true
                                                    enabled: false
                                                }
                                            }

                                            RowLayout {
                                                Layout.fillWidth: true
                                                spacing: 10

                                                ColumnLayout {
                                                    spacing: 1
                                                    Layout.fillWidth: true
                                                    QsText {
                                                        text: "Saturación de color"
                                                        color: root.textPri
                                                        font.family: "Inter"
                                                        font.pixelSize: 12
                                                        font.weight: Font.Medium
                                                    }
                                                    QsText {
                                                        text: "Actual: " + monitorDelegate.localSaturation
                                                        color: root.textSec
                                                        font.family: "Inter"
                                                        font.pixelSize: 10
                                                        elide: Text.ElideRight
                                                        Layout.fillWidth: true
                                                    }
                                                }

                                                Item {
                                                    id: saturationMeter
                                                    property real saturationValue: Math.max(0, Math.min(100, Number(monitorDelegate.localSaturation || 0)))
                                                    Layout.preferredWidth: 176
                                                    Layout.minimumWidth: 132
                                                    Layout.maximumWidth: 190
                                                    height: 30
                                                    opacity: monitorInfo.saturation_supported === true ? 1.0 : 0.55

                                                    function setFromX(posX, commit) {
                                                        if (monitorInfo.saturation_supported !== true)
                                                            return
                                                        let nextValue = Math.round(Math.max(0, Math.min(width, posX)) / width * 100)
                                                        monitorDelegate.localSaturation = nextValue
                                                        if (commit) {
                                                            monitorsPage.updateMonitorField(monitorInfo.name, "saturation", nextValue)
                                                            monitorAction.run(["python3", "/home/ismael/scripts/update_monitors.py", "--saturation", monitorInfo.name, String(nextValue)])
                                                        }
                                                    }

                                                    Rectangle {
                                                        anchors.left: parent.left
                                                        anchors.right: parent.right
                                                        anchors.verticalCenter: parent.verticalCenter
                                                        height: 8
                                                        radius: 4
                                                        color: Qt.rgba(1, 1, 1, 0.07)
                                                        border.color: root.border
                                                        border.width: 1

                                                        Rectangle {
                                                            anchors.left: parent.left
                                                            anchors.top: parent.top
                                                            anchors.bottom: parent.bottom
                                                            width: Math.max(parent.height, parent.width * (saturationMeter.saturationValue / 100))
                                                            visible: saturationMeter.saturationValue > 0
                                                            radius: 4
                                                            color: root.accent
                                                        }
                                                    }

                                                    Rectangle {
                                                        width: 10
                                                        height: 10
                                                        radius: 5
                                                        x: Math.max(0, Math.min(parent.width - width, parent.width * (saturationMeter.saturationValue / 100) - width / 2))
                                                        anchors.verticalCenter: parent.verticalCenter
                                                        color: monitorInfo.saturation_supported === true ? root.accent : root.textSec
                                                        border.color: root.bgCard
                                                        border.width: 1
                                                    }

                                                    MouseArea {
                                                        anchors.fill: parent
                                                        enabled: monitorInfo.saturation_supported === true
                                                        cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                                                        onPressed: mouse => saturationMeter.setFromX(mouse.x, false)
                                                        onPositionChanged: mouse => {
                                                            if (pressed)
                                                                saturationMeter.setFromX(mouse.x, false)
                                                        }
                                                        onReleased: mouse => saturationMeter.setFromX(mouse.x, true)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
    }

    Component {
        id: systemPageComp
                    ColumnLayout {
                        visible: root.activeTab === "system"
                        Layout.fillWidth: true
                        spacing: 14

                        property var settingsMap: {
                            "systemInfo": hlSysInfo
                        }

                        QsText {
                            text: "Especificaciones del Hardware"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                        }

                        // Hardware card
                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: hardwareLayout.implicitHeight + 32
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            Loader { id: hlSysInfo; anchors.fill: parent; sourceComponent: highlightEffectComp }

                            GridLayout {
                                id: hardwareLayout
                                anchors.fill: parent
                                anchors.margins: 16
                                columns: 2
                                rowSpacing: 8
                                columnSpacing: 20

                                QsText {
                                    text: "Procesador (CPU):"
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                }
                                QsText {
                                    text: root.cpuModel || "Cargando CPU..."
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.Medium
                                    elide: Text.ElideRight
                                    Layout.fillWidth: true
                                }

                                QsText {
                                    text: "Uso de Memoria (RAM):"
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                }
                                QsText {
                                    text: root.ramUsage || "Cargando RAM..."
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.Medium
                                }

                                QsText {
                                    text: "Carga de CPU actual:"
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                }
                                QsText {
                                    text: root.cpuUsage || "Calculando..."
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.Medium
                                }
                            }
                        }

                        QsText {
                            text: "Sistema Operativo"
                            color: root.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            Layout.topMargin: 4
                        }

                        // OS card
                        Rectangle {
                            Layout.fillWidth: true
                            implicitHeight: osLayout.implicitHeight + 32
                            radius: 12
                            color: root.bgCard
                            border.color: root.border
                            border.width: 1

                            GridLayout {
                                id: osLayout
                                anchors.fill: parent
                                anchors.margins: 16
                                columns: 2
                                rowSpacing: 8
                                columnSpacing: 20

                                QsText {
                                    text: "Distribución:"
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                }
                                QsText {
                                    text: root.distroName
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.Medium
                                }

                                QsText {
                                    text: "Versión del Kernel:"
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                }
                                QsText {
                                    text: root.kernelVersion || "Cargando..."
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.Medium
                                }
                            }
                        }
                    }
    }

}
