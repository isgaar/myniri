import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

BasePopup {
    id: window

    anchors {
        top: true
        left: true
        right: false
    }
    margins.top: shellRoot.getPopupTopMargin(window.screen)
    margins.left: window.anchorMargin

    property int anchorMargin: 136

    property bool isLoading: true
    signal bluetoothPowerChanged()

    Timer {
        id: loadingTimeout
        interval: 3000
        onTriggered: window.isLoading = false
    }

    Timer {
        id: toggleRefreshTimer
        interval: 600
        onTriggered: window.loadDevices()
    }

    function loadDevices() {
        if (!window.isBluetoothActive) {
            bluetoothModel.clear()
            window.isLoading = false
            loadingTimeout.stop()
            return
        }
        bluetoothModel.clear()
        window.isLoading = true
        loadingTimeout.restart()
        btListPoller.running = false
        btListPoller.running = true
    }

    onVisibleChanged: {
        if (visible) {
            shellRoot.updateMakoPosition("bluetoothmenu", "open", Math.round(window.implicitHeight + 55).toString())
            content.forceActiveFocus(Qt.MouseFocusReason)
            btScanner.running = false
            btScanner.running = true
            window.loadDevices()
            btStateReader.running = false
            btStateReader.running = true
        } else {
            shellRoot.updateMakoPosition("bluetoothmenu", "closed")
            btScanner.running = false
            btListPoller.running = false
            loadingTimeout.stop()
        }
    }

    implicitWidth: Math.min(380, Math.max(300, (window.screen ? window.screen.width : 1920) - 16))
    implicitHeight: Math.min(600, layoutCol.implicitHeight + 24)
    property int contentHeight: Math.min(600, layoutCol.implicitHeight + 24)

    function toggle(x) {
        if (visible) {
            visible = false
        } else {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(12, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 12))
            }
            visible = true
        }
    }

    function close() {
        visible = false
    }

    ListModel { id: bluetoothModel }

    property bool isBluetoothActive: false
    property string connectingMac: ""

    // Lector de estado inicial y dinámico del radio de BT
    Process {
        id: btStateReader
        command: ["bash", "-c", "bluetoothctl show 2>/dev/null | grep -q 'Powered: yes' && echo true || echo false"]
        running: window.visible
        stdout: SplitParser {
            onRead: data => {
                let active = data.trim() === "true"
                if (active !== window.isBluetoothActive) {
                    window.isBluetoothActive = active
                    if (active && window.visible) {
                        window.loadDevices()
                    } else if (!active) {
                        bluetoothModel.clear()
                        window.isLoading = false
                        loadingTimeout.stop()
                    }
                }
            }
        }
    }

    Process {
        id: btListPoller
        command: [
            "stdbuf", "-oL", "bash", "-c",
            "bluetoothctl devices 2>/dev/null | while read -r _ mac name; do " +
            "[ -z \"$mac\" ] && continue; " +
            "info=$(bluetoothctl info \"$mac\" 2>/dev/null); " +
            "connected=$(echo \"$info\" | grep -q 'Connected: yes' && echo 1 || echo 0); " +
            "icon=$(echo \"$info\" | grep 'Icon:' | awk '{print $2}'); " +
            "battery='null'; " +
            "bat_line=$(echo \"$info\" | grep -i 'Battery Percentage:'); " +
            "if [ -n \"$bat_line\" ]; then " +
            "bat_val=$(echo \"$bat_line\" | grep -o -E '\\([0-9]+\\)' | tr -d '()'); " +
            "[ -z \"$bat_val\" ] && bat_val=$(echo \"$bat_line\" | awk '{print $NF}'); " +
            "[[ \"$bat_val\" =~ ^[0-9]+$ ]] && battery=\"$bat_val\"; " +
            "fi; " +
            "uuid=$(echo \"$info\" | grep 'UUID:'); " +
            "type='unknown'; " +
            "if [[ \"$icon\" == *audio* || \"$icon\" == *headset* || \"$uuid\" == *Audio* || \"$uuid\" == *Headset* ]]; then type='audio'; " +
            "elif [[ \"$icon\" == *keyboard* || \"$uuid\" == *Keyboard* ]]; then type='input'; " +
            "elif [[ \"$icon\" == *mouse* || \"$uuid\" == *Mouse* ]]; then type='input'; " +
            "elif [[ \"$icon\" == *gamepad* || \"$icon\" == *gaming* || \"$uuid\" == *Gamepad* ]]; then type='gamepad'; " +
            "elif [[ \"$icon\" == *phone* || \"$uuid\" == *Phone* ]]; then type='phone'; " +
            "elif [ -n \"$icon\" ]; then type=\"$icon\"; fi; " +
            "echo \"$mac|$name|$connected|$type|$battery\"; " +
            "done"
        ]
        running: false
        onRunningChanged: {
            if (running) {
                bluetoothModel.clear()
            }
        }
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line === "") return
                let parts = line.split("|")
                if (parts.length >= 5) {
                    let mac = parts[0]
                    let name = parts[1]
                    let connected = parts[2] === "1"
                    let type = parts[3]
                    let batteryVal = parts[4]
                    let battery = (batteryVal !== "null" && batteryVal !== "") ? parseInt(batteryVal) : -1

                    let icon = "\uf294"
                    let font_family = "Font Awesome 6 Brands"

                    if (type === "audio") {
                        icon = "\uf025"
                        font_family = "Font Awesome 6 Free"
                    } else if (type === "input") {
                        icon = "\uf11c"
                        font_family = "Font Awesome 6 Free"
                    } else if (type === "gamepad" || type === "input-gaming") {
                        icon = "\uf11b"
                        font_family = "Font Awesome 6 Free"
                    } else if (type === "phone") {
                        icon = "\uf3cd"
                        font_family = "Font Awesome 6 Free"
                    } else if (type === "computer") {
                        icon = "\uf108"
                        font_family = "Font Awesome 6 Free"
                    } else if (type === "input-keyboard") {
                        icon = "\uf11c"
                        font_family = "Font Awesome 6 Free"
                    } else if (type === "input-mouse") {
                        icon = "\uf8cc"
                        font_family = "Font Awesome 6 Free"
                    }

                    if (window.isLoading) {
                        loadingTimeout.stop()
                        window.isLoading = false
                    }

                    bluetoothModel.append({
                        "mac": mac,
                        "name": name,
                        "connected": connected,
                        "type": type,
                        "battery": battery,
                        "icon": icon,
                        "font_family": font_family
                    })
                }
            }
        }
    }

    Process {
        id: btScanner
        command: ["bluetoothctl", "--timeout", "10", "scan", "on"]
        running: false
    }

    Timer {
        interval: 8000
        repeat: true
        running: window.visible
        onTriggered: {
            window.loadDevices()
            btStateReader.running = false
            Qt.callLater(() => btStateReader.running = true)
        }
    }

    Rectangle {
        id: content
        anchors.fill: parent
        color: window.bgMain
        radius: window.cornersEnabled ? window.cornerRadius : 0
        border.color: window.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: window.visible = false

        ColumnLayout {
            id: layoutCol
            anchors { fill: parent; margins: 12 }
            spacing: 0

            // 1. Cabecera con Toggle y Engrane
            RowLayout {
                Layout.fillWidth: true
                height: 44
                spacing: 12

                QsText {
                    text: "Bluetooth"
                    color: window.textPri
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: Font.Medium
                    Layout.fillWidth: true
                }

                // Switch Toggle UI
                Item {
                    width: 44; height: 24
                    Rectangle {
                        anchors.fill: parent
                        radius: 12
                        color: window.isBluetoothActive ? window.accent : Qt.rgba(0.5, 0.5, 0.5, 0.2)
                        border.color: window.isBluetoothActive ? window.accent : Qt.rgba(0.5, 0.5, 0.5, 0.3)
                        border.width: 1
                        Behavior on color { ColorAnimation { duration: 150 } }

                        Rectangle {
                            width: 20; height: 20
                            radius: 10
                            color: "white"
                            y: 2
                            x: window.isBluetoothActive ? parent.width - width - 2 : 2
                            Behavior on x { NumberAnimation { duration: 150; easing.type: Easing.OutQuad } }
                        }
                    }
                    TapHandler {
                        onTapped: {
                            let cmd = window.isBluetoothActive
                                ? ["bluetoothctl", "power", "off"]
                                : ["bluetoothctl", "power", "on"]
                            Qt.createQmlObject(
                                'import Quickshell.Io; Process { command: ' +
                                JSON.stringify(cmd) + '; running: true }', window)
                            window.isBluetoothActive = !window.isBluetoothActive
                            window.bluetoothPowerChanged()
                            if (!window.isBluetoothActive) {
                                bluetoothModel.clear()
                                window.isLoading = false
                                loadingTimeout.stop()
                            } else {
                                toggleRefreshTimer.restart()
                            }
                        }
                    }
                }

                // Gear Settings button
                Rectangle {
                    width: 28; height: 28; radius: 8
                    color: "transparent"; border.color: window.border; border.width: 1
                    QsText {
                        anchors.centerIn: parent; text: "\uf013"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 13; color: window.textSec
                    }
                    HoverHandler { id: gearHover }
                    Rectangle { anchors.fill: parent; radius: parent.radius; color: gearHover.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent" }
                    TapHandler {
                        onTapped: {
                            window.visible = false
                            Qt.createQmlObject('import Quickshell.Io; Process { command: ["blueman-manager"]; running: true }', window)
                        }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: Qt.rgba(1, 1, 1, 0.08)
                Layout.topMargin: 4
                Layout.bottomMargin: 8
            }

            // 2. Lista de dispositivos
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                visible: window.isBluetoothActive

                Repeater {
                    model: bluetoothModel
                    delegate: Item {
                        Layout.fillWidth: true
                        height: 48

                        Rectangle {
                            anchors.fill: parent
                            radius: 8
                            color: model.connected ? Qt.rgba(window.accent.r, window.accent.g, window.accent.b, 0.12) : "transparent"
                            border.color: model.connected ? window.border : "transparent"
                            border.width: model.connected ? 1 : 0

                            RowLayout {
                                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                                spacing: 10

                                QsText {
                                    text: model.icon !== undefined ? model.icon : "\uf294"
                                    font.family: model.font_family !== undefined ? model.font_family : "Font Awesome 6 Brands"
                                    font.pixelSize: 14
                                    color: model.connected ? window.accent : window.textSec
                                }

                                Column {
                                    spacing: 2
                                    Layout.fillWidth: true
                                    QsText {
                                        text: model.name
                                        color: window.textPri
                                        font.family: "Inter"
                                        font.pixelSize: 12
                                        font.weight: model.connected ? Font.Medium : Font.Normal
                                        elide: Text.ElideRight
                                        width: parent.width
                                    }
                                    QsText {
                                        text: model.mac === window.connectingMac 
                                            ? "Conectando..." 
                                            : (model.connected 
                                                ? (model.battery !== undefined && model.battery !== null && model.battery >= 0 ? "Conectado • Batería: " + model.battery + "%" : "Conectado") 
                                                : "Emparejado")
                                        color: window.textSec
                                        font.family: "Inter"
                                        font.pixelSize: 10
                                    }
                                }

                                // Botón de desconexión/conexión rápida si ya está conectado
                                Rectangle {
                                    width: 24; height: 24; radius: 6
                                    color: "transparent"
                                    visible: model.connected
                                    QsText {
                                        anchors.centerIn: parent; text: "\uf057"
                                        font.family: "Font Awesome 6 Free"
                                        font.pixelSize: 12; color: window.danger
                                    }
                                    TapHandler {
                                        onTapped: {
                                            Qt.createQmlObject(
                                                'import Quickshell.Io; Process { command: ["bluetoothctl", "disconnect", "' + model.mac + '"]; running: true }', window)
                                            Qt.callLater(() => {
                                                window.loadDevices()
                                            })
                                        }
                                    }
                                }
                            }

                            HoverHandler { id: rowHover }
                            Rectangle {
                                anchors.fill: parent; radius: parent.radius
                                color: rowHover.hovered && !model.connected ? Qt.rgba(1, 1, 1, 0.025) : "transparent"
                            }
                        }

                        TapHandler {
                            onTapped: {
                                if (!model.connected) {
                                    window.connectingMac = model.mac
                                    Qt.createQmlObject(
                                        'import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/connect_bt.sh", "' + model.mac + '"]; running: true; onExited: { window.connectingMac = ""; window.loadDevices() } }', window)
                                }
                            }
                        }
                    }
                }
            }

            // Mensajes alternativos
            QsText {
                visible: !window.isBluetoothActive
                text: "Bluetooth desactivado"
                color: window.textSec
                font.family: "Inter"
                font.pixelSize: 12
                Layout.alignment: Qt.AlignHCenter
                topPadding: 16
                bottomPadding: 16
            }

            QsText {
                visible: window.isBluetoothActive && window.isLoading && bluetoothModel.count === 0
                text: "Buscando dispositivos..."
                color: window.textSec
                font.family: "Inter"
                font.pixelSize: 12
                Layout.alignment: Qt.AlignHCenter
                topPadding: 16
                bottomPadding: 16
            }

            QsText {
                visible: window.isBluetoothActive && !window.isLoading && bluetoothModel.count === 0
                text: "No se encontraron dispositivos"
                color: window.textSec
                font.family: "Inter"
                font.pixelSize: 12
                Layout.alignment: Qt.AlignHCenter
                topPadding: 16
                bottomPadding: 16
            }
        }
    }
}
