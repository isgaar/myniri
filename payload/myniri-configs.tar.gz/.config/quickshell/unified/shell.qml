// ~/.config/quickshell/unified/shell.qml
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick

ShellRoot {
    id: shellRoot

    // Theme properties & loading
    property var themeConfig: {
        "accent": "#5aa7de",
        "accentWf": "#4a9fd4",
        "accentBt": "#7c6fc4",
        "bgMain": "#801a1a1a",
        "bgCard": "#232323",
        "bgTile": "#2a2a2a",
        "bgActive": "#172232",
        "border": "#3a3a3a",
        "textPri": "#f0eee8",
        "textSec": "#918f88",
        "danger": "#e06c6c",
        "warning": "#e67e22",
        "animationsEnabled": true,
        "animationDuration": 250,
        "topbarStyle": "actual",
        "wallpaperPath": "",
        "wallpaperAccent": "#5aa7de",
        "wallpaperBrightnessLeft": "dark",
        "wallpaperBrightnessRight": "dark",
        "wallpaperAnalyzedAt": 0
    }
    property bool barBackdropVisible: false

    Process {
        id: themeReader
        command: ["jq", "-c", ".", Qt.resolvedUrl("theme.json").toString().replace("file://", "")]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let trimmed = data.trim();
                if (!trimmed) return;
                try {
                    let parsed = JSON.parse(trimmed);
                    if (parsed) {
                        shellRoot.themeConfig = parsed;
                    }
                } catch (e) {
                    console.log("Error parsing theme.json: " + e);
                }
            }
        }
    }

    function loadTheme(): void {
        themeReader.running = false;
        themeReader.running = true;
    }

    function assignBackdropScreens(): void {
        let s0 = Quickshell.screens.length > 0 ? Quickshell.screens[0] : null;
        if (typeof backdrop0 !== "undefined" && backdrop0.screen !== s0) backdrop0.screen = s0;
        let s1 = Quickshell.screens.length > 1 ? Quickshell.screens[1] : null;
        if (typeof backdrop1 !== "undefined" && backdrop1.screen !== s1) backdrop1.screen = s1;
        let s2 = Quickshell.screens.length > 2 ? Quickshell.screens[2] : null;
        if (typeof backdrop2 !== "undefined" && backdrop2.screen !== s2) backdrop2.screen = s2;
        let s3 = Quickshell.screens.length > 3 ? Quickshell.screens[3] : null;
        if (typeof backdrop3 !== "undefined" && backdrop3.screen !== s3) backdrop3.screen = s3;
        updateBarBackdropVisibility();
    }

    Component.onCompleted: {
        loadTheme();
        assignBackdropScreens();
    }

    // IPC handler for dynamic theme reload
    IpcHandler {
        target: "theme"
        function reload(): void {
            shellRoot.loadTheme();
        }
        function reloadTheme(): void {
            shellRoot.loadTheme();
        }
    }

    function showWifiPasswordPrompt(ssid, callback): void {
        if (wifiPasswordDialogLoader.item) {
            wifiPasswordDialogLoader.item.open(ssid, callback)
        } else {
            wifiPasswordDialogLoader.pendingSsid = ssid
            wifiPasswordDialogLoader.pendingCallback = callback
            wifiPasswordDialogLoader.source = "WifiPasswordDialog.qml"
            wifiPasswordDialogLoader.active = true
        }
    }

    // Wifi Password Prompt IPC
    IpcHandler {
        target: "wifi"
        property string ssid: ""
        function showPrompt(): void {
            shellRoot.showWifiPasswordPrompt(ssid, null)
        }
    }

    // Tiempo de gracia antes de destruir Loaders (balance memoria vs. rendimiento)
    readonly property int loaderUnloadDelay: 60000

    // Dynamic top margin for popups to ensure uniform gaps
    function getPopupTopMargin(scr) {
        let hasTopBar = (scr && activeScreen && scr.name === activeScreen.name);
        let topBarHeight = 32;
        let gap = 12;
        return hasTopBar ? (topBarHeight + gap) : gap;
    }

    // Centralizado: evita Process duplicados en cada panel para update_mako_position.sh
    Process {
        id: makoPosProcess
        running: false
    }
    function updateMakoPosition(panel, state, offset) {
        let args = ["/home/ismael/scripts/update_mako_position.sh", panel, state]
        if (offset !== undefined && offset !== "") args.push(offset)
        makoPosProcess.command = args
        makoPosProcess.running = true
    }

    // Centralized Helper Functions for Lazy-Loaded Panels
    function closeAllPopups(): void {
        if (panelLoader.active && panelLoader.item) panelLoader.item.visible = false
        if (notificationsLoader.active && notificationsLoader.item) notificationsLoader.item.visible = false
        if (batteryLoader.active && batteryLoader.item) batteryLoader.item.visible = false
        if (bgappsLoader.active && bgappsLoader.item) bgappsLoader.item.visible = false
        if (ejectPanelLoader.active && ejectPanelLoader.item) ejectPanelLoader.item.visible = false
        if (wifimenuLoader.active && wifimenuLoader.item) wifimenuLoader.item.close()
        if (networkMenuLoader.active && networkMenuLoader.item) networkMenuLoader.item.close()
        if (bluetoothMenuLoader.active && bluetoothMenuLoader.item) bluetoothMenuLoader.item.close()
        if (volumeDialogLoader.active && volumeDialogLoader.item) volumeDialogLoader.item.close()
        if (micDialogLoader.active && micDialogLoader.item) micDialogLoader.item.close()
        if (calendarLoader.active && calendarLoader.item) calendarLoader.item.visible = false
        if (powerDialogLoader.active && powerDialogLoader.item) powerDialogLoader.item.close()
        if (memoryLoader.active && memoryLoader.item) memoryLoader.item.close()
        if (shortcutsDialogLoader.active && shortcutsDialogLoader.item) shortcutsDialogLoader.item.close()
        if (launcherDialogLoader.active && launcherDialogLoader.item) launcherDialogLoader.item.close()
        if (clipboardMenuLoader.active && clipboardMenuLoader.item) clipboardMenuLoader.item.close()
        shellRoot.updateBarBackdropVisibility()
    }

    function isLoaderVisible(loader): bool {
        return loader.active && loader.item && loader.item.visible
    }

    function barPopupVisible(): bool {
        return shellRoot.isLoaderVisible(panelLoader) ||
               shellRoot.isLoaderVisible(notificationsLoader) ||
               shellRoot.isLoaderVisible(batteryLoader) ||
               shellRoot.isLoaderVisible(bgappsLoader) ||
               shellRoot.isLoaderVisible(ejectPanelLoader) ||
               shellRoot.isLoaderVisible(wifimenuLoader) ||
               shellRoot.isLoaderVisible(networkMenuLoader) ||
               shellRoot.isLoaderVisible(bluetoothMenuLoader) ||
               shellRoot.isLoaderVisible(volumeDialogLoader) ||
               shellRoot.isLoaderVisible(micDialogLoader) ||
               shellRoot.isLoaderVisible(calendarLoader) ||
               shellRoot.isLoaderVisible(powerDialogLoader) ||
               shellRoot.isLoaderVisible(memoryLoader)
    }

    function closeBarPopups(): void {
        if (panelLoader.active && panelLoader.item) panelLoader.item.visible = false
        if (notificationsLoader.active && notificationsLoader.item) notificationsLoader.item.visible = false
        if (batteryLoader.active && batteryLoader.item) batteryLoader.item.visible = false
        if (bgappsLoader.active && bgappsLoader.item) bgappsLoader.item.visible = false
        if (ejectPanelLoader.active && ejectPanelLoader.item) ejectPanelLoader.item.visible = false
        if (wifimenuLoader.active && wifimenuLoader.item) wifimenuLoader.item.close()
        if (networkMenuLoader.active && networkMenuLoader.item) networkMenuLoader.item.close()
        if (bluetoothMenuLoader.active && bluetoothMenuLoader.item) bluetoothMenuLoader.item.close()
        if (volumeDialogLoader.active && volumeDialogLoader.item) volumeDialogLoader.item.close()
        if (micDialogLoader.active && micDialogLoader.item) micDialogLoader.item.close()
        if (calendarLoader.active && calendarLoader.item) calendarLoader.item.visible = false
        if (powerDialogLoader.active && powerDialogLoader.item) powerDialogLoader.item.close()
        if (memoryLoader.active && memoryLoader.item) memoryLoader.item.close()
        shellRoot.updateBarBackdropVisibility()
    }

    function updateBarBackdropVisibility(): void {
        let shouldShow = shellRoot.barPopupVisible()
        shellRoot.barBackdropVisible = shouldShow
        if (typeof backdrop0 !== "undefined") backdrop0.visible = shouldShow && backdrop0.screen !== null
        if (typeof backdrop1 !== "undefined") backdrop1.visible = shouldShow && backdrop1.screen !== null
        if (typeof backdrop2 !== "undefined") backdrop2.visible = shouldShow && backdrop2.screen !== null
        if (typeof backdrop3 !== "undefined") backdrop3.visible = shouldShow && backdrop3.screen !== null
    }

    function updateNotificationMargin(): void {
        shellRoot.updateBarBackdropVisibility()
        let base = 45
        let loaders = [
            panelLoader, wifimenuLoader, networkMenuLoader, bluetoothMenuLoader, volumeDialogLoader, micDialogLoader,
            calendarLoader, powerDialogLoader, batteryLoader, bgappsLoader, notificationsLoader, ejectPanelLoader
        ]
        for (let i = 0; i < loaders.length; i++) {
            let l = loaders[i]
            if (l.active && l.item && l.item.visible) {
                notificationPopup.topMargin = (l.item.margins.top || 0) + l.item.contentHeight + 8
                return
            }
        }
        notificationPopup.topMargin = base
    }

    function findQuickTiles(parent) {
        if (!parent) return null;
        if (typeof parent.refreshBluetooth === "function") {
            return parent;
        }
        if (parent.children !== undefined) {
            for (let i = 0; i < parent.children.length; i++) {
                let found = findQuickTiles(parent.children[i]);
                if (found) return found;
            }
        }
        return null;
    }

    function openLoadedItem(item, x) {
        let posX = (typeof x === "number" && !isNaN(x) && x > 0) ? x : undefined;
        if (typeof item.toggle === "function") {
            if (posX !== undefined) item.toggle(posX);
            else item.toggle();
        } else if (typeof item.open === "function") {
            if (posX !== undefined) item.open(posX);
            else item.open();
        } else if (typeof item.setPosition === "function") {
            if (posX !== undefined) item.setPosition(posX);
            item.visible = true;
            if (typeof item.refresh === "function") {
                item.refresh();
            }
        } else {
            item.visible = true;
        }
    }

    function toggleLoader(loaderId, sourceFile, x) {
        let isCurrentlyVisible = loaderId.active && loaderId.item && loaderId.item.visible;
        closeAllPopups();
        if (!isCurrentlyVisible) {
            if (loaderId.item) {
                shellRoot.openLoadedItem(loaderId.item, x);
            } else {
                loaderId.posXToOpen = x;
                loaderId.source = sourceFile;
                loaderId.active = true;
            }
        }
    }

    // ControlPanel (Main Panel)
    IpcHandler {
        target: "panel"
        function toggle(): void {
            shellRoot.toggleLoader(panelLoader, "ControlPanel.qml", undefined)
        }
        function close(): void {
            if (panelLoader.active && panelLoader.item) panelLoader.item.visible = false
        }
    }

    // Notifications
    IpcHandler {
        target: "notifications"
        function toggle(): void {
            shellRoot.toggleLoader(notificationsLoader, "NotificationsPanel.qml", undefined)
        }
        function close(): void {
            if (notificationsLoader.active && notificationsLoader.item) notificationsLoader.item.visible = false
        }
    }

    IpcHandler {
        target: "notification_popup"
        function trigger(payloadStr: string): void {
            try {
                let payload = JSON.parse(payloadStr)
                notificationPopup.showNotification(
                    payload.summary || "",
                    payload.body || "",
                    payload.app || "Sistema",
                    payload.urgency || "normal"
                )
            } catch (e) {
                console.log("Error parsing notification payload: " + e)
            }
        }
    }

    // Battery
    IpcHandler {
        target: "battery"
        function toggle(): void {
            shellRoot.toggleLoader(batteryLoader, "BatteryPanel.qml", undefined)
        }
        function close(): void {
            if (batteryLoader.active && batteryLoader.item) batteryLoader.item.visible = false
        }
    }

    // Background Apps
    IpcHandler {
        target: "bgapps"
        function toggle(): void {
            shellRoot.toggleLoader(bgappsLoader, "BgAppsPanel.qml", undefined)
        }
        function close(): void {
            if (bgappsLoader.active && bgappsLoader.item) bgappsLoader.item.visible = false
        }
    }

    // Eject Devices
    IpcHandler {
        target: "eject"
        function toggle(): void {
            shellRoot.toggleLoader(ejectPanelLoader, "EjectPanel.qml", undefined)
        }
        function close(): void {
            if (ejectPanelLoader.active && ejectPanelLoader.item) ejectPanelLoader.item.visible = false
        }
    }

    // Wifi Menu
    IpcHandler {
        target: "wifimenu"
        function toggle(): void {
            shellRoot.toggleLoader(wifimenuLoader, "WifiMenuWindow.qml", undefined)
        }
        function close(): void {
            if (wifimenuLoader.active && wifimenuLoader.item) wifimenuLoader.item.close()
        }
    }

    // Network Menu
    IpcHandler {
        target: "networkmenu"
        function toggle(): void {
            shellRoot.toggleLoader(networkMenuLoader, "NetworkMenu.qml", undefined)
        }
        function close(): void {
            if (networkMenuLoader.active && networkMenuLoader.item) networkMenuLoader.item.close()
        }
    }

    // Bluetooth Menu
    IpcHandler {
        target: "bluetoothmenu"
        function toggle(): void {
            shellRoot.toggleLoader(bluetoothMenuLoader, "BluetoothMenu.qml", undefined)
        }
        function close(): void {
            if (bluetoothMenuLoader.active && bluetoothMenuLoader.item) bluetoothMenuLoader.item.close()
        }
    }

    // Clipboard Menu
    property bool pendingClipboardOpen: false
    function doOpenClipboard(): void {
        let targetScreen = activeScreen
        for (let i = 0; i < Quickshell.screens.length; i++) {
            if (Quickshell.screens[i].name === cursorOutputName) {
                targetScreen = Quickshell.screens[i]
                break
            }
        }
        if (clipboardMenuLoader.item) {
            clipboardMenuLoader.item.screen = targetScreen
            clipboardMenuLoader.item.toggle()
        } else {
            clipboardMenuLoader.targetScreen = targetScreen
            clipboardMenuLoader.openPending = true
            clipboardMenuLoader.source = "ClipboardMenu.qml"
            clipboardMenuLoader.active = true
        }
    }
    IpcHandler {
        target: "clipboardmenu"
        function toggle(): void {
            if (clipboardMenuLoader.active && clipboardMenuLoader.item && clipboardMenuLoader.item.visible) {
                clipboardMenuLoader.item.close()
            } else {
                closeAllPopups()
                pendingClipboardOpen = true
                cursorOutputReader.running = false
                cursorOutputReader.running = true
            }
        }
        function close(): void {
            if (clipboardMenuLoader.active && clipboardMenuLoader.item) clipboardMenuLoader.item.close()
        }
    }

    // Keyboard Shortcuts Dialog IPC
    IpcHandler {
        target: "shortcuts"
        function toggle(): void {
            if (shortcutsDialogLoader.active && shortcutsDialogLoader.item && shortcutsDialogLoader.item.visible) {
                shortcutsDialogLoader.item.close()
            } else {
                closeAllPopups()
                if (shortcutsDialogLoader.item) {
                    shortcutsDialogLoader.item.open()
                } else {
                    shortcutsDialogLoader.openPending = true
                    shortcutsDialogLoader.source = "ShortcutsDialog.qml"
                    shortcutsDialogLoader.active = true
                }
            }
        }
        function close(): void {
            if (shortcutsDialogLoader.active && shortcutsDialogLoader.item) shortcutsDialogLoader.item.close()
        }
    }

    // Cursor position helper (shared)
    property string cursorOutputName: ""
    Process {
        id: cursorOutputReader
        command: ["bash", "/home/ismael/scripts/get_output_at_cursor.sh"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let name = data.trim()
                if (name) shellRoot.cursorOutputName = name
            }
        }
        onExited: {
            if (pendingLauncherOpen) {
                pendingLauncherOpen = false
                shellRoot.doOpenLauncher()
            } else if (pendingClipboardOpen) {
                pendingClipboardOpen = false
                shellRoot.doOpenClipboard()
            }
        }
    }

    // App Launcher IPC
    property bool pendingLauncherOpen: false
    function doOpenLauncher(): void {
        let targetScreen = activeScreen
        for (let i = 0; i < Quickshell.screens.length; i++) {
            if (Quickshell.screens[i].name === cursorOutputName) {
                targetScreen = Quickshell.screens[i]
                break
            }
        }
        if (launcherDialogLoader.item) {
            launcherDialogLoader.item.screen = targetScreen
            launcherDialogLoader.item.open()
        } else {
            launcherDialogLoader.targetScreen = targetScreen
            launcherDialogLoader.openPending = true
            launcherDialogLoader.source = "AppLauncherDialog.qml"
            launcherDialogLoader.active = true
        }
    }
    IpcHandler {
        target: "launcher"
        function toggle(): void {
            if (launcherDialogLoader.active && launcherDialogLoader.item && launcherDialogLoader.item.visible) {
                launcherDialogLoader.item.close()
            } else {
                closeAllPopups()
                pendingLauncherOpen = true
                cursorOutputReader.running = false
                cursorOutputReader.running = true
            }
        }
        function close(): void {
            if (launcherDialogLoader.active && launcherDialogLoader.item) launcherDialogLoader.item.close()
        }
    }

    // Polkit Dialog IPC
    IpcHandler {
        target: "polkit"
        function showPrompt(payloadStr: string): void {
            if (polkitDialogLoader.item) {
                try {
                    let payload = JSON.parse(payloadStr)
                    polkitDialogLoader.item.open(payload.message, payload.identities, payload.default_user)
                } catch (e) {
                    console.log("Error parsing polkit prompt: " + e)
                }
            } else {
                polkitDialogLoader.pendingPayload = payloadStr
                polkitDialogLoader.source = "PolkitDialog.qml"
                polkitDialogLoader.active = true
            }
        }
        function finishPrompt(payloadStr: string): void {
            if (polkitDialogLoader.active && polkitDialogLoader.item) {
                try {
                    let payload = JSON.parse(payloadStr)
                    polkitDialogLoader.item.handleResult(payload.success)
                } catch (e) {
                    console.log("Error parsing polkit result: " + e)
                }
            }
        }
        function close(): void {
            if (polkitDialogLoader.active && polkitDialogLoader.item) {
                polkitDialogLoader.item.close()
            }
        }
    }

    // Volume Dialog IPC
    IpcHandler {
        target: "volume"
        function toggle(): void {
            shellRoot.toggleLoader(volumeDialogLoader, "VolumeDialog.qml", undefined)
        }
        function close(): void {
            if (volumeDialogLoader.active && volumeDialogLoader.item) {
                volumeDialogLoader.item.close()
            }
        }
    }

    // Mic Dialog IPC
    IpcHandler {
        target: "mic"
        function toggle(): void {
            shellRoot.toggleLoader(micDialogLoader, "MicDialog.qml", undefined)
        }
        function close(): void {
            if (micDialogLoader.active && micDialogLoader.item) {
                micDialogLoader.item.close()
            }
        }
    }

    // Calendar IPC
    IpcHandler {
        target: "calendar"
        function toggle(): void {
            shellRoot.toggleLoader(calendarLoader, "CalendarPanel.qml", undefined)
        }
        function close(): void {
            if (calendarLoader.active && calendarLoader.item) {
                calendarLoader.item.close()
            }
        }
    }

    // Power IPC
    IpcHandler {
        target: "power"
        function toggle(): void {
            shellRoot.toggleLoader(powerDialogLoader, "PowerDialog.qml", undefined)
        }
        function close(): void {
            if (powerDialogLoader.active && powerDialogLoader.item) {
                powerDialogLoader.item.close()
            }
        }
    }

    // Settings IPC
    IpcHandler {
        target: "settings"
        function toggle(): void {
            if (settingsWindowLoader.active && settingsWindowLoader.item && settingsWindowLoader.item.visible) {
                settingsWindowLoader.item.close()
            } else {
                closeAllPopups()
                if (settingsWindowLoader.item) {
                    settingsWindowLoader.item.open()
                } else {
                    settingsWindowLoader.openPending = true
                    settingsWindowLoader.source = "SettingsWindow.qml"
                    settingsWindowLoader.active = true
                }
            }
        }
        function openTab(tabName: string): void {
            closeAllPopups()
            if (settingsWindowLoader.item) {
                settingsWindowLoader.item.open(tabName)
            } else {
                settingsWindowLoader.pendingTab = tabName
                settingsWindowLoader.openPending = true
                settingsWindowLoader.source = "SettingsWindow.qml"
                settingsWindowLoader.active = true
            }
        }
        function close(): void {
            if (settingsWindowLoader.active && settingsWindowLoader.item) {
                settingsWindowLoader.item.close()
            }
        }
        function toggleMaximize(): void {
            if (settingsWindowLoader.active && settingsWindowLoader.item && settingsWindowLoader.item.visible) {
                settingsWindowLoader.item.fullscreen = !settingsWindowLoader.item.fullscreen
            }
        }
    }

    // Primary Monitor IPC
    IpcHandler {
        target: "primary_monitor"
        function update(): void {
            primaryMonitorReader.running = false
            primaryMonitorReader.running = true
        }
    }

    // Ventanas backdrop fullscreen para cada monitor (estáticos para preservar apilamiento bajo los popups)
    PanelWindow {
        id: backdrop0
        screen: null
        visible: false
        
        anchors { top: true; bottom: true; left: true; right: true }
        margins.top: shellRoot.getPopupTopMargin(backdrop0.screen)
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        WlrLayershell.exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "quickshell-backdrop"
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            onClicked: shellRoot.closeBarPopups()
        }
    }

    PanelWindow {
        id: backdrop1
        screen: null
        visible: false
        
        anchors { top: true; bottom: true; left: true; right: true }
        margins.top: shellRoot.getPopupTopMargin(backdrop1.screen)
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        WlrLayershell.exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "quickshell-backdrop"
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            onClicked: shellRoot.closeBarPopups()
        }
    }

    PanelWindow {
        id: backdrop2
        screen: null
        visible: false
        
        anchors { top: true; bottom: true; left: true; right: true }
        margins.top: shellRoot.getPopupTopMargin(backdrop2.screen)
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        WlrLayershell.exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "quickshell-backdrop"
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            onClicked: shellRoot.closeBarPopups()
        }
    }

    PanelWindow {
        id: backdrop3
        screen: null
        visible: false
        
        anchors { top: true; bottom: true; left: true; right: true }
        margins.top: shellRoot.getPopupTopMargin(backdrop3.screen)
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        WlrLayershell.exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "quickshell-backdrop"
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            onClicked: shellRoot.closeBarPopups()
        }
    }

    property string primaryScreenName: ""
    property var activeScreen: {
        for (let i = 0; i < Quickshell.screens.length; i++) {
            if (Quickshell.screens[i].name === primaryScreenName) {
                return Quickshell.screens[i]
            }
        }
        return Quickshell.screens.length > 0 ? Quickshell.screens[0] : null
    }

    onActiveScreenChanged: {
        if (panelLoader.item) panelLoader.item.screen = activeScreen
        if (notificationsLoader.item) notificationsLoader.item.screen = activeScreen
        if (batteryLoader.item) batteryLoader.item.screen = activeScreen
        if (memoryLoader.item) memoryLoader.item.screen = activeScreen
        if (bgappsLoader.item) bgappsLoader.item.screen = activeScreen
        if (ejectPanelLoader.item) ejectPanelLoader.item.screen = activeScreen
        if (wifimenuLoader.item) wifimenuLoader.item.screen = activeScreen
        if (wifiPasswordDialogLoader.item) wifiPasswordDialogLoader.item.screen = activeScreen
        if (shortcutsDialogLoader.item) shortcutsDialogLoader.item.screen = activeScreen
        if (polkitDialogLoader.item) polkitDialogLoader.item.screen = activeScreen
        if (volumeDialogLoader.item) volumeDialogLoader.item.screen = activeScreen
        if (micDialogLoader.item) micDialogLoader.item.screen = activeScreen
        if (calendarLoader.item) calendarLoader.item.screen = activeScreen
        if (powerDialogLoader.item) powerDialogLoader.item.screen = activeScreen
        if (settingsWindowLoader.item) settingsWindowLoader.item.screen = activeScreen
    }

    Process {
        id: primaryMonitorReader
        command: ["bash", "/home/ismael/scripts/get_primary_monitor.sh"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                let name = data.trim();
                if (name && name !== shellRoot.primaryScreenName) {
                    shellRoot.primaryScreenName = name;
                }
            }
        }
    }

    // Actualiza la pantalla primaria únicamente al conectar/desconectar monitores
    Connections {
        target: Quickshell
        function onScreensChanged() {
            primaryMonitorReader.running = false
            primaryMonitorReader.running = true
            shellRoot.assignBackdropScreens()
        }
    }
    Loader {
        id: panelLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: panelLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) panelLoader.unloadTimer.restart()
                else if (item && item.visible) panelLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: notificationsLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: notificationsLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) notificationsLoader.unloadTimer.restart()
                else if (item && item.visible) notificationsLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: batteryLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: batteryLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) batteryLoader.unloadTimer.restart()
                else if (item && item.visible) batteryLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: memoryLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: memoryLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) memoryLoader.unloadTimer.restart()
                else if (item && item.visible) memoryLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: bgappsLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: bgappsLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) bgappsLoader.unloadTimer.restart()
                else if (item && item.visible) bgappsLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: ejectPanelLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: ejectPanelLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) ejectPanelLoader.unloadTimer.restart()
                else if (item && item.visible) ejectPanelLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    TopBar {
        id: topBar
        screen: activeScreen
        onTogglePanel: (x) => shellRoot.toggleLoader(panelLoader, "ControlPanel.qml", x)
        onToggleCalendar: (x) => shellRoot.toggleLoader(calendarLoader, "CalendarPanel.qml", x)
        onToggleNotifications: (x) => shellRoot.toggleLoader(notificationsLoader, "NotificationsPanel.qml", x)
        onTogglePower: (x) => shellRoot.toggleLoader(powerDialogLoader, "PowerDialog.qml", x)
        onToggleBgApps: (x) => shellRoot.toggleLoader(bgappsLoader, "BgAppsPanel.qml", x)
        onToggleEject: (x) => shellRoot.toggleLoader(ejectPanelLoader, "EjectPanel.qml", x)
        onToggleWifi: (x) => shellRoot.toggleLoader(networkMenuLoader, "NetworkMenu.qml", x)
        onToggleBluetooth: (x) => shellRoot.toggleLoader(bluetoothMenuLoader, "BluetoothMenu.qml", x)
        onToggleVolume: (x) => shellRoot.toggleLoader(volumeDialogLoader, "VolumeDialog.qml", x)
        onToggleMic: (x) => shellRoot.toggleLoader(micDialogLoader, "MicDialog.qml", x)
        onToggleBattery: (x) => shellRoot.toggleLoader(batteryLoader, "BatteryPanel.qml", x)
        onToggleMemory: (x) => shellRoot.toggleLoader(memoryLoader, "MemoryDetailPanel.qml", x)
    }
    
    Loader {
        id: wifimenuLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: wifimenuLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) wifimenuLoader.unloadTimer.restart()
                else if (item && item.visible) wifimenuLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: networkMenuLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: networkMenuLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) networkMenuLoader.unloadTimer.restart()
                else if (item && item.visible) networkMenuLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
            shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: bluetoothMenuLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: bluetoothMenuLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) bluetoothMenuLoader.unloadTimer.restart()
                else if (item && item.visible) bluetoothMenuLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            item.bluetoothPowerChanged.connect(function() {
                if (panelLoader.active && panelLoader.item) {
                    let quickTiles = findQuickTiles(panelLoader.item)
                    if (quickTiles && typeof quickTiles.refreshBluetooth === "function") {
                        quickTiles.refreshBluetooth()
                    }
                }
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
            shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: clipboardMenuLoader
        active: false
        asynchronous: true
        property bool openPending: false
        property var targetScreen: null
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: clipboardMenuLoader.active = false }
        onLoaded: {
            item.screen = targetScreen || activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) clipboardMenuLoader.unloadTimer.restart()
                else if (item && item.visible) clipboardMenuLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            if (openPending) {
                item.toggle()
                openPending = false
            }
            shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: wifiPasswordDialogLoader
        active: false
        asynchronous: true
        property string pendingSsid: ""
        property var pendingCallback: null
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: wifiPasswordDialogLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) wifiPasswordDialogLoader.unloadTimer.restart()
                else if (item && item.visible) wifiPasswordDialogLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            if (pendingSsid !== "") {
                item.open(pendingSsid, pendingCallback)
                pendingSsid = ""
                pendingCallback = null
            }
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: shortcutsDialogLoader
        active: false
        asynchronous: true
        property bool openPending: false
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: shortcutsDialogLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) shortcutsDialogLoader.unloadTimer.restart()
                else if (item && item.visible) shortcutsDialogLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            if (openPending) {
                item.open()
                openPending = false
            }
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: launcherDialogLoader
        active: false
        asynchronous: true
        property bool openPending: false
        property var targetScreen: null
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: launcherDialogLoader.active = false }
        onLoaded: {
            item.screen = targetScreen || activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) launcherDialogLoader.unloadTimer.restart()
                else if (item && item.visible) launcherDialogLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            if (openPending) {
                item.open()
                openPending = false
            }
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: polkitDialogLoader
        active: false
        asynchronous: true
        property string pendingPayload: ""
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: polkitDialogLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) polkitDialogLoader.unloadTimer.restart()
                else if (item && item.visible) polkitDialogLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            if (pendingPayload !== "") {
                try {
                    let payload = JSON.parse(pendingPayload)
                    item.open(payload.message, payload.identities, payload.default_user)
                } catch (e) {
                    console.log("Error parsing polkit prompt on load: " + e)
                }
                pendingPayload = ""
            }
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: volumeDialogLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: volumeDialogLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) volumeDialogLoader.unloadTimer.restart()
                else if (item && item.visible) volumeDialogLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: micDialogLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: micDialogLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) micDialogLoader.unloadTimer.restart()
                else if (item && item.visible) micDialogLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: calendarLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: calendarLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) calendarLoader.unloadTimer.restart()
                else if (item && item.visible) calendarLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: powerDialogLoader
        active: false
        asynchronous: true
        property var posXToOpen: undefined
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: powerDialogLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) powerDialogLoader.unloadTimer.restart()
                else if (item && item.visible) powerDialogLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            shellRoot.openLoadedItem(item, posXToOpen)
            posXToOpen = undefined
                shellRoot.updateNotificationMargin()
        }
    }

    Loader {
        id: settingsWindowLoader
        active: false
        asynchronous: true
        property bool openPending: false
        property string pendingTab: ""
        property Timer unloadTimer: Timer { interval: shellRoot.loaderUnloadDelay; onTriggered: settingsWindowLoader.active = false }
        onLoaded: {
            item.screen = activeScreen
            item.visibleChanged.connect(function() {
                if (item && !item.visible) settingsWindowLoader.unloadTimer.restart()
                else if (item && item.visible) settingsWindowLoader.unloadTimer.stop()
                shellRoot.updateNotificationMargin()
            })
            item.backingWindowVisibleChanged.connect(function() {
                if (item && !item.backingWindowVisible) {
                    item.visible = false
                    settingsWindowLoader.active = false
                }
            })
            if (openPending) {
                item.open(pendingTab || undefined)
                pendingTab = ""
                openPending = false
            }
                shellRoot.updateNotificationMargin()
        }
    }

    NotificationPopup {
        id: notificationPopup
        topMargin: 45
    }
}
