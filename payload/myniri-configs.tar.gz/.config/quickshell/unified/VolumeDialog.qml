// VolumeDialog.qml — Diálogo de control de volumen y selector de dispositivos
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

BasePopup {
    id: window

    WindowSettings { id: ws }

    anchors {
        top: true
        left: true
        right: false
    }
    margins.top: shellRoot.getPopupTopMargin(window.screen)
    margins.left: window.anchorMargin

    property int anchorMargin: 312

    implicitWidth: 360
    implicitHeight: contentCol.implicitHeight + 24
    property int contentHeight: contentCol.implicitHeight + 24

    WlrLayershell.layer: WlrLayer.Overlay

    // Process to retrieve and update audio details
    Process {
        id: audioRefresh
        command: ["bash", "-c", "default=$(pactl get-default-sink); echo \"DEFAULT:$default\"; pactl list sinks | grep -E -i \"Name:|Nombre:|Description:|Descripción:\"; pactl get-sink-volume @DEFAULT_SINK@ | grep -oP '\\d+%' | head -1 | tr -d '%'; pactl get-sink-mute @DEFAULT_SINK@ | awk '{print \"MUTE:\"$2}'"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("DEFAULT:")) {
                    window.defaultSink = line.substring(8).trim()
                    sinkModel.clear()
                } else if (line.startsWith("Nombre:") || line.startsWith("Name:")) {
                    window.tempName = line.substring(line.indexOf(":") + 1).trim()
                } else if (line.startsWith("Descripción:") || line.startsWith("Description:")) {
                    let desc = line.substring(line.indexOf(":") + 1).trim()
                    let name = window.tempName
                    let icon = window.friendlyIcon(desc, name)
                    sinkModel.append({ name: name, label: desc, icon: icon })
                    if (name === window.defaultSink) {
                        window.activeSinkLabel = desc
                    }
                } else if (line.startsWith("MUTE:")) {
                    let val = line.substring(5).trim().toLowerCase()
                    window.volMuted = (val === "yes" || val === "sí" || val === "si")
                } else {
                    let v = parseInt(line)
                    if (!isNaN(v)) {
                        window.volume = Math.min(v, 100)
                        window.pendingVolume = window.volume
                    }
                }
            }
        }
    }

    Timer {
        id: refreshTimer
        interval: 100
        repeat: false
        onTriggered: window.refreshAudio()
    }

    function refreshAudio() {
        audioRefresh.running = false
        Qt.callLater(() => audioRefresh.running = true)
    }

    // State properties
    property string defaultSink: ""
    property string activeSinkLabel: "Dispositivo de Audio"
    property int volume: 50
    property int pendingVolume: volume
    property bool volMuted: false
    property string tempName: ""

    // Theme Colors
    readonly property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false
    readonly property color bgMain: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a";
        return Qt.color(raw);
    }
    readonly property color bgCard: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgCard) || "#232323";
        let base = Qt.color(raw);
        return blurEnabled ? Qt.rgba(base.r, base.g, base.b, 0.65) : base;
    }
    readonly property color bgActive: Qt.rgba(accent.r, accent.g, accent.b, 0.12)
    readonly property color border: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    readonly property color textPri: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
    readonly property color textSec: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
    readonly property color accent: (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property color danger: (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e06c6c"

    ListModel { id: sinkModel }

    Component.onCompleted: {
        window.refreshAudio()
    }

    function friendlyIcon(desc, name) {
        let dl = desc.toLowerCase()
        let nl = name.toLowerCase()
        if (dl.includes("headphone") || dl.includes("auricular") || dl.includes("headset") || nl.includes("headphone")) return "\uf590" // headphones
        if (dl.includes("bluetooth") || dl.includes("bluez") || nl.includes("bluez")) return "\uf294" // bluetooth
        if (dl.includes("hdmi") || dl.includes("dp") || dl.includes("displayport")) return "\uf26c" // tv/display
        return "\uf028" // volume icon
    }

    function toggle(x) {
        if (visible) {
            visible = false
        } else {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(12, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 12))
            }
            visible = true
        }
    }

    function open(x) {
        if (!visible) {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(12, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 12))
            }
            visible = true
        }
    }

    function close() {
        visible = false
    }

    onVisibleChanged: {
        if (visible) {
            window.refreshAudio()
            autoCloseTimer.restart()
            contentRect.forceActiveFocus(Qt.MouseFocusReason)
            shellRoot.updateMakoPosition("volume", "open", Math.round(window.implicitHeight + 55).toString())
        } else {
            autoCloseTimer.stop()
            shellRoot.updateMakoPosition("volume", "closed")
        }
    }

    // Auto-close when inactive
    Timer {
        id: autoCloseTimer
        interval: 5000
        repeat: false
        onTriggered: window.close()
    }

    function resetAutoClose() {
        autoCloseTimer.restart()
    }

    // Audio change commit logic
    function setVolumeFromX(x, width) {
        resetAutoClose()
        let clampVal = Math.max(0, Math.min(1, x / width))
        window.pendingVolume = Math.round(clampVal * 100)
        window.volume = window.pendingVolume
        if (window.volume > 0) window.volMuted = false
        volumeCommit.restart()
    }

    Process { id: volumeSetterProcess }

    Timer {
        id: volumeCommit
        interval: 15
        repeat: false
        onTriggered: {
            volumeSetterProcess.running = false
            volumeSetterProcess.command = ["bash", "-c", "pactl set-sink-volume @DEFAULT_SINK@ " + window.pendingVolume + "%; pactl set-sink-mute @DEFAULT_SINK@ 0"]
            volumeSetterProcess.running = true
        }
    }

    Process { id: muteProcess }
    Process { id: switchSinkProcess }

    Rectangle {
        id: contentRect
        anchors.fill: parent
        color: window.bgMain
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        border.color: window.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: window.close()

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onPressed: window.resetAutoClose()
            onPositionChanged: window.resetAutoClose()
        }

        ColumnLayout {
            id: contentCol
            anchors { fill: parent; margins: 14 }
            spacing: 14

            // --- SECCIÓN 1: Slider HUD ---
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 6

                QsText {
                    text: window.activeSinkLabel
                    color: window.textPri
                    font.family: "Inter"
                    font.pixelSize: 13
                    font.weight: Font.DemiBold
                    elide: Text.ElideRight
                    Layout.fillWidth: true
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12

                    // Icono Mute. Evitamos f6a9 porque esta fuente lo dibuja
                    // como bloque; el mute se compone con una barra.
                    Item {
                        Layout.preferredWidth: 20
                        Layout.preferredHeight: 22

                        QsText {
                            anchors.centerIn: parent
                            text: "\uf027"
                            font.family: "Font Awesome 6 Free"
                            font.weight: Font.Black
                            font.pixelSize: 15
                            color: window.textSec
                        }

                        Rectangle {
                            visible: window.volMuted
                            width: 2
                            height: 18
                            radius: 1
                            color: window.danger
                            anchors.centerIn: parent
                            rotation: -45
                            antialiasing: true
                        }

                        TapHandler {
                            onTapped: {
                                muteProcess.running = false
                                muteProcess.command = ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]
                                muteProcess.running = true
                                window.volMuted = !window.volMuted
                                refreshTimer.restart()
                            }
                        }
                    }

                    // Slider Pill
                    Item {
                        id: volumeSlider
                        Layout.fillWidth: true
                        height: 24

                        Rectangle {
                            id: track
                            anchors.left: parent.left
                            anchors.right: parent.right
                            anchors.verticalCenter: parent.verticalCenter
                            height: 8
                            radius: 4
                            color: window.border

                            // Accent fill
                            Rectangle {
                                width: (window.volume / 100) * parent.width
                                height: parent.height
                                radius: parent.radius
                                color: window.volMuted ? window.textSec : window.accent
                            }

                            // Subtle dots/ticks inside the slider
                            Row {
                                anchors.fill: parent
                                anchors.leftMargin: parent.width / 10
                                anchors.rightMargin: parent.width / 10
                                spacing: (parent.width - (parent.width / 5)) / 10
                                Repeater {
                                    model: 9
                                    Rectangle {
                                        width: 2; height: 2; radius: 1
                                        color: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.15) : Qt.rgba(255, 255, 255, 0.15)
                                        anchors.verticalCenter: parent.verticalCenter
                                    }
                                }
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onPressed: mouse => window.setVolumeFromX(mouse.x, width)
                            onPositionChanged: mouse => {
                                if (pressed) window.setVolumeFromX(mouse.x, width)
                            }
                        }
                    }

                    // Icono Vol Alto
                    QsText {
                        text: "\uf028"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 15
                        color: window.textSec
                        Layout.preferredWidth: 20
                        horizontalAlignment: Text.AlignHCenter
                    }
                }
            }

            // --- DIVIDER ---
            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: window.border
            }

            // --- SECCIÓN 2: Selector de Dispositivos ---
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 8

                QsText {
                    text: "Dispositivos de salida"
                    color: window.textSec
                    font.family: "Inter"
                    font.pixelSize: 10
                    font.weight: Font.Medium
                    font.capitalization: Font.AllUppercase
                    Layout.fillWidth: true
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    Repeater {
                        model: sinkModel

                        delegate: Rectangle {
                            id: deviceItem
                            Layout.fillWidth: true
                            height: 38
                            radius: ws.cornersEnabled ? Math.min(10, ws.cornerRadius) : 0
                            color: model.name === window.defaultSink ? window.bgActive : window.bgCard
                            border.color: model.name === window.defaultSink ? window.accent : window.border
                            border.width: 1

                            RowLayout {
                                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                                spacing: 8

                                // Icon
                                QsText {
                                    text: model.icon
                                    font.family: "Font Awesome 6 Free"
                                    font.pixelSize: 12
                                    color: model.name === window.defaultSink ? window.accent : window.textSec
                                }

                                // Device friendly name
                                QsText {
                                    text: model.label
                                    color: window.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 11
                                    font.weight: model.name === window.defaultSink ? Font.DemiBold : Font.Normal
                                    elide: Text.ElideRight
                                    Layout.fillWidth: true
                                }

                                // Checkmark for active
                                QsText {
                                    visible: model.name === window.defaultSink
                                    text: "\uf00c"
                                    font.family: "Font Awesome 6 Free"
                                    font.pixelSize: 11
                                    color: window.accent
                                }
                            }

                            HoverHandler { id: itemHover }
                            Rectangle {
                                anchors.fill: parent
                                radius: parent.radius
                                color: itemHover.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                            }

                            TapHandler {
                                onTapped: {
                                    window.resetAutoClose()
                                    let sname = model.name
                                    let cmd = ["bash", "-c",
                                        "pactl set-default-sink " + sname +
                                        "; pactl list sink-inputs short | awk '{print $1}' | xargs -r -I{} pactl move-sink-input {} " + sname]
                                    switchSinkProcess.running = false
                                    switchSinkProcess.command = cmd
                                    switchSinkProcess.running = true
                                    window.defaultSink = sname
                                    refreshTimer.restart()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
