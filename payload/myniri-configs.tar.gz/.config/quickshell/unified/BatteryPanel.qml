// BatteryPanel.qml — Panel de batería y perfiles de energía
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

BasePopup {
    id: root

    WindowSettings { id: ws }

    anchors { top: true; left: true; right: false }
    margins.top: shellRoot.getPopupTopMargin(root.screen)
    margins.left: root.anchorMargin

    property int anchorMargin: 0

    implicitWidth:  340
    implicitHeight: contentCol.implicitHeight + 28
    property int contentHeight: contentCol.implicitHeight + 28

    property string batPercent: "0"
    property string batState: "Unknown"
    property string batTime: ""
    property string batHealth: "Unknown"
    property string batCapacity: "Unknown"
    property string activeProfile: "balanced"

    

    onVisibleChanged: {
        if (visible) {
            shellRoot.updateMakoPosition("battery", "open", Math.round(root.implicitHeight + 55).toString())
            content.forceActiveFocus(Qt.MouseFocusReason)
        } else {
            shellRoot.updateMakoPosition("battery", "closed")
        }
    }

    // ── Toggle / close ───────────────────────────────────────
    function toggle(x) {
        visible = !visible
        if (visible) {
            if (x !== undefined && x >= 0) {
                let screenW = root.screen ? root.screen.width : 1920
                root.anchorMargin = Math.max(12, Math.min(x - root.implicitWidth/2, screenW - root.implicitWidth - 12))
            }
            loadData.running = false
            Qt.callLater(() => loadData.running = true)
            content.forceActiveFocus(Qt.MouseFocusReason)
        }
    }

    // ── Carga de datos ────────────────────────────────────────
    Process {
        id: loadData
        running: false
        command: ["bash", "/home/ismael/scripts/battery_info.sh"]
        stdout: SplitParser {
            onRead: data => {
                let parts = data.trim().split("\t")
                if (parts.length < 6) return
                root.batPercent  = parts[0]
                root.batState    = parts[1]
                root.batTime     = parts[2]
                root.batHealth   = parts[3]
                root.batCapacity = parts[4]
                root.activeProfile = parts[5]
            }
        }
    }

    // ── Aplicar perfil ────────────────────────────────────────
    Process { id: applyProfile; running: false }

    function setProfile(profile) {
        root.activeProfile = profile
        applyProfile.command = ["bash", "/home/ismael/scripts/set_profile.sh", profile]
        applyProfile.running = true
    }

    // ── Helper: icono dinámico según porcentaje y estado ─────
    function stateIcon(s) {
        let p = parseInt(root.batPercent) || 0
        if (s === "charging")      return "\uf0e7"   // fa-bolt (cargando)
        if (s === "fully-charged") return "\uf240"   // fa-battery-full
        // Descargando: icono según nivel
        if (p >= 88) return "\uf240"   // fa-battery-full       ████████
        if (p >= 63) return "\uf241"   // fa-battery-three-quarters ██████
        if (p >= 38) return "\uf242"   // fa-battery-half       ████
        if (p >= 13) return "\uf243"   // fa-battery-quarter    ██
        return "\uf244"               // fa-battery-empty      □
    }
    function stateLabel(s) {
        switch(s) {
            case "charging":      return "Cargando"
            case "discharging":   return "Descargando"
            case "fully-charged": return "Carga completa"
            default:              return s
        }
    }

    // ── UI ────────────────────────────────────────────────────
    Rectangle {
        id: bg
        anchors.fill: parent
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        color:        root.bgMain
        border.color: root.border
        border.width: 1
    }    
    
    Rectangle {
        id: content
        anchors.fill: parent
        focus:        true
        color: root.bgMain
        radius: root.cornersEnabled ? root.cornerRadius : 0
        border.color: root.border
        border.width: 1

        Keys.onEscapePressed: root.visible = false

        ColumnLayout {
            id: contentCol
            anchors {
                top: parent.top; left: parent.left; right: parent.right
                margins: 14
            }
            spacing: 12

            // ── Encabezado ────────────────────────────────────
            Item {
                Layout.fillWidth: true
                implicitHeight: root.batTime !== "" ? 42 : 32

                // Icono de batería grande
                QsText {
                    id: batIcon
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.stateIcon(root.batState)
                    font.family:    "Font Awesome 6 Free"
                    font.pixelSize: 26
                    color: {
                        let p = parseInt(root.batPercent) || 0
                        if (root.batState === "charging")  return root.accent
                        if (p <= 15)                       return "#e06c6c"
                        if (p <= 40)                       return "#e6a550"
                        return root.textPri
                    }
                }

                ColumnLayout {
                    id: textCol
                    anchors {
                        left: batIcon.right
                        leftMargin: 10
                        right: closeBtn.left
                        rightMargin: 10
                        verticalCenter: parent.verticalCenter
                    }
                    spacing: 2

                    // Porcentaje + estado
                    RowLayout {
                        spacing: 8
                        QsText {
                            text: root.batPercent + "%"
                            color: root.textPri
                            font.family:  "Inter"
                            font.pixelSize: 22
                            font.weight:  Font.DemiBold
                        }
                        QsText {
                            text: root.stateLabel(root.batState)
                            color: root.textSec
                            font.family:    "Inter"
                            font.pixelSize: 13
                            Layout.alignment: Qt.AlignVCenter
                        }
                    }

                    // Tiempo restante / hasta lleno
                    QsText {
                        visible: root.batTime !== ""
                        text: root.batTime !== "" ? "Time until full: " + root.batTime : ""
                        color: root.textSec
                        font.family:    "Inter"
                        font.pixelSize: 11
                    }
                }

                // Botón cerrar
                Rectangle {
                    id: closeBtn
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    width: 28; height: 28; radius: 14
                    color: closeHover.hovered ? Qt.rgba(1,1,1,0.08) : "transparent"
                    border.color: closeHover.hovered ? root.border : "transparent"
                    border.width: 1
                    QsText {
                        anchors.centerIn: parent
                        text: "\uf00d"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 11
                        color: root.textSec
                    }
                    HoverHandler { id: closeHover }
                    TapHandler   { onTapped: root.visible = false }
                }
            }

            // ── Separador ─────────────────────────────────────
            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: Qt.rgba(1,1,1,0.07)
            }

            // ── Tarjetas de info: Salud + Capacidad ───────────
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                // Salud
                Rectangle {
                    Layout.fillWidth: true
                    height: 56
                    radius: ws.cornersEnabled ? ws.cornerRadius : 0
                    color:  root.bgCard
                    border.color: root.border
                    border.width: 1

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 3
                        QsText {
                            Layout.alignment: Qt.AlignHCenter
                            text: "Salud"
                            color: root.textSec
                            font.family:    "Inter"
                            font.pixelSize: 10
                        }
                        QsText {
                            Layout.alignment: Qt.AlignHCenter
                            text: root.batHealth
                            color: root.textPri
                            font.family:  "Inter"
                            font.pixelSize: 15
                            font.weight:  Font.DemiBold
                        }
                    }
                }

                // Capacidad
                Rectangle {
                    Layout.fillWidth: true
                    height: 56
                    radius: ws.cornersEnabled ? ws.cornerRadius : 0
                    color:  root.bgCard
                    border.color: root.border
                    border.width: 1

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: 3
                        QsText {
                            Layout.alignment: Qt.AlignHCenter
                            text: "Capacidad"
                            color: root.textSec
                            font.family:    "Inter"
                            font.pixelSize: 10
                        }
                        QsText {
                            Layout.alignment: Qt.AlignHCenter
                            text: root.batCapacity
                            color: root.textPri
                            font.family:  "Inter"
                            font.pixelSize: 15
                            font.weight:  Font.DemiBold
                        }
                    }
                }
            }

            // ── Separador ─────────────────────────────────────
            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: Qt.rgba(1,1,1,0.07)
            }

            // ── Selector de perfil ────────────────────────────
            QsText {
                text: "Perfil de energía"
                color: root.textPri
                opacity: 0.75
                font.family:    "Inter"
                font.pixelSize: 10
                font.weight:    Font.Medium
                leftPadding: 2
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.bottomMargin: 0
                spacing: 6

                Repeater {
                    model: [
                        { id: "power-saver",  label: "Power Saver", icon: "\uf04c" },
                        { id: "balanced",     label: "Balanced",    icon: "\uf074" },
                        { id: "performance",  label: "Performance", icon: "\uf135" }
                    ]

                    delegate: Rectangle {
                        Layout.fillWidth: true
                        height: 44
                        radius: ws.cornersEnabled ? ws.cornerRadius : 0

                        readonly property bool isActive: root.activeProfile === modelData.id

                        color: isActive
                            ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.12)
                            : (btnHover.hovered ? Qt.rgba(1,1,1,0.07) : root.bgCard)

                        border.color: isActive
                            ? root.accent
                            : (btnHover.hovered ? Qt.rgba(1,1,1,0.12) : root.border)
                        border.width: 1

                        Behavior on color        { ColorAnimation { duration: 120 } }
                        Behavior on border.color { ColorAnimation { duration: 120 } }

                        ColumnLayout {
                            anchors.centerIn: parent
                            spacing: 3

                            QsText {
                                Layout.alignment: Qt.AlignHCenter
                                text: modelData.icon
                                font.family:    "Font Awesome 6 Free"
                                font.pixelSize: 13
                                color: isActive ? root.accent : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                                Behavior on color { ColorAnimation { duration: 120 } }
                            }
                            QsText {
                                Layout.alignment: Qt.AlignHCenter
                                text: modelData.label
                                font.family:  "Inter"
                                font.pixelSize: 11
                                font.weight:  Font.DemiBold
                                color: isActive ? root.textPri : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.7)
                            }
                        }

                        HoverHandler { id: btnHover }
                        TapHandler   { onTapped: root.setProfile(modelData.id) }
                    }
                }
            }

            // ── Chip: perfil del sistema activo (tuned/gov) ───
            QsText {
                id: backendLabel
                Layout.alignment: Qt.AlignHCenter
                Layout.bottomMargin: 2
                text: {
                    // Se actualiza tras aplicar perfil
                    switch(root.activeProfile) {
                        case "power-saver":  return "tlp: force bat (Power Saver)"
                        case "balanced":     return "tlp: auto (Balanced)"
                        case "performance":  return "tlp: force ac (Performance)"
                        default:             return ""
                    }
                }
                color: root.textSec
                font.family:    "Inter"
                font.pixelSize: 9
                opacity: 0.7
            }
        }
    }
}
