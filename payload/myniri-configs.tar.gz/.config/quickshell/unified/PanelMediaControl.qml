// PanelMediaControl.qml — Zona de reproducción multimedia
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

Item {
    id: root
    implicitHeight: visible ? mainCard.height : 0
    visible: mediaStatus !== "None" && mediaStatus !== ""

    property color bgCard
    property color border
    property color textPri
    property color textSec
    property color accent
    property bool panelVisible: false

    property string mediaStatus: "None"
    property string mediaTitle: ""
    property string mediaArtist: ""
    property string mediaArtUrl: ""
    property real mediaLength: 0     // in seconds
    property real mediaPosition: 0   // in seconds
    property string currentPlayer: ""
    property var availablePlayers: []

    function formatTime(secs) {
        if (isNaN(secs) || secs < 0) return "00:00"
        let h = Math.floor(secs / 3600)
        let m = Math.floor((secs % 3600) / 60)
        let s = Math.floor(secs % 60)
        if (h > 0) {
            return h + ":" + (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s)
        }
        return (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s)
    }

    function runPlayerctl(args) {
        let cmd = ["playerctl"]
        if (root.currentPlayer !== "") {
            cmd.push("-p", root.currentPlayer)
        }
        cmd = cmd.concat(args)
        Qt.createQmlObject('import Quickshell.Io; Process { command: ' + JSON.stringify(cmd) + '; running: true }', root)
    }

    onCurrentPlayerChanged: {
        if (root.currentPlayer !== undefined) {
            Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "-c", "echo \'' + root.currentPlayer + '\' > /tmp/qs_current_player"]; running: true }', root)
        }
    }

    // Poller de estado y metadatos
    Process {
        id: mediaPoller
        command: ["bash", "-c", [
            "CURRENT_PLAYER=$(cat /tmp/qs_current_player 2>/dev/null || echo \"\")",
            "PLAYER_ARG=\"\"",
            "if [ -n \"$CURRENT_PLAYER\" ]; then PLAYER_ARG=\"-p $CURRENT_PLAYER\"; fi",
            "if playerctl $PLAYER_ARG status >/dev/null 2>&1; then",
            "  echo \"STATUS:$(playerctl $PLAYER_ARG status 2>/dev/null)\";",
            "  echo \"TITLE:$(playerctl $PLAYER_ARG metadata xesam:title 2>/dev/null)\";",
            "  echo \"ARTIST:$(playerctl $PLAYER_ARG metadata xesam:artist 2>/dev/null)\";",
            "  echo \"ARTURL:$(playerctl $PLAYER_ARG metadata mpris:artUrl 2>/dev/null)\";",
            "  echo \"LENGTH:$(playerctl $PLAYER_ARG metadata mpris:length 2>/dev/null)\";",
            "  echo \"POSITION:$(playerctl $PLAYER_ARG position 2>/dev/null)\";",
            "else",
            "  echo \"STATUS:None\";",
            "fi;",
            "echo \"PLAYERS:$(playerctl -l 2>/dev/null | tr '\\n' ',' | sed 's/,$//')\""
        ].join("\n")]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("STATUS:")) {
                    root.mediaStatus = line.substring(7)
                } else if (line.startsWith("TITLE:")) {
                    let newTitle = line.substring(6)
                    if (root.mediaTitle !== newTitle) {
                        root.mediaTitle = newTitle
                        root.mediaArtUrl = ""
                    }
                } else if (line.startsWith("ARTIST:")) {
                    let newArtist = line.substring(7)
                    if (root.mediaArtist !== newArtist) {
                        root.mediaArtist = newArtist
                        root.mediaArtUrl = ""
                    }
                } else if (line.startsWith("ARTURL:")) {
                    let url = line.substring(7)
                    if (url !== "") {
                        root.mediaArtUrl = url
                    }
                } else if (line.startsWith("LENGTH:")) {
                    let val = parseInt(line.substring(7))
                    root.mediaLength = isNaN(val) ? 0 : Math.round(val / 1000000)
                } else if (line.startsWith("POSITION:")) {
                    let val = parseFloat(line.substring(9))
                    if (!sliderMouseArea.pressed && !isNaN(val)) {
                        root.mediaPosition = val
                    }
                } else if (line.startsWith("PLAYERS:")) {
                    let playersStr = line.substring(8)
                    let pList = playersStr ? playersStr.split(",") : []
                    if (JSON.stringify(root.availablePlayers) !== JSON.stringify(pList)) {
                        root.availablePlayers = pList
                        if (root.currentPlayer !== "" && pList.indexOf(root.currentPlayer) === -1) {
                            root.currentPlayer = pList.length > 0 ? pList[0] : ""
                            mediaPoller.running = false
                            Qt.callLater(() => mediaPoller.running = true)
                        } else if (root.currentPlayer === "" && pList.length > 0) {
                            root.currentPlayer = pList[0]
                            mediaPoller.running = false
                            Qt.callLater(() => mediaPoller.running = true)
                        }
                    }
                }
            }
        }
    }

    // Timer de actualización adaptativo
    Timer {
        id: pollTimer
        interval: root.mediaStatus === "Playing" ? 1000 : 3000
        running: root.panelVisible
        repeat: true
        triggeredOnStart: true
        onTriggered: {
            mediaPoller.running = false
            Qt.callLater(() => mediaPoller.running = true)
        }
    }

    // Incrementar posición localmente entre encuestas para mayor suavidad
    Timer {
        id: tickTimer
        interval: 250
        running: root.panelVisible && root.mediaStatus === "Playing" && !sliderMouseArea.pressed
        repeat: true
        onTriggered: {
            if (root.mediaPosition < root.mediaLength) {
                root.mediaPosition = Math.min(root.mediaLength, root.mediaPosition + 0.25)
            }
        }
    }

    Rectangle {
        id: mainCard
        width: parent.width
        height: mainCol.implicitHeight + 20
        color: root.bgCard
        radius: 10
        border.color: root.border
        border.width: 1

        ColumnLayout {
            id: mainCol
            anchors {
                fill: parent
                margins: 10
            }
            spacing: 8

            // Fila superior: Portada, Metadatos y Controles
            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                // Portada del Álbum
                Rectangle {
                    width: 48
                    height: 48
                    radius: 8
                    color: root.border
                    border.color: root.border
                    border.width: 1
                    clip: true

                    Image {
                        id: artImage
                        anchors.fill: parent
                        source: root.mediaArtUrl ? root.mediaArtUrl : ""
                        fillMode: Image.PreserveAspectCrop
                        visible: status === Image.Ready
                    }

                    QsText {
                        anchors.centerIn: parent
                        text: "\uf001" // Icono de nota musical
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 18
                        color: root.textSec
                        visible: !artImage.visible
                    }
                }

                // Título y Artista
                ColumnLayout {
                    spacing: 2
                    Layout.fillWidth: true

                    QsText {
                        text: root.mediaTitle ? root.mediaTitle : "Sin reproducción"
                        color: root.textPri
                        font.family: "Inter"
                        font.pixelSize: 13
                        font.weight: Font.DemiBold
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                    }

                    QsText {
                        text: root.mediaArtist ? root.mediaArtist : "Desconocido"
                        color: root.textSec
                        font.family: "Inter"
                        font.pixelSize: 11
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                    }
                }

                // Botones multimedia
                RowLayout {
                    spacing: 6
                    Layout.alignment: Qt.AlignVCenter

                    // Anterior
                    Rectangle {
                        width: 30; height: 30; radius: 15
                        Layout.alignment: Qt.AlignVCenter
                        color: prevHover.hovered ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(255, 255, 255, 0.06)) : ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.02) : Qt.rgba(255, 255, 255, 0.02))
                        border.color: root.border; border.width: 1

                        QsText {
                            anchors.centerIn: parent
                            text: "\uf048"
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 10
                            color: root.textPri
                        }

                        HoverHandler { id: prevHover }
                        TapHandler {
                            onTapped: root.runPlayerctl(["previous"])
                        }
                    }

                    // Play / Pausa
                    Rectangle {
                        width: 34; height: 34; radius: 17
                        Layout.alignment: Qt.AlignVCenter
                        color: playHover.hovered ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(255, 255, 255, 0.06)) : ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.02) : Qt.rgba(255, 255, 255, 0.02))
                        border.color: root.border; border.width: 1

                        QsText {
                            anchors.centerIn: parent
                            anchors.horizontalCenterOffset: (root.mediaStatus === "Playing") ? 0 : 1
                            text: root.mediaStatus === "Playing" ? "\uf04c" : "\uf04b"
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 11
                            color: root.textPri
                        }

                        HoverHandler { id: playHover }
                        TapHandler {
                            onTapped: root.runPlayerctl(["play-pause"])
                        }
                    }

                    // Siguiente
                    Rectangle {
                        width: 30; height: 30; radius: 15
                        Layout.alignment: Qt.AlignVCenter
                        color: nextHover.hovered ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(255, 255, 255, 0.06)) : ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.02) : Qt.rgba(255, 255, 255, 0.02))
                        border.color: root.border; border.width: 1

                        QsText {
                            anchors.centerIn: parent
                            text: "\uf051"
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 10
                            color: root.textPri
                        }

                        HoverHandler { id: nextHover }
                        TapHandler {
                            onTapped: root.runPlayerctl(["next"])
                        }
                    }
                }
            }

            // Fila inferior: Slider de Progreso y Tiempos
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2

                // Selector de reproductor
                Rectangle {
                    visible: true
                    Layout.fillWidth: true
                    height: 24
                    radius: 8
                    color: playerMouseArea.containsMouse ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(255, 255, 255, 0.06)) : "transparent"
                    border.color: root.border
                    border.width: 1

                    RowLayout {
                        anchors.centerIn: parent
                        spacing: 6
                        QsText {
                            text: "\uf0c9"
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 10
                            color: root.textSec
                        }
                        QsText {
                            text: (root.currentPlayer || "Auto") + " (Jugadores: " + root.availablePlayers.length + ")"
                            font.family: "Inter"
                            font.pixelSize: 11
                            color: root.textSec
                        }
                    }

                    MouseArea {
                        id: playerMouseArea
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        hoverEnabled: true
                        onClicked: {
                            if (root.availablePlayers.length <= 1) return;
                            let idx = root.availablePlayers.indexOf(root.currentPlayer)
                            if (idx === -1) idx = 0
                            idx = (idx + 1) % root.availablePlayers.length
                            root.currentPlayer = root.availablePlayers[idx]
                            mediaPoller.running = false
                            Qt.callLater(() => mediaPoller.running = true)
                        }
                    }
                }

                Item {
                    id: progressSlider
                    visible: root.mediaLength > 0
                    Layout.fillWidth: true
                    height: 24

                    property real positionPct: root.mediaLength > 0 ? (root.mediaPosition / root.mediaLength) : 0

                    Rectangle {
                        id: trackBg
                        anchors.left: parent.left
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter
                        height: 8
                        radius: 4
                        color: root.border

                        Rectangle {
                            width: progressSlider.positionPct * parent.width
                            height: parent.height
                            radius: parent.radius
                            color: root.accent
                        }

                        Row {
                            anchors.fill: parent
                            anchors.leftMargin: parent.width / 10
                            anchors.rightMargin: parent.width / 10
                            spacing: (parent.width - (parent.width / 5)) / 10
                            Repeater {
                                model: 9
                                Rectangle {
                                    width: 2; height: 2; radius: 1
                                    color: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.15) : Qt.rgba(255, 255, 255, 0.15)
                                    anchors.verticalCenter: parent.verticalCenter
                                }
                            }
                        }
                    }

                    MouseArea {
                        id: sliderMouseArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor

                        function seekFromX(localX) {
                            if (root.mediaLength <= 0) return
                            let pct = Math.max(0, Math.min(1, localX / width))
                            root.mediaPosition = pct * root.mediaLength
                            let targetSec = Math.round(root.mediaPosition)
                            root.runPlayerctl(["position", targetSec.toString()])
                        }

                        onPressed: mouse => seekFromX(mouse.x)
                        onPositionChanged: mouse => {
                            if (pressed) seekFromX(mouse.x)
                        }
                    }
                }

                // Etiquetas de tiempo
                RowLayout {
                    visible: root.mediaLength > 0
                    Layout.fillWidth: true

                    QsText {
                        text: root.formatTime(root.mediaPosition)
                        color: root.textSec
                        font.family: "Inter"
                        font.pixelSize: 10
                        font.weight: Font.Medium
                    }

                    Item { Layout.fillWidth: true }

                    QsText {
                        text: "-" + root.formatTime(Math.max(0, root.mediaLength - root.mediaPosition))
                        color: root.textSec
                        font.family: "Inter"
                        font.pixelSize: 10
                        font.weight: Font.Medium
                    }
                }
            }
        }
    }
}
