// AppLauncherDialog.qml — Lanzador de aplicaciones QML estilo premium
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

BasePopup {
    id: root

    WindowSettings { id: ws }

    // Centrado sin anclas a toda la pantalla
    anchors.top: false
    anchors.bottom: false
    anchors.left: false
    anchors.right: false
    
    implicitWidth: 620
    implicitHeight: 520

    // Foco exclusivo para que el teclado funcione directo al abrir
    WlrLayershell.keyboardFocus: root.visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property var allAppsList: []
    property int selectedIndex: 0

    // Colores del tema

    readonly property color bgTile:   (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#2a2a2a"




    function open() {
        root.visible = true
        searchInput.text = ""
        filterApps("")
        Qt.callLater(() => searchInput.forceActiveFocus())
        appsLoader.running = false
        appsLoader.running = true
    }

    function close() {
        root.visible = false
        appsFilteredModel.clear()
        allAppsList = []
    }

    function toggle() {
        if (visible) {
            close()
        } else {
            open()
        }
    }

    function filterApps(searchText) {
        appsFilteredModel.clear()
        let term = (searchText || "").toLowerCase().trim()
        for (let i = 0; i < allAppsList.length; i++) {
            let app = allAppsList[i]
            let name = app.name || ""
            let comment = app.comment || ""
            let keywords = app.keywords || ""
            if (term === "" || 
                name.toLowerCase().indexOf(term) !== -1 ||
                comment.toLowerCase().indexOf(term) !== -1 ||
                keywords.toLowerCase().indexOf(term) !== -1) {
                appsFilteredModel.append(app)
            }
        }
        selectedIndex = 0
    }

    function launchApp(execCmd, name) {
        // Record launch count to history
        if (name) {
            historyRecorder.command = ["/home/ismael/scripts/record_app_launch.py", name]
            historyRecorder.running = true
        }

        // Run the actual app via niri msg action spawn
        let code = 'import Quickshell.Io; Process { command: ["niri", "msg", "action", "spawn", "--", "sh", "-c", ' + JSON.stringify(execCmd) + ']; running: true }'
        try {
            Qt.createQmlObject(code, root)
        } catch (e) {
            console.log("Error running process: " + e)
        }
        root.close()
    }

    Process {
        id: historyRecorder
        command: []
        running: false
    }

    Process {
        id: appsLoader
        command: ["/home/ismael/scripts/get_apps.py"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let parsed = JSON.parse(data)
                    if (parsed && parsed.length > 0) {
                        allAppsList = parsed
                        filterApps(searchInput.text)
                    }
                } catch(e) {
                    console.log("Error parsing apps list JSON:", e)
                }
            }
        }
    }

    ListModel {
        id: appsFilteredModel
    }

    onVisibleChanged: {
        if (visible) {
            open()
        }
    }



    // Contenedor principal del diálogo (estilo vidrio oscuro)
    Rectangle {
        id: dialogBox
        anchors.fill: parent
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        color: root.bgMain
        border.color: root.border
        border.width: 1

        MouseArea {
            anchors.fill: parent
            // Evitar que los clics dentro del diálogo lo cierren
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            // Campo de búsqueda con icono
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                TextField {
                    id: searchInput
                    placeholderText: "Buscar aplicaciones..."
                    placeholderTextColor: root.textSec
                    color: root.textPri
                    selectedTextColor: "#111317"
                    selectionColor: root.accent
                    
                    background: Rectangle {
                        color: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.04) : Qt.rgba(255, 255, 255, 0.04)
                        border.color: searchInput.activeFocus ? root.accent : root.border
                        border.width: 1
                        radius: ws.cornersEnabled ? Math.min(10, ws.cornerRadius) : 0
                    }

                    font.family: "Inter"
                    font.pixelSize: 14
                    Layout.fillWidth: true
                    Layout.preferredHeight: 40
                    leftPadding: 36
                    rightPadding: 10

                    onTextChanged: root.filterApps(text)

                    // Icono de lupa
                    QsText {
                        text: "\uf002" // fa-search
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 14
                        color: searchInput.activeFocus ? root.accent : root.textSec
                        anchors.left: parent.left
                        anchors.leftMargin: 12
                        anchors.verticalCenter: parent.verticalCenter
                    }

                    // Manejo de teclado
                    Keys.onPressed: (event) => {
                        if (event.key === Qt.Key_Down) {
                            if (appsFilteredModel.count > 0) {
                                root.selectedIndex = (root.selectedIndex + 1) % appsFilteredModel.count
                            }
                            event.accepted = true
                        } else if (event.key === Qt.Key_Up) {
                            if (appsFilteredModel.count > 0) {
                                root.selectedIndex = (root.selectedIndex - 1 + appsFilteredModel.count) % appsFilteredModel.count
                            }
                            event.accepted = true
                        } else if (event.key === Qt.Key_Enter || event.key === Qt.Key_Return) {
                            if (appsFilteredModel.count > 0 && root.selectedIndex >= 0 && root.selectedIndex < appsFilteredModel.count) {
                                root.launchApp(appsFilteredModel.get(root.selectedIndex).exec, appsFilteredModel.get(root.selectedIndex).name)
                            }
                            event.accepted = true
                        } else if (event.key === Qt.Key_Escape) {
                            root.close()
                            event.accepted = true
                        }
                    }
                }
            }

            // Separador
            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: root.border
            }

            // Lista de aplicaciones
            ListView {
                id: appsList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: appsFilteredModel
                currentIndex: root.selectedIndex

                onCurrentIndexChanged: {
                    appsList.positionViewAtIndex(currentIndex, ListView.Contain)
                }

                delegate: Rectangle {
                    id: delegateItem
                    width: ListView.view.width
                    height: 52
                    radius: ws.cornersEnabled ? Math.min(10, ws.cornerRadius) : 0
                    
                    // Resaltado si está seleccionado
                    property bool isSelected: index === root.selectedIndex
                    
                    color: isSelected ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(255, 255, 255, 0.06)) : "transparent"
                    border.color: isSelected ? root.accent : "transparent"
                    border.width: 1

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 12

                        // Icono de la aplicación
                        Item {
                            width: 32
                            height: 32
                            Layout.alignment: Qt.AlignVCenter

                            Image {
                                id: appIcon
                                anchors.fill: parent
                                source: {
                                    if (!model.icon) return ""
                                    if (model.icon.startsWith("/")) return "file://" + model.icon
                                    return "image://icon/" + model.icon
                                }
                                fillMode: Image.PreserveAspectFit
                                asynchronous: true
                                sourceSize.width: 32
                                sourceSize.height: 32
                                cache: true
                                visible: status === Image.Ready
                            }

                            // Fallback a icono de app genérico si no se carga
                            QsText {
                                anchors.centerIn: parent
                                visible: appIcon.status !== Image.Ready
                                text: "\uf009" // fa-th-large
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 16
                                color: delegateItem.isSelected ? root.accent : root.textSec
                            }
                        }

                        // Texto: Nombre e información
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 1

                            QsText {
                                text: model.name
                                color: delegateItem.isSelected ? root.textPri : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.8)
                                font.family: "Inter"
                                font.pixelSize: 13
                                font.weight: Font.DemiBold
                                Layout.fillWidth: true
                                elide: Text.ElideRight
                            }

                            QsText {
                                text: model.comment || "Aplicación del sistema"
                                color: delegateItem.isSelected ? Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.65) : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.45)
                                font.family: "Inter"
                                font.pixelSize: 10
                                Layout.fillWidth: true
                                elide: Text.ElideRight
                                visible: text !== ""
                            }
                        }
                    }

                    // Navegación por ratón
                    HoverHandler {
                        onHoveredChanged: {
                            if (hovered) {
                                root.selectedIndex = index
                            }
                        }
                    }

                    TapHandler {
                        onTapped: root.launchApp(model.exec, model.name)
                    }
                }

                // Vista si la lista está vacía
                QsText {
                    anchors.centerIn: parent
                    text: "No se encontraron aplicaciones"
                    color: root.textSec
                    font.family: "Inter"
                    font.pixelSize: 13
                    visible: appsFilteredModel.count === 0
                }
            }
        }
    }
}
