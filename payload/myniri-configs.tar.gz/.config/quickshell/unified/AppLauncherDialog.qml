// AppLauncherDialog.qml — Lanzador de aplicaciones QML estilo premium
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects

BasePopup {
    id: root

    WindowSettings { id: ws }

    // Centrado sin anclas a toda la pantalla
    anchors.top: false
    anchors.bottom: false
    anchors.left: false
    anchors.right: false
    
    implicitWidth: 620
    implicitHeight: 520

    // Foco exclusivo para que el teclado funcione directo al abrir
    WlrLayershell.keyboardFocus: root.visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    property var allAppsList: []
    property int selectedIndex: 0
    property bool revealApps: false

    // Colores del tema
    readonly property color bgTile: (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#2a2a2a"

    function open() {
        if (dialogBox.state === "opened") return
        dialogBox.state = "closed"
        root.visible = true
        dialogBox.state = "opened"
        revealApps = true
        searchInput.text = ""
        filterApps("")
        Qt.callLater(() => searchInput.forceActiveFocus())
        appsLoader.running = false
        appsLoader.running = true
    }

    function close() {
        if (dialogBox.state === "closed" || dialogBox.state === "closing") return
        dialogBox.state = "closing"
        revealApps = false
        closeTimer.start()
    }

    function toggle() {
        if (visible) {
            close()
        } else {
            open()
        }
    }

    function filterApps(searchText) {
        appsFilteredModel.clear()
        let term = (searchText || "").toLowerCase().trim()
        for (let i = 0; i < allAppsList.length; i++) {
            let app = allAppsList[i]
            let name = app.name || ""
            let comment = app.comment || ""
            let keywords = app.keywords || ""
            if (term === "" || 
                name.toLowerCase().indexOf(term) !== -1 ||
                comment.toLowerCase().indexOf(term) !== -1 ||
                keywords.toLowerCase().indexOf(term) !== -1) {
                appsFilteredModel.append(app)
            }
        }
        selectedIndex = 0
    }

    function launchApp(execCmd, name) {
        // Record launch count to history
        if (name) {
            historyRecorder.command = ["/home/ismael/scripts/record_app_launch.py", name]
            historyRecorder.running = true
        }

        appLauncher.command = ["niri", "msg", "action", "spawn", "--", "/home/ismael/.local/bin/honey", "sh", "-c", execCmd]
        appLauncher.running = true
        root.close()
    }

    // Helper to infer application categories
    function getAppCategory(app) {
        if (!app) return ""
        let name = (app.name || "").toLowerCase()
        let exec = (app.exec || "").toLowerCase()
        let comment = (app.comment || "").toLowerCase()
        let keywords = (app.keywords || "").toLowerCase()
        
        if (name.includes("firefox") || name.includes("chrome") || name.includes("brave") || name.includes("zen") ||
            exec.includes("firefox") || exec.includes("chrome") || exec.includes("brave") || exec.includes("zen") ||
            comment.includes("web") || comment.includes("browser") || keywords.includes("browser") || keywords.includes("network") ||
            name.includes("internet") || comment.includes("internet")) {
            return "Internet"
        }
        if (name.includes("kitty") || name.includes("konsole") || name.includes("terminal") || name.includes("alacritty") ||
            exec.includes("kitty") || exec.includes("konsole") || exec.includes("alacritty") ||
            keywords.includes("terminal") || keywords.includes("console")) {
            return "Terminal"
        }
        if (name.includes("code") || name.includes("codium") || exec.includes("code") || exec.includes("codium") ||
            comment.includes("desarrollo") || comment.includes("development") || comment.includes("programar") ||
            keywords.includes("development") || keywords.includes("programming")) {
            return "Desarrollo"
        }
        if (name.includes("krita") || name.includes("gimp") || name.includes("inkscape") || name.includes("blender") ||
            comment.includes("graphics") || comment.includes("drawing") || comment.includes("imagen") ||
            keywords.includes("graphics") || keywords.includes("editor")) {
            return "Gráficos"
        }
        if (name.includes("spotify") || name.includes("mpv") || name.includes("vlc") || name.includes("player") ||
            comment.includes("audio") || comment.includes("video") || comment.includes("music") ||
            keywords.includes("player") || keywords.includes("multimedia")) {
            return "Multimedia"
        }
        if (name.includes("settings") || name.includes("config") || comment.includes("system") || comment.includes("settings") ||
            keywords.includes("system") || keywords.includes("configuration")) {
            return "Sistema"
        }
        if (name.includes("steam") || keywords.includes("game") || comment.includes("game")) {
            return "Juegos"
        }
        if (comment.includes("office") || keywords.includes("office") || name.includes("office") ||
            comment.includes("document") || keywords.includes("document")) {
            return "Oficina"
        }
        
        if (keywords.trim() !== "") {
            let words = keywords.split(/[\s,;]+/)
            if (words.length > 0 && words[0].length > 3) {
                return words[0].charAt(0).toUpperCase() + words[0].slice(1)
            }
        }
        
        return ""
    }

    Timer {
        id: closeTimer
        interval: 120
        repeat: false
        onTriggered: {
            root.visible = false
            dialogBox.state = "closed"
            appsFilteredModel.clear()
            allAppsList = []
        }
    }

    Process {
        id: historyRecorder
        command: []
        running: false
    }

    Process {
        id: appLauncher
        command: []
        running: false
        onExited: running = false
    }

    Process {
        id: appsLoader
        command: ["/home/ismael/scripts/get_apps.py"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let parsed = JSON.parse(data)
                    if (parsed && parsed.length > 0) {
                        allAppsList = parsed
                        filterApps(searchInput.text)
                    }
                } catch(e) {
                    console.log("Error parsing apps list JSON:", e)
                }
            }
        }
    }

    ListModel {
        id: appsFilteredModel
    }

    onVisibleChanged: {
        if (visible) {
            open()
        }
    }

    // Contenedor principal del diálogo (estilo vidrio oscuro con blur por compositor)
    Rectangle {
        id: dialogBox
        anchors.fill: parent
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        
        // Translucent background based on blur setting
        color: {
            let base = root.bgMain
            return root.blurEnabled ? Qt.rgba(base.r, base.g, base.b, 0.75) : Qt.rgba(base.r, base.g, base.b, 0.95)
        }
        border.color: root.border
        border.width: 1

        states: [
            State {
                name: "closed"
                PropertyChanges { target: dialogBox; scale: 0.85; opacity: 0.0 }
            },
            State {
                name: "closing"
                PropertyChanges { target: dialogBox; scale: 0.95; opacity: 0.0 }
            },
            State {
                name: "opened"
                PropertyChanges { target: dialogBox; scale: 1.0; opacity: 1.0 }
            }
        ]

        transitions: [
            Transition {
                from: "closed"
                to: "opened"
                ParallelAnimation {
                    NumberAnimation {
                        target: dialogBox
                        property: "scale"
                        duration: 220
                        easing.type: Easing.OutBack
                        easing.overshoot: 2.5
                    }
                    NumberAnimation {
                        target: dialogBox
                        property: "opacity"
                        duration: 150
                        easing.type: Easing.OutQuad
                    }
                }
            },
            Transition {
                from: "opened"
                to: "closing"
                ParallelAnimation {
                    NumberAnimation {
                        target: dialogBox
                        property: "scale"
                        duration: 120
                        easing.type: Easing.OutQuad
                    }
                    NumberAnimation {
                        target: dialogBox
                        property: "opacity"
                        duration: 120
                        easing.type: Easing.OutQuad
                    }
                }
            }
        ]

        MouseArea {
            anchors.fill: parent
            // Evitar que los clics dentro del diálogo lo cierren
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.leftMargin: 24
            anchors.rightMargin: 24
            anchors.topMargin: 20
            anchors.bottomMargin: 20
            spacing: 16

            // Campo de búsqueda con icono
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                TextField {
                    id: searchInput
                    placeholderText: "Buscar aplicaciones..."
                    placeholderTextColor: root.textSec
                    color: root.textPri
                    selectedTextColor: "#111317"
                    selectionColor: root.accent
                    
                    background: Item {
                        // Subtle focused underline glow
                        Rectangle {
                            anchors.bottom: parent.bottom
                            anchors.horizontalCenter: parent.horizontalCenter
                            width: searchInput.activeFocus ? parent.width : 0
                            height: 2
                            color: root.accent
                            
                            Behavior on width {
                                NumberAnimation { duration: 200; easing.type: Easing.OutQuad }
                            }
                        }
                    }

                    font.family: "Inter"
                    font.pixelSize: 15
                    Layout.fillWidth: true
                    Layout.preferredHeight: 44
                    leftPadding: 40
                    rightPadding: 16

                    onTextChanged: root.filterApps(text)

                    // Icono de lupa
                    QsText {
                        text: "\uf002" // fa-search
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 15
                        color: searchInput.activeFocus ? root.accent : root.textSec
                        anchors.left: parent.left
                        anchors.leftMargin: 14
                        anchors.verticalCenter: parent.verticalCenter
                    }

                    // Manejo de teclado
                    Keys.onPressed: (event) => {
                        if (event.key === Qt.Key_Down) {
                            if (appsFilteredModel.count > 0) {
                                root.selectedIndex = (root.selectedIndex + 1) % appsFilteredModel.count
                            }
                            event.accepted = true
                        } else if (event.key === Qt.Key_Up) {
                            if (appsFilteredModel.count > 0) {
                                root.selectedIndex = (root.selectedIndex - 1 + appsFilteredModel.count) % appsFilteredModel.count
                            }
                            event.accepted = true
                        } else if (event.key === Qt.Key_Enter || event.key === Qt.Key_Return) {
                            if (appsFilteredModel.count > 0 && root.selectedIndex >= 0 && root.selectedIndex < appsFilteredModel.count) {
                                root.launchApp(appsFilteredModel.get(root.selectedIndex).exec, appsFilteredModel.get(root.selectedIndex).name)
                            }
                            event.accepted = true
                        } else if (event.key === Qt.Key_Escape) {
                            root.close()
                            event.accepted = true
                        }
                    }
                }
            }

            // Separador sutil (0.5px de alto con opacidad reducida)
            Rectangle {
                Layout.fillWidth: true
                height: 0.5
                color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.4)
            }

            // Lista de aplicaciones
            ListView {
                id: appsList
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: appsFilteredModel
                currentIndex: root.selectedIndex

                onCurrentIndexChanged: {
                    appsList.positionViewAtIndex(currentIndex, ListView.Contain)
                }

                delegate: Rectangle {
                    id: delegateItem
                    width: ListView.view.width
                    height: 56
                    radius: ws.cornersEnabled ? Math.min(10, ws.cornerRadius) : 0
                    
                    // Resaltado si está seleccionado
                    property bool isSelected: index === root.selectedIndex
                    
                    color: isSelected ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(255, 255, 255, 0.06)) : "transparent"
                    border.color: isSelected ? root.accent : "transparent"
                    border.width: 1

                    // Animation properties for stagger reveal
                    opacity: root.revealApps ? 1.0 : 0.0
                    transform: Translate {
                        y: root.revealApps ? 0 : 4
                        Behavior on y {
                            SequentialAnimation {
                                PauseAnimation {
                                    duration: root.revealApps ? (120 + index * 32) : 0
                                }
                                NumberAnimation {
                                    duration: root.revealApps ? 220 : 100
                                    easing.type: Easing.OutQuad
                                }
                            }
                        }
                    }

                    Behavior on opacity {
                        SequentialAnimation {
                            PauseAnimation {
                                duration: root.revealApps ? (120 + index * 32) : 0
                            }
                            NumberAnimation {
                                duration: root.revealApps ? 220 : 100
                                easing.type: Easing.OutQuad
                            }
                        }
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 16
                        anchors.rightMargin: 16
                        anchors.topMargin: 8
                        anchors.bottomMargin: 8
                        spacing: 14

                        // Icono de la aplicación
                        Item {
                            width: 32
                            height: 32
                            Layout.alignment: Qt.AlignVCenter

                            Image {
                                id: appIcon
                                anchors.fill: parent
                                source: {
                                    if (!model.icon) return ""
                                    if (model.icon.startsWith("/")) return "file://" + model.icon
                                    return "image://icon/" + model.icon
                                }
                                fillMode: Image.PreserveAspectFit
                                asynchronous: true
                                sourceSize.width: 32
                                sourceSize.height: 32
                                cache: true
                                visible: status === Image.Ready
                            }

                            // Fallback a icono de app genérico si no se carga
                            QsText {
                                anchors.centerIn: parent
                                visible: appIcon.status !== Image.Ready
                                text: "\uf009" // fa-th-large
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 16
                                color: delegateItem.isSelected ? root.accent : root.textSec
                            }
                        }

                        // App name (single line, elided if long)
                        QsText {
                            text: model.name
                            color: delegateItem.isSelected ? root.textPri : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.8)
                            font.family: "Inter"
                            font.pixelSize: 13
                            font.weight: Font.DemiBold
                            Layout.fillWidth: true
                            Layout.alignment: Qt.AlignVCenter
                            elide: Text.ElideRight
                        }

                        // Category label (right aligned, muted)
                        QsText {
                            text: root.getAppCategory(model)
                            color: delegateItem.isSelected ? Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.5) : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.3)
                            font.family: "Inter"
                            font.pixelSize: 10
                            Layout.alignment: Qt.AlignVCenter | Qt.AlignRight
                            visible: text !== ""
                        }
                    }

                    // Navegación por ratón
                    HoverHandler {
                        onHoveredChanged: {
                            if (hovered) {
                                root.selectedIndex = index
                            }
                        }
                    }

                    TapHandler {
                        onTapped: root.launchApp(model.exec, model.name)
                    }
                }

                // Vista si la lista está vacía
                QsText {
                    anchors.centerIn: parent
                    text: "No se encontraron aplicaciones"
                    color: root.textSec
                    font.family: "Inter"
                    font.pixelSize: 13
                    visible: appsFilteredModel.count === 0
                }
            }
        }
    }
}
