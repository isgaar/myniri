// MemoryDetailPanel.qml — Panel de procesos con mayor consumo de RAM
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

BasePopup {
    id: window

    WindowSettings { id: ws }

    anchors { top: true; left: true; right: false }
    margins.top: shellRoot.getPopupTopMargin(window.screen)
    margins.left: window.anchorMargin

    implicitWidth: 360
    property int contentHeight: contentCol.implicitHeight + 24

    WlrLayershell.layer: WlrLayer.Overlay

    property int anchorMargin: 312

    property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false
    property color bgMain: (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a"
    property color border: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    property color textPri: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
    property color textSec: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
    property color accent: (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    property color danger: (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e06c6c"

    ListModel { id: procModel }

    Process {
        id: procReader
        command: ["bash", "-c", "ps -eo pid,%mem,rss,args --sort=-%mem 2>/dev/null | awk 'NR>1{print $1 \"|\" $2 \"|\" $3 \"|\" substr($0, index($0,$4))}' | head -10"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                let sep = line.indexOf("|")
                if (sep < 0) return
                let pid = line.substring(0, sep)
                let rest = line.substring(sep + 1)
                let sep2 = rest.indexOf("|")
                if (sep2 < 0) return
                let memPct = rest.substring(0, sep2)
                let rest2 = rest.substring(sep2 + 1)
                let sep3 = rest2.indexOf("|")
                if (sep3 < 0) return
                let rssKb = rest2.substring(0, sep3)
                let name = rest2.substring(sep3 + 1)
                let rssMb = (parseInt(rssKb) || 0) / 1024
                procModel.append({
                    pid: pid,
                    memPct: memPct,
                    rss: rssMb.toFixed(1),
                    name: name
                })
            }
        }
    }

    function toggle(x) {
        if (visible) { visible = false; return }
        if (x !== undefined && x >= 0) {
            let screenW = window.screen ? window.screen.width : 1920
            window.anchorMargin = Math.max(12, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 12))
        }
        visible = true
    }

    function open(x) {
        if (!visible) {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(12, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 12))
            }
            visible = true
        }
    }

    function close() { visible = false }

    function resetAutoClose() { autoCloseTimer.restart() }

    onVisibleChanged: {
        if (visible) {
            procModel.clear()
            procReader.running = false
            procReader.running = true
            autoCloseTimer.restart()
            contentRect.forceActiveFocus(Qt.MouseFocusReason)
        } else {
            autoCloseTimer.stop()
        }
    }

    Timer {
        id: autoCloseTimer
        interval: 5000
        repeat: false
        onTriggered: window.close()
    }

    Rectangle {
        id: contentRect
        anchors.fill: parent
        color: window.bgMain
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        border.color: window.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: window.close()

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onPressed: window.resetAutoClose()
            onPositionChanged: window.resetAutoClose()
        }

        ColumnLayout {
            id: contentCol
            anchors { fill: parent; margins: 14 }
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Rectangle {
                    width: 28; height: 28; radius: 8
                    color: Qt.rgba(window.accent.r, window.accent.g, window.accent.b, 0.12)
                    QsText { anchors.centerIn: parent; text: "\uf2db"; font.family: "Font Awesome 6 Free"; font.pixelSize: 13; color: window.accent }
                }

                ColumnLayout {
                    spacing: 1
                    Layout.fillWidth: true
                    QsText { text: "Procesos por RAM"; color: window.textPri; font.family: "Inter"; font.pixelSize: 13; font.weight: Font.DemiBold }
                    QsText { text: "Top 10 por consumo de memoria"; color: window.textSec; font.family: "Inter"; font.pixelSize: 10 }
                }
            }

            Rectangle {
                Layout.fillWidth: true; height: 1; color: window.border
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 4

                Repeater {
                    model: procModel

                    delegate: Rectangle {
                        Layout.fillWidth: true
                        height: 32
                        radius: 6
                        color: index === 0 ? Qt.rgba(window.accent.r, window.accent.g, window.accent.b, 0.08) : "transparent"

                        RowLayout {
                            anchors.fill: parent; anchors.margins: 8
                            spacing: 8

                            Rectangle {
                                width: 20; height: 20; radius: 5
                                color: index === 0 ? window.accent : Qt.rgba(1,1,1,0.04)

                                QsText {
                                    anchors.centerIn: parent
                                    text: (index + 1).toString()
                                    color: index === 0 ? "white" : window.textSec
                                    font.family: "Inter"; font.pixelSize: 10; font.weight: Font.Bold
                                }
                            }

                            QsText {
                                text: model.name
                                color: window.textPri
                                font.family: "Inter"; font.pixelSize: 11
                                elide: Text.ElideRight; Layout.fillWidth: true
                                font.weight: index === 0 ? Font.DemiBold : Font.Normal

                                Behavior on color { ColorAnimation { duration: 150 } }
                            }

                            QsText {
                                text: model.memPct + "%"
                                color: window.textSec
                                font.family: "Inter"; font.pixelSize: 10
                                Layout.preferredWidth: 36; horizontalAlignment: Text.AlignRight
                            }

                            QsText {
                                text: model.rss + "MB"
                                color: window.textSec
                                font.family: "Inter"; font.pixelSize: 10
                                Layout.preferredWidth: 48; horizontalAlignment: Text.AlignRight
                            }
                        }
                    }
                }

                QsText {
                    text: procModel.count === 0 ? "Cargando…" : ""
                    visible: procModel.count === 0
                    color: window.textSec
                    font.family: "Inter"; font.pixelSize: 11
                    horizontalAlignment: Text.AlignHCenter
                    Layout.fillWidth: true
                    Layout.topMargin: 16
                }
            }
        }
    }
}
