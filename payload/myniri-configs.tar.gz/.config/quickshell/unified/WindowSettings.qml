// WindowSettings.qml - tokens centralizados de apariencia Honey/Quickshell.
import QtQuick

Item {
    id: root
    visible: false

    readonly property var theme: (typeof shellRoot !== "undefined" && shellRoot.themeConfig) ? shellRoot.themeConfig : ({})

    readonly property color accent: theme.accent || "#6fcdad"
    readonly property color accentWf: theme.accentWf || accent
    readonly property color accentBt: theme.accentBt || accent
    readonly property color border: theme.border || "#3a3a3a"
    readonly property color bgMain: theme.bgMain || "#801a1a1a"
    readonly property color bgCard: theme.bgCard || "#232323"
    readonly property color bgTile: theme.bgTile || "#2a2a2a"
    readonly property color bgActive: theme.bgActive || "#172232"
    readonly property color textPri: theme.textPri || "#f0eee8"
    readonly property color textSec: theme.textSec || "#918f88"
    readonly property color danger: theme.danger || "#e06c6c"
    readonly property color warning: theme.warning || "#e67e22"

    readonly property bool cornersEnabled: theme.cornersEnabled !== false
    readonly property int cornerRadius: theme.cornerRadius !== undefined ? theme.cornerRadius : 9
    readonly property int radiusWindow: cornersEnabled ? cornerRadius : 0
    readonly property int radiusCard: cornersEnabled ? Math.max(6, Math.min(12, cornerRadius)) : 0
    readonly property int radiusControl: cornersEnabled ? Math.max(5, Math.min(9, cornerRadius - 1)) : 0
    readonly property int radiusPill: 999

    readonly property bool blurEnabled: theme.blurEnabled !== false
    readonly property int blurRadius: theme.blurRadius !== undefined ? theme.blurRadius : 2
    readonly property bool animEnabled: theme.animationsEnabled !== false
    readonly property int animFast: Math.max(80, Math.round((theme.animationDuration || 250) * 0.55))
    readonly property int animNormal: theme.animationDuration || 250

    readonly property int borderWidth: 1
    readonly property int gapXs: 4
    readonly property int gapSm: 8
    readonly property int gapMd: 12
    readonly property int gapLg: 16
    readonly property int padSm: 10
    readonly property int padMd: 14
    readonly property int padLg: 20

    readonly property color accentSoft: alpha(accent, 0.16)
    readonly property color accentBorder: alpha(accent, 0.42)
    readonly property color hover: alpha(textPri, 0.07)
    readonly property color pressed: alpha(textPri, 0.11)
    readonly property color subtleBorder: alpha(textPri, 0.10)
    readonly property color scrim: "#66000000"

    function alpha(c, opacity) {
        return Qt.rgba(c.r, c.g, c.b, opacity)
    }

    function mix(a, b, amount) {
        let t = Math.max(0, Math.min(1, amount))
        return Qt.rgba(
            a.r + (b.r - a.r) * t,
            a.g + (b.g - a.g) * t,
            a.b + (b.b - a.b) * t,
            a.a + (b.a - a.a) * t
        )
    }

    function interactiveBg(active, hovered) {
        if (active) return accent
        return hovered ? hover : "transparent"
    }

    function interactiveBorder(active, focused) {
        if (active || focused) return accentBorder
        return border
    }

    function getContrastColor(c) {
        let luminance = 0.299 * c.r + 0.587 * c.g + 0.114 * c.b
        return luminance > 0.6 ? "#121212" : "#ffffff"
    }
}
