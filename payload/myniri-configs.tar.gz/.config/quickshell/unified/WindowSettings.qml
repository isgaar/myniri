// WindowSettings.qml — Control centralizado de esquinas y color de énfasis
import QtQuick

Item {
    id: root
    visible: false

    readonly property color accent: (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property bool cornersEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false
    readonly property int cornerRadius: (shellRoot.themeConfig && shellRoot.themeConfig.cornerRadius) !== undefined ? shellRoot.themeConfig.cornerRadius : 12
    readonly property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false
    readonly property int blurRadius: (shellRoot.themeConfig && shellRoot.themeConfig.blurRadius) !== undefined ? shellRoot.themeConfig.blurRadius : 7

    readonly property bool animEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
    readonly property color border: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    readonly property color bgMain: (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a"
    readonly property color bgCard: (shellRoot.themeConfig && shellRoot.themeConfig.bgCard) || "#232323"
    readonly property color bgTile: (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#2a2a2a"
    readonly property color textPri: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
    readonly property color textSec: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
    readonly property color danger: (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e06c6c"
    readonly property color warning: (shellRoot.themeConfig && shellRoot.themeConfig.warning) || "#e67e22"

    readonly property color accentBorder: Qt.rgba(accent.r, accent.g, accent.b, 0.4)

    function getContrastColor(c) {
        let luminance = 0.299 * c.r + 0.587 * c.g + 0.114 * c.b;
        return luminance > 0.6 ? "#121212" : "#ffffff";
    }
}
