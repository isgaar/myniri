// PowerDialog.qml — Menú de energía premium en QML
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

BasePopup {
    id: window

    anchors {
        top: true
        left: true
        right: false
    }
    margins.top: 40
    margins.left: window.anchorMargin

    property int anchorMargin: 8

    implicitWidth: 340
    implicitHeight: contentCol.implicitHeight + 24
    property int contentHeight: contentCol.implicitHeight + 24

    WlrLayershell.layer: WlrLayer.Overlay



    // Theme Colors
    readonly property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false
    readonly property color bgMain: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a";
        return Qt.color(raw);
    }
    readonly property color bgCard: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgCard) || "#232323";
        let base = Qt.color(raw);
        return blurEnabled ? Qt.rgba(base.r, base.g, base.b, 0.65) : base;
    }
    readonly property color border: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    readonly property color textPri: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
    readonly property color textSec: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
    readonly property color danger: (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e06c6c"
    readonly property color warning: (shellRoot.themeConfig && shellRoot.themeConfig.warning) || "#e67e22"
    readonly property color accent: (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property bool cornersEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false
    readonly property int cornerRadius: (shellRoot.themeConfig && shellRoot.themeConfig.cornerRadius) !== undefined ? shellRoot.themeConfig.cornerRadius : 12

    function toggle(x) {
        if (visible) {
            visible = false
        } else {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(8, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 8))
            }
            visible = true
        }
    }

    function open(x) {
        if (!visible) {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(8, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 8))
            }
            visible = true
        }
    }

    function close() {
        visible = false
    }

    onVisibleChanged: {
        if (visible) {
            contentRect.forceActiveFocus(Qt.MouseFocusReason)
            shellRoot.updateMakoPosition("power", "open", Math.round(window.implicitHeight + 55).toString())
        } else {
            shellRoot.updateMakoPosition("power", "closed")
        }
    }

    function runAction(commandArray) {
        window.close()
        Qt.createQmlObject(
            'import Quickshell.Io; Process { command: ' + JSON.stringify(commandArray) + '; running: true }',
            window
        )
    }

    Rectangle {
        id: contentRect
        anchors.fill: parent
        color: window.bgMain
        radius: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false ? (shellRoot.themeConfig.cornerRadius || 16) : 0
        border.color: window.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: window.close()

        // Close on clicking backdrop
        TapHandler {
            onTapped: window.close()
        }

        ColumnLayout {
            id: contentCol
            anchors { fill: parent; margins: 12 }
            spacing: 12

            QsText {
                text: "Opciones de Energía"
                color: window.textPri
                font.family: "Inter"
                font.pixelSize: 13
                font.weight: Font.DemiBold
                Layout.fillWidth: true
            }

            GridLayout {
                columns: 2
                columnSpacing: 8
                rowSpacing: 8
                Layout.fillWidth: true

                // 1. Bloquear
                Rectangle {
                    Layout.fillWidth: true
                    height: 50
                    radius: window.cornersEnabled ? Math.min(10, window.cornerRadius) : 0
                    color: window.bgCard
                    border.color: window.border
                    border.width: 1

                    RowLayout {
                        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                        spacing: 8

                        Rectangle {
                            width: 32; height: 32; radius: window.cornersEnabled ? 16 : 0
                            color: window.accent
                            QsText {
                                anchors.centerIn: parent
                                text: "\uf023" // fa-lock
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 13
                                color: "#ffffff"
                            }
                        }

                        QsText {
                            text: "Bloquear"
                            color: window.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Medium
                        }
                    }

                    HoverHandler { id: h1 }
                    Rectangle {
                        anchors.fill: parent; radius: parent.radius
                        color: h1.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                    }
                    TapHandler {
                        onTapped: window.runAction(["bash", "-c", "swaylock -f || hyprlock || loginctl lock-session"])
                    }
                }

                // 2. Suspender
                Rectangle {
                    Layout.fillWidth: true
                    height: 50
                    radius: window.cornersEnabled ? Math.min(10, window.cornerRadius) : 0
                    color: window.bgCard
                    border.color: window.border
                    border.width: 1

                    RowLayout {
                        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                        spacing: 8

                        Rectangle {
                            width: 32; height: 32; radius: window.cornersEnabled ? 16 : 0
                            color: window.accent // Suspender
                            QsText {
                                anchors.centerIn: parent
                                text: "\uf186" // fa-moon
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 13
                                color: "#ffffff"
                            }
                        }

                        QsText {
                            text: "Suspender"
                            color: window.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Medium
                        }
                    }

                    HoverHandler { id: h2 }
                    Rectangle {
                        anchors.fill: parent; radius: parent.radius
                        color: h2.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                    }
                    TapHandler {
                        onTapped: window.runAction(["systemctl", "suspend"])
                    }
                }

                // 3. Cerrar Sesión
                Rectangle {
                    Layout.fillWidth: true
                    height: 50
                    radius: window.cornersEnabled ? Math.min(10, window.cornerRadius) : 0
                    color: window.bgCard
                    border.color: window.border
                    border.width: 1

                    RowLayout {
                        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                        spacing: 8

                        Rectangle {
                            width: 32; height: 32; radius: window.cornersEnabled ? 16 : 0
                            color: window.accent // Cerrar sesion
                            QsText {
                                anchors.centerIn: parent
                                text: "\uf2f5" // fa-arrow-right-from-bracket
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 13
                                color: "#ffffff"
                            }
                        }

                        QsText {
                            text: "Cerrar sesión"
                            color: window.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Medium
                        }
                    }

                    HoverHandler { id: h3 }
                    Rectangle {
                        anchors.fill: parent; radius: parent.radius
                        color: h3.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                    }
                    TapHandler {
                        onTapped: window.runAction(["bash", "-c", "swaymsg exit || hyprctl dispatch exit || loginctl terminate-session $XDG_SESSION_ID"])
                    }
                }

                // 4. Reiniciar Sway
                Rectangle {
                    Layout.fillWidth: true
                    height: 50
                    radius: window.cornersEnabled ? Math.min(10, window.cornerRadius) : 0
                    color: window.bgCard
                    border.color: window.border
                    border.width: 1

                    RowLayout {
                        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                        spacing: 8

                        Rectangle {
                            width: 32; height: 32; radius: window.cornersEnabled ? 16 : 0
                            color: window.accent // Reiniciar Sway
                            QsText {
                                anchors.centerIn: parent
                                text: "\uf01e" // fa-rotate
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 13
                                color: "#ffffff"
                            }
                        }

                        QsText {
                            text: "Reiniciar Sway"
                            color: window.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Medium
                        }
                    }

                    HoverHandler { id: h4 }
                    Rectangle {
                        anchors.fill: parent; radius: parent.radius
                        color: h4.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                    }
                    TapHandler {
                        onTapped: window.runAction(["bash", "-c", "swaymsg restart || hyprctl reload"])
                    }
                }

                // 5. Reiniciar (Reboot)
                Rectangle {
                    Layout.fillWidth: true
                    height: 50
                    radius: window.cornersEnabled ? Math.min(10, window.cornerRadius) : 0
                    color: window.bgCard
                    border.color: window.border
                    border.width: 1

                    RowLayout {
                        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                        spacing: 8

                        Rectangle {
                            width: 32; height: 32; radius: window.cornersEnabled ? 16 : 0
                            color: window.accent // Reiniciar
                            QsText {
                                anchors.centerIn: parent
                                text: "\uf021" // fa-rotate-right
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 13
                                color: "#ffffff"
                            }
                        }

                        QsText {
                            text: "Reiniciar"
                            color: window.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Medium
                        }
                    }

                    HoverHandler { id: h5 }
                    Rectangle {
                        anchors.fill: parent; radius: parent.radius
                        color: h5.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                    }
                    TapHandler {
                        onTapped: window.runAction(["systemctl", "reboot"])
                    }
                }

                // 6. Apagar (Poweroff)
                Rectangle {
                    Layout.fillWidth: true
                    height: 50
                    radius: window.cornersEnabled ? Math.min(10, window.cornerRadius) : 0
                    color: window.bgCard
                    border.color: window.border
                    border.width: 1

                    RowLayout {
                        anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                        spacing: 8

                        Rectangle {
                            width: 32; height: 32; radius: window.cornersEnabled ? 16 : 0
                            color: window.accent // Apagar
                            QsText {
                                anchors.centerIn: parent
                                text: "\uf011" // fa-power-off
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 13
                                color: "#ffffff"
                            }
                        }

                        QsText {
                            text: "Apagar"
                            color: window.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Medium
                        }
                    }

                    HoverHandler { id: h6 }
                    Rectangle {
                        anchors.fill: parent; radius: parent.radius
                        color: h6.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent"
                    }
                    TapHandler {
                        onTapped: window.runAction(["systemctl", "poweroff"])
                    }
                }
            }
        }
    }
}
