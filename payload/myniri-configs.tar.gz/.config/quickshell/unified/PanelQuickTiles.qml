// PanelQuickTiles.qml — Zona 3: tiles rapidos WiFi + Bluetooth
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

Item {
    id: root
    implicitHeight: 68

    property color bgCard
    property color bgTile
    property color border
    property color textPri
    property color textSec
    property color accentWf
    property color accentBt

    property string activeExpandedList: "none"
    signal expandListRequested(string listName)
    readonly property bool isDark: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "dark"

    property string wifiSsid: "..."
    property string wifiSignal: ""
    property bool wifiEnabled: false

    // Pausa los pollers cuando el panel está cerrado (ahorra CPU)
    property bool panelVisible: false

    Process {
        id: wifiPoller
        command: ["bash", "-c", [
            "state=$(nmcli -t -f WIFI radio 2>/dev/null);",
            "echo \"STATE:$state\";",
            "nmcli --escape no -t -f active,ssid,signal dev wifi list --rescan no 2>/dev/null |",
            "awk -F: '$1==\"yes\" || $1==\"si\" || $1==\"sí\" {sig=$NF; ssid=\"\"; for(i=2;i<=NF-1;i++) ssid=ssid (i>2?\":\":\"\") $i; print \"ACTIVE:\"ssid\"|\"sig; found=1; exit} END {if(!found) print \"ACTIVE:|\"}'"
        ].join(" ")]
        running: root.panelVisible
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("STATE:")) {
                    let state = line.substring(6)
                    root.wifiEnabled = state === "enabled" || state === "activado"
                    if (!root.wifiEnabled) {
                        root.wifiSsid = "Desactivado"
                        root.wifiSignal = "Wi-Fi apagado"
                    }
                    return
                }
                if (line.startsWith("ACTIVE:")) {
                    let payload = line.substring(7)
                    let parts = payload.split("|")
                    if (parts.length >= 2 && parts[0] !== "") {
                        root.wifiSsid = parts[0]
                        root.wifiSignal = parts[1] + "%"
                    } else if (root.wifiEnabled) {
                        root.wifiSsid = "Sin conexion"
                        root.wifiSignal = "Wi-Fi encendido"
                    }
                }
            }
        }
    }

    function refreshWifi() {
        wifiPoller.running = false
        Qt.callLater(() => wifiPoller.running = true)
    }

    Timer {
        interval: 6000
        repeat: true
        running: root.panelVisible
        onTriggered: root.refreshWifi()
    }

    property bool btEnabled: false
    property string btLabel: "Apagado"
    property string btTitle: "Bluetooth"

    function refreshBluetooth() {
        btRefresh.running = false
        Qt.callLater(() => btRefresh.running = true)
    }

    Timer {
        id: btRefreshDelay
        interval: 350
        repeat: false
        onTriggered: root.refreshBluetooth()
    }

    Process {
        id: btRefresh
        command: ["bash", "-c",
            "if bluetoothctl show 2>/dev/null | grep -q 'Powered: yes'; then echo POWERED:yes; bluetoothctl devices Connected 2>/dev/null | head -1 | sed 's/^Device [^ ]* /DEVICE:/'; else echo POWERED:no; fi"]
        running: root.panelVisible
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line === "POWERED:yes") {
                    root.btEnabled = true
                    root.btTitle = "Bluetooth"
                    root.btLabel = "Encendido"
                } else if (line === "POWERED:no") {
                    root.btEnabled = false
                    root.btTitle = "Desactivado"
                    root.btLabel = "Apagado"
                } else if (line.startsWith("DEVICE:")) {
                    root.btTitle = line.substring(7)
                    root.btLabel = "Conectado"
                }
            }
        }
    }

    Process {
        id: btMenu
        command: ["bash", "-lc", "~/scripts/bt_menu.sh"]
        running: false
        onRunningChanged: if (!running) btRefreshDelay.restart()
    }

    RowLayout {
        anchors.fill: parent
        spacing: 8

        // ── Tile WiFi ───────────────────────────────────────────
        Rectangle {
            id: wifiTileRect
            Layout.fillWidth: true
            height: 68
            radius: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false ? (shellRoot.themeConfig.cornerRadius || 12) : 0
            color: root.bgCard
            border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
            border.width: 1

            RowLayout {
                anchors.fill: parent
                spacing: 0

                // Area Principal
                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    Rectangle {
                        anchors.fill: parent
                        color: wfHover.hovered ? Qt.rgba(1, 1, 1, 0.03) : "transparent"
                        radius: wifiTileRect.radius
                        Rectangle {
                            anchors.right: parent.right; anchors.top: parent.top; anchors.bottom: parent.bottom
                            width: 12; color: parent.color
                        }
                    }

                    RowLayout {
                        anchors { fill: parent; margins: 12; rightMargin: 6 }
                        spacing: 10

                        Rectangle {
                            width: 36; height: 36; radius: 18
                            color: root.wifiEnabled ? root.accentWf : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)
                            Behavior on color { ColorAnimation { duration: 150 } }

                            QsText {
                                anchors.centerIn: parent
                                text: "\uf1eb"
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 16
                                color: root.wifiEnabled ? "#ffffff" : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                            }
                        }

                        Column {
                            spacing: 2
                            Layout.fillWidth: true

                            QsText {
                                text: root.wifiEnabled ? root.wifiSsid : "Desactivado"
                                color: root.textPri
                                font.family: "Inter"
                                font.pixelSize: 13
                                font.weight: Font.DemiBold
                                font.hintingPreference: Font.PreferNoHinting
                                renderType: Text.NativeRendering
                                elide: Text.ElideRight
                                width: parent.width
                            }
                            QsText {
                                text: root.wifiEnabled ? root.wifiSignal : "Wi-Fi apagado"
                                color: root.wifiEnabled ? root.textSec : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.45)
                                font.family: "Inter"
                                font.pixelSize: 11
                                font.weight: Font.Medium
                                font.hintingPreference: Font.PreferNoHinting
                                renderType: Text.NativeRendering
                            }
                        }
                    }

                    HoverHandler { id: wfHover }
                    TapHandler {
                        onTapped: {
                            let cmd = root.wifiEnabled
                                ? ["nmcli", "radio", "wifi", "off"]
                                : ["nmcli", "radio", "wifi", "on"]
                            Qt.createQmlObject(
                                'import Quickshell.Io; Process { command: ' +
                                JSON.stringify(cmd) + '; running: true }', root)
                            root.wifiEnabled = !root.wifiEnabled
                        }
                    }
                }

                // Separador
                Rectangle {
                    width: 1
                    Layout.fillHeight: true
                    color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
                }

                // Boton secundario
                Item {
                    width: 44
                    Layout.fillHeight: true

                    Rectangle {
                        anchors.fill: parent
                        color: wfExpandHover.hovered ? Qt.rgba(1, 1, 1, 0.06) : "transparent"
                        radius: wifiTileRect.radius
                        Rectangle {
                            anchors.left: parent.left; anchors.top: parent.top; anchors.bottom: parent.bottom
                            width: 12; color: parent.color
                        }
                    }

                    QsText {
                        anchors.centerIn: parent
                        text: root.activeExpandedList === "wifi" ? "\uf107" : "\uf105"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 16
                        color: root.textPri
                    }

                    HoverHandler { id: wfExpandHover }
                    TapHandler {
                        onTapped: root.expandListRequested("wifi")
                    }
                }
            }
        }

        // ── Tile Bluetooth ──────────────────────────────────────
        Rectangle {
            id: btTileRect
            Layout.fillWidth: true
            height: 68
            radius: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false ? (shellRoot.themeConfig.cornerRadius || 12) : 0
            color: root.bgCard
            border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
            border.width: 1

            RowLayout {
                anchors.fill: parent
                spacing: 0

                // Area Principal
                Item {
                    Layout.fillWidth: true
                    Layout.fillHeight: true

                    Rectangle {
                        anchors.fill: parent
                        color: btHover.hovered ? Qt.rgba(1, 1, 1, 0.03) : "transparent"
                        radius: btTileRect.radius
                        Rectangle {
                            anchors.right: parent.right; anchors.top: parent.top; anchors.bottom: parent.bottom
                            width: 12; color: parent.color
                        }
                    }

                    RowLayout {
                        anchors { fill: parent; margins: 12; rightMargin: 6 }
                        spacing: 10

                        Rectangle {
                            width: 36; height: 36; radius: 18
                            color: root.btEnabled ? root.accentBt : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)
                            Behavior on color { ColorAnimation { duration: 150 } }

                            QsText {
                                anchors.centerIn: parent
                                text: "\uf294"
                                font.family: "Font Awesome 6 Brands"
                                font.pixelSize: 16
                                color: root.btEnabled ? "#ffffff" : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                            }
                        }

                        Column {
                            spacing: 2
                            Layout.fillWidth: true

                            QsText {
                                text: root.btTitle
                                color: root.textPri
                                font.family: "Inter"
                                font.pixelSize: 13
                                font.weight: Font.DemiBold
                                font.hintingPreference: Font.PreferNoHinting
                                renderType: Text.NativeRendering
                                elide: Text.ElideRight
                                width: parent.width
                            }
                            QsText {
                                text: root.btLabel
                                color: root.btEnabled ? root.textSec : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.45)
                                font.family: "Inter"
                                font.pixelSize: 11
                                font.weight: Font.Medium
                                font.hintingPreference: Font.PreferNoHinting
                                renderType: Text.NativeRendering
                            }
                        }
                    }

                    HoverHandler { id: btHover }
                    TapHandler {
                        onTapped: {
                            let cmd = root.btEnabled
                                ? ["bluetoothctl", "power", "off"]
                                : ["bluetoothctl", "power", "on"]
                            Qt.createQmlObject(
                                'import Quickshell.Io; Process { command: ' +
                                JSON.stringify(cmd) + '; running: true }', root)
                            root.btEnabled = !root.btEnabled
                            btRefreshDelay.restart()
                        }
                    }
                }

                // Separador
                Rectangle {
                    width: 1
                    Layout.fillHeight: true
                    color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
                }

                // Boton secundario
                Item {
                    width: 44
                    Layout.fillHeight: true

                    Rectangle {
                        anchors.fill: parent
                        color: btExpandHover.hovered ? Qt.rgba(1, 1, 1, 0.06) : "transparent"
                        radius: btTileRect.radius
                        Rectangle {
                            anchors.left: parent.left; anchors.top: parent.top; anchors.bottom: parent.bottom
                            width: 12; color: parent.color
                        }
                    }

                    QsText {
                        anchors.centerIn: parent
                        text: root.activeExpandedList === "bluetooth" ? "\uf107" : "\uf105"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 16
                        color: root.textPri
                    }

                    HoverHandler { id: btExpandHover }
                    TapHandler {
                        onTapped: root.expandListRequested("bluetooth")
                    }
                }
            }
        }
    }
}
