import QtQuick
import QtQuick.Controls

Item {
    id: control

    property bool checked: false
    property color checkedColor: (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    property color uncheckedColor: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    property color knobColor: "#ffffff"

    signal toggled()

    implicitWidth: 40
    implicitHeight: 22

    property bool hovered: false

    Rectangle {
        id: track
        anchors.fill: parent
        radius: height / 2
        
        // Solid track background for maximum contrast against light/dark cards
        color: control.checked 
            ? control.checkedColor 
            : (control.hovered ? Qt.rgba(control.uncheckedColor.r, control.uncheckedColor.g, control.uncheckedColor.b, 1.0) : Qt.rgba(control.uncheckedColor.r, control.uncheckedColor.g, control.uncheckedColor.b, 0.85))

        // No border for a cleaner, modern pill switch aesthetic
        border.width: 0

        Behavior on color {
            ColorAnimation { duration: 150; easing.type: Easing.OutQuad }
        }

        Rectangle {
            id: knob
            width: parent.height - 4
            height: parent.height - 4
            radius: height / 2
            y: 2
            
            x: control.checked ? parent.width - width - 2 : 2
            color: control.knobColor

            // Modern subtle shadow
            layer.enabled: true
            
            // Dynamic position transition with spring overshoot
            Behavior on x {
                enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
                NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: 1.15 }
            }

            // Knob interactive scaling feedback
            scale: control.hovered ? 1.06 : 1.0
            Behavior on scale {
                NumberAnimation { duration: 120; easing.type: Easing.OutQuad }
            }
        }
    }

    HoverHandler {
        id: hoverHandler
        onHoveredChanged: control.hovered = hovered
    }

    TapHandler {
        onTapped: {
            control.toggled();
        }
    }
}
