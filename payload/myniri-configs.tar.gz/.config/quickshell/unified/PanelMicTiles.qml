// PanelMicTiles.qml — Zona de tiles para micrófonos (fuentes de audio)
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

Item {
    id: root

    WindowSettings { id: ws }
    implicitHeight: 60

    property color bgCard
    property color bgTile
    property color border
    property color textPri
    property color textSec
    property color accent
    property bool panelVisible: false
    readonly property bool isDark: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "dark"

    ListModel { id: sourceModel }
    property string defaultSource: ""

    Process {
        command: ["bash", "-c",
            "default=$(pactl get-default-source); echo \"DEFAULT:$default\"; pactl list sources short | grep -v '\\.monitor' | awk '{print $1\":\"$2}'"]
        running: root.panelVisible
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("DEFAULT:")) {
                    root.defaultSource = line.substring(8)
                    return
                }
                let parts = line.split(":")
                if (parts.length < 2) return
                let id   = parts[0]
                let name = parts.slice(1).join(":")
                let friendly = root.friendlyName(name)
                for (let i = 0; i < sourceModel.count; i++)
                    if (sourceModel.get(i).name === name) return
                sourceModel.append({ sourceId: id, name: name, label: friendly })
            }
        }
    }

    function friendlyName(n) {
        let nl = n.toLowerCase()
        if (nl.includes("bluez") || nl.includes("bluetooth")) return "Mic. Bluetooth"
        if (nl.includes("usb")) return "Mic. USB"
        if (nl.includes("analog") || nl.includes("pci")) return "Micrófono Integrado"
        return n.split(".")[0]
    }

    Row {
        anchors.fill: parent
        spacing: 8

        Repeater {
            model: sourceModel

            delegate: Rectangle {
                width: (root.width - (sourceModel.count - 1) * 8) / Math.max(sourceModel.count, 1)
                height: 60
                radius: ws.cornersEnabled ? ws.cornerRadius : 0
                color: root.bgCard
                border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
                border.width: 1
                activeFocusOnTab: false
                focus: false

                RowLayout {
                    anchors { fill: parent; margins: 10 }
                    spacing: 8

                    Rectangle {
                        width: 32; height: 32; radius: 16
                        color: model.name === root.defaultSource ? root.accent : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)

                        QsText {
                            anchors.centerIn: parent
                            text: "\uf130" // Icono de micrófono
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 13
                            color: model.name === root.defaultSource ? "#ffffff" : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                        }
                    }

                    Column {
                        spacing: 2
                        Layout.fillWidth: true

                        QsText {
                            text: model.label
                            color: root.textPri
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            elide: Text.ElideRight
                            width: parent.width
                        }
                        QsText {
                            text: model.name === root.defaultSource ? "Activo" : ""
                            color: root.textSec
                            font.pixelSize: 10
                        }
                    }
                }

                HoverHandler { id: sourceHover }
                Rectangle {
                    anchors.fill: parent; radius: parent.radius
                    color: sourceHover.hovered ? Qt.rgba(1, 1, 1, 0.03) : "transparent"
                }

                TapHandler {
                    onTapped: {
                        let sid = model.sourceId
                        let sname = model.name
                        let cmd = ["bash", "-c",
                            "pactl set-default-source " + sid +
                            "; pactl list source-outputs short | awk '{print $1}' | xargs -r -I{} pactl move-source-output {} " + sid]
                        Qt.createQmlObject(
                            'import Quickshell.Io; Process { command: ' +
                            JSON.stringify(cmd) + '; running: true }', root)
                        root.defaultSource = sname
                    }
                }
            }
        }

        Item {
            visible: sourceModel.count === 0
            width: root.width; height: 60
            QsText {
                anchors.centerIn: parent
                text: "Sin micrófonos"
                color: root.textSec
                font.pixelSize: 12
            }
        }
    }
}
