// ~/.config/quickshell/unified/EjectMenu.qml
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Quickshell.Io

ColumnLayout {
    id: root

    WindowSettings { id: ws }
    spacing: 8
    signal closeRequested()

    property color bgCard: "#232323"
    property color border: "#3a3a3a"
    property color textPri: "#e8e6e0"
    property color textSec: "#888680"
    property color accent: "#5aa7de"
    property color danger: "#e06c6c"

    property color accentGn: "#5db06a"

    function loadDevices() {
        deviceLoader.running = false
        deviceLoader.running = true
    }

    function loadApps() {
        loadDevices()
    }

    Process {
        id: deviceLoader
        command: ["bash", "-c", "/home/ismael/scripts/get_eject_devices_json.sh"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let devices = JSON.parse(data)
                    devicesModel.clear()
                    for (let i = 0; i < devices.length; i++) {
                        devicesModel.append(devices[i])
                    }
                } catch(e) {
                    console.log("Error parsing JSON:", e)
                }
            }
        }
    }

    Timer {
        id: reloadTimer
        interval: 1500
        repeat: false
        running: false
        onTriggered: {
            root.loadDevices()
        }
    }

    QsText {
        text: "Dispositivos Extraíbles"
        color: root.textPri
        font.family: "Inter"
        font.pixelSize: 14
        font.weight: Font.Bold
        Layout.bottomMargin: 8
    }

    ListModel {
        id: devicesModel
    }

    Repeater {
        model: devicesModel
        delegate: Rectangle {
            id: delegateItem
            Layout.fillWidth: true
            height: 44
            color: root.bgCard
            border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
            border.width: 1
            radius: ws.cornersEnabled ? ws.cornerRadius : 0

            property string mountpointResult: ""

            Timer {
                id: mountRefreshTimer
                interval: 800
                repeat: false
                running: false
                onTriggered: {
                    root.loadApps()
                }
            }

            RowLayout {
                anchors.fill: parent
                anchors.margins: 8
                spacing: 12

                Rectangle {
                    width: 28; height: 28; radius: 14
                    color: root.accent
                    Layout.alignment: Qt.AlignVCenter

                    QsText {
                        anchors.centerIn: parent
                        text: (model.name.toLowerCase().indexOf("sd") !== -1) ? "\uf0a0" : "\uf287"
                        font.family: (model.name.toLowerCase().indexOf("sd") !== -1) ? "Font Awesome 6 Free" : "Font Awesome 6 Brands"
                        color: "#ffffff"
                        font.pixelSize: 13
                    }
                }

                QsText {
                    text: model.name
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 13
                    font.weight: Font.DemiBold
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }

                QsText {
                    text: model.size
                    color: root.textSec
                    font.family: "Inter"
                    font.pixelSize: 11
                    font.weight: Font.Normal
                    Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
                }

                // Botones de acción condicionales
                // Caso A — mountpoint es null, vacío o la cadena "null": mostrar botón de montar
                Rectangle {
                    visible: model.mountpoint === null || model.mountpoint === "" || model.mountpoint === "null"
                    width: 30; height: 30; radius: 6
                    color: mountHover.hovered ? root.accentGn : "transparent"
                    QsText {
                        anchors.centerIn: parent
                        text: "\uf0a0" // hdd / mount icon
                        font.family: "Font Awesome 6 Free"
                        color: mountHover.hovered ? "#ffffff" : root.accentGn
                        font.pixelSize: 12
                    }
                    HoverHandler { id: mountHover }
                    TapHandler {
                        onTapped: {
                            delegateItem.mountpointResult = ""
                            Qt.createQmlObject('import Quickshell.Io; Process {
                                command: ["bash", "/home/ismael/scripts/mount_device.sh", "' + model.device + '"];
                                running: true;
                                stdout: SplitParser {
                                    onRead: data => {
                                        delegateItem.mountpointResult = data.trim();
                                    }
                                }
                                onExited: {
                                    if (exitCode === 0) {
                                        Qt.createQmlObject(\'import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/open_files.sh", "\' + delegateItem.mountpointResult + \'"]; running: true }\', delegateItem);
                                    }
                                }
                            }', delegateItem)
                            mountRefreshTimer.restart()
                        }
                    }
                }

                // Caso B — mountpoint tiene valor real: mostrar dos botones (abrir explorador + expulsar)
                RowLayout {
                    visible: !(model.mountpoint === null || model.mountpoint === "" || model.mountpoint === "null")
                    spacing: 4

                    // Botón abrir explorador
                    Rectangle {
                        width: 30; height: 30; radius: 6
                        color: openHover.hovered ? root.accent : "transparent"
                        QsText {
                            anchors.centerIn: parent
                            text: "\uf07c" // folder-open
                            font.family: "Font Awesome 6 Free"
                            color: openHover.hovered ? "#ffffff" : root.accent
                            font.pixelSize: 12
                        }
                        HoverHandler { id: openHover }
                        TapHandler {
                            onTapped: {
                                Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/open_files.sh", "' + model.mountpoint + '"]; running: true }', delegateItem)
                            }
                        }
                    }

                    // Botón expulsar
                    Rectangle {
                        width: 30; height: 30; radius: 6
                        color: ejectHover.hovered ? root.danger : "transparent"
                        QsText {
                            anchors.centerIn: parent
                            text: "\uf052" // fa-eject
                            font.family: "Font Awesome 6 Free"
                            color: ejectHover.hovered ? "#ffffff" : root.danger
                            font.pixelSize: 12
                        }
                        HoverHandler { id: ejectHover }
                        TapHandler {
                            onTapped: {
                                Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/eject_device.sh", "' + model.device + '"]; running: true }', delegateItem)
                                root.closeRequested()
                                reloadTimer.restart()
                            }
                        }
                    }
                }
            }
        }
    }

    QsText {
        visible: devicesModel.count === 0
        text: "No hay dispositivos para expulsar"
        color: root.textSec
        font.family: "Inter"
        font.pixelSize: 13
        Layout.alignment: Qt.AlignHCenter
        Layout.topMargin: 10
        Layout.bottomMargin: 10
    }
}
