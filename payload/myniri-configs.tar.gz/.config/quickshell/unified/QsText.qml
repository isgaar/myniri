import QtQuick

Text {
    property bool smoothText: true
    renderType: Text.NativeRendering
    renderTypeQuality: Text.VeryHighRenderTypeQuality
    antialiasing: true
    style: Text.Normal
    styleColor: "transparent"
    font.family: "Inter"
    font.kerning: true
    font.preferShaping: true
    font.preferTypoLineMetrics: true
    font.hintingPreference: Font.PreferNoHinting
    layer.enabled: false
}
