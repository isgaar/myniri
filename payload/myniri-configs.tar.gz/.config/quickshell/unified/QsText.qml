import QtQuick

Text {
    property bool smoothText: false
    renderType: Text.NativeRendering
    style: smoothText ? Text.Normal : Text.Outline
    styleColor: "transparent"
    font.hintingPreference: smoothText ? Font.PreferDefaultHinting : Font.PreferNoHinting
    layer.enabled: smoothText
}
