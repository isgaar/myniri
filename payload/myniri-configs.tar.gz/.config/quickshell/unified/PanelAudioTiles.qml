// PanelAudioTiles.qml — Zona 5: tiles de dispositivos de audio
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

Item {
    id: root

    WindowSettings { id: ws }
    implicitHeight: 60

    property color bgCard
    property color bgTile
    property color border
    property color textPri
    property color textSec
    property color accent
    property bool panelVisible: false
    readonly property bool isDark: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "dark"

    ListModel { id: sinkModel }
    property string defaultSink: ""

    Process {
        command: ["bash", "-c",
            "default=$(pactl get-default-sink); echo \"DEFAULT:$default\"; pactl list sinks short | awk '{print $1\":\"$2}'"]
        running: root.panelVisible
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("DEFAULT:")) {
                    root.defaultSink = line.substring(8)
                    return
                }
                let parts = line.split(":")
                if (parts.length < 2) return
                let id   = parts[0]
                let name = parts.slice(1).join(":")
                let friendly = root.friendlyName(name)
                let isMono = name.toLowerCase().includes("mono")
                for (let i = 0; i < sinkModel.count; i++)
                    if (sinkModel.get(i).name === name) return
                sinkModel.append({ sinkId: id, name: name, label: friendly, mono: isMono })
            }
        }
    }

    function friendlyName(n) {
        let nl = n.toLowerCase()
        if (nl.includes("jbl") || nl.includes("harman")) return "JBL Tune 520C"
        if (nl.includes("bluetooth") || nl.includes("bluez")) return "Bluetooth"
        if (nl.includes("hdmi") || nl.includes("dp")) return "HDMI"
        if (nl.includes("analog") || nl.includes("pci")) return "Bocinas"
        return n.split(".")[0]
    }

    Row {
        anchors.fill: parent
        spacing: 8

        Repeater {
            model: sinkModel

            delegate: Rectangle {
                width: (root.width - (sinkModel.count - 1) * 8) / Math.max(sinkModel.count, 1)
                height: 60
                radius: ws.cornersEnabled ? ws.cornerRadius : 0
                color: root.bgCard
                border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
                border.width: 1
                activeFocusOnTab: false
                focus: false

                RowLayout {
                    anchors { fill: parent; margins: 10 }
                    spacing: 8

                    Rectangle {
                        width: 32; height: 32; radius: 16
                        color: model.name === root.defaultSink ? root.accent : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)

                        QsText {
                            anchors.centerIn: parent
                            text: model.mono ? "\uf130" : "\uf028"
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 13
                            color: model.name === root.defaultSink ? "#ffffff" : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                        }
                    }

                    Column {
                        spacing: 2
                        Layout.fillWidth: true

                        QsText {
                            text: model.label + (model.mono ? " Mono" : " Estereo")
                            color: root.textPri
                            font.pixelSize: 11
                            font.weight: Font.DemiBold
                            elide: Text.ElideRight
                            width: parent.width
                        }
                        QsText {
                            text: model.name === root.defaultSink ? "Activo" : ""
                            color: root.textSec
                            font.pixelSize: 10
                        }
                    }
                }

                HoverHandler { id: sinkHover }
                Rectangle {
                    anchors.fill: parent; radius: parent.radius
                    color: sinkHover.hovered ? Qt.rgba(1, 1, 1, 0.03) : "transparent"
                }

                TapHandler {
                    onTapped: {
                        let sid = model.sinkId
                        let sname = model.name
                        let cmd = ["bash", "-c",
                            "pactl set-default-sink " + sid +
                            "; pactl list sink-inputs short | awk '{print $1}' | xargs -r -I{} pactl move-sink-input {} " + sid]
                        Qt.createQmlObject(
                            'import Quickshell.Io; Process { command: ' +
                            JSON.stringify(cmd) + '; running: true }', root)
                        root.defaultSink = sname
                    }
                }
            }
        }

        Item {
            visible: sinkModel.count === 0
            width: root.width; height: 60
            QsText {
                anchors.centerIn: parent
                text: "Sin dispositivos de audio"
                color: root.textSec
                font.pixelSize: 12
            }
        }
    }
}
