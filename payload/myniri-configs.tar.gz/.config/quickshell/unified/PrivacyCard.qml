// PrivacyCard.qml — Active privacy sessions for the control panel.
import QtQuick
import QtQuick.Layouts

Item {
    id: root

    WindowSettings { id: ws }

    property color bgCard
    property color bgTile
    property color border
    property color textPri
    property color textSec
    property color accent
    property color danger
    property color warning

    property var monitor
    property string activeExpandedList: "none"
    signal expandListRequested(string listName)

    readonly property var items: monitor ? monitor.activeList : []
    readonly property bool hasItems: items.length > 0
    readonly property bool expanded: activeExpandedList === "privacy"
    readonly property color localTone: danger
    readonly property color remoteTone: warning
    readonly property color severityTone: monitor && monitor.localActive ? localTone : remoteTone
    property int timeTick: 0

    visible: implicitHeight > 0
    clip: true
    opacity: hasItems ? 1 : 0
    implicitHeight: hasItems ? card.implicitHeight : 0
    Layout.preferredHeight: implicitHeight
    Layout.minimumHeight: 0

    Behavior on implicitHeight {
        NumberAnimation {
            duration: ws.animEnabled ? ws.animNormal : 0
            easing.type: Easing.OutCubic
        }
    }
    Behavior on opacity {
        NumberAnimation {
            duration: ws.animEnabled ? ws.animFast : 0
            easing.type: Easing.OutQuad
        }
    }

    function typeIcon(typeName) {
        if (typeName === "camera") return "\uf030"
        if (typeName === "mic") return "\uf130"
        if (typeName === "screen") return "\uf108"
        return "\uf120"
    }

    function typeTone(typeName) {
        return typeName === "remote" ? remoteTone : localTone
    }

    function relativeTime(ts) {
        let elapsed = Math.max(0, Date.now() - ts)
        if (elapsed < 45000) return "ahora"
        let mins = Math.max(1, Math.floor(elapsed / 60000))
        if (mins < 60) return mins + " min"
        return Math.floor(mins / 60) + " h"
    }

    Timer {
        interval: 30000
        repeat: true
        running: root.hasItems
        onTriggered: root.timeTick++
    }

    Rectangle {
        id: card
        width: parent.width
        implicitHeight: content.implicitHeight + 24
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        color: root.bgCard
        border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
        border.width: 1

        ColumnLayout {
            id: content
            anchors {
                left: parent.left
                right: parent.right
                top: parent.top
                margins: 12
            }
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Rectangle {
                    width: 34
                    height: 34
                    radius: 17
                    color: Qt.rgba(root.severityTone.r, root.severityTone.g, root.severityTone.b, 0.18)
                    border.color: Qt.rgba(root.severityTone.r, root.severityTone.g, root.severityTone.b, 0.45)
                    border.width: 1

                    QsText {
                        anchors.centerIn: parent
                        text: root.monitor && root.monitor.remoteActive && !root.monitor.localActive ? "\uf120" : "\uf06e"
                        color: root.severityTone
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 14
                        font.weight: Font.Black
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1

                    QsText {
                        text: "Privacidad"
                        color: root.textPri
                        font.family: "Inter"
                        font.pixelSize: 13
                        font.weight: Font.DemiBold
                        renderType: Text.NativeRendering
                    }

                    QsText {
                        text: root.monitor && root.monitor.localActive ? "Captura local activa" : "Sesión remota activa"
                        color: root.textSec
                        font.family: "Inter"
                        font.pixelSize: 11
                        font.weight: Font.Medium
                        renderType: Text.NativeRendering
                    }
                }

                Rectangle {
                    height: 24
                    implicitWidth: countText.implicitWidth + 18
                    radius: 12
                    color: Qt.rgba(root.severityTone.r, root.severityTone.g, root.severityTone.b, 0.18)
                    border.color: Qt.rgba(root.severityTone.r, root.severityTone.g, root.severityTone.b, 0.45)
                    border.width: 1

                    QsText {
                        id: countText
                        anchors.centerIn: parent
                        text: root.items.length + (root.items.length === 1 ? " activo" : " activos")
                        color: root.textPri
                        font.family: "Inter"
                        font.pixelSize: 11
                        font.weight: Font.DemiBold
                        renderType: Text.NativeRendering
                    }
                }

                Item {
                    width: 28
                    height: 28

                    Rectangle {
                        anchors.fill: parent
                        radius: ws.cornersEnabled ? ws.radiusControl : 0
                        color: expandHover.hovered ? Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06) : "transparent"
                    }

                    QsText {
                        anchors.centerIn: parent
                        text: root.expanded ? "\uf107" : "\uf105"
                        color: root.textPri
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 13
                    }

                    HoverHandler { id: expandHover }
                    TapHandler { onTapped: root.expandListRequested("privacy") }
                }
            }

            Repeater {
                id: rowsRepeater
                model: root.items

                delegate: Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: detailCol.implicitHeight + 16
                    radius: ws.cornersEnabled ? ws.radiusControl : 0
                    color: Qt.rgba(root.bgTile.r, root.bgTile.g, root.bgTile.b, 0.72)
                    border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.22)
                    border.width: 1

                    RowLayout {
                        anchors {
                            fill: parent
                            leftMargin: 10
                            rightMargin: 10
                        }
                        spacing: 10

                        Rectangle {
                            width: 28
                            height: 28
                            radius: 14
                            color: Qt.rgba(root.typeTone(modelData.type).r, root.typeTone(modelData.type).g, root.typeTone(modelData.type).b, 0.18)

                            QsText {
                                anchors.centerIn: parent
                                text: root.typeIcon(modelData.type)
                                color: root.typeTone(modelData.type)
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 12
                                font.weight: Font.Black
                            }
                        }

                        ColumnLayout {
                            id: detailCol
                            Layout.fillWidth: true
                            spacing: 2

                            RowLayout {
                                Layout.fillWidth: true

                                QsText {
                                    Layout.fillWidth: true
                                    text: modelData.appName
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.DemiBold
                                    renderType: Text.NativeRendering
                                    elide: Text.ElideRight
                                }

                                QsText {
                                    text: {
                                        root.timeTick
                                        return root.relativeTime(modelData.timestamp)
                                    }
                                    color: root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 10
                                    font.weight: Font.Medium
                                    renderType: Text.NativeRendering
                                }
                            }

                            QsText {
                                Layout.fillWidth: true
                                text: root.expanded && modelData.pid !== "" ? modelData.detail + " · pid " + modelData.pid : modelData.detail
                                color: root.textSec
                                font.family: "Inter"
                                font.pixelSize: 11
                                font.weight: Font.Medium
                                renderType: Text.NativeRendering
                                elide: Text.ElideRight
                            }
                        }
                    }
                }
            }
        }
    }
}
