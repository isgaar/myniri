// PolkitDialog.qml — Diálogo de autenticación PolicyKit personalizado estilo premium
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

BasePopup {
    id: root

    anchors {
        top: false
        bottom: false
        left: false
        right: false
    }
    
    // Al no tener anclas y establecer su tamaño implícito, Wayland lo centra.
    implicitWidth: 540
    implicitHeight: errorText.length > 0 ? 300 : 264

    property string messageText: ""
    property string usernameText: ""
    property string errorText: ""
    property bool showPassword: false
    property bool authenticating: false
    property var identitiesList: []
    property string defaultUser: ""

    readonly property color bgTile: (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#2a2a2a"





    function open(message, identities, defaultUser) {
        root.messageText = message
        root.identitiesList = identities
        root.defaultUser = defaultUser
        root.usernameText = defaultUser
        root.errorText = ""
        root.showPassword = false
        root.authenticating = false
        root.visible = true
        passwordField.text = ""
        Qt.callLater(() => passwordField.forceActiveFocus())
    }

    function close() {
        root.visible = false
    }

    function getContrastColor(c) {
        let r = c.r;
        let g = c.g;
        let b = c.b;
        let luminance = 0.299 * r + 0.587 * g + 0.114 * b;
        return luminance > 0.6 ? "#121212" : "#ffffff";
    }

    function cancel() {
        if (root.authenticating) return
        let response = {
            cancelled: true
        }
        writeResponse(JSON.stringify(response))
        root.close()
    }

    function submit() {
        if (root.authenticating || passwordField.text.length === 0) return
        root.authenticating = true
        root.errorText = ""
        let response = {
            username: userSelector.visible ? userSelector.currentText : root.usernameText,
            password: passwordField.text
        }
        writeResponse(JSON.stringify(response))
    }

    function handleResult(success) {
        root.authenticating = false
        if (success) {
            root.close()
        } else {
            root.errorText = "Contraseña incorrecta. Inténtelo de nuevo."
            passwordField.text = ""
            passwordField.selectAll()
            passwordField.forceActiveFocus()
        }
    }

    function writeResponse(respStr) {
        let code = 'import Quickshell.Io; Process { command: ["python3", "-c", "import sys; open(\'/tmp/qs-polkit.fifo\', \'w\').write(sys.argv[1])", ' + JSON.stringify(respStr) + ']; running: true }'
        try {
            Qt.createQmlObject(code, root)
        } catch (e) {
            console.log("Error writing response to pipe: " + e)
        }
    }

    onVisibleChanged: {
        if (visible) {
            passwordField.text = ""
            root.errorText = ""
            Qt.callLater(() => passwordField.forceActiveFocus())
        }
    }

    // Sin backdrop fullscreen para evitar que toda la pantalla se vea con blur

    Rectangle {
        id: dialogBox
        anchors.fill: parent
        radius: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false ? (shellRoot.themeConfig.cornerRadius || 16) : 0
        
        // Un fondo más opaco para que el texto sea legible
        color: {
            let base = Qt.color(root.bgCard)
            return Qt.rgba(base.r, base.g, base.b, 0.85)
        }
        border.color: root.border
        border.width: 1

        scale: root.visible ? 1.0 : 0.9
        Behavior on scale {
            enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
            NumberAnimation { duration: 180; easing.type: Easing.OutCubic }
        }
        Behavior on height {
            enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
            NumberAnimation { duration: 160; easing.type: Easing.OutCubic }
        }

        MouseArea {
            anchors.fill: parent
            // Evitar clics internos para cerrar el diálogo
        }

        RowLayout {
            anchors { fill: parent; margins: 20 }
            spacing: 16

            // Icono de Escudo de Seguridad
            Rectangle {
                Layout.alignment: Qt.AlignTop
                Layout.preferredWidth: 46
                Layout.preferredHeight: 46
                radius: 23
                color: root.bgTile
                border.color: root.border
                border.width: 1

                QsText {
                    anchors.centerIn: parent
                    text: "\uf023" // fa-lock
                    font.family: "Font Awesome 6 Free"
                    font.pixelSize: 20
                    color: root.accent
                }
            }

            // Cuerpo del diálogo
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 12

                QsText {
                    text: "Autenticación del Sistema"
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 15
                    font.weight: Font.DemiBold
                    Layout.fillWidth: true
                }

                QsText {
                    text: root.messageText || "Se requiere autenticación para realizar esta acción privilegiada."
                    color: root.textSec
                    font.family: "Inter"
                    font.pixelSize: 11
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                }

                // Usuario y contraseña
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 8
                        QsText {
                            text: "Usuario:"
                            color: root.textPri
                            font.family: "Inter"
                            font.pixelSize: 13
                            font.weight: Font.Medium
                            Layout.preferredWidth: 86
                        }
                        ComboBox {
                            id: userSelector
                            visible: root.identitiesList.length > 1
                            model: root.identitiesList
                            currentIndex: Math.max(0, root.identitiesList.indexOf(root.defaultUser))
                            
                            Layout.fillWidth: true
                            Layout.preferredHeight: 32
                            
                            font.family: "Inter"
                            font.pixelSize: 12
                            font.weight: Font.DemiBold
                            
                            background: Rectangle {
                                color: Qt.rgba(1, 1, 1, 0.04)
                                border.color: userSelector.activeFocus ? root.accent : root.border
                                border.width: 1
                                radius: 8
                            }
                            
                            contentItem: QsText {
                                text: userSelector.displayText
                                font: userSelector.font
                                color: root.textPri
                                verticalAlignment: Text.AlignVCenter
                                leftPadding: 10
                            }
                            
                            popup: Popup {
                                y: userSelector.height + 4
                                width: userSelector.width
                                implicitHeight: contentItem.implicitHeight
                                padding: 1
                                
                                contentItem: ListView {
                                    clip: true
                                    implicitHeight: contentHeight
                                    model: userSelector.popup.visible ? userSelector.delegateModel : null
                                    currentIndex: userSelector.highlightedIndex
                                    ScrollIndicator.vertical: ScrollIndicator { }
                                }
                                
                                background: Rectangle {
                                    color: root.bgCard
                                    border.color: root.border
                                    border.width: 1
                                    radius: 8
                                }
                            }
                            
                            delegate: ItemDelegate {
                                width: userSelector.width
                                contentItem: QsText {
                                    text: modelData
                                    color: highlighted ? "#ffffff" : root.textSec
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.Medium
                                    verticalAlignment: Text.AlignVCenter
                                    leftPadding: 10
                                }
                                background: Rectangle {
                                    color: highlighted ? root.bgTile : "transparent"
                                    radius: 6
                                }
                                highlighted: userSelector.highlightedIndex === index
                            }
                        }
                        QsText {
                            visible: root.identitiesList.length <= 1
                            text: root.usernameText
                            color: root.textPri
                            font.family: "Inter"
                            font.pixelSize: 12
                            font.weight: Font.DemiBold
                            verticalAlignment: Text.AlignVCenter
                            Layout.fillWidth: true
                            Layout.preferredHeight: 32
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 8
                        QsText {
                            text: "Contraseña:"
                            color: root.textPri
                            font.family: "Inter"
                            font.pixelSize: 13
                            font.weight: Font.Medium
                            Layout.preferredWidth: 86
                        }

                        TextField {
                            id: passwordField
                            echoMode: root.showPassword ? TextInput.Normal : TextInput.Password
                            color: root.textPri
                            selectedTextColor: "#111317"
                            selectionColor: root.accent
                            enabled: !root.authenticating

                            background: Rectangle {
                                color: Qt.rgba(1, 1, 1, 0.04)
                                border.color: passwordField.activeFocus ? root.accent : root.border
                                border.width: 1
                                radius: 8
                            }

                            font.family: "Inter"
                            font.pixelSize: 13
                            Layout.fillWidth: true
                            Layout.preferredHeight: 32
                            leftPadding: 10
                            rightPadding: 10

                            Keys.onReturnPressed: root.submit()
                            Keys.onEscapePressed: root.cancel()
                        }
                    }
                }

                // Mostrar Contraseña Toggle
                RowLayout {
                    spacing: 8
                    Layout.fillWidth: true
                    enabled: !root.authenticating

                    Item {
                        width: 44; height: 24

                        Rectangle {
                            anchors.fill: parent
                            radius: 12
                            color: root.showPassword ? root.accent : Qt.rgba(0.5, 0.5, 0.5, 0.2)
                            border.color: root.showPassword ? root.accent : Qt.rgba(0.5, 0.5, 0.5, 0.3)
                            border.width: 1
                            Behavior on color { ColorAnimation { duration: 150 } }

                            Rectangle {
                                width: 20; height: 20
                                radius: 10
                                color: "white"
                                y: 2
                                x: root.showPassword ? parent.width - width - 2 : 2
                                
                                Behavior on x {
                                    NumberAnimation { duration: 150; easing.type: Easing.OutQuad }
                                }
                            }
                        }

                        TapHandler { onTapped: root.showPassword = !root.showPassword }
                    }

                    QsText {
                        text: "Mostrar contraseña"
                        color: root.textSec
                        font.family: "Inter"
                        font.pixelSize: 11
                    }
                }

                // Error text si falla
                QsText {
                    text: root.errorText
                    color: root.danger
                    font.family: "Inter"
                    font.pixelSize: 11
                    visible: root.errorText !== ""
                    Layout.fillWidth: true
                }

                // Botones de acción
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    Layout.topMargin: 4

                    Item { Layout.fillWidth: true }

                    // Botón Cancelar
                    Button {
                        text: "Cancelar"
                        enabled: !root.authenticating
                        
                        contentItem: QsText {
                            text: parent.text
                            font.family: "Inter"
                            font.pixelSize: 12
                            font.weight: Font.Medium
                            color: root.textSec
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }

                        background: Rectangle {
                            implicitWidth: 84
                            implicitHeight: 32
                            radius: 8
                            color: cancelHover.hovered ? Qt.rgba(1, 1, 1, 0.05) : "transparent"
                            border.color: root.border
                            border.width: 1
                            HoverHandler { id: cancelHover }
                        }

                        onClicked: root.cancel()
                    }

                    // Botón Desbloquear
                    Button {
                        text: root.authenticating ? "Verificando..." : "Desbloquear"
                        enabled: !root.authenticating && passwordField.text.length > 0
                        
                        contentItem: QsText {
                            text: parent.text
                            font.family: "Inter"
                            font.pixelSize: 12
                            font.weight: Font.DemiBold
                            color: parent.enabled ? root.getContrastColor(root.accent) : Qt.rgba(255, 255, 255, 0.35)
                            horizontalAlignment: Text.AlignHCenter
                            verticalAlignment: Text.AlignVCenter
                        }

                        background: Rectangle {
                            implicitWidth: root.authenticating ? 104 : 96
                            implicitHeight: 32
                            radius: 8
                            color: parent.enabled ? (unlockHover.hovered ? Qt.lighter(root.accent, 1.1) : root.accent) : Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.15)
                            border.color: parent.enabled ? (unlockHover.hovered ? Qt.lighter(root.accent, 1.1) : root.accent) : "transparent"
                            border.width: 1
                            HoverHandler { id: unlockHover; enabled: parent.enabled }
                        }

                        onClicked: root.submit()
                    }
                }
            }
        }
    }
}
