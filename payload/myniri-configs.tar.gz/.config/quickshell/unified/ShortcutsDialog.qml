// ShortcutsDialog.qml — Popup de ayuda de atajos de teclado (dinámico desde config.kdl)
import Quickshell
import Quickshell.Wayland
import Quickshell.Shell
import QtQuick
import QtQuick.Layouts

BasePopup {
    id: root

    WindowSettings { id: ws }

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }

    function open() {
        root.visible = true
        dialogBox.forceActiveFocus()
        bindsLoader.rerun()
    }

    function close() {
        root.visible = false
    }

    readonly property color bgTile:   (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#2a2a2a"

    property var categories: []

    Process {
        id: bindsLoader
        command: ["/home/ismael/scripts/read_niri_binds.py"]
        running: false

        stdout: SplitParser {
            onRead: (data) => {
                try {
                    let parsed = JSON.parse(data)
                    if (Array.isArray(parsed) && parsed.length > 0) {
                        root.categories = parsed
                    }
                } catch (e) {
                    console.warn("Failed to parse niri binds JSON:", e)
                }
            }
        }
    }
    onVisibleChanged: {
        if (visible) {
            dialogBox.forceActiveFocus()
        }
    }

    Rectangle {
        id: backdrop
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.45)

        opacity: root.visible ? 1.0 : 0.0
        Behavior on opacity {
            enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
            NumberAnimation { duration: 150; easing.type: Easing.OutQuad }
        }

        MouseArea {
            anchors.fill: parent
            onClicked: root.close()
        }
    }

    Rectangle {
        id: dialogBox
        anchors.centerIn: parent
        width: Math.min(720, root.width - 32)
        height: Math.min(560, root.height - 32)
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        color: root.bgMain
        border.color: root.border
        border.width: 1
        focus: true

        scale: root.visible ? 1.0 : 0.95
        Behavior on scale {
            enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
            NumberAnimation { duration: 150; easing.type: Easing.OutQuad }
        }

        Keys.onEscapePressed: root.close()

        MouseArea {
            anchors.fill: parent
            // Evitar que los clics dentro del diálogo lo cierren
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 16

            // Cabecera del diálogo
            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Rectangle {
                    width: 38
                    height: 38
                    radius: 19
                    color: root.bgTile
                    border.color: root.border
                    border.width: 1

                    QsText {
                        anchors.centerIn: parent
                        text: "\uf11c" // Keyboard icon
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 16
                        color: root.accent
                    }
                }

                ColumnLayout {
                    spacing: 2

                    QsText {
                        text: "Atajos de Teclado"
                        color: root.textPri
                        font.family: "Inter"
                        font.pixelSize: 15
                        font.weight: Font.DemiBold
                    }

                    QsText {
                        text: "Guía rápida del entorno Niri de Ismael"
                        color: root.textSec
                        font.family: "Inter"
                        font.pixelSize: 11
                    }
                }

                Item {
                    Layout.fillWidth: true
                }

                // Botón cerrar (X)
                Rectangle {
                    width: 32
                    height: 32
                    radius: 16
                    color: closeHover.hovered ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(1, 1, 1, 0.03)
                    border.color: root.border
                    border.width: 1

                    QsText {
                        anchors.centerIn: parent
                        text: "\uf00d" // Close icon
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 12
                        color: root.textSec
                    }

                    HoverHandler { id: closeHover }
                    TapHandler { onTapped: root.close() }
                }
            }

            // Separador
            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: root.border
            }

            // Cuadrícula de categorías
            GridLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                columns: 2
                columnSpacing: 16
                rowSpacing: 16

                Repeater {
                    model: root.categories

                    delegate: Rectangle {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        radius: ws.cornersEnabled ? ws.cornerRadius : 0
                        color: root.bgCard
                        border.color: root.border
                        border.width: 1

                        ColumnLayout {
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 8

                            // Cabecera de Categoría
                            RowLayout {
                                spacing: 8
                                Layout.fillWidth: true

                                QsText {
                                    text: modelData.icon
                                    font.family: "Font Awesome 6 Free"
                                    font.pixelSize: 13
                                    color: root.accent
                                }

                                QsText {
                                    text: modelData.name
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 12
                                    font.weight: Font.DemiBold
                                    Layout.fillWidth: true
                                }
                            }

                            // Separador de categoría
                            Rectangle {
                                Layout.fillWidth: true
                                height: 1
                                color: Qt.rgba(1, 1, 1, 0.05)
                            }

                            // Lista de atajos
                            ColumnLayout {
                                Layout.fillWidth: true
                                Layout.fillHeight: true
                                spacing: 6

                                Repeater {
                                    model: modelData.items

                                    delegate: RowLayout {
                                        id: shortcutItem
                                        Layout.fillWidth: true
                                        height: 22
                                        property var keyList: modelData.keys

                                        QsText {
                                            text: modelData.desc
                                            color: root.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            Layout.fillWidth: true
                                            elide: Text.ElideRight
                                        }

                                        Row {
                                            spacing: 4
                                            Layout.alignment: Qt.AlignVCenter

                                            Repeater {
                                                model: shortcutItem.keyList

                                                delegate: Row {
                                                    spacing: 4
                                                    Layout.alignment: Qt.AlignVCenter

                                                    // Teclado 3D
                                                    Rectangle {
                                                        color: "#141414"
                                                        radius: 4
                                                        width: keyCapText.implicitWidth + 12
                                                        height: 18

                                                        Rectangle {
                                                            anchors { fill: parent; bottomMargin: 2 }
                                                            color: "#2e2e2e"
                                                            radius: 4
                                                            border.color: "#444444"
                                                            border.width: 1

                                                            QsText {
                                                                id: keyCapText
                                                                anchors.centerIn: parent
                                                                text: modelData
                                                                color: "#f0eee8"
                                                                font.family: "Inter"
                                                                font.pixelSize: 9
                                                                font.weight: Font.DemiBold
                                                            }
                                                        }
                                                    }

                                                    // Separador '+'
                                                    QsText {
                                                        text: "+"
                                                        color: "#6c6a64"
                                                        font.family: "Inter"
                                                        font.pixelSize: 9
                                                        font.weight: Font.DemiBold
                                                        Layout.alignment: Qt.AlignVCenter
                                                        visible: index < shortcutItem.keyList.length - 1
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
