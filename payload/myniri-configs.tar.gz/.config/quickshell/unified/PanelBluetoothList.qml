// PanelBluetoothList.qml — Zona 4b: Lista de Bluetooth
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

Item {
    id: root
    implicitHeight: headerRow.height + btList.height + 24

    property color bgCard
    property color bgActive
    property color border
    property color borderHi
    property color textPri
    property color textSec
    property color accent
    property color accentBt

    ListModel { id: bluetoothModel }

    Process {
        id: btListPoller
        command: ["bash", "-c", [
            "echo CLEAR;",
            "bluetoothctl devices | while read -r _ mac name; do",
            "  if bluetoothctl info \"$mac\" 2>/dev/null | grep -q 'Connected: yes'; then",
            "    echo \"ACTIVE:$mac\";",
            "  fi;",
            "  echo \"$mac|$name\";",
            "done | head -10"
        ].join(" ")]
        running: root.visible
        onRunningChanged: if (running) { bluetoothModel.clear() }
        
        stdout: SplitParser {
            property string activeMac: ""
            onRead: data => {
                let line = data.trim()
                if (line === "CLEAR") {
                    bluetoothModel.clear()
                    activeMac = ""
                    return
                }
                if (line.startsWith("ACTIVE:")) {
                    activeMac = line.substring(7)
                    for (let i = 0; i < bluetoothModel.count; i++)
                        bluetoothModel.setProperty(i, "active", bluetoothModel.get(i).mac === activeMac)
                    return
                }
                if (!line) return
                let parts = line.split("|")
                if (parts.length < 2) return
                let mac = parts[0]
                let name = parts.slice(1).join("|")
                
                for (let i = 0; i < bluetoothModel.count; i++)
                    if (bluetoothModel.get(i).mac === mac) return
                
                bluetoothModel.append({ mac, name, active: mac === activeMac })
            }
        }
    }

    Timer {
        interval: 9000
        repeat: true
        running: root.visible
        onTriggered: {
            btListPoller.running = false
            Qt.callLater(() => btListPoller.running = true)
        }
    }

    Rectangle {
        anchors.fill: parent
        color: root.bgCard; radius: 12
        border.color: root.border; border.width: 1
    }

    RowLayout {
        id: headerRow
        anchors { top: parent.top; left: parent.left; right: parent.right; margins: 14 }
        height: 44
        spacing: 8

        QsText {
            text: "Bluetooth"
            color: root.textPri
            font.pixelSize: 14; font.weight: Font.Medium
        }

        Item { Layout.fillWidth: true }

        Rectangle {
            width: 28; height: 28; radius: 8
            color: "transparent"; border.color: root.border; border.width: 1
            QsText {
                anchors.centerIn: parent; text: "\uf013"
                font.family: "Font Awesome 6 Free"
                font.pixelSize: 13; color: root.textSec
            }
            HoverHandler { id: gearHover }
            Rectangle { anchors.fill: parent; radius: parent.radius; color: gearHover.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent" }
            TapHandler {
                onTapped: {
                    Qt.createQmlObject('import Quickshell.Io; Process { command: ["blueman-manager"]; running: true }', root)
                }
            }
        }
    }

    // Activa el escaneo activo de BT solo mientras la lista está abierta.
    // Se limita a 10s para no dejar el adaptador en modo scan indefinido.
    Process {
        id: btScanner
        command: ["bluetoothctl", "--timeout", "10", "scan", "on"]
        running: root.visible
    }

    property string connectingMac: ""

    Column {
        id: btList
        anchors { top: headerRow.bottom; left: parent.left; right: parent.right; margins: 8; topMargin: 2 }
        spacing: 2

        Repeater {
            id: btRepeater
            model: bluetoothModel

            delegate: Item {
                width: btList.width
                height: 54

                Rectangle {
                    anchors.fill: parent
                    radius: 8
                    color: model.active ? root.bgActive : "transparent"
                    border.color: model.active ? root.borderHi : "transparent"
                    border.width: model.active ? 1 : 0

                    RowLayout {
                        anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                        spacing: 8

                        QsText {
                            text: "\uf294"
                            font.family: "Font Awesome 6 Brands"
                            font.pixelSize: 15
                            color: model.active ? root.accentBt : root.textSec
                        }

                        Column {
                            spacing: 2
                            Layout.fillWidth: true
                            QsText {
                                text: model.name
                                color: root.textPri
                                font.pixelSize: 13
                                font.weight: model.active ? Font.Medium : Font.Normal
                                elide: Text.ElideRight
                                width: parent.width
                            }
                            QsText {
                                text: model.mac === root.connectingMac ? "Conectando..." : (model.active ? "Conectado" : "Emparejado")
                                color: root.textSec; font.pixelSize: 11
                            }
                        }

                        Rectangle {
                            width: 28; height: 24; radius: 6
                            color: "transparent"; border.color: root.border; border.width: 1
                            QsText {
                                anchors.centerIn: parent; text: "\uf141"
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 11; color: root.textSec
                            }
                            HoverHandler { id: moreHover }
                            Rectangle { anchors.fill: parent; radius: parent.radius; color: moreHover.hovered ? Qt.rgba(1, 1, 1, 0.04) : "transparent" }
                        }
                    }

                    HoverHandler { id: rowHover }
                    Rectangle {
                        anchors.fill: parent; radius: parent.radius
                        color: rowHover.hovered && !model.active ? Qt.rgba(1, 1, 1, 0.025) : "transparent"
                    }
                }

                TapHandler {
                    onTapped: {
                        if (!model.active) {
                            root.connectingMac = model.mac
                            Qt.createQmlObject(
                                'import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/connect_bt.sh", "' + model.mac + '"]; running: true; onExited: root.connectingMac = "" }', root)
                        }
                    }
                }
            }
        }

        QsText {
            visible: bluetoothModel.count === 0
            width: btList.width
            horizontalAlignment: Text.AlignHCenter
            topPadding: 20; bottomPadding: 20
            text: "Buscando dispositivos..."
            color: root.textSec; font.pixelSize: 13
        }
    }
}
