import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
    BasePopup {
        id: menu

    WindowSettings { id: ws }
        anchors {
            top: true
            left: true
            right: false
        }
        margins.top: shellRoot.getPopupTopMargin(menu.screen)
        margins.left: menu.anchorMargin

        property int anchorMargin: 0

        implicitWidth: 320
        implicitHeight: menuRect.implicitHeight
        property int contentHeight: menuRect.implicitHeight

        onVisibleChanged: {
            if (visible) {
                shellRoot.updateMakoPosition("bgapps", "open", Math.round(menu.implicitHeight + 55).toString())
            } else {
                shellRoot.updateMakoPosition("bgapps", "closed")
            }
        }

        function toggle(x) {
            visible = !visible
            if (visible) {
                if (x !== undefined) setPosition(x)
                refresh()
            }
        }

        function setPosition(x) {
            if (x !== undefined && x >= 0) {
                let screenW = menu.screen ? menu.screen.width : 1920
                menu.anchorMargin = Math.max(12, Math.min(x - menu.implicitWidth/2, screenW - menu.implicitWidth - 12))
            }
        }

        function refresh() {
            bgMenuContent.loadApps()
            menuRect.forceActiveFocus(Qt.MouseFocusReason)
        }

        Rectangle {
            id: menuRect
            width: parent.width
            implicitHeight: bgMenuContent.implicitHeight + 24
            color: menu.bgMain
            radius: ws.cornersEnabled ? ws.cornerRadius : 0
            border.color: menu.border
            border.width: 1

            focus: true
            Keys.onEscapePressed: menu.visible = false

            BgAppsMenu {
                id: bgMenuContent
                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.margins: 12
                onCloseRequested: menu.visible = false

                bgCard: menu.bgCard
                border: menu.border
                textPri: menu.textPri
                textSec: menu.textSec
                accent: menu.accent
                danger: menu.danger
            }
        }
    }
