import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

PanelWindow {
    id: root

    // Configuración estándar de Wayland para paneles flotantes
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "quickshell"
    WlrLayershell.keyboardFocus: root.visible ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None
    WlrLayershell.exclusionMode: ExclusionMode.Ignore

    color: "transparent"
    visible: false

    // Posicionamiento dinámico por anclaje y margen
    anchors {
        top: true
        left: true
        bottom: false
        right: false
    }

    property int xPos: 0
    property int yPos: 0

    margins.left: xPos
    margins.top: yPos

    implicitWidth: 380
    implicitHeight: Math.min(600, layoutCol.implicitHeight + 24)

    // Paleta de Diseño Unificada global
    readonly property color bgMain: (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a"
    readonly property color bgCard: (shellRoot.themeConfig && shellRoot.themeConfig.bgCard) || "#2a2a2a"
    readonly property color border: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    readonly property color textPri: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
    readonly property color textSec: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
    readonly property color accent: (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property color danger: (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e74c3c"
    readonly property bool cornersEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false
    readonly property int cornerRadius: (shellRoot.themeConfig && shellRoot.themeConfig.cornerRadius) !== undefined ? shellRoot.themeConfig.cornerRadius : 16

    readonly property color dividerColor: Qt.rgba(1, 1, 1, 0.08)
    readonly property color itemHoverBg: Qt.rgba(1, 1, 1, 0.05)

    onVisibleChanged: {
        if (visible) {
            cursorPosProcess.running = false
            cursorPosProcess.running = true
        }
    }

    // Proceso para obtener la posición actual del cursor de Niri
    Process {
        id: cursorPosProcess
        command: ["bash", "-c", "niri msg --json cursor-position 2>/dev/null"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let json = JSON.parse(data.trim())
                    let cursorX = json.x
                    let cursorY = json.y

                    let screenWidth = root.screen ? root.screen.width : 1920
                    let screenHeight = root.screen ? root.screen.height : 1080

                    let winWidth = 380
                    let winHeight = Math.min(600, layoutCol.implicitHeight + 24)

                    // Ajustar posición para evitar salirse de la pantalla
                    root.xPos = Math.max(8, Math.min(cursorX - winWidth / 2, screenWidth - winWidth - 8))
                    root.yPos = Math.max(8, Math.min(cursorY - 20, screenHeight - winHeight - 8))
                } catch(e) {}
            }
        }
    }

    function toggle() {
        visible = !visible
        if (visible) {
            loadEntries()
            searchField.text = ""
            Qt.callLater(() => searchField.forceActiveFocus())
        }
    }

    function close() {
        visible = false
    }

    // Proceso de carga de entradas de historial
    property bool isLoading: false
    ListModel { id: clipboardModel }

    function loadEntries() {
        isLoading = true
        clipboardModel.clear()
        clipLoader.running = false
        clipLoader.running = true
    }

    Process {
        id: clipLoader
        command: ["bash", "/home/ismael/scripts/get_clipboard_json.sh"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let entries = JSON.parse(data.trim())
                    for (let i = 0; i < entries.length; i++) {
                        clipboardModel.append(entries[i])
                    }
                } catch(e) {}
                root.isLoading = false
            }
        }
    }

    Rectangle {
        id: content
        anchors.fill: parent
        color: root.bgMain
        radius: root.cornersEnabled ? root.cornerRadius : 0
        border.color: root.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: root.visible = false

        ColumnLayout {
            id: layoutCol
            anchors { fill: parent; margins: 12 }
            spacing: 0

            // 1. Cabecera (Portapapeles + Borrar Historial)
            RowLayout {
                Layout.fillWidth: true
                height: 44
                spacing: 12

                QsText {
                    text: "Portapapeles"
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: Font.Medium
                    Layout.fillWidth: true
                }

                // Botón de Papelera
                Rectangle {
                    width: 28; height: 28; radius: 8
                    color: "transparent"

                    QsText {
                        anchors.centerIn: parent
                        text: "\uf1f8"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 13
                        color: trashHover.hovered ? root.danger : root.textSec
                        Behavior on color { ColorAnimation { duration: 150 } }
                    }

                    HoverHandler { id: trashHover }
                    TapHandler {
                        onTapped: {
                            Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "-c", "cliphist wipe"]; running: true; onExited: { root.loadEntries() } }', root)
                        }
                    }
                }
            }

            // Separador superior
            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: root.dividerColor
                Layout.topMargin: 4
                Layout.bottomMargin: 8
            }

            // 2. Campo de búsqueda
            Item {
                Layout.fillWidth: true
                height: 36
                Layout.bottomMargin: 8

                Rectangle {
                    anchors.fill: parent
                    radius: 8
                    color: Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)
                    border.color: root.dividerColor
                    border.width: 1

                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: 10
                        anchors.rightMargin: 10
                        spacing: 8

                        QsText {
                            text: "\uf002"
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 11
                            color: root.textSec
                        }

                        TextField {
                            id: searchField
                            placeholderText: "Buscar..."
                            placeholderTextColor: root.textSec
                            color: root.textPri
                            selectedTextColor: "#111317"
                            selectionColor: root.accent
                            background: Item {}

                            font.family: "Inter"
                            font.pixelSize: 13
                            Layout.fillWidth: true
                            Layout.preferredHeight: 36
                            padding: 0
                        }
                    }
                }
            }

            // Separador medio
            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: root.dividerColor
                Layout.bottomMargin: 8
            }

            // 3. ScrollView con lista de entradas
            ScrollView {
                id: scrollView
                Layout.fillWidth: true
                Layout.preferredHeight: Math.min(400, clipboardList.contentHeight)
                clip: true

                ListView {
                    id: clipboardList
                    width: parent.width
                    model: clipboardModel
                    delegate: Item {
                        id: delegateRoot
                        width: parent.width
                        height: delegateRoot.visible ? 38 : 0
                        visible: searchField.text === "" || model.preview.toLowerCase().includes(searchField.text.toLowerCase())

                        Rectangle {
                            anchors.fill: parent
                            color: hover.hovered ? root.itemHoverBg : "transparent"
                            radius: 8
                            anchors.margins: 2

                            Rectangle {
                                visible: index > 0 && delegateRoot.visible
                                anchors.top: parent.top
                                anchors.left: parent.left
                                anchors.right: parent.right
                                anchors.leftMargin: 36
                                height: 1
                                color: root.dividerColor
                            }

                            RowLayout {
                                anchors.fill: parent
                                anchors.leftMargin: 12
                                anchors.rightMargin: 12
                                spacing: 12

                                Item {
                                    width: 16
                                    height: 16
                                    QsText {
                                        anchors.centerIn: parent
                                        text: model.type === "image" ? "\uf03e" : "\uf0c5"
                                        font.family: "Font Awesome 6 Free"
                                        font.pixelSize: 12
                                        color: index === 0 ? root.accent : root.textSec
                                    }
                                }

                                QsText {
                                    text: model.preview
                                    color: root.textPri
                                    font.family: "Inter"
                                    font.pixelSize: 13
                                    font.weight: index === 0 ? Font.Medium : Font.Normal
                                    elide: Text.ElideRight
                                    Layout.fillWidth: true
                                }
                            }

                            HoverHandler { id: hover }
                            TapHandler {
                                onTapped: {
                                    Qt.createQmlObject(
                                        'import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/clipboard_paste.sh", "' + model.id + '"]; running: true }', root)
                                    root.visible = false
                                }
                            }
                        }
                    }
                }
            }

            // Mensaje de lista vacía
            QsText {
                visible: clipboardModel.count === 0 && !root.isLoading
                text: "El portapapeles está vacío"
                color: root.textSec
                font.family: "Inter"
                font.pixelSize: 12
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 20
                Layout.bottomMargin: 20
            }

            // Spinner de carga
            RowLayout {
                visible: root.isLoading
                Layout.alignment: Qt.AlignHCenter
                spacing: 8
                Layout.topMargin: 20
                Layout.bottomMargin: 20

                QsText {
                    text: "\uf1ce"
                    font.family: "Font Awesome 6 Free"
                    font.pixelSize: 12
                    color: root.textSec
                    RotationAnimator on rotation {
                        from: 0; to: 360; duration: 1000; loops: Animation.Infinite; running: root.visible && root.isLoading
                    }
                }
                QsText {
                    text: "Cargando..."
                    color: root.textSec
                    font.family: "Inter"
                    font.pixelSize: 12
                }
            }

            // 4. Botón inferior (Abrir Gestor Externo)
            Item {
                Layout.fillWidth: true
                height: 54

                Rectangle {
                    anchors.fill: parent
                    anchors.margins: 8
                    anchors.topMargin: 12
                    radius: 8
                    color: settingsHover.hovered ? root.itemHoverBg : "transparent"

                    RowLayout {
                        anchors.centerIn: parent
                        spacing: 8
                        QsText {
                            text: "Abrir Gestor de Portapapeles..."
                            color: root.textPri
                            font.family: "Inter"
                            font.pixelSize: 13
                        }
                    }

                    HoverHandler { id: settingsHover }
                    TapHandler {
                        onTapped: {
                            root.visible = false
                            Qt.createQmlObject(
                                'import Quickshell.Io; Process { command: ["bash", "-c", "copyq show || clipse || gpaste-ui"]; running: true }', root)
                        }
                    }
                }
            }
        }
    }
}
