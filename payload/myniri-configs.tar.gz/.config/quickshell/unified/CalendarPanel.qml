import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

BasePopup {
    id: panel

    anchors {
        top: true
        left: true
        right: false
    }
    margins.top: 40
    margins.left: panel.anchorMargin

    property int anchorMargin: 0

    implicitWidth: 360
    implicitHeight: 380
    property int contentHeight: 380

    property int currentYear: new Date().getFullYear()
    property int currentMonth: new Date().getMonth()

    function toggle(x) {
        visible = !visible
        if (visible) {
            if (x !== undefined && x >= 0) {
                let screenW = panel.screen ? panel.screen.width : 1920
                panel.anchorMargin = Math.max(8, Math.min(x - panel.implicitWidth/2, screenW - panel.implicitWidth - 8))
            }
            let now = new Date()
            panel.currentYear = now.getFullYear()
            panel.currentMonth = now.getMonth()
            updateCalendar()
            content.forceActiveFocus(Qt.MouseFocusReason)
        }
    }

    

    ListModel {
        id: calendarModel
    }

    function getFormattedDate() {
        let now = new Date()
        let days = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"]
        let months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
        
        let dayName = days[now.getDay()]
        let dayNum = now.getDate()
        let monthName = months[now.getMonth()]
        let year = now.getFullYear()
        
        return dayName + ", " + dayNum + " de " + monthName + " de " + year
    }

    function getMonthYearHeader() {
        let months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
        return months[panel.currentMonth] + " " + panel.currentYear
    }

    function nextMonth() {
        if (panel.currentMonth === 11) {
            panel.currentMonth = 0
            panel.currentYear++
        } else {
            panel.currentMonth++
        }
        updateCalendar()
    }

    function prevMonth() {
        if (panel.currentMonth === 0) {
            panel.currentMonth = 11
            panel.currentYear--
        } else {
            panel.currentMonth--
        }
        updateCalendar()
    }

    function updateCalendar() {
        calendarModel.clear()
        let now = new Date()
        let todayYear = now.getFullYear()
        let todayMonth = now.getMonth()
        let todayDate = now.getDate()

        let viewYear = panel.currentYear
        let viewMonth = panel.currentMonth

        let firstDay = new Date(viewYear, viewMonth, 1).getDay() // 0 = Sunday
        let daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate()
        let daysInPrevMonth = new Date(viewYear, viewMonth, 0).getDate()

        // Fill previous month days
        for (let i = firstDay - 1; i >= 0; i--) {
            calendarModel.append({
                day: daysInPrevMonth - i,
                isCurrentMonth: false,
                isToday: false
            })
        }

        // Fill current month days
        for (let d = 1; d <= daysInMonth; d++) {
            let isToday = (d === todayDate && viewMonth === todayMonth && viewYear === todayYear)
            calendarModel.append({
                day: d,
                isCurrentMonth: true,
                isToday: isToday
            })
        }

        // Fill next month days
        let remaining = 42 - calendarModel.count
        for (let n = 1; n <= remaining; n++) {
            calendarModel.append({
                day: n,
                isCurrentMonth: false,
                isToday: false
            })
        }
    }

    // Timer to update time/date dynamically while open
    Timer {
        id: timeUpdater
        interval: 1000
        repeat: true
        running: panel.visible
        onTriggered: {
            timeText.text = Qt.formatDateTime(new Date(), "h:mm AP")
            dateText.text = getFormattedDate()
        }
    }

    onVisibleChanged: {
        if (visible) {
            let now = new Date()
            panel.currentYear = now.getFullYear()
            panel.currentMonth = now.getMonth()
            timeText.text = Qt.formatDateTime(now, "h:mm AP")
            dateText.text = getFormattedDate()
            updateCalendar()
            shellRoot.updateMakoPosition("calendar", "open", Math.round(panel.implicitHeight + 55).toString())
        } else {
            shellRoot.updateMakoPosition("calendar", "closed")
        }
    }

    Rectangle {
        id: content
        anchors.fill: parent
        color: panel.bgMain
        radius: panel.cornersEnabled ? panel.cornerRadius : 0
        border.color: panel.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: panel.visible = false

        Column {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 12

            // Header: Date and Time
            Item {
                width: parent.width
                height: 20

                QsText {
                    id: dateText
                    width: parent.width - timeText.implicitWidth - 10
                    text: ""
                    color: panel.textPri
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: Font.Bold
                    elide: Text.ElideRight
                    anchors.verticalCenter: parent.verticalCenter
                }

                QsText {
                    id: timeText
                    text: ""
                    color: panel.textPri
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: Font.Bold
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                }
            }

            // Divider matching other panels
            Rectangle {
                width: parent.width
                height: 1
                color: panel.border
            }

            // Month navigation bar
            RowLayout {
                width: parent.width
                height: 26

                Rectangle {
                    width: 26; height: 26; radius: 13
                    color: prevMonthHover.hovered ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.08) : Qt.rgba(255, 255, 255, 0.08)) : "transparent"
                    QsText {
                        anchors.centerIn: parent
                        text: "\uf053" // chevron-left
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 11
                        font.weight: Font.Bold
                        color: panel.textSec
                    }
                    HoverHandler { id: prevMonthHover }
                    TapHandler {
                        onTapped: panel.prevMonth()
                    }
                }

                QsText {
                    Layout.fillWidth: true
                    horizontalAlignment: Text.AlignHCenter
                    text: getMonthYearHeader()
                    color: panel.textPri
                    font.family: "Inter"
                    font.pixelSize: 13
                    font.weight: Font.Bold
                }

                Rectangle {
                    width: 26; height: 26; radius: 13
                    color: nextMonthHover.hovered ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.08) : Qt.rgba(255, 255, 255, 0.08)) : "transparent"
                    QsText {
                        anchors.centerIn: parent
                        text: "\uf054" // chevron-right
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 11
                        font.weight: Font.Bold
                        color: panel.textSec
                    }
                    HoverHandler { id: nextMonthHover }
                    TapHandler {
                        onTapped: panel.nextMonth()
                    }
                }
            }

            // Grid for weekdays header (D L M M J V S)
            Row {
                width: parent.width
                height: 20

                Repeater {
                    model: ["D", "L", "M", "M", "J", "V", "S"]
                    delegate: Item {
                        width: daysGrid.cellWidth
                        height: 20
                        QsText {
                            anchors.centerIn: parent
                            text: modelData
                            color: panel.textSec
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Bold
                        }
                    }
                }
            }

            // Grid for calendar days
            GridView {
                id: daysGrid
                width: parent.width
                height: 216 // 6 rows of 36px
                cellWidth: width / 7
                cellHeight: 36
                interactive: false

                model: calendarModel
                delegate: Item {
                    width: daysGrid.cellWidth
                    height: daysGrid.cellHeight

                    Rectangle {
                        anchors.centerIn: parent
                        width: 30
                        height: 30
                        radius: 15
                        color: model.isToday ? Qt.rgba(panel.accent.r, panel.accent.g, panel.accent.b, 0.15) : (dayHover.hovered ? ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(255, 255, 255, 0.06)) : "transparent")
                        border.color: model.isToday ? panel.accent : "transparent"
                        border.width: model.isToday ? 1 : 0

                        QsText {
                            id: dayNumText
                            anchors.centerIn: parent
                            text: model.day.toString()
                            color: model.isToday ? panel.accent : (model.isCurrentMonth ? panel.textPri : ((shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.25) : Qt.rgba(255, 255, 255, 0.25)))
                            font.family: "Inter"
                            font.pixelSize: 12
                            font.weight: model.isToday ? Font.Bold : Font.Medium
                        }
                    }

                    HoverHandler { id: dayHover }
                }
            }
        }
    }
}
