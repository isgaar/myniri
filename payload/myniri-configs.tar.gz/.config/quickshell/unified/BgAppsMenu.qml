// ~/.config/quickshell/bgapps/BgAppsMenu.qml
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls
import Quickshell.Io

ColumnLayout {
    id: root

    WindowSettings { id: ws }
    spacing: 8
    signal closeRequested()

    property color bgCard: "#232323"
    property color border: "#3a3a3a"
    property color textPri: "#e8e6e0"
    property color textSec: "#888680"
    property color accent: "#5aa7de"
    property color danger: "#e06c6c"

    function loadApps() {
        appLoader.running = false
        appLoader.running = true
    }

    Process {
        id: appLoader
        command: ["bash", "-c", "/home/ismael/scripts/get_bg_apps_json.sh"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let apps = JSON.parse(data)
                    appsModel.clear()
                    for (let i = 0; i < apps.length; i++) {
                        appsModel.append(apps[i])
                    }
                } catch(e) {
                    console.log("Error parsing JSON:", e)
                }
            }
        }
    }

    QsText {
        text: "Apps en Segundo Plano"
        color: root.textPri
        font.family: "Inter"
        font.pixelSize: 14
        font.weight: Font.Bold
        Layout.bottomMargin: 8
    }

    ListModel {
        id: appsModel
    }

    Repeater {
        model: appsModel
        delegate: Rectangle {
            Layout.fillWidth: true
            height: 44
            color: root.bgCard
            border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
            border.width: 1
            radius: ws.cornersEnabled ? ws.cornerRadius : 0

            RowLayout {
                anchors.fill: parent
                anchors.margins: 8
                spacing: 12

                Rectangle {
                    width: 28; height: 28; radius: 14
                    color: root.accent
                    Layout.alignment: Qt.AlignVCenter

                    QsText {
                        anchors.centerIn: parent
                        text: model.icon
                        font.family: model.font_family || "Font Awesome 6 Free"
                        color: "#ffffff"
                        font.pixelSize: 13
                    }
                }

                QsText {
                    text: model.name
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 13
                    font.weight: Font.DemiBold
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }

                // Focus/Launch button
                Rectangle {
                    width: 30; height: 30; radius: 6
                    color: focusHover.hovered ? Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.1) : "transparent"
                    QsText {
                        anchors.centerIn: parent
                        text: "\uf08e" // fa-external-link
                        font.family: "Font Awesome 6 Free"
                        color: root.textPri
                        font.pixelSize: 12
                    }
                    HoverHandler { id: focusHover }
                    TapHandler {
                        onTapped: {
                            Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/bg_app_action.sh", "focus", "' + model.app_id + '", "' + model.cmd + '", "' + model.class_or_id + '"]; running: true }', root)
                            root.closeRequested()
                        }
                    }
                }

                // Kill button
                Rectangle {
                    width: 30; height: 30; radius: 6
                    color: killHover.hovered ? root.danger : "transparent"
                    QsText {
                        anchors.centerIn: parent
                        text: "\uf00d" // fa-times
                        font.family: "Font Awesome 6 Free"
                        color: killHover.hovered ? "#ffffff" : root.danger
                        font.pixelSize: 12
                    }
                    HoverHandler { id: killHover }
                    TapHandler {
                        onTapped: {
                            Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/bg_app_action.sh", "kill", "' + model.app_id + '"]; running: true }', root)
                            root.closeRequested()
                        }
                    }
                }
            }
        }
    }

    QsText {
        visible: appsModel.count === 0
        text: "No hay aplicaciones en segundo plano"
        color: root.textSec
        font.family: "Inter"
        font.pixelSize: 13
        Layout.alignment: Qt.AlignHCenter
        Layout.topMargin: 10
        Layout.bottomMargin: 10
    }
}
