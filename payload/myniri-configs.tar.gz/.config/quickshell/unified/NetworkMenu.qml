import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

BasePopup {
    id: window

    anchors {
        top: true
        left: true
        right: false
    }
    margins.top: shellRoot.getPopupTopMargin(window.screen)
    margins.left: window.anchorMargin

    property int anchorMargin: 136

    property bool isEthernet: false
    property string ethInterface: "—"
    property string ethIp: "—"
    property string ethGateway: "—"
    property string ethDns: "—"

    onVisibleChanged: {
        if (visible) {
            shellRoot.updateMakoPosition("networkmenu", "open", Math.round(window.implicitHeight + 55).toString())
            content.forceActiveFocus(Qt.MouseFocusReason)
            netDetector.running = false
            netDetector.running = true
            ethInfoReader.running = false
            ethInfoReader.running = true
            if (!isEthernet && networkList) {
                networkList.refresh()
            }
        } else {
            shellRoot.updateMakoPosition("networkmenu", "closed")
            netDetector.running = false
            ethInfoReader.running = false
        }
    }

    implicitWidth: Math.min(380, Math.max(300, (window.screen ? window.screen.width : 1920) - 16))
    implicitHeight: Math.min(800, isEthernet ? ethLayout.implicitHeight + 24 : (networkList ? networkList.implicitHeight + 24 : 300))
    property int contentHeight: Math.min(800, isEthernet ? ethLayout.implicitHeight + 24 : (networkList ? networkList.implicitHeight + 24 : 300))

    function toggle(x) {
        if (visible) {
            visible = false
        } else {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(12, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 12))
            }
            visible = true
        }
    }

    function close() {
        visible = false
    }

    // Proceso para detectar tipo de red activa
    Process {
        id: netDetector
        command: ["bash", "-c", "ETH=$(nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null | grep ':ethernet:connected' | cut -d: -f1 | head -1); [ -n \"$ETH\" ] && echo \"eth\" || echo \"wifi\""]
        running: window.visible
        stdout: SplitParser {
            onRead: data => {
                window.isEthernet = data.trim() === "eth"
            }
        }
    }

    // Lector de información detallada de Ethernet
    Process {
        id: ethInfoReader
        command: ["bash", "-c", "ETH=$(nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null | grep ':ethernet:connected' | cut -d: -f1 | head -1); [ -z \"$ETH\" ] && ETH=$(ip -o link show | awk -F': ' '$2 ~ /^e/ {print $2}' | head -1); IP=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}' || hostname -I | awk '{print $1}'); GW=$(ip route show | grep default | awk '{print $3; exit}'); DNS=$(awk '/nameserver/{print $2; exit}' /etc/resolv.conf); printf '{\"interface\":\"%s\",\"ip\":\"%s\",\"gateway\":\"%s\",\"dns\":\"%s\"}' \"$ETH\" \"$IP\" \"$GW\" \"$DNS\""]
        running: false
        stdout: SplitParser {
            onRead: data => {
                try {
                    let parsed = JSON.parse(data.trim())
                    window.ethInterface = parsed.interface || "Desconocida"
                    window.ethIp = parsed.ip || "—"
                    window.ethGateway = parsed.gateway || "—"
                    window.ethDns = parsed.dns || "—"
                } catch(e) {}
            }
        }
    }

    Timer {
        interval: 10000
        repeat: true
        running: window.visible
        onTriggered: {
            netDetector.running = false
            Qt.callLater(() => netDetector.running = true)
            if (window.isEthernet) {
                ethInfoReader.running = false
                Qt.callLater(() => ethInfoReader.running = true)
            } else if (networkList) {
                networkList.refresh()
            }
        }
    }

    Rectangle {
        id: content
        anchors.fill: parent
        color: window.bgMain
        radius: window.cornersEnabled ? window.cornerRadius : 0
        border.color: window.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: window.visible = false

        // ── MODO ETHERNET ──
        ColumnLayout {
            id: ethLayout
            anchors { fill: parent; margins: 12 }
            spacing: 0
            visible: window.isEthernet

            RowLayout {
                Layout.fillWidth: true
                height: 44
                QsText {
                    text: "Red Cableada (Ethernet)"
                    color: window.textPri
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: Font.Medium
                    Layout.fillWidth: true
                }
                Canvas {
                    id: ethernetHeaderIcon
                    Layout.preferredWidth: 18
                    Layout.preferredHeight: 18
                    Layout.alignment: Qt.AlignVCenter
                    antialiasing: true

                    onPaint: {
                        let ctx = getContext("2d")
                        ctx.clearRect(0, 0, width, height)
                        ctx.lineWidth = 1.7
                        ctx.lineCap = "round"
                        ctx.lineJoin = "round"
                        ctx.strokeStyle = window.accent

                        ctx.beginPath()
                        ctx.moveTo(5.8, 3.0)
                        ctx.lineTo(12.2, 3.0)
                        ctx.quadraticCurveTo(13.8, 3.0, 13.8, 4.6)
                        ctx.lineTo(13.8, 8.6)
                        ctx.quadraticCurveTo(13.8, 10.2, 12.2, 10.2)
                        ctx.lineTo(5.8, 10.2)
                        ctx.quadraticCurveTo(4.2, 10.2, 4.2, 8.6)
                        ctx.lineTo(4.2, 4.6)
                        ctx.quadraticCurveTo(4.2, 3.0, 5.8, 3.0)
                        ctx.stroke()

                        ctx.beginPath()
                        ctx.moveTo(7.1, 3.0)
                        ctx.lineTo(7.1, 4.9)
                        ctx.moveTo(10.9, 3.0)
                        ctx.lineTo(10.9, 4.9)
                        ctx.moveTo(9, 10.4)
                        ctx.lineTo(9, 12.7)
                        ctx.moveTo(4.2, 13.8)
                        ctx.lineTo(13.8, 13.8)
                        ctx.stroke()
                    }

                    Connections {
                        target: window
                        function onAccentChanged() { ethernetHeaderIcon.requestPaint() }
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                height: 1
                color: Qt.rgba(1, 1, 1, 0.08)
                Layout.bottomMargin: 12
            }

            // Contenedor de detalles Ethernet
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: ethGrid.implicitHeight + 24
                color: window.bgCard
                radius: 8
                border.color: window.border
                border.width: 1

                GridLayout {
                    id: ethGrid
                    anchors { fill: parent; margins: 12 }
                    columns: 2
                    rowSpacing: 10
                    columnSpacing: 20

                    QsText { text: "Interfaz:"; color: window.textSec; font.pixelSize: 12 }
                    QsText { text: window.ethInterface; color: window.textPri; font.weight: Font.Medium; font.pixelSize: 12 }

                    QsText { text: "Dirección IP:"; color: window.textSec; font.pixelSize: 12 }
                    QsText { text: window.ethIp; color: window.textPri; font.weight: Font.Medium; font.pixelSize: 12 }

                    QsText { text: "Puerta de enlace:"; color: window.textSec; font.pixelSize: 12 }
                    QsText { text: window.ethGateway; color: window.textPri; font.weight: Font.Medium; font.pixelSize: 12 }

                    QsText { text: "Servidor DNS:"; color: window.textSec; font.pixelSize: 12 }
                    QsText { text: window.ethDns; color: window.textPri; font.weight: Font.Medium; font.pixelSize: 12 }
                }
            }

            Item { Layout.fillHeight: true; Layout.preferredHeight: 12 }

            // Botón de configuración de red
            Rectangle {
                Layout.fillWidth: true
                height: 38
                radius: 8
                color: settingsHover.hovered ? Qt.rgba(1, 1, 1, 0.05) : "transparent"
                border.color: window.border
                border.width: 1

                RowLayout {
                    anchors.centerIn: parent
                    spacing: 8
                    QsText {
                        text: "Configuración de Red..."
                        color: window.textPri
                        font.family: "Inter"
                        font.pixelSize: 13
                    }
                }

                HoverHandler { id: settingsHover }
                TapHandler {
                    onTapped: {
                        window.visible = false
                        Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "-c", "nm-connection-editor || gnome-control-center network"]; running: true }', window)
                    }
                }
            }
        }

        // ── MODO WI-FI ──
        PanelNetworkList {
            id: networkList
            visible: !window.isEthernet
            anchors.fill: parent
            anchors.margins: 12
            bgCard: window.bgMain
            bgActive: window.bgActive
            border: "transparent"
            borderHi: window.border
            textPri: window.textPri
            textSec: window.textSec
            accentWf: window.accent

            onNetworkConnected: {
                window.visible = false
            }
            onCloseRequested: {
                window.visible = false
            }
        }
    }
}
