#!/bin/bash

set -u

SSID="${1:-}"
PASS="${2:-}"

notify_ok() {
    notify-send --icon=network-wireless --expire-time=2500 "Wi-Fi" "Conectado - $SSID" 2>/dev/null || true
}

notify_error() {
    notify-send --icon=network-wireless --expire-time=3000 "Wi-Fi" "$1" -u normal 2>/dev/null || true
}

wifi_iface() {
    nmcli -t -f DEVICE,TYPE,STATE dev 2>/dev/null \
        | awk -F: '$2 == "wifi" && $3 != "unavailable" {print $1; exit}'
}

saved_uuid_for_ssid() {
    local uuid type saved_ssid

    while IFS=: read -r uuid type; do
        [ "$type" = "802-11-wireless" ] || continue
        saved_ssid=$(nmcli --escape no -g 802-11-wireless.ssid connection show "$uuid" 2>/dev/null)
        [ "$saved_ssid" = "$SSID" ] || continue
        printf '%s\n' "$uuid"
        return 0
    done < <(nmcli -t -f UUID,TYPE connection show 2>/dev/null)

    return 1
}

delete_saved_ssid() {
    local uuid type saved_ssid

    while IFS=: read -r uuid type; do
        [ "$type" = "802-11-wireless" ] || continue
        saved_ssid=$(nmcli --escape no -g 802-11-wireless.ssid connection show "$uuid" 2>/dev/null)
        [ "$saved_ssid" = "$SSID" ] || continue
        nmcli connection delete uuid "$uuid" >/dev/null 2>&1 || true
    done < <(nmcli -t -f UUID,TYPE connection show 2>/dev/null)
}

has_visible_open_network() {
    nmcli --escape no -t -f SSID,SECURITY dev wifi list --rescan no 2>/dev/null \
        | awk -F: -v target="$SSID" '
            NF >= 2 {
                sec=$NF
                ssid=""
                for (i=1; i<NF; i++) ssid=ssid (i>1 ? ":" : "") $i
                if (ssid == target && (sec == "" || sec == "--")) found=1
            }
            END { exit found ? 0 : 1 }
        '
}

[ -n "$SSID" ] || exit 1

IFACE=$(wifi_iface)
if [ -z "$IFACE" ]; then
    notify_error "No encontré una interfaz Wi-Fi disponible."
    exit 1
fi

if [ -n "$PASS" ]; then
    delete_saved_ssid
    if nmcli --wait 20 device wifi connect "$SSID" password "$PASS" ifname "$IFACE" >/dev/null 2>&1; then
        UUID=$(saved_uuid_for_ssid || true)
        if [ -n "$UUID" ]; then
            nmcli connection modify uuid "$UUID" \
                802-11-wireless-security.psk-flags 0 \
                802-11-wireless-security.psk "$PASS" 2>/dev/null || true
        fi
        notify_ok
        exit 0
    fi

    delete_saved_ssid
    notify_error "No se pudo autenticar en $SSID."
    exit 1
fi

UUID=$(saved_uuid_for_ssid || true)
if [ -n "$UUID" ]; then
    if nmcli --wait 20 connection up uuid "$UUID" ifname "$IFACE" >/dev/null 2>&1; then
        notify_ok
        exit 0
    fi
    notify_error "La conexión guardada de $SSID no funcionó."
    exit 1
fi

if has_visible_open_network; then
    if nmcli --wait 20 device wifi connect "$SSID" ifname "$IFACE" >/dev/null 2>&1; then
        notify_ok
        exit 0
    fi

    notify_error "No se pudo conectar a $SSID."
    exit 1
fi

exit 2
