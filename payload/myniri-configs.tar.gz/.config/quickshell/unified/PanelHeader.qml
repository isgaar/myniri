// PanelHeader.qml — Zona 1: avatar + nombre + uptime + iconos
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

Item {
    id: root
    implicitHeight: 72

    property color bgCard
    property color border
    property color textPri
    property color textSec
    property color accent
    property bool panelVisible: false
    signal closeRequested()

    property string username: "ismael"
    property string uptime: "..."

    Process {
        command: ["bash", "-c", "uptime -p | sed 's/up //'"]
        running: root.panelVisible
        stdout: SplitParser {
            onRead: data => root.uptime = data.trim()
        }
    }

    Rectangle {
        anchors.fill: parent
        color: root.bgCard
        radius: 12
        border.color: root.border
        border.width: 1
    }

    Item {
        anchors { fill: parent; leftMargin: 14; rightMargin: 14 }

        // Avatar
        Rectangle {
            id: avatar
            anchors.left: parent.left
            anchors.verticalCenter: parent.verticalCenter
            width: 44; height: 44; radius: 22
            color: "#2e2e3a"
            border.color: root.border
            border.width: 1

            Image {
                anchors.fill: parent
                anchors.margins: 2
                source: "file:///var/lib/AccountsService/icons/" + root.username
                fillMode: Image.PreserveAspectCrop
                visible: status === Image.Ready
            }

            QsText {
                anchors.centerIn: parent
                text: root.username.substring(0, 2).toUpperCase()
                color: root.accent
                font.pixelSize: 15
                font.weight: Font.Medium
                visible: parent.children[0].status !== Image.Ready
            }
        }

        // Nombre + uptime
        Column {
            id: infoCol
            anchors.left: avatar.right
            anchors.leftMargin: 12
            anchors.verticalCenter: parent.verticalCenter
            spacing: 2

            QsText {
                text: root.username
                color: root.textPri
                font.pixelSize: 15
                font.weight: Font.Medium
            }
            QsText {
                text: "up " + root.uptime
                color: root.textSec
                font.pixelSize: 12
            }
        }

        // Iconos FA: lock, power, settings
        Row {
            id: iconsRow
            anchors.right: parent.right
            anchors.verticalCenter: parent.verticalCenter
            spacing: 6

            Repeater {
                model: [
                    { icon: "\uf023", cmd: ["bash", "-c", "swaylock -f"] },
                    { icon: "\uf011", cmd: ["bash", "-c", "bash ~/scripts/power_menu.sh"] },
                    { icon: "\uf013", cmd: ["bash", "-c", "qs ipc -c unified call settings toggle"] }
                ]

                delegate: Rectangle {
                    width: 30; height: 30; radius: 15
                    color: btnHover.hovered ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
                    border.color: btnHover.hovered ? root.border : "transparent"
                    border.width: 1
                    activeFocusOnTab: false
                    focus: false

                    QsText {
                        anchors.centerIn: parent
                        text: modelData.icon
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 13
                        color: root.textSec
                    }

                    HoverHandler { id: btnHover }
                    TapHandler {
                        onTapped: {
                            if (modelData.cmd[2] !== "")
                                Qt.createQmlObject(
                                    'import Quickshell.Io; Process { command: ' +
                                    JSON.stringify(modelData.cmd) + '; running: true }', root)
                            root.closeRequested()
                        }
                    }
                }
            }
        }
    }
}
