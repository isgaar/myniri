// BasePopup.qml — Componente base para todos los paneles y diálogos
import Quickshell
import Quickshell.Wayland
import QtQuick

PanelWindow {
    id: root

    // Configuración estándar de Wayland para paneles flotantes
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "quickshell"
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.OnDemand
    WlrLayershell.exclusionMode: ExclusionMode.Ignore

    // Estado base
    color: "transparent"
    visible: false

    // Posicionamiento estándar (puede ser sobreescrito)
    anchors.top: true
    margins.top: shellRoot.getPopupTopMargin(root.screen)

    // Paleta de Diseño Unificada global
    readonly property color bgMain: (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a"
    readonly property color bgCard: (shellRoot.themeConfig && shellRoot.themeConfig.bgCard) || "#2a2a2a"
    readonly property color bgTile: (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#333333"
    readonly property color border: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    readonly property color textPri: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
    readonly property color textSec: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
    readonly property color accent: (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property color bgActive: Qt.rgba(accent.r, accent.g, accent.b, 0.12)
    readonly property color accentHover: (shellRoot.themeConfig && shellRoot.themeConfig.accentHover) || "#4a97ce"
    readonly property color danger: (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e74c3c"
    readonly property color success: (shellRoot.themeConfig && shellRoot.themeConfig.success) || "#2ecc71"
    readonly property color warning: (shellRoot.themeConfig && shellRoot.themeConfig.warning) || "#f1c40f"
    readonly property bool cornersEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false
    readonly property int cornerRadius: (shellRoot.themeConfig && shellRoot.themeConfig.cornerRadius) !== undefined ? shellRoot.themeConfig.cornerRadius : 16
    readonly property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false

    // Default property wrapper para animar todos los paneles automáticamente
    default property alias content: container.data

    Item {
        id: container
        anchors.fill: parent
        
        opacity: root.visible ? 1 : 0
        Behavior on opacity {
            NumberAnimation { duration: 200 }
        }
    }
}
