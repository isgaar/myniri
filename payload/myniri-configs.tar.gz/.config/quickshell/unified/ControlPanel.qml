// ControlPanel.qml — Popup principal anclado arriba-derecha
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

BasePopup {
    id: root

    anchors {
        top: true
        left: true
    }
    margins.top: 40
    margins.left: root.anchorMargin

    property int anchorMargin: (root.screen ? root.screen.width : 1920) - root.implicitWidth - 8

    implicitWidth: 440
    implicitHeight: contentCol.implicitHeight + 24
    property int contentHeight: contentCol.implicitHeight + 24
    property string activeExpandedList: "none"

    onVisibleChanged: {
        if (visible) {
            shellRoot.updateMakoPosition("panel", "open", Math.round(root.implicitHeight + 55).toString())
            contentRect.forceActiveFocus(Qt.MouseFocusReason)
        } else {
            shellRoot.updateMakoPosition("panel", "closed")
            activeExpandedList = "none"
        }
    }

    function toggle(x) {
        if (visible) {
            visible = false
        } else {
            if (x !== undefined && x >= 0) {
                let screenW = root.screen ? root.screen.width : 1920
                root.anchorMargin = Math.max(8, Math.min(x - root.implicitWidth/2, screenW - root.implicitWidth - 8))
            }
            visible = true
        }
    }

    // Timer para refrescar tile WiFi tras conectar ─────────────
    Timer {
        id: wifiRefreshDelay
        interval: 2000
        repeat: false
        onTriggered: quickTiles.refreshWifi()
    }


    Rectangle {
        id: contentRect
        width: parent.width
        height: parent.height
        color: root.bgMain
        radius: (shellRoot.themeConfig && shellRoot.themeConfig.cornersEnabled) !== false ? (shellRoot.themeConfig.cornerRadius || 16) : 0
        border.color: root.border
        border.width: 1
        layer.enabled: true

        opacity: 0
        y: -15

        states: [
            State {
                name: "visible"
                when: root.visible
                PropertyChanges { target: contentRect; opacity: 1.0; y: 0 }
            }
        ]

        transitions: [
            Transition {
                from: ""
                to: "visible"
                enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
                ParallelAnimation {
                    NumberAnimation { property: "y"; duration: 180; easing.type: Easing.OutCubic }
                    NumberAnimation { property: "opacity"; duration: 150; easing.type: Easing.OutQuad }
                }
            }
        ]

        focus: true
        focusPolicy: Qt.NoFocus
        activeFocusOnTab: false
        palette.highlight: "transparent"
        palette.highlightedText: "#e8e6e0"
        palette.button: "transparent"
        palette.buttonText: "#e8e6e0"

        Keys.onEscapePressed: root.visible = false

        ColumnLayout {
            id: contentCol
            anchors {
                top: parent.top
                left: parent.left
                right: parent.right
                margins: 12
            }
            spacing: 8

            PanelHeader {
                Layout.fillWidth: true
                bgCard: root.bgCard
                border: root.border
                textPri: root.textPri
                textSec: root.textSec
                accent: root.accent
                panelVisible: root.visible
                onCloseRequested: root.visible = false
            }

            PanelSliders {
                Layout.fillWidth: true
                bgCard: root.bgCard
                border: root.border
                textSec: root.textSec
                accent: root.accent
                panelVisible: root.visible
            }

            PanelQuickTiles {
                id: quickTiles
                Layout.fillWidth: true
                bgCard: root.bgCard
                bgTile: root.bgTile
                border: root.border
                textPri: root.textPri
                textSec: root.textSec
                accentWf: root.accent
                accentBt: root.accent
                panelVisible: root.visible

                activeExpandedList: root.activeExpandedList
                onExpandListRequested: listName => {
                    root.activeExpandedList = (root.activeExpandedList === listName) ? "none" : listName
                }
            }

            PanelNetworkList {
                Layout.fillWidth: true
                visible: root.activeExpandedList === "wifi"
                bgCard: root.bgCard
                bgActive: root.bgActive
                border: root.border
                borderHi: root.border
                textPri: root.textPri
                textSec: root.textSec
                accent: root.accent
                accentWf: root.accent
                onNetworkConnected: {
                    quickTiles.refreshWifi()
                    wifiRefreshDelay.restart()
                }
                onCloseRequested: root.activeExpandedList = "none"
            }

            PanelBluetoothList {
                Layout.fillWidth: true
                visible: root.activeExpandedList === "bluetooth"
                bgCard: root.bgCard
                bgActive: root.bgActive
                border: root.border
                borderHi: root.border
                textPri: root.textPri
                textSec: root.textSec
                accent: root.accent
                accentBt: root.accent
            }

            PanelAudioTiles {
                Layout.fillWidth: true
                bgCard: root.bgCard
                bgTile: root.bgTile
                border: root.border
                textPri: root.textPri
                textSec: root.textSec
                accent: root.accent
                panelVisible: root.visible
            }

            PanelMicTiles {
                Layout.fillWidth: true
                bgCard: root.bgCard
                bgTile: root.bgTile
                border: root.border
                textPri: root.textPri
                textSec: root.textSec
                accent: root.accent
                panelVisible: root.visible
            }

            PanelToggles {
                Layout.fillWidth: true
                bgCard: root.bgCard
                bgTile: root.bgTile
                border: root.border
                textPri: root.textPri
                accent: root.accent
                panelVisible: root.visible
            }

            PanelMediaControl {
                Layout.fillWidth: true
                Layout.bottomMargin: 4
                bgCard: root.bgCard
                border: root.border
                textPri: root.textPri
                textSec: root.textSec
                accent: root.accent
                panelVisible: root.visible
            }
        }
    }
}
