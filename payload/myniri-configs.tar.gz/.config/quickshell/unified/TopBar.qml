// TopBar.qml — Barra superior de reemplazo para Waybar
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

PanelWindow {
    id: root
    visible: true

    anchors {
        top: true
        left: true
        right: true
    }

    implicitHeight: 32
    color: "transparent"

    WlrLayershell.layer: WlrLayer.Top
    WlrLayershell.namespace: "quickshell-topbar"
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    WlrLayershell.exclusiveZone: 32

    // Señales para comunicación con shell.qml
    signal togglePanel(real x)
    signal toggleCalendar(real x)
    signal toggleNotifications(real x)
    signal togglePower(real x)
    signal toggleBgApps(real x)
    signal toggleWifi(real x)
    signal toggleVolume(real x)
    signal toggleMic(real x)
    signal toggleBattery(real x)
    signal toggleMemory(real x)

    // ── Paleta de colores ────────────────────────────────────────
    readonly property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false
    readonly property color bgMain: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a";
        let base = Qt.color(raw);
        return blurEnabled ? Qt.rgba(base.r, base.g, base.b, 0.85) : base;
    }
    readonly property color bgCard: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgCard) || "#232323";
        let base = Qt.color(raw);
        return blurEnabled ? Qt.rgba(base.r, base.g, base.b, 0.85) : base;
    }
    readonly property color bgHover: {
        let base = Qt.color((shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de")
        return Qt.rgba(base.r, base.g, base.b, 0.25)
    }
    readonly property color textPri:  (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
    readonly property color textSec:  (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
    readonly property color accent:   (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property color accentGn: (shellRoot.themeConfig && shellRoot.themeConfig.accentGn) || "#5db06a"
    readonly property color border:   (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    readonly property color danger:   (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e06c6c"
    
    // Propiedades de estado
    property string activeAppName: "Niri"
    property string clockText: ""
    property string clockTooltip: ""
    property string batPercent: "—"
    property string batIcon: "\uf240"
    property string memUsage: "—"
    property string memUsedGb: "—"
    property string memTotalGb: "—"
    property string localIp: "—"
    property string volUsage: "—"
    property string micUsage: "—"
    property bool isMicMuted: false
    property bool isBluetoothActive: false
    property string bluetoothDevice: ""
    property string notifText: "\uf0f3"
    property bool hasUnreadNotifs: false
    property var workspaceGroups: []
    property var activeBgApps: []
    property string volumeAction: ""

    // Animated backing properties (smooth transitions)
    property real batLevelAnimated: 50
    property real memLevelAnimated: 50
    property real volLevelAnimated: 50
    property real wifiSignalAnimated: 0
    Behavior on batLevelAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
    Behavior on memLevelAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
    Behavior on volLevelAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
    Behavior on wifiSignalAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }

    // Pulso animado para nuevas notificaciones
    property bool prevHasUnread: false
    onHasUnreadNotifsChanged: {
        if (hasUnreadNotifs && !prevHasUnread) notifPulse.start()
        prevHasUnread = hasUnreadNotifs
    }

    SequentialAnimation {
        id: notifPulse
        loops: 3
        NumberAnimation { target: notifDot; property: "scale"; to: 1.6; duration: 200; easing.type: Easing.OutBack }
        NumberAnimation { target: notifDot; property: "scale"; to: 1.0; duration: 200 }
    }

    // Color de batería fluido
    property color batColor: batLevelAnimated <= 15 ? root.danger : batLevelAnimated <= 30 ? "#ff9f0a" : root.accentGn
    Behavior on batColor { ColorAnimation { duration: 400 } }
    
    IdleMonitor {
        id: idleMonitor
        timeout: 90
    }

    // Actualizador de Reloj (Optimizado a 10s de intervalo ya que no muestra segundos)
    Timer {
        id: clockTimer
        interval: 10000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: {
            let d = new Date();
            root.clockText = d.toLocaleDateString(Qt.locale("en_US"), "ddd dd MMM") + "  " + d.toLocaleTimeString(Qt.locale("en_US"), "hh:mm ap")
        }
        onRunningChanged: if (running) {
            let d = new Date();
            root.clockText = d.toLocaleDateString(Qt.locale("en_US"), "ddd dd MMM") + "  " + d.toLocaleTimeString(Qt.locale("en_US"), "hh:mm ap")
        }
    }

    // Lector de aplicación activa (Event-driven persistente, 0% CPU en reposo)
    Process {
        id: activeAppReader
        command: ["/home/ismael/scripts/active_app_listener.py"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                try {
                    let parsed = JSON.parse(data.trim())
                    root.activeAppName = parsed.text || "Niri"
                } catch(e) {}
            }
        }
    }

    // ── Funciones de Procesamiento de Workspaces (In-Memory Reactivas) ─────────
    function groupWorkspaces(workspacesList) {
        let groups = {};
        for (let i = 0; i < workspacesList.length; i++) {
            let w = workspacesList[i];
            if (!groups[w.output]) {
                groups[w.output] = [];
            }
            groups[w.output].push(w);
        }
        
        let groupedArray = [];
        let outputs = Object.keys(groups).sort();
        for (let i = 0; i < outputs.length; i++) {
            let out = outputs[i];
            let list = groups[out];
            list.sort((a, b) => a.idx - b.idx);
            groupedArray.push({
                output: out,
                workspaces: list.map(w => {
                    return {
                        name: w.name || w.idx.toString(),
                        focused: w.is_focused,
                        active: w.is_active,
                        id: w.id
                    }
                })
            });
        }
        return groupedArray;
    }

    function updateFocusedWorkspace(activatedId, focused) {
        let groups = root.workspaceGroups;
        if (!groups) return;

        // Buscar el output al que pertenece el workspace activado
        let activatedOutput = "";
        for (let i = 0; i < groups.length; i++) {
            let g = groups[i];
            for (let j = 0; j < g.workspaces.length; j++) {
                if (g.workspaces[j].id === activatedId) {
                    activatedOutput = g.output;
                    break;
                }
            }
            if (activatedOutput) break;
        }

        let newGroups = [];
        for (let i = 0; i < groups.length; i++) {
            let g = groups[i];
            let newWorkspaces = [];
            for (let j = 0; j < g.workspaces.length; j++) {
                let w = g.workspaces[j];
                let isTarget = (w.id === activatedId);
                let wFocused = w.focused;
                let wActive = w.active;

                if (isTarget) {
                    wActive = true;
                    wFocused = focused;
                } else {
                    if (g.output === activatedOutput) {
                        wActive = false;
                    }
                    if (focused) {
                        wFocused = false;
                    }
                }
                newWorkspaces.push({
                    name: w.name,
                    focused: wFocused,
                    active: wActive,
                    id: w.id
                });
            }
            newGroups.push({
                output: g.output,
                workspaces: newWorkspaces
            });
        }
        root.workspaceGroups = newGroups;
    }

    // Lector persistente del event-stream de Niri
    Process {
        id: wsListener
        command: ["niri", "msg", "--json", "event-stream"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                let lines = data.split("\n");
                for (let line of lines) {
                    if (!line.trim()) continue;
                    try {
                        let evt = JSON.parse(line.trim());
                        if (evt.WorkspacesChanged) {
                            root.workspaceGroups = root.groupWorkspaces(evt.WorkspacesChanged.workspaces);
                        } else if (evt.WorkspaceActivated) {
                            root.updateFocusedWorkspace(evt.WorkspaceActivated.id, evt.WorkspaceActivated.focused);
                        }
                    } catch(e) {}
                }
            }
        }
    }

    property string targetWorkspace: ""
    Process {
        id: wsSwitcher
        command: ["bash", "-c", "niri msg action " + root.targetWorkspace]
    }

    // Lector de batería
    Process {
        id: batteryReader
        command: ["bash", "-c", "cat /sys/class/power_supply/BAT*/capacity 2>/dev/null | head -n1 || echo '—'"]
        running: true
        stdout: SplitParser { onRead: data => {
            let p = parseInt(data.trim())
            if (!isNaN(p)) {
                root.batPercent = p.toString() + "%"
                root.batLevelAnimated = p
                if (p >= 88) root.batIcon = "\uf240"
                else if (p >= 63) root.batIcon = "\uf241"
                else if (p >= 38) root.batIcon = "\uf242"
                else if (p >= 13) root.batIcon = "\uf243"
                else root.batIcon = "\uf244"
            }
        } }
    }
    Timer {
        interval: 15000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: batteryReader.running = true
        onRunningChanged: if (running) batteryReader.running = true
    }

    // Wi-Fi / Ethernet
    property bool ethernetConnected: false
    Process {
        id: netStateReader
        command: ["bash", "-c", "IFACE=$(iw dev 2>/dev/null | awk '/Interface/{print $2; exit}'); ETH=$(nmcli -t -f DEVICE,TYPE,STATE device status 2>/dev/null | grep ':ethernet:connected' | cut -d: -f1 | head -1); [ -n \"$ETH\" ] && echo \"eth\" || echo \"wifi\"; if [ -n \"$IFACE\" ]; then iw dev \"$IFACE\" link 2>/dev/null | awk '/signal:/{print $2}' | tr -d 'dBm'; else echo '-90'; fi"]
        running: true
        stdout: SplitParser { onRead: data => {
            let line = data.trim()
            if (line === "eth" || line === "wifi") root.ethernetConnected = (line === "eth")
            else {
                let s = parseInt(line)
                if (!isNaN(s)) root.wifiSignalAnimated = Math.max(0, Math.min(100, ((s + 90) / 60) * 100))
            }
        } }
    }
    Process {
        id: ipReader
        command: ["bash", "-c", "ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}' || hostname -I | awk '{print $1}' || echo '—'"]
        running: true
        stdout: SplitParser { onRead: data => {
            let ip = data.trim()
            root.localIp = ip !== "" ? ip : "—"
        } }
    }
    Timer {
        interval: 15000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: { netStateReader.running = true; ipReader.running = true }
        onRunningChanged: if (running) { netStateReader.running = true; ipReader.running = true }
    }

    // Memoria
    Process {
        id: memReader
        command: ["awk", "/MemTotal/{t=$2} /MemAvailable/{a=$2} END{printf \"%.0f|%.1f|%.1f\", (t-a)*100/t, (t-a)/1024/1024, t/1024/1024}", "/proc/meminfo"]
        running: true
        stdout: SplitParser { onRead: data => { 
            let parts = data.trim().split("|")
            if (parts.length === 3) {
                let p = parseInt(parts[0])
                if (!isNaN(p)) {
                    root.memUsage = p + "%"
                    root.memLevelAnimated = p
                }
                root.memUsedGb = parts[1]
                root.memTotalGb = parts[2]
            }
        } }
    }
    Timer {
        interval: 15000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: memReader.running = true
        onRunningChanged: if (running) memReader.running = true
    }

    // Volumen y Mic
    Process {
        id: audioMonitor
        command: ["/home/ismael/scripts/audio_monitor.py"]
        running: true
        stdout: SplitParser { onRead: data => {
            let line = data.trim()
            if (line.startsWith("VOLUME ")) {
                let parts = line.split(" ")
                if (parts.length >= 2) {
                    let val = parseFloat(parts[1])
                    if (!isNaN(val)) { root.volUsage = Math.round(val * 100) + "%"; root.volLevelAnimated = Math.round(val * 100) }
                }
            } else if (line.startsWith("MIC ")) {
                let parts = line.split(" ")
                if (parts.length >= 2) {
                    let val = parseFloat(parts[1])
                    if (!isNaN(val)) {
                        root.micUsage = Math.round(val * 100) + "%"
                        root.isMicMuted = line.includes("MUTED")
                        if (root.isMicMuted) root.micUsage = "Silenciado"
                    }
                }
            }
        } }
    }

    Process {
        id: volumeAdjuster
        command: ["bash", "-c", "pactl set-sink-volume @DEFAULT_SINK@ " + root.volumeAction + "; pactl set-sink-mute @DEFAULT_SINK@ 0"]
    }

    // Bluetooth
    Process {
        id: btReader
        command: ["/home/ismael/scripts/bluetooth_monitor.py"]
        running: true
        stdout: SplitParser { onRead: data => {
            let line = data.trim()
            if (line.startsWith("yes")) {
                root.isBluetoothActive = true
                let colonIdx = line.indexOf(":")
                if (colonIdx !== -1) {
                    root.bluetoothDevice = line.substring(colonIdx + 1)
                } else {
                    root.bluetoothDevice = ""
                }
            } else {
                root.isBluetoothActive = false
                root.bluetoothDevice = ""
            }
        } }
    }

    Process {
        id: notifReader
        command: ["bash", "/home/ismael/scripts/notif_status.sh"]
        running: true
        stdout: SplitParser { onRead: data => {
            try { let parsed = JSON.parse(data.trim()); root.notifText = parsed.text || "\uf0f3"; root.hasUnreadNotifs = parsed.hasUnread === true } catch(e) {}
        } }
    }

    Process {
        id: bgAppsReader
        command: ["bash", "-c", "/home/ismael/scripts/get_bg_apps_json.sh"]
        running: true
        stdout: SplitParser { onRead: data => {
            try { let parsed = JSON.parse(data.trim()); root.activeBgApps = parsed } catch(e) {}
        } }
    }

    Timer {
        interval: 10000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: { notifReader.running = true; bgAppsReader.running = true }
        onRunningChanged: if (running) { notifReader.running = true; bgAppsReader.running = true }
    }

    // Componente base para los botones (píldoras)
    component BarPill: Rectangle {
        id: pillRoot
        property alias rowContent: container.data
        property bool isHovered: hover.hovered
        property alias tapHandler: tap
        property bool hasBorder: false

        height: 24
        implicitWidth: container.implicitWidth + (hasBorder ? 18 : 8)
        Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        
        WindowSettings { id: ws }
        radius: ws.cornersEnabled ? Math.min(ws.cornerRadius, 12) : 0
        color: hasBorder ? (isHovered ? root.bgHover : root.bgCard) : (isHovered ? root.bgHover : "transparent")
        border.color: hasBorder ? root.border : "transparent"
        border.width: hasBorder ? 1 : 0

        Behavior on color { ColorAnimation { duration: 150 } }
        
        scale: tap.pressed ? 0.90 : (isHovered ? 1.05 : 1.0)
        Behavior on scale { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }

        function getX() { return pillRoot.mapToItem(null, pillRoot.width / 2, 0).x }

        RowLayout {
            id: container
            anchors.centerIn: parent
            spacing: 6
        }

        HoverHandler { id: hover }
        TapHandler { id: tap }
    }

    Rectangle {
        id: barRect
        width: parent.width
        height: parent.height
        color: root.bgMain
        border.color: "transparent"
        border.width: 0
        
        y: 0
        opacity: 0

        Component.onCompleted: {
            let d = new Date();
            root.clockText = d.toLocaleDateString(Qt.locale("en_US"), "ddd dd MMM") + "  " + d.toLocaleTimeString(Qt.locale("en_US"), "hh:mm ap")
            slideDown.start()
        }

        ParallelAnimation {
            id: slideDown
            NumberAnimation { target: barRect; property: "y"; to: 0; duration: 600; easing.type: Easing.OutQuart }
            NumberAnimation { target: barRect; property: "opacity"; to: 1; duration: 400; easing.type: Easing.OutQuad }
        }

        MouseArea {
            anchors.fill: parent
            onWheel: (wheel) => {
                root.targetWorkspace = wheel.angleDelta.y > 0 ? "focus-workspace-up" : "focus-workspace-down"
                wsSwitcher.running = false
                wsSwitcher.running = true
            }
            onClicked: {
                shellRoot.closeAllPopups()
            }
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 8
            anchors.rightMargin: 8
            spacing: 4

            // ── IZQUIERDA ──
            RowLayout {
                Layout.alignment: Qt.AlignLeft | Qt.AlignVCenter
                spacing: 2

                Item {
                    width: wsGroupsRow.implicitWidth
                    height: 24
                    Layout.preferredWidth: width
                    Layout.preferredHeight: height

                    RowLayout {
                        id: wsGroupsRow
                        anchors.fill: parent
                        spacing: 8
                        Repeater {
                            model: root.workspaceGroups
                            delegate: RowLayout {
                                spacing: 2
                                Rectangle {
                                    visible: index > 0
                                    width: 1
                                    height: 12
                                    color: root.border
                                    Layout.leftMargin: 6
                                    Layout.rightMargin: 6
                                    Layout.alignment: Qt.AlignVCenter
                                }
                                Repeater {
                                    model: modelData.workspaces
                                    delegate: Rectangle {
                                        width: modelData.focused ? 26 : 20; height: 20; radius: 6
                                        color: modelData.focused ? root.textPri : modelData.active ? Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.15) : "transparent"
                                        border.color: modelData.active ? root.border : "transparent"
                                        border.width: modelData.active ? 1 : 0
                                        Behavior on width { NumberAnimation { duration: 350; easing.type: Easing.OutBack; easing.overshoot: 2.5 } }
                                        Behavior on color { ColorAnimation { duration: 150 } }
                                        QsText { renderType: Text.NativeRendering; anchors.centerIn: parent; text: modelData.name; color: modelData.focused ? root.bgMain : root.textSec; font.family: "Inter"; font.weight: Font.Bold; font.pixelSize: 11 }
                                        TapHandler {
                                            onTapped: {
                                                root.targetWorkspace = "focus-monitor " + parent.parent.parent.modelData.output + " && niri msg action focus-workspace " + modelData.name
                                                wsSwitcher.running = false
                                                wsSwitcher.running = true
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.NoButton
                        onWheel: (wheel) => {
                            root.targetWorkspace = wheel.angleDelta.y > 0 ? "focus-workspace-up" : "focus-workspace-down"
                            wsSwitcher.running = false
                            wsSwitcher.running = true
                        }
                    }
                }

                Item { width: 8; height: 1 }
                
                QsText { renderType: Text.NativeRendering; text: root.activeAppName; color: root.textPri; font.family: "Inter"; font.pixelSize: 13; font.weight: Font.Bold }
            }

            // ── CENTRO ──
            Item { Layout.fillWidth: true }

            // ── DERECHA ──
            RowLayout {
                Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
                spacing: 4

                // BgApps
                BarPill {
                    hasBorder: true
                    rowContent: [
                        RowLayout { spacing: 6; visible: root.activeBgApps.length > 0; Repeater { model: root.activeBgApps; QsText { smoothText: true; renderType: Text.NativeRendering; text: modelData.icon || "\uf013"; color: root.textPri; font.family: modelData.font_family || "Font Awesome 6 Free"; font.pixelSize: 12; font.weight: Font.Bold } } },
                        QsText { visible: root.activeBgApps.length === 0; renderType: Text.NativeRendering; text: "\uf077"; color: root.textPri; font.family: "Font Awesome 6 Free"; font.pixelSize: 12; font.weight: Font.Bold }
                    ]
                    tapHandler.onTapped: root.toggleBgApps(getX())
                }

                // Memoria
                BarPill {
                    id: memPill
                    rowContent: [
                        Item { width: 12; height: 12; implicitWidth: 12; implicitHeight: 12
                            Canvas { anchors.fill: parent
                                onPaint: { let ctx = getContext("2d"); ctx.reset(); ctx.lineWidth = 1.5; ctx.strokeStyle = root.textSec; ctx.beginPath(); ctx.arc(width/2, width/2, width/2 - 2, 0, Math.PI * 2); ctx.stroke(); let endAngle = (root.memLevelAnimated / 100) * Math.PI * 2 - Math.PI / 2; ctx.strokeStyle = root.accent; ctx.beginPath(); ctx.arc(width/2, width/2, width/2 - 2, -Math.PI / 2, endAngle); ctx.stroke() }
                            }
                            QsText { anchors.centerIn: parent; text: "\uf2db"; color: root.textSec; font.family: "Font Awesome 6 Free"; font.pixelSize: 7 }
                        },
                        Item {
                            id: memDetailWrap
                            clip: true
                            implicitWidth: memPill.isHovered ? memDetailText.implicitWidth : 0
                            implicitHeight: memDetailText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: memDetailText
                                renderType: Text.NativeRendering
                                text: root.memUsedGb + " GB / " + root.memTotalGb + " GB"
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12; font.weight: Font.Bold
                                opacity: memPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleMemory(getX())
                }

                // Mic
                BarPill {
                    rowContent: [
                        QsText { renderType: Text.NativeRendering; text: root.isMicMuted ? "\uf131" : "\uf130"; color: root.isMicMuted ? root.textSec : root.accent; font.family: "Font Awesome 6 Free"; font.pixelSize: 12; Behavior on color { ColorAnimation { duration: 200 } } }
                    ]
                    tapHandler.onTapped: root.toggleMic(getX())
                }

                // Volume
                BarPill {
                    id: volPill
                    rowContent: [
                        Item { width: 14; height: 12; implicitWidth: 14; implicitHeight: 12
                            Rectangle { anchors.bottom: parent.bottom; anchors.left: parent.left; anchors.right: parent.right; height: 2; radius: 1; color: root.border
                                Rectangle { anchors.left: parent.left; anchors.bottom: parent.bottom; width: parent.width * (root.volLevelAnimated / 100); height: parent.height; radius: 1; color: root.accentGn; Behavior on width { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } } }
                            }
                            QsText { anchors.centerIn: parent; text: root.volLevelAnimated === 0 ? "\uf6a9" : "\uf028"; color: root.textPri; font.family: "Font Awesome 6 Free"; font.pixelSize: 10 }
                        },
                        Item {
                            id: volPctWrap
                            clip: true
                            implicitWidth: volPill.isHovered ? volPctText.implicitWidth : 0
                            implicitHeight: volPctText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: volPctText
                                renderType: Text.NativeRendering
                                text: root.volUsage
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12; font.weight: Font.Bold
                                opacity: volPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleVolume(getX())

                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.NoButton
                        onWheel: (wheel) => {
                            root.volumeAction = wheel.angleDelta.y > 0 ? "+5%" : "-5%"
                            volumeAdjuster.running = false
                            volumeAdjuster.running = true
                        }
                    }
                }

                // Bluetooth
                BarPill {
                    rowContent: [
                        QsText {
                            renderType: Text.NativeRendering
                            text: root.isBluetoothActive ? "\uf294" : "\uf293"
                            color: root.isBluetoothActive ? root.accent : root.textSec
                            font.family: "Font Awesome 6 Brands"
                            font.pixelSize: 12
                        },
                        QsText {
                            visible: root.isBluetoothActive && root.bluetoothDevice !== ""
                            renderType: Text.NativeRendering
                            text: root.bluetoothDevice
                            color: root.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: Font.Medium
                        }
                    ]
                    tapHandler.onTapped: { Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "/home/ismael/scripts/bt_toggle.sh"]; running: true }', root) }
                }

                // Wifi / Ethernet
                BarPill {
                    id: netPill
                    rowContent: [
                        QsText { renderType: Text.NativeRendering; text: root.ethernetConnected ? "\uf796" : "\uf1eb"; color: root.textPri; font.family: "Font Awesome 6 Free"; font.pixelSize: 12 },
                        Item {
                            id: ipWrap
                            clip: true
                            implicitWidth: netPill.isHovered ? ipText.implicitWidth : 0
                            implicitHeight: ipText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: ipText
                                renderType: Text.NativeRendering
                                text: root.localIp
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12; font.weight: Font.Bold
                                opacity: netPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleWifi(getX())
                }

                // Batería
                BarPill {
                    id: batPill
                    rowContent: [
                        Item { width: 18; height: 12; implicitWidth: 18; implicitHeight: 12
                            Rectangle { anchors.fill: parent; radius: 2; color: "transparent"; border.color: root.batLevelAnimated <= 15 ? root.danger : root.textSec; border.width: 1.5
                                Rectangle { anchors.left: parent.left; anchors.top: parent.top; anchors.bottom: parent.bottom; anchors.leftMargin: 2; anchors.topMargin: 2; anchors.bottomMargin: 2; width: (parent.width - 4) * (root.batLevelAnimated / 100); radius: 1; color: root.batColor
                                    Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
                                }
                            }
                            Rectangle { anchors.left: parent.right; anchors.verticalCenter: parent.verticalCenter; width: 2; height: 4; radius: 1; color: root.batLevelAnimated <= 15 ? root.danger : root.textSec }
                        },
                        Item {
                            id: batPctWrap
                            clip: true
                            implicitWidth: batPill.isHovered ? batPctText.implicitWidth : 0
                            implicitHeight: batPctText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: batPctText
                                renderType: Text.NativeRendering
                                text: root.batPercent
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12; font.weight: Font.Bold
                                opacity: batPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleBattery(getX())
                }

                // Menú principal
                BarPill {
                    rowContent: [ QsText { renderType: Text.NativeRendering; text: "\uf0c9"; color: root.textPri; font.family: "Font Awesome 6 Free"; font.pixelSize: 12 } ]
                    tapHandler.onTapped: root.togglePanel(getX())
                }

                // Notificaciones
                BarPill {
                    rowContent: [
                        Item {
                            width: 14; height: 14
                            implicitWidth: 14; implicitHeight: 14
                            QsText {
                                anchors.centerIn: parent
                                renderType: Text.NativeRendering
                                text: root.notifText
                                color: root.hasUnreadNotifs ? root.danger : root.textPri
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 12
                            }
                            Rectangle {
                                id: notifDot
                                visible: root.hasUnreadNotifs
                                width: 6; height: 6; radius: 3
                                color: root.danger
                                anchors.top: parent.top
                                anchors.right: parent.right
                                anchors.topMargin: -1
                                anchors.rightMargin: -1
                                transformOrigin: Item.Center
                                scale: 1.0
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleNotifications(getX())
                }

                // Reloj
                BarPill {
                    color: "transparent"
                    border.color: "transparent"
                    rowContent: [ QsText { renderType: Text.NativeRendering; text: root.clockText; color: root.textPri; font.family: "Inter"; font.pixelSize: 13; font.weight: Font.Bold } ]
                    tapHandler.onTapped: root.toggleCalendar(getX())
                }

                // Energía
                BarPill {
                    rowContent: [ QsText { renderType: Text.NativeRendering; text: "\uf011"; color: root.textPri; font.family: "Font Awesome 6 Free"; font.pixelSize: 12 } ]
                    tapHandler.onTapped: root.togglePower(getX())
                }
            }
        }
    }
}
