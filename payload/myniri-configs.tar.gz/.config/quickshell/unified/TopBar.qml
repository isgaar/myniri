// TopBar.qml — Barra superior de reemplazo para Waybar
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects

PanelWindow {
    id: root
    visible: true

    anchors {
        top: true
        left: true
        right: true
    }

    implicitHeight: 32
    color: "transparent"

    WlrLayershell.layer: WlrLayer.Top
    WlrLayershell.namespace: "quickshell-topbar"
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    WlrLayershell.exclusiveZone: 32

    // Señales para comunicación con shell.qml
    signal togglePanel(real x)
    signal toggleCalendar(real x)
    signal toggleNotifications(real x)
    signal togglePower(real x)
    signal toggleBgApps(real x)
    signal toggleEject(real x)
    signal toggleWifi(real x)
    signal toggleBluetooth(real x)
    signal toggleVolume(real x)
    signal toggleMic(real x)
    signal toggleBattery(real x)
    signal toggleMemory(real x)

    // ── Paleta de colores ────────────────────────────────────────
    readonly property bool blurEnabled: (shellRoot.themeConfig && shellRoot.themeConfig.blurEnabled) !== false
    readonly property color bgMain: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgMain) || "#1a1a1a";
        let base = Qt.color(raw);
        return blurEnabled ? Qt.rgba(base.r, base.g, base.b, 0.85) : base;
    }
    readonly property color bgCard: {
        let raw = (shellRoot.themeConfig && shellRoot.themeConfig.bgCard) || "#232323";
        let base = Qt.color(raw);
        return blurEnabled ? Qt.rgba(base.r, base.g, base.b, 0.85) : base;
    }
    readonly property color bgHover: {
        let base = Qt.color((shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de")
        return Qt.rgba(base.r, base.g, base.b, 0.25)
    }
    readonly property string topbarStyle: (shellRoot.themeConfig && shellRoot.themeConfig.topbarStyle) || "actual"
    readonly property bool cupertinoTopbar: topbarStyle === "cupertino"
    readonly property string wallpaperBrightnessLeft: (shellRoot.themeConfig && shellRoot.themeConfig.wallpaperBrightnessLeft) || "dark"
    readonly property string wallpaperBrightnessRight: (shellRoot.themeConfig && shellRoot.themeConfig.wallpaperBrightnessRight) || "dark"
    readonly property bool cupertinoWallpaperIsDarkLeft: root.isFocusedWindowFullscreen || root.wallpaperBrightnessLeft === "dark"
    readonly property bool cupertinoWallpaperIsDarkRight: root.isFocusedWindowFullscreen || root.wallpaperBrightnessRight === "dark"

    // Colores para la izquierda (Workspaces, Título)
    readonly property color cupertinoForegroundLeft: cupertinoWorkspaceTextLeft
    readonly property color cupertinoForegroundMutedLeft: cupertinoWallpaperIsDarkLeft ? Qt.rgba(0.97, 0.98, 0.96, 0.68) : Qt.rgba(0.08, 0.09, 0.10, 0.58)
    readonly property color cupertinoWorkspaceBgLeft: cupertinoWallpaperIsDarkLeft ? Qt.rgba(1, 1, 1, 0.72) : Qt.rgba(0, 0, 0, 0.72)
    readonly property color cupertinoWorkspaceTextLeft: cupertinoWallpaperIsDarkLeft ? Qt.rgba(0.04, 0.045, 0.04, 0.96) : Qt.rgba(0.97, 0.98, 0.96, 0.96)
    readonly property color cupertinoShadowColorLeft: cupertinoWallpaperIsDarkLeft ? Qt.rgba(0, 0, 0, 0.40) : "transparent"
    readonly property color cupertinoPillBgLeft: cupertinoWallpaperIsDarkLeft ? Qt.rgba(1, 1, 1, 0.28) : Qt.rgba(0, 0, 0, 0.12)
    readonly property color cupertinoPillBorderLeft: cupertinoWallpaperIsDarkLeft ? Qt.rgba(0, 0, 0, 0.28) : Qt.rgba(1, 1, 1, 0.28)

    // Colores para la derecha (Tray, Reloj, Apagado)
    readonly property color cupertinoForegroundRight: cupertinoWallpaperIsDarkRight ? Qt.rgba(0.97, 0.98, 0.96, 0.96) : Qt.rgba(0.08, 0.09, 0.10, 0.90)
    readonly property color cupertinoForegroundMutedRight: cupertinoWallpaperIsDarkRight ? Qt.rgba(0.97, 0.98, 0.96, 0.68) : Qt.rgba(0.08, 0.09, 0.10, 0.58)
    readonly property color cupertinoShadowColorRight: cupertinoWallpaperIsDarkRight ? Qt.rgba(0, 0, 0, 0.40) : "transparent"
    readonly property color cupertinoPillBgRight: cupertinoWallpaperIsDarkRight ? Qt.rgba(1, 1, 1, 0.28) : Qt.rgba(0, 0, 0, 0.12)
    readonly property color cupertinoPillBorderRight: cupertinoWallpaperIsDarkRight ? Qt.rgba(0, 0, 0, 0.28) : Qt.rgba(1, 1, 1, 0.28)
    readonly property color cupertinoPillHoverRight: cupertinoWallpaperIsDarkRight ? Qt.rgba(1, 1, 1, 0.42) : Qt.rgba(0, 0, 0, 0.22)

    readonly property color textPriLeft: cupertinoTopbar ? (cupertinoWallpaperIsDarkLeft ? Qt.rgba(0.97, 0.98, 0.96, 0.96) : Qt.rgba(0.08, 0.09, 0.10, 0.90)) : ((shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8")
    readonly property color textSecLeft: cupertinoTopbar ? cupertinoForegroundMutedLeft : ((shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88")

    readonly property color textPriRight: cupertinoTopbar ? cupertinoForegroundRight : ((shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8")
    readonly property color textSecRight: cupertinoTopbar ? cupertinoForegroundMutedRight : ((shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88")

    readonly property color textPri: textPriRight
    readonly property color textSec: textSecRight
    readonly property int topbarTextWeight: Font.DemiBold
    readonly property color accent:   (shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de"
    readonly property color accentGn: (shellRoot.themeConfig && shellRoot.themeConfig.accentGn) || "#5db06a"
    readonly property color border:   (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
    readonly property color danger:   (shellRoot.themeConfig && shellRoot.themeConfig.danger) || "#e06c6c"
    
    // Propiedades de estado
    property bool isFocusedWindowFullscreen: false
    property string activeAppName: "Niri"
    property string clockText: ""
    property string clockTooltip: ""
    property string batPercent: "—"
    property string batIcon: "\uf240"
    property string memUsage: "—"
    property string memUsedGb: "—"
    property string memTotalGb: "—"
    property string localIp: "—"
    property string netType: "none"
    property string netName: "—"
    property string netSpeed: "—"
    property bool netConnected: false
    property string volUsage: "—"
    property string micUsage: "—"
    property bool isMicMuted: false
    property bool isBluetoothActive: false
    property bool isCharging: false
    property string bluetoothDevice: ""
    property string btDeviceBattery: ""
    property string btDeviceType: ""

    onBluetoothDeviceChanged: {
        if (bluetoothDevice !== "") {
            btDetailsReader.running = false
            btDetailsReader.running = true
        } else {
            root.btDeviceBattery = ""
            root.btDeviceType = ""
        }
    }
    property string notifText: "\uf0f3"
    property bool hasUnreadNotifs: false
    property var workspaceGroups: []
    property var activeBgApps: []
    property int ejectDeviceCount: 0
    property string volumeAction: ""
    property bool isVolMuted: false

    // Animated backing properties (smooth transitions)
    property real batLevelAnimated: 50
    property real memLevelAnimated: 50
    property real volLevelAnimated: 50
    property real wifiSignalAnimated: 0
    Behavior on batLevelAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
    Behavior on memLevelAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
    Behavior on volLevelAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
    Behavior on wifiSignalAnimated { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }

    // Pulso animado para nuevas notificaciones
    property bool prevHasUnread: false
    onHasUnreadNotifsChanged: {
        if (hasUnreadNotifs && !prevHasUnread) notifPulse.start()
        prevHasUnread = hasUnreadNotifs
    }

    SequentialAnimation {
        id: notifPulse
        loops: 3
        NumberAnimation { target: notifDot; property: "scale"; to: 1.6; duration: 200; easing.type: Easing.OutBack }
        NumberAnimation { target: notifDot; property: "scale"; to: 1.0; duration: 200 }
    }

    // Color de batería fluido
    property color batColor: batLevelAnimated <= 15 ? root.danger : batLevelAnimated <= 30 ? "#ff9f0a" : root.accentGn
    Behavior on batColor { ColorAnimation { duration: 400 } }
    
    IdleMonitor {
        id: idleMonitor
        timeout: 90
    }

    function updateClock() {
        let d = new Date();
        root.clockText = d.toLocaleDateString(Qt.locale("en_US"), "ddd dd MMM") + "  " + d.toLocaleTimeString(Qt.locale("en_US"), "hh:mm ap")
    }

    // Actualizador de Reloj. No depende del idle para evitar que muestre una hora vieja.
    Timer {
        id: clockTimer
        interval: 1000; running: true; repeat: true
        onTriggered: root.updateClock()
    }

    // Helper de formato en JS
    function formatAppName(appName, title) {
        if (!appName) appName = "";
        if (!title) title = "";
        
        let val = (appName + " " + title).toLowerCase();
        let title_lc = title.toLowerCase();
        
        if (val.includes("kitty")) return "Kitty";
        if (val.includes("codium") || val.includes("visual studio code")) return "VSCodium";
        if (val.includes("firefox")) return "Firefox";
        if (val.includes("brave")) return "Brave";
        if (val.includes("zen")) return "Zen";
        if (val.includes("dolphin")) return "Dolphin";
        if (val.includes("discord")) return "Discord";
        if (val.includes("telegram")) return "Telegram";
        if (val.includes("spotify")) return "Spotify";
        if (val.includes("steam")) return "Steam";
        if (val.includes("okular")) return "Okular";
        if (val.includes("krita")) return "Krita";
        if (val.includes("konsole")) return "Konsole";
        if (val.includes("antigravity")) return "Antigravity";
        
        if (title && title !== "null" && title_lc !== "focused") {
            let t = title.replace(/\s+-\s+.*$/, "")
                         .replace(/\s+—\s+.*$/, "")
                         .replace(/\s*\|.*$/, "");
            if (t) {
                return t.charAt(0).toUpperCase() + t.slice(1);
            }
        }
        
        if (appName && appName !== "null") {
            return appName.charAt(0).toUpperCase() + appName.slice(1);
        }
        
        return "Niri";
    }

    // Temporizador de debounce para evitar condiciones de carrera (80ms)
    Timer {
        id: activeAppDebounceTimer
        interval: 80
        repeat: false
        onTriggered: {
            activeAppQuery.running = false;
            activeAppQuery.running = true;
        }
    }

    // Consulta puntual de ventana enfocada
    Process {
        id: activeAppQuery
        command: ["niri", "msg", "--json", "windows"]
        stdout: SplitParser {
            onRead: data => {
                let trimmed = data.trim();
                if (!trimmed) return;
                try {
                    let windows = JSON.parse(trimmed);
                    let focused = windows.find(w => w.is_focused);
                    if (focused) {
                        root.activeAppName = formatAppName(focused.app_id, focused.title);
                    } else {
                        root.activeAppName = "Niri";
                    }

                    let isFS = false;
                    let activeWsId = -1;
                    if (root.workspaceGroups && root.screen) {
                        let group = root.workspaceGroups.find(g => g.output === root.screen.name);
                        if (group) {
                            let activeWs = group.workspaces.find(w => w.active);
                            if (activeWs) activeWsId = activeWs.id;
                        }
                    }

                    for (let i = 0; i < windows.length; i++) {
                        let w = windows[i];
                        let isTarget = (activeWsId !== -1) ? (w.workspace_id === activeWsId) : w.is_focused;
                        if (isTarget && w.layout && w.layout.tile_size) {
                            let tileWidth = w.layout.tile_size[0];
                            let tileHeight = w.layout.tile_size[1];
                            let screenWidth = (root.screen && root.screen.width) ? root.screen.width : 1920;
                            let screenHeight = (root.screen && root.screen.height) ? root.screen.height : 1080;
                            if (tileWidth >= screenWidth - 15 && tileHeight >= screenHeight - 45) {
                                isFS = true;
                                break;
                            }
                        }
                    }
                    root.isFocusedWindowFullscreen = isFS;
                } catch(e) {}
            }
        }
    }

    // Timer to monitor active window focus and fullscreen state periodically (backup for layout updates)
    Timer {
        id: activeAppWatcher
        interval: 500
        repeat: true
        running: root.cupertinoTopbar
        triggeredOnStart: true
        onTriggered: {
            activeAppDebounceTimer.restart();
        }
    }

    // ── Funciones de Procesamiento de Workspaces (In-Memory Reactivas) ─────────
    function groupWorkspaces(workspacesList) {
        let groups = {};
        for (let i = 0; i < workspacesList.length; i++) {
            let w = workspacesList[i];
            if (!groups[w.output]) {
                groups[w.output] = [];
            }
            groups[w.output].push(w);
        }
        
        let groupedArray = [];
        let outputs = Object.keys(groups).sort();
        for (let i = 0; i < outputs.length; i++) {
            let out = outputs[i];
            let list = groups[out];
            list.sort((a, b) => a.idx - b.idx);
            groupedArray.push({
                output: out,
                workspaces: list.map(w => {
                    return {
                        name: w.name || w.idx.toString(),
                        focused: w.is_focused,
                        active: w.is_active,
                        id: w.id
                    }
                })
            });
        }
        return groupedArray;
    }

    function updateFocusedWorkspace(activatedId, focused) {
        let groups = root.workspaceGroups;
        if (!groups) return;

        // Buscar el output al que pertenece el workspace activado
        let activatedOutput = "";
        for (let i = 0; i < groups.length; i++) {
            let g = groups[i];
            for (let j = 0; j < g.workspaces.length; j++) {
                if (g.workspaces[j].id === activatedId) {
                    activatedOutput = g.output;
                    break;
                }
            }
            if (activatedOutput) break;
        }

        let newGroups = [];
        for (let i = 0; i < groups.length; i++) {
            let g = groups[i];
            let newWorkspaces = [];
            for (let j = 0; j < g.workspaces.length; j++) {
                let w = g.workspaces[j];
                let isTarget = (w.id === activatedId);
                let wFocused = w.focused;
                let wActive = w.active;

                if (isTarget) {
                    wActive = true;
                    wFocused = focused;
                } else {
                    if (g.output === activatedOutput) {
                        wActive = false;
                    }
                    if (focused) {
                        wFocused = false;
                    }
                }
                newWorkspaces.push({
                    name: w.name,
                    focused: wFocused,
                    active: wActive,
                    id: w.id
                });
            }
            newGroups.push({
                output: g.output,
                workspaces: newWorkspaces
            });
        }
        root.workspaceGroups = newGroups;
    }

    // Lector de event-stream de Niri corregido
    Process {
        id: wsListener
        command: ["niri", "msg", "--json", "event-stream"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim();
                if (!line) return;
                try {
                    let evt = JSON.parse(line);
                    if (evt.WorkspacesChanged) {
                        root.workspaceGroups = root.groupWorkspaces(evt.WorkspacesChanged.workspaces);
                    } else if (evt.WorkspaceActivated) {
                        root.updateFocusedWorkspace(evt.WorkspaceActivated.id, evt.WorkspaceActivated.focused);
                        activeAppDebounceTimer.restart();
                    } else if (evt.WindowFocusChanged || evt.WindowOpened || evt.WindowClosed || evt.WindowsChanged) {
                        activeAppDebounceTimer.restart();
                    }
                } catch(e) {}
            }
        }
    }

    property string targetWorkspace: ""
    Process {
        id: wsSwitcher
        command: ["bash", "-c", "niri msg action " + root.targetWorkspace]
    }

    // Lector de batería
    Process {
        id: batteryReader
        command: ["bash", "-c", "cat /sys/class/power_supply/BAT*/capacity 2>/dev/null | head -n1 || echo '—'"]
        running: true
        stdout: SplitParser { onRead: data => {
            let p = parseInt(data.trim())
            if (!isNaN(p)) {
                root.batPercent = p.toString() + "%"
                root.batLevelAnimated = p
                if (p >= 88) root.batIcon = "\uf240"
                else if (p >= 63) root.batIcon = "\uf241"
                else if (p >= 38) root.batIcon = "\uf242"
                else if (p >= 13) root.batIcon = "\uf243"
                else root.batIcon = "\uf244"
            }
        } }
    }
    Process {
        id: chargingReader
        command: ["bash", "-c", "cat /sys/class/power_supply/BAT*/status 2>/dev/null | head -n1 || echo 'Unknown'"]
        running: true
        stdout: SplitParser { onRead: data => {
            root.isCharging = data.trim() === "Charging"
        } }
    }
    Process {
        id: ejectDeviceCountReader
        command: ["bash", "-c", "if lsblk -J -o HOTPLUG,TYPE >/dev/null 2>&1; then lsblk -J -o HOTPLUG,TYPE | jq '[.blockdevices[]? | .. | objects | select(.type? == \"part\" and .hotplug? == true)] | length'; else lsblk -r -o HOTPLUG,TYPE 2>/dev/null | awk '\$1==\"1\" && \$2==\"part\" {count++} END {print count+0}'; fi"]
        running: true
        stdout: SplitParser { onRead: data => {
            let count = parseInt(data.trim())
            if (!isNaN(count)) root.ejectDeviceCount = count
        } }
    }
    Process {
        id: udevMonitor
        command: ["udevadm", "monitor", "--kernel", "--subsystem-match=block"]
        running: true
        stdout: SplitParser { onRead: data => {
            let line = data.trim()
            if (line.includes(" add ") || line.includes(" remove ")) {
                ejectDeviceCountReader.running = false
                ejectDeviceCountReader.running = true
            }
        } }
    }
    Timer {
        interval: 15000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: { batteryReader.running = true; chargingReader.running = true; ejectDeviceCountReader.running = true }
        onRunningChanged: if (running) { batteryReader.running = true; chargingReader.running = true; ejectDeviceCountReader.running = true }
    }

    // Wi-Fi / Ethernet
    property bool ethernetConnected: false
    Process {
        id: netReader
        command: ["/home/ismael/scripts/honey_network_status.sh"]
        running: true
        stdout: SplitParser { onRead: data => {
            let parts = data.trim().split("\t")
            if (parts.length >= 5) {
                root.netType = parts[0]
                root.netName = parts[1] || "—"
                let signal = parseInt(parts[2])
                root.wifiSignalAnimated = isNaN(signal) ? 0 : Math.max(0, Math.min(100, signal))
                root.localIp = parts[3] || "—"
                root.netSpeed = parts.slice(4).join("\t") || "—"
                root.ethernetConnected = root.netType === "ethernet"
                root.netConnected = root.netType === "ethernet" || root.netType === "wifi"
            }
        } }
    }
    Timer {
        interval: 15000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: {
            netReader.running = true
            if (bluetoothDevice !== "") {
                btDetailsReader.running = false
                btDetailsReader.running = true
            }
        }
        onRunningChanged: if (running) {
            netReader.running = true
            if (bluetoothDevice !== "") {
                btDetailsReader.running = false
                btDetailsReader.running = true
            }
        }
    }

    // Memoria
    Process {
        id: memReader
        command: ["awk", "/MemTotal/{t=$2} /MemAvailable/{a=$2} END{printf \"%.0f|%.1f|%.1f\", (t-a)*100/t, (t-a)/1024/1024, t/1024/1024}", "/proc/meminfo"]
        running: true
        stdout: SplitParser { onRead: data => { 
            let parts = data.trim().split("|")
            if (parts.length === 3) {
                let p = parseInt(parts[0])
                if (!isNaN(p)) {
                    root.memUsage = p + "%"
                    root.memLevelAnimated = p
                }
                root.memUsedGb = parts[1]
                root.memTotalGb = parts[2]
            }
        } }
    }
    Timer {
        interval: 15000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: memReader.running = true
        onRunningChanged: if (running) memReader.running = true
    }

    // Temporizador de reinicio para eventos de audio
    Timer {
        id: audioRestartTimer
        interval: 1000
        repeat: false
        onTriggered: {
            audioEvents.running = false;
            audioEvents.running = true;
        }
    }

    // Escucha de eventos de PulseAudio/PipeWire
    Process {
        id: audioEvents
        command: ["pactl", "subscribe"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim();
                if (line.includes("sink") || line.includes("source") || line.includes("server")) {
                    audioQuery.running = false;
                    audioQuery.running = true;
                }
            }
        }
        onExited: {
            audioRestartTimer.restart();
        }
    }

    // Consulta puntual con marcas unívocas SINK y SOURCE
    Process {
        id: audioQuery
        command: ["bash", "-c", "echo SINK $(wpctl get-volume @DEFAULT_AUDIO_SINK@); echo SOURCE $(wpctl get-volume @DEFAULT_AUDIO_SOURCE@)"]
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim();
                let parts = line.split(/\s+/);
                if (parts.length >= 3) {
                    let val = parseFloat(parts[2]);
                    if (!isNaN(val)) {
                        if (parts[0] === "SINK") {
                            root.volUsage = Math.round(val * 100) + "%";
                            root.volLevelAnimated = Math.round(val * 100);
                            root.isVolMuted = line.includes("[MUTED]");
                            if (root.isVolMuted) root.volUsage = "Silenciado";
                        } else if (parts[0] === "SOURCE") {
                            root.micUsage = Math.round(val * 100) + "%";
                            root.isMicMuted = line.includes("[MUTED]");
                            if (root.isMicMuted) root.micUsage = "Silenciado";
                        }
                    }
                }
            }
        }
    }

    Process {
        id: volumeAdjuster
        command: ["bash", "-c", "pactl set-sink-volume @DEFAULT_SINK@ " + root.volumeAction + "; pactl set-sink-mute @DEFAULT_SINK@ 0"]
    }

    // Temporizador de debounce para Bluetooth (150ms)
    Timer {
        id: btDebounceTimer
        interval: 150
        repeat: false
        onTriggered: {
            btQuery.running = false;
            btQuery.running = true;
        }
    }

    // Temporizador de reinicio para eventos de Bluetooth
    Timer {
        id: btRestartTimer
        interval: 1000
        repeat: false
        onTriggered: {
            btEvents.running = false;
            btEvents.running = true;
        }
    }

    // Escucha DBus asíncrona no-bloqueante
    Process {
        id: btEvents
        command: ["dbus-monitor", "--system", "type='signal',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged',path_namespace='/org/bluez'"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                btDebounceTimer.restart();
            }
        }
        onExited: {
            btRestartTimer.restart();
        }
    }

    // Consulta de estado delegada al script shell externo
    Process {
        id: btQuery
        command: ["bash", "/home/ismael/scripts/qs_bt_status.sh"]
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim();
                if (line.startsWith("yes")) {
                    root.isBluetoothActive = true;
                    let colonIdx = line.indexOf(":");
                    if (colonIdx !== -1) {
                        root.bluetoothDevice = line.substring(colonIdx + 1);
                    } else {
                        root.bluetoothDevice = "";
                    }
                } else {
                    root.isBluetoothActive = false;
                    root.bluetoothDevice = "";
                }
            }
        }
    }
    Process {
        id: btDetailsReader
        command: ["bash", "-c", "bluetoothctl devices Connected 2>/dev/null | while read -r _ mac name; do info=$(bluetoothctl info \"$mac\" 2>/dev/null); bat=$(echo \"$info\" | grep -i \"Battery Percentage:\" | grep -o -E '\\([0-9]+\\)' | tr -d '()'); [ -z \"$bat\" ] && bat=$(echo \"$info\" | grep -i \"Battery Percentage:\" | awk '{print $NF}'); icon=$(echo \"$info\" | grep \"Icon:\" | awk '{print $2}'); type=\"Dispositivo\"; if [[ \"$icon\" == *audio* || \"$icon\" == *headset* ]]; then type=\"Audífonos\"; elif [[ \"$icon\" == *keyboard* ]]; then type=\"Teclado\"; elif [[ \"$icon\" == *mouse* ]]; then type=\"Mouse\"; elif [[ \"$icon\" == *gamepad* || \"$icon\" == *gaming* ]]; then type=\"Control\"; elif [[ \"$icon\" == *phone* ]]; then type=\"Teléfono\"; fi; echo \"$bat|$type\"; exit; done"]
        running: false
        stdout: SplitParser { onRead: data => {
            let parts = data.trim().split("|")
            if (parts.length >= 2) {
                root.btDeviceBattery = parts[0] !== "" ? parts[0] : ""
                root.btDeviceType = parts[1]
            } else {
                root.btDeviceBattery = ""
                root.btDeviceType = ""
            }
        } }
    }

    Process {
        id: notifReader
        command: ["bash", "/home/ismael/scripts/notif_status.sh"]
        running: true
        stdout: SplitParser { onRead: data => {
            try { let parsed = JSON.parse(data.trim()); root.notifText = parsed.text || "\uf0f3"; root.hasUnreadNotifs = parsed.hasUnread === true } catch(e) {}
        } }
    }

    Process {
        id: bgAppsReader
        command: ["bash", "-c", "/home/ismael/scripts/get_bg_apps_json.sh"]
        running: true
        stdout: SplitParser { onRead: data => {
            try { let parsed = JSON.parse(data.trim()); root.activeBgApps = parsed } catch(e) {}
        } }
    }

    Timer {
        interval: 10000; running: !idleMonitor.isIdle; repeat: true
        onTriggered: { notifReader.running = true; bgAppsReader.running = true }
        onRunningChanged: if (running) { notifReader.running = true; bgAppsReader.running = true }
    }

    // Componente base para los botones (píldoras)
    component BarPill: Rectangle {
        id: pillRoot
        property alias rowContent: container.data
        property bool isHovered: hover.hovered
        property alias tapHandler: tap
        property bool hasBorder: false

        height: 24
        implicitWidth: container.implicitWidth + (hasBorder ? 18 : 8)
        Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        
        WindowSettings { id: ws }
        radius: ws.cornersEnabled ? Math.min(ws.cornerRadius, 12) : 0
        color: hasBorder
            ? (isHovered ? (root.cupertinoTopbar ? root.cupertinoPillHoverRight : root.bgHover) : (root.cupertinoTopbar ? root.cupertinoPillBgRight : root.bgCard))
            : (isHovered ? (root.cupertinoTopbar ? root.cupertinoPillHoverRight : root.bgHover) : "transparent")
        border.color: hasBorder ? (root.cupertinoTopbar ? root.cupertinoPillBorderRight : root.border) : "transparent"
        border.width: hasBorder ? 1 : 0

        Behavior on color { ColorAnimation { duration: 150 } }
        
        // Native text rendering keeps Quartz-like glyphs only while the item is
        // drawn at device scale. Hover/click feedback uses color/width instead.
        scale: 1.0

        function getX() { return pillRoot.mapToItem(null, pillRoot.width / 2, 0).x }

        RowLayout {
            id: container
            anchors.centerIn: parent
            spacing: 6
        }

        HoverHandler { id: hover }
        TapHandler { id: tap }
    }

    component NetworkSignalIcon: Item {
        id: netIcon
        property bool ethernet: false
        property bool connected: false
        property real signal: 0
        property color activeColor: root.textPri
        property color inactiveColor: Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.25)
        property color offlineColor: root.textSec

        width: 18
        height: 16
        implicitWidth: width
        implicitHeight: height
        Layout.alignment: Qt.AlignVCenter

        Image {
            anchors.centerIn: parent
            width: 16
            height: 16
            sourceSize.width: 22
            sourceSize.height: 22
            fillMode: Image.PreserveAspectFit
            smooth: true
            mipmap: true
            cache: true
            visible: netIcon.ethernet
            source: "file:///usr/share/icons/breeze-dark/status/22/network-wired-activated-symbolic.svg"

            Behavior on opacity { NumberAnimation { duration: 160 } }

            layer.enabled: root.cupertinoTopbar
            layer.effect: DropShadow {
                radius: 2
                samples: 5
                horizontalOffset: 0
                verticalOffset: 1
                color: Qt.rgba(0, 0, 0, 0.45)
            }
        }

        function wifiLevel() {
            if (!netIcon.connected) return 0
            if (netIcon.signal >= 80) return 4
            if (netIcon.signal >= 55) return 3
            if (netIcon.signal >= 30) return 2
            return 1
        }

        Canvas {
            id: wifiCanvas
            anchors.centerIn: parent
            width: 18
            height: 16
            visible: !netIcon.ethernet
            antialiasing: true
            opacity: netIcon.connected ? 1.0 : 0.62

            onPaint: {
                let ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                const level = netIcon.wifiLevel()
                const cx = width / 2
                const cy = 11.8
                const start = Math.PI * 1.16
                const end = Math.PI * 1.84
                const active = netIcon.connected ? netIcon.activeColor : netIcon.offlineColor
                const inactive = netIcon.connected ? netIcon.inactiveColor : netIcon.offlineColor
                const arcs = [
                    { radius: 8.4, level: 4 },
                    { radius: 6.0, level: 3 },
                    { radius: 3.6, level: 2 }
                ]

                ctx.lineWidth = 1.9
                ctx.lineCap = "round"
                for (let i = 0; i < arcs.length; i++) {
                    ctx.beginPath()
                    ctx.strokeStyle = level >= arcs[i].level ? active : inactive
                    ctx.globalAlpha = (!netIcon.connected || level >= arcs[i].level) ? 1.0 : 0.55
                    ctx.arc(cx, cy, arcs[i].radius, start, end)
                    ctx.stroke()
                }

                ctx.beginPath()
                ctx.fillStyle = level >= 1 ? active : inactive
                ctx.globalAlpha = (!netIcon.connected || level >= 1) ? 1.0 : 0.55
                ctx.arc(cx, 12.4, 1.65, 0, Math.PI * 2)
                ctx.fill()
                ctx.globalAlpha = 1.0
            }

            Behavior on opacity { NumberAnimation { duration: 160 } }

            Connections {
                target: netIcon
                function onSignalChanged() { wifiCanvas.requestPaint() }
                function onConnectedChanged() { wifiCanvas.requestPaint() }
                function onActiveColorChanged() { wifiCanvas.requestPaint() }
                function onInactiveColorChanged() { wifiCanvas.requestPaint() }
                function onOfflineColorChanged() { wifiCanvas.requestPaint() }
            }
        }
    }

    component VolumeSignalIcon: Item {
        id: volIcon
        property real level: 0
        property bool muted: false
        property color activeColor: root.textPri
        property color inactiveColor: Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.28)
        property color mutedColor: root.danger

        width: 18
        height: 16
        implicitWidth: width
        implicitHeight: height

        Canvas {
            id: volumeCanvas
            anchors.fill: parent
            antialiasing: true

            onPaint: {
                let ctx = getContext("2d")
                ctx.clearRect(0, 0, width, height)

                const active = !volIcon.muted && volIcon.level > 0
                const waveCount = volIcon.muted || volIcon.level <= 0 ? 0 : (volIcon.level >= 55 ? 2 : 1)
                const baseColor = active ? volIcon.activeColor : volIcon.inactiveColor

                ctx.fillStyle = baseColor
                ctx.strokeStyle = baseColor
                ctx.lineJoin = "round"
                ctx.lineCap = "round"

                ctx.beginPath()
                ctx.moveTo(2.0, 6.2)
                ctx.lineTo(4.8, 6.2)
                ctx.lineTo(8.2, 3.4)
                ctx.lineTo(8.2, 12.6)
                ctx.lineTo(4.8, 9.8)
                ctx.lineTo(2.0, 9.8)
                ctx.closePath()
                ctx.fill()

                ctx.lineWidth = 1.8
                if (waveCount >= 1) {
                    ctx.beginPath()
                    ctx.arc(8.8, 8, 3.7, -0.68, 0.68)
                    ctx.stroke()
                }
                ctx.globalAlpha = waveCount >= 2 ? 1.0 : 0.34
                ctx.beginPath()
                ctx.arc(8.9, 8, 6.7, -0.56, 0.56)
                ctx.stroke()
                ctx.globalAlpha = 1.0

                if (volIcon.muted || volIcon.level <= 0) {
                    ctx.strokeStyle = volIcon.mutedColor
                    ctx.lineWidth = 2.2
                    ctx.beginPath()
                    ctx.moveTo(13.5, 3.3)
                    ctx.lineTo(4.6, 12.7)
                    ctx.stroke()
                }
            }

            Connections {
                target: volIcon
                function onLevelChanged() { volumeCanvas.requestPaint() }
                function onMutedChanged() { volumeCanvas.requestPaint() }
                function onActiveColorChanged() { volumeCanvas.requestPaint() }
                function onInactiveColorChanged() { volumeCanvas.requestPaint() }
                function onMutedColorChanged() { volumeCanvas.requestPaint() }
            }
        }
    }

    Rectangle {
        id: barRect
        width: parent.width
        height: parent.height
        color: "transparent"
        border.color: "transparent"
        border.width: 0
        clip: true
        
        y: 0
        opacity: 0

        Component.onCompleted: {
            root.updateClock()
            slideDown.start()
            
            // Consultas iniciales asíncronas
            activeAppQuery.running = true;
            audioQuery.running = true;
            btQuery.running = true;
        }

        Rectangle {
            anchors.fill: parent
            visible: !root.cupertinoTopbar
            color: root.bgMain
        }

        Rectangle {
            anchors.fill: parent
            visible: root.cupertinoTopbar
            color: "transparent"
            clip: true

            // Cupertino intelligent glass: strongest at the top, fading down.
            Rectangle {
                anchors.fill: parent
                gradient: Gradient {
                    orientation: Gradient.Vertical
                    GradientStop { position: 0.0; color: Qt.rgba(0.02, 0.025, 0.035, 0.60) }
                    GradientStop { position: 0.30; color: Qt.rgba(0.02, 0.025, 0.035, 0.35) }
                    GradientStop { position: 0.60; color: Qt.rgba(0.02, 0.025, 0.035, 0.12) }
                    GradientStop { position: 0.85; color: Qt.rgba(0.02, 0.025, 0.035, 0.01) }
                    GradientStop { position: 1.0; color: "transparent" }
                }
            }

            // Cupertino fullscreen solid dark background overlay
            Rectangle {
                anchors.fill: parent
                color: "#0a0b0d"
                opacity: root.isFocusedWindowFullscreen ? 1.0 : 0.0
                Behavior on opacity {
                    NumberAnimation {
                        duration: 350
                        easing.type: Easing.InOutQuad
                    }
                }
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                height: 1
                color: "transparent"
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: 1
                color: Qt.rgba(0, 0, 0, 0.06)
            }
        }

        ParallelAnimation {
            id: slideDown
            NumberAnimation { target: barRect; property: "y"; to: 0; duration: 600; easing.type: Easing.OutQuart }
            NumberAnimation { target: barRect; property: "opacity"; to: 1; duration: 400; easing.type: Easing.OutQuad }
        }

        MouseArea {
            anchors.fill: parent
            onWheel: (wheel) => {
                root.targetWorkspace = wheel.angleDelta.y > 0 ? "focus-workspace-up" : "focus-workspace-down"
                wsSwitcher.running = false
                wsSwitcher.running = true
            }
            onClicked: {
                shellRoot.closeAllPopups()
            }
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 8
            anchors.rightMargin: 8
            spacing: 4

            // ── IZQUIERDA ──
            RowLayout {
                Layout.alignment: Qt.AlignLeft | Qt.AlignVCenter
                spacing: 2

                Item {
                    width: wsGroupsRow.implicitWidth
                    height: 24
                    Layout.preferredWidth: width
                    Layout.preferredHeight: height

                    RowLayout {
                        id: wsGroupsRow
                        anchors.fill: parent
                        spacing: 8
                        Repeater {
                            model: root.workspaceGroups
                            delegate: RowLayout {
                                spacing: 2
                                Rectangle {
                                    visible: index > 0
                                    width: 1
                                    height: 12
                                    color: root.border
                                    Layout.leftMargin: 6
                                    Layout.rightMargin: 6
                                    Layout.alignment: Qt.AlignVCenter
                                }
                                Repeater {
                                    model: modelData.workspaces
                                    delegate: Rectangle {
                                        width: modelData.focused ? 26 : 20; height: 20; radius: 6
                                        color: modelData.focused
                                            ? (root.cupertinoTopbar ? root.cupertinoWorkspaceBgLeft : root.textPriLeft)
                                            : modelData.active ? Qt.rgba(root.textPriLeft.r, root.textPriLeft.g, root.textPriLeft.b, root.cupertinoTopbar ? (root.cupertinoWallpaperIsDarkLeft ? 0.28 : 0.12) : 0.15) : "transparent"
                                        border.color: modelData.active ? (root.cupertinoTopbar ? root.cupertinoPillBorderLeft : root.border) : "transparent"
                                        border.width: modelData.active ? 1 : 0
                                        Behavior on width { NumberAnimation { duration: 350; easing.type: Easing.OutBack; easing.overshoot: 2.5 } }
                                        Behavior on color { ColorAnimation { duration: 150 } }
                                        QsText {
                                            renderType: Text.NativeRendering
                                            anchors.centerIn: parent
                                            text: modelData.name
                                            color: modelData.focused ? (root.cupertinoTopbar ? root.cupertinoWorkspaceTextLeft : root.bgMain) : root.textSecLeft
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            font.weight: root.topbarTextWeight
                                            layer.enabled: root.cupertinoTopbar && !modelData.focused
                                            layer.effect: DropShadow {
                                                radius: 2
                                                samples: 5
                                                horizontalOffset: 0
                                                verticalOffset: 1
                                                color: root.cupertinoShadowColorLeft
                                            }
                                        }
                                        TapHandler {
                                            onTapped: {
                                                root.targetWorkspace = "focus-monitor " + parent.parent.parent.modelData.output + " && niri msg action focus-workspace " + modelData.name
                                                wsSwitcher.running = false
                                                wsSwitcher.running = true
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.NoButton
                        onWheel: (wheel) => {
                            root.targetWorkspace = wheel.angleDelta.y > 0 ? "focus-workspace-up" : "focus-workspace-down"
                            wsSwitcher.running = false
                            wsSwitcher.running = true
                        }
                    }
                }

                Item { width: 8; height: 1 }
                
                QsText {
                    renderType: Text.NativeRendering
                    text: root.activeAppName
                    color: root.textPriLeft
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: root.topbarTextWeight
                    layer.enabled: root.cupertinoTopbar
                    layer.effect: DropShadow {
                        radius: 2
                        samples: 5
                        horizontalOffset: 0
                        verticalOffset: 1
                        color: root.cupertinoShadowColorLeft
                    }
                }
            }

            // ── CENTRO ──
            Item { Layout.fillWidth: true }

            // ── DERECHA ──
            RowLayout {
                Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
                spacing: 4

                // Eject Devices
                BarPill {
                    visible: root.ejectDeviceCount > 0
                    rowContent: [
                        Item {
                            width: 16; height: 16
                            implicitWidth: 16; implicitHeight: 16
                            QsText {
                                anchors.centerIn: parent
                                renderType: Text.NativeRendering
                                text: "\uf287" // USB icon
                                color: root.textPri
                                font.family: "Font Awesome 6 Brands"
                                font.pixelSize: 12
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                            Rectangle {
                                width: 14; height: 14; radius: 7
                                color: root.accent
                                visible: root.ejectDeviceCount > 1
                                anchors.top: parent.top
                                anchors.right: parent.right
                                anchors.topMargin: -6
                                anchors.rightMargin: -6
                                QsText {
                                    anchors.centerIn: parent
                                    text: root.ejectDeviceCount.toString()
                                    color: "#ffffff"
                                    font.family: "Inter"
                                    font.pixelSize: 8
                                    font.weight: root.topbarTextWeight
                                }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleEject(getX())
                }

                // BgApps
                BarPill {
                    hasBorder: true
                    rowContent: [
                        RowLayout {
                            spacing: 6
                            visible: root.activeBgApps.length > 0
                            Repeater {
                                model: root.activeBgApps
                                Item {
                                    width: 15
                                    height: 15
                                    Image {
                                        id: bgAppIcon
                                        anchors.fill: parent
                                        source: modelData.icon_path && modelData.icon_path !== "" ? "file://" + modelData.icon_path : "image://icon/" + (modelData.icon_name || modelData.desktop_id || modelData.app_id)
                                        sourceSize.width: 24
                                        sourceSize.height: 24
                                        fillMode: Image.PreserveAspectFit
                                        smooth: true
                                        mipmap: true
                                        cache: true
                                        visible: status === Image.Ready

                                        layer.enabled: root.cupertinoTopbar
                                        layer.effect: DropShadow {
                                            radius: 2
                                            samples: 5
                                            horizontalOffset: 0
                                            verticalOffset: 1
                                            color: Qt.rgba(0, 0, 0, 0.45)
                                        }
                                    }
                                    QsText {
                                        anchors.centerIn: parent
                                        visible: bgAppIcon.status !== Image.Ready
                                        text: "\uf013"
                                        color: root.textPri
                                        font.family: "Font Awesome 6 Free"
                                        font.pixelSize: 10
                                        layer.enabled: root.cupertinoTopbar
                                        layer.effect: DropShadow {
                                            radius: 2
                                            samples: 5
                                            horizontalOffset: 0
                                            verticalOffset: 1
                                            color: root.cupertinoShadowColorRight
                                        }
                                    }
                                }
                            }
                        },
                        QsText {
                            visible: root.activeBgApps.length === 0
                            renderType: Text.NativeRendering
                            text: "\uf077"
                            color: root.textPri
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 12
                            font.weight: Font.Bold
                            layer.enabled: root.cupertinoTopbar
                            layer.effect: DropShadow {
                                radius: 2
                                samples: 5
                                horizontalOffset: 0
                                verticalOffset: 1
                                color: root.cupertinoShadowColorRight
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleBgApps(getX())
                }

                // Memoria
                BarPill {
                    id: memPill
                    rowContent: [
                        Item { width: 12; height: 12; implicitWidth: 12; implicitHeight: 12
                            Canvas {
                                id: memCanvas
                                anchors.fill: parent
                                onPaint: { let ctx = getContext("2d"); ctx.reset(); ctx.lineWidth = 1.5; ctx.strokeStyle = root.cupertinoTopbar ? root.textSecRight : root.textSec; ctx.beginPath(); ctx.arc(width/2, width/2, width/2 - 2, 0, Math.PI * 2); ctx.stroke(); let endAngle = (root.memLevelAnimated / 100) * Math.PI * 2 - Math.PI / 2; ctx.strokeStyle = root.cupertinoTopbar ? root.textPriRight : root.accent; ctx.beginPath(); ctx.arc(width/2, width/2, width/2 - 2, -Math.PI / 2, endAngle); ctx.stroke() }
                                Connections {
                                    target: root
                                    function onMemLevelAnimatedChanged() { memCanvas.requestPaint() }
                                    function onTextPriRightChanged() { memCanvas.requestPaint() }
                                    function onTextSecRightChanged() { memCanvas.requestPaint() }
                                }
                            }
                            QsText {
                                anchors.centerIn: parent
                                text: "\uf2db"
                                color: root.textSec
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 7
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                        },
                        Item {
                            id: memDetailWrap
                            clip: true
                            implicitWidth: memPill.isHovered ? memDetailText.implicitWidth : 0
                            implicitHeight: memDetailText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: memDetailText
                                renderType: Text.NativeRendering
                                text: root.memUsedGb + " GB / " + root.memTotalGb + " GB"
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12
                                font.weight: root.topbarTextWeight
                                opacity: memPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleMemory(getX())
                }

                // Mic
                BarPill {
                    rowContent: [
                        Item {
                            width: 14
                            height: 16
                            QsText {
                                renderType: Text.NativeRendering
                                anchors.centerIn: parent
                                text: "\uf130"
                                color: root.isMicMuted ? root.textSecRight : (root.cupertinoTopbar ? root.textPriRight : root.accent)
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 12
                                Behavior on color { ColorAnimation { duration: 200 } }
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                            Rectangle {
                                visible: root.isMicMuted
                                width: 2
                                height: 15
                                radius: 1
                                color: root.cupertinoTopbar ? root.textSecRight : "#e06c6c"
                                anchors.centerIn: parent
                                rotation: -45
                                antialiasing: true
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleMic(getX())
                }

                // Volume
                BarPill {
                    id: volPill
                    rowContent: [
                        VolumeSignalIcon {
                            level: root.volLevelAnimated
                            muted: root.isVolMuted
                            activeColor: root.textPriRight
                            inactiveColor: root.textSecRight
                            mutedColor: root.cupertinoTopbar ? root.textSecRight : root.danger
                        },
                        Item {
                            id: volPctWrap
                            clip: true
                            implicitWidth: volPill.isHovered ? volPctText.implicitWidth : 0
                            implicitHeight: volPctText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: volPctText
                                renderType: Text.NativeRendering
                                text: root.volUsage
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12
                                font.weight: root.topbarTextWeight
                                opacity: volPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleVolume(getX())

                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.NoButton
                        onWheel: (wheel) => {
                            root.volumeAction = wheel.angleDelta.y > 0 ? "+5%" : "-5%"
                            volumeAdjuster.running = false
                            volumeAdjuster.running = true
                        }
                    }
                }

                // Bluetooth
                BarPill {
                    id: bluetoothPill
                    visible: root.isBluetoothActive || root.bluetoothDevice !== ""
                    rowContent: [
                        QsText {
                            renderType: Text.NativeRendering
                            text: root.isBluetoothActive ? "\uf294" : "\uf293"
                            color: root.isBluetoothActive ? (root.isFocusedWindowFullscreen ? root.textPriRight : root.accent) : root.textSec
                            font.family: "Font Awesome 6 Brands"
                            font.pixelSize: 12
                            layer.enabled: root.cupertinoTopbar
                            layer.effect: DropShadow {
                                radius: 2
                                samples: 5
                                horizontalOffset: 0
                                verticalOffset: 1
                                color: root.cupertinoShadowColorRight
                            }
                        },
                        QsText {
                            visible: root.isBluetoothActive && root.bluetoothDevice !== ""
                            renderType: Text.NativeRendering
                            text: root.bluetoothDevice
                            color: root.textPri
                            font.family: "Inter"
                            font.pixelSize: 11
                            font.weight: root.topbarTextWeight
                            layer.enabled: root.cupertinoTopbar
                            layer.effect: DropShadow {
                                radius: 2
                                samples: 5
                                horizontalOffset: 0
                                verticalOffset: 1
                                color: root.cupertinoShadowColorRight
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleBluetooth(getX())
                }

                // Wifi / Ethernet
                BarPill {
                    id: netPill
                    rowContent: [
                        NetworkSignalIcon {
                            ethernet: root.ethernetConnected
                            connected: root.netConnected
                            signal: root.wifiSignalAnimated
                            activeColor: root.textPri
                            inactiveColor: Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.25)
                            offlineColor: root.textSec
                        },
                        Item {
                            id: ipWrap
                            clip: true
                            implicitWidth: netPill.isHovered ? ipText.implicitWidth : 0
                            implicitHeight: ipText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: ipText
                                renderType: Text.NativeRendering
                                text: root.netType === "ethernet" ? root.localIp : (root.netType === "wifi" ? root.netName + " · " + Math.round(root.wifiSignalAnimated) + "%" : "Sin conexión")
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12
                                font.weight: root.topbarTextWeight
                                opacity: netPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleWifi(getX())
                }

                // Batería
                BarPill {
                    id: batPill
                    visible: root.batPercent !== "—"
                    rowContent: [
                        Item { width: 18; height: 12; implicitWidth: 18; implicitHeight: 12
                            Rectangle { anchors.fill: parent; radius: 2; color: "transparent"; border.color: root.batLevelAnimated <= 15 ? root.danger : (root.cupertinoTopbar ? root.textPriRight : root.textSec); border.width: 1.5
                                Rectangle { anchors.left: parent.left; anchors.top: parent.top; anchors.bottom: parent.bottom; anchors.leftMargin: 2; anchors.topMargin: 2; anchors.bottomMargin: 2; width: (parent.width - 4) * (root.batLevelAnimated / 100); radius: 1; color: root.cupertinoTopbar ? (root.batLevelAnimated <= 15 ? root.danger : root.textPriRight) : root.batColor
                                    Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
                                }
                            }
                            Rectangle { anchors.left: parent.right; anchors.verticalCenter: parent.verticalCenter; width: 2; height: 4; radius: 1; color: root.batLevelAnimated <= 15 ? root.danger : (root.cupertinoTopbar ? root.textPriRight : root.textSec) }
                            QsText {
                                visible: root.isCharging
                                anchors.centerIn: parent
                                text: "\uf0e7"
                                color: "#f9cb42"
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 8
                                font.weight: Font.Black
                                z: 1
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                        },
                        Item {
                            id: batPctWrap
                            clip: true
                            implicitWidth: batPill.isHovered ? batPctText.implicitWidth : 0
                            implicitHeight: batPctText.implicitHeight
                            Behavior on implicitWidth { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                            QsText {
                                id: batPctText
                                renderType: Text.NativeRendering
                                text: root.batPercent
                                color: root.textPri; font.family: "Inter"; font.pixelSize: 12
                                font.weight: root.topbarTextWeight
                                opacity: batPill.isHovered ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleBattery(getX())
                }

                // Menú principal
                BarPill {
                    rowContent: [ QsText { renderType: Text.NativeRendering; text: "\uf0c9"; color: root.textPri; font.family: "Font Awesome 6 Free"; font.pixelSize: 12; layer.enabled: root.cupertinoTopbar; layer.effect: DropShadow { radius: 2; samples: 5; horizontalOffset: 0; verticalOffset: 1; color: root.cupertinoShadowColorRight } } ]
                    tapHandler.onTapped: root.togglePanel(getX())
                }

                // Notificaciones
                BarPill {
                    rowContent: [
                        Item {
                            width: 14; height: 14
                            implicitWidth: 14; implicitHeight: 14
                            QsText {
                                anchors.centerIn: parent
                                renderType: Text.NativeRendering
                                text: root.notifText
                                color: root.hasUnreadNotifs ? root.danger : root.textPri
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 12
                                layer.enabled: root.cupertinoTopbar
                                layer.effect: DropShadow {
                                    radius: 2
                                    samples: 5
                                    horizontalOffset: 0
                                    verticalOffset: 1
                                    color: root.cupertinoShadowColorRight
                                }
                            }
                            Rectangle {
                                id: notifDot
                                visible: root.hasUnreadNotifs
                                width: 6; height: 6; radius: 3
                                color: root.danger
                                anchors.top: parent.top
                                anchors.right: parent.right
                                anchors.topMargin: -1
                                anchors.rightMargin: -1
                                transformOrigin: Item.Center
                                scale: 1.0
                            }
                        }
                    ]
                    tapHandler.onTapped: root.toggleNotifications(getX())
                }

                // Reloj
                BarPill {
                    color: "transparent"
                    border.color: "transparent"
                    rowContent: [ QsText { renderType: Text.NativeRendering; text: root.clockText; color: root.textPri; font.family: "Inter"; font.pixelSize: 14; font.weight: root.topbarTextWeight; layer.enabled: root.cupertinoTopbar; layer.effect: DropShadow { radius: 2; samples: 5; horizontalOffset: 0; verticalOffset: 1; color: root.cupertinoShadowColorRight } } ]
                    tapHandler.onTapped: root.toggleCalendar(getX())
                }

                // Energía
                BarPill {
                    rowContent: [ QsText { renderType: Text.NativeRendering; text: "\uf011"; color: root.textPri; font.family: "Font Awesome 6 Free"; font.pixelSize: 12; layer.enabled: root.cupertinoTopbar; layer.effect: DropShadow { radius: 2; samples: 5; horizontalOffset: 0; verticalOffset: 1; color: root.cupertinoShadowColorRight } } ]
                    tapHandler.onTapped: root.togglePower(getX())
                }
            }
        }
    }
}
