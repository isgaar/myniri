// PrivacyMonitor.qml — single runtime source for active privacy-sensitive sessions.
import Quickshell.Io
import QtQuick

Item {
    id: root

    property var activeList: []
    readonly property bool micActive: hasType("mic")
    readonly property bool cameraActive: hasType("camera")
    readonly property bool screenActive: hasType("screen")
    readonly property bool remoteActive: hasType("remote")
    readonly property bool localActive: micActive || cameraActive || screenActive
    readonly property bool hasActiveItems: activeList.length > 0

    property var seenSince: ({})

    function hasType(typeName) {
        for (let i = 0; i < activeList.length; i++) {
            if (activeList[i].type === typeName) return true
        }
        return false
    }

    function itemKey(item) {
        return [
            item.type || "unknown",
            item.pid || "",
            item.appName || "",
            item.detail || ""
        ].join("|")
    }

    function publish(items) {
        let now = Date.now()
        let nextSeen = {}
        let nextItems = []

        for (let i = 0; i < items.length; i++) {
            let item = items[i] || {}
            if (!item.type) continue

            let key = itemKey(item)
            let firstSeen = root.seenSince[key] || now
            nextSeen[key] = firstSeen

            nextItems.push({
                "type": item.type,
                "appName": item.appName || "Proceso desconocido",
                "detail": item.detail || "actividad privada",
                "pid": item.pid || "",
                "timestamp": firstSeen
            })
        }

        root.seenSince = nextSeen
        root.activeList = nextItems
    }

    function refresh() {
        if (!scanProcess.running) scanProcess.running = true
    }

    Timer {
        interval: 1500
        repeat: true
        running: true
        onTriggered: root.refresh()
    }

    Component.onCompleted: root.refresh()

    Process {
        id: scanProcess
        running: false
        command: ["bash", "-lc", `
set +e

empty='[]'

if ! command -v jq >/dev/null 2>&1; then
  printf '%s\n' "$empty"
  exit 0
fi

pipewire_items='[]'
if command -v pw-dump >/dev/null 2>&1; then
  pipewire_items=$(pw-dump 2>/dev/null | jq -c '
    [
      .[]
      | (.info.props? // {}) as $p
      | ($p["media.class"] // "") as $class
      | ($p["node.name"] // "") as $node
      | ($p["application.name"] // $p["client.name"] // $p["node.description"] // "Proceso desconocido") as $app
      | (($p["application.process.id"] // $p["process.id"] // "") | tostring) as $pid
      | if (($class | test("Video"; "i")) and (($node | test("xdp|portal|screencast|screen"; "i")) or ($app | test("xdg-desktop-portal|portal"; "i")))) then
          { type: "screen", appName: $app, detail: "compartiendo pantalla", pid: $pid }
        elif $class == "Stream/Input/Audio" then
          { type: "mic", appName: $app, detail: "usando el micrófono", pid: $pid }
        elif $class == "Stream/Input/Video" then
          { type: "camera", appName: $app, detail: "usando la cámara", pid: $pid }
        else empty end
    ]' 2>/dev/null)
fi

camera_items='[]'
if command -v fuser >/dev/null 2>&1; then
  camera_items=$(
    for dev in /dev/video*; do
      [ -e "$dev" ] || continue
      fuser "$dev" 2>/dev/null | tr ' ' '\n' | awk 'NF' | while read -r pid; do
        [ -n "$pid" ] || continue
        app=$(ps -p "$pid" -o comm= 2>/dev/null | sed 's/^ *//;s/ *$//')
        [ -n "$app" ] || app="Proceso desconocido"
        jq -cn --arg app "$app" --arg pid "$pid" --arg dev "$dev" \
          '{ type: "camera", appName: $app, detail: ("mantiene " + $dev), pid: $pid }'
      done
    done | jq -sc '.'
  )
fi

remote_items='[]'
if command -v ss >/dev/null 2>&1; then
  ssh_count=$(ss -Htnp state established '( sport = :22 or dport = :22 )' 2>/dev/null | wc -l)
  if [ "\${ssh_count:-0}" -gt 0 ]; then
    remote_items=$(jq -cn --arg detail "$ssh_count conexión(es) SSH activas" \
      '[{ type: "remote", appName: "SSH", detail: $detail, pid: "" }]')
  fi
fi

server_items=$(
  for svc in wayvnc x11vnc xrdp xrdp-sesman; do
    command -v pgrep >/dev/null 2>&1 || continue
    pgrep -x "$svc" 2>/dev/null | while read -r pid; do
      [ -n "$pid" ] || continue
      jq -cn --arg app "$svc" --arg pid "$pid" \
        '{ type: "remote", appName: $app, detail: "servidor remoto activo", pid: $pid }'
    done
  done | jq -sc '.'
)

jq -cn \
  --argjson pipewire "\${pipewire_items:-[]}" \
  --argjson camera "\${camera_items:-[]}" \
  --argjson remote "\${remote_items:-[]}" \
  --argjson servers "\${server_items:-[]}" \
  '$pipewire + $camera + $remote + $servers
   | unique_by((.type // "") + "|" + (.pid // "") + "|" + (.appName // "") + "|" + (.detail // ""))'
`]
        stdout: SplitParser {
            onRead: data => {
                let trimmed = data.trim()
                if (!trimmed) return
                try {
                    root.publish(JSON.parse(trimmed))
                } catch (e) {
                    root.publish([])
                }
            }
        }
        onExited: (exitCode, exitStatus) => {
            if (exitCode !== 0) root.publish([])
        }
    }
}
