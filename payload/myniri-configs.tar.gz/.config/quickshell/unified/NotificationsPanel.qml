import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

    BasePopup {
        id: panel

    WindowSettings { id: ws }

        anchors {
            top: true
            left: true
            right: false
        }
        margins.top: shellRoot.getPopupTopMargin(panel.screen)
        margins.left: panel.anchorMargin

        property int anchorMargin: 0

        implicitWidth: 380
        implicitHeight: 430
        property int contentHeight: 430

        property bool dndMode: false

        Process {
            id: checkDndProcess
            command: ["bash", "-c", "makoctl mode 2>/dev/null | grep -q dnd && echo true || echo false"]
            stdout: SplitParser {
                onRead: data => {
                    panel.dndMode = data.trim() === "true"
                }
            }
        }

        Process {
            id: toggleDndProcess
            command: ["makoctl", "mode", "-t", "dnd"]
            onExited: {
                checkDndProcess.running = false
                checkDndProcess.running = true
            }
        }

        Timer {
            id: dndTimer
            interval: 1000
            repeat: true
            running: panel.visible
            onTriggered: {
                checkDndProcess.running = false
                checkDndProcess.running = true
            }
        }

        onVisibleChanged: {
            if (visible) {
                shellRoot.updateMakoPosition("notifications", "open", Math.round(panel.implicitHeight + 55).toString())
                checkDndProcess.running = false
                checkDndProcess.running = true
            } else {
                shellRoot.updateMakoPosition("notifications", "closed")
            }
        }

        readonly property color bgTile: (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#2a2a2a"




        function toggle(x) {
            visible = !visible
            if (visible) {
                if (x !== undefined && x >= 0) {
                    let screenW = panel.screen ? panel.screen.width : 1920
                    panel.anchorMargin = Math.max(12, Math.min(x - panel.implicitWidth/2, screenW - panel.implicitWidth - 12))
                }
                refreshNotifications()
                content.forceActiveFocus(Qt.MouseFocusReason)
            }
        }

        function getAppIcon(appId, urgency) {
            let id = (appId || "").toLowerCase()
            if (id.includes("discord")) return "\uf392"
            if (id.includes("telegram")) return "\uf2c6"
            if (id.includes("steam")) return "\uf1b6"
            if (id.includes("spotify")) return "\uf1bc"
            if (id.includes("pentablet") || id.includes("xppen")) return "\uf304"
            if (id.includes("firefox")) return "\uf269"
            if (id.includes("chrome")) return "\uf268"
            if (id.includes("mail")) return "\uf0e0"
            if (id.includes("terminal") || id.includes("kitty") || id.includes("alacritty")) return "\uf120"
            if (id.includes("github")) return "\uf09b"
            if (id.includes("slack")) return "\uf198"
            if (id.includes("youtube")) return "\uf167"
            if (id.includes("twitch")) return "\uf1e8"
            return urgency === "high" ? "\uf071" : "\uf0f3"
        }

        function refreshNotifications() {
            notifModel.clear()
            loadNotifications.running = false
            Qt.callLater(() => loadNotifications.running = true)
        }

        ListModel { id: notifModel }

        Process {
            id: clearProcess
            running: false
            command: ["/home/ismael/scripts/clear_notifications.sh"]
            onExited: panel.refreshNotifications()
        }

        Process {
            id: actionProcess
            running: false
        }

        Process {
            id: loadNotifications
            running: false
            command: ["/home/ismael/scripts/get_notifs.py"]
            stdout: SplitParser {
                onRead: data => {
                    let line = data.replace(/[\r\n]+$/, "")
                    if (line === "CLEAR") {
                        notifModel.clear()
                        return
                    }
                    if (!line) return
                    let parts = line.split("\t")
                    if (parts.length < 7) return
                    notifModel.append({
                        state: parts[0],
                        idText: parts[1],
                        app: parts[2] || "Notificacion",
                        summary: parts[3],
                        body: parts[4],
                        urgency: parts[5],
                        desktopEntry: parts[6] || parts[2],
                        preview: parts[7] || "",
                        iconPath: parts[8] || "",
                        groupCount: parseInt(parts[9]) || 1
                    })
                }
            }
        }

        Rectangle {
            id: content
            anchors.fill: parent
            color: panel.bgMain
            radius: ws.cornersEnabled ? ws.cornerRadius : 0
            border.color: panel.border
            border.width: 1
            focus: true

            Keys.onEscapePressed: panel.visible = false

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 12
                spacing: 10

                RowLayout {
                    Layout.fillWidth: true
                    height: 34
                    spacing: 8

                    QsText {
                        text: "\uf0f3"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 15
                        color: panel.textPri
                    }

                    QsText {
                        text: "Notificaciones"
                        color: panel.textPri
                        font.family: "Inter"
                        font.pixelSize: 15
                        font.weight: Font.DemiBold
                        Layout.fillWidth: true
                    }

                    Rectangle {
                        width: dndText.implicitWidth + 28
                        height: 28
                        radius: ws.cornersEnabled ? Math.min(10, ws.cornerRadius) : 0
                        color: panel.dndMode ? Qt.rgba(panel.accent.r, panel.accent.g, panel.accent.b, 0.12) : (dndHover.hovered ? Qt.rgba(1, 1, 1, 0.08) : "transparent")
                        border.color: panel.dndMode ? panel.accent : (dndHover.hovered ? panel.border : "transparent")
                        border.width: 1

                        RowLayout {
                            anchors.centerIn: parent
                            spacing: 6
                            QsText {
                                text: "\uf1f6" // Bell slash
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 12
                                color: panel.dndMode ? panel.accent : panel.textSec
                            }
                            QsText {
                                id: dndText
                                text: "Modo concentración"
                                color: panel.dndMode ? panel.accent : panel.textSec
                                font.family: "Inter"
                                font.pixelSize: 11
                            }
                        }
                        
                        HoverHandler { id: dndHover }
                        TapHandler { 
                            onTapped: {
                                panel.dndMode = !panel.dndMode
                                toggleDndProcess.running = false
                                toggleDndProcess.running = true
                            }
                        }
                    }

                    Rectangle {
                        width: 30
                        height: 30
                        radius: 15
                        color: refreshHover.hovered ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
                        border.color: refreshHover.hovered ? panel.border : "transparent"
                        border.width: 1

                        QsText {
                            anchors.centerIn: parent
                            text: "\uf1f8"
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 12
                            color: panel.textSec
                        }

                        HoverHandler { id: refreshHover }
                        TapHandler { onTapped: clearProcess.running = true }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    height: 1
                    color: Qt.rgba(1, 1, 1, 0.08)
                }

                Flickable {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    contentWidth: width
                    contentHeight: listCol.implicitHeight

                    Column {
                        id: listCol
                        width: parent.width
                        spacing: 8

                        Repeater {
                            model: notifModel

                            delegate: Rectangle {
                                width: listCol.width
                                height: Math.max(model.preview !== "" ? 92 : 72, itemCol.implicitHeight + 24)
                                radius: ws.cornersEnabled ? ws.cornerRadius : 0
                                color: model.state === "now" ? Qt.rgba(panel.accent.r, panel.accent.g, panel.accent.b, 0.12) : panel.bgCard
                                border.color: model.state === "now" ? Qt.rgba(panel.accent.r, panel.accent.g, panel.accent.b, 0.45) : panel.border
                                border.width: 1

                                // Group count badge
                                Rectangle {
                                    visible: model.groupCount > 1
                                    anchors.top: parent.top
                                    anchors.right: parent.right
                                    anchors.topMargin: 6
                                    anchors.rightMargin: 6
                                    width: 18; height: 18; radius: 9
                                    color: panel.accent
                                    z: 2

                                    QsText {
                                        anchors.centerIn: parent
                                        text: model.groupCount > 99 ? "99+" : model.groupCount.toString()
                                        color: "white"
                                        font.family: "Inter"
                                        font.pixelSize: 9
                                        font.weight: Font.Bold
                                    }
                                }

                                TapHandler {
                                    onTapped: {
                                        if (model.preview !== "") {
                                            actionProcess.command = ["/home/ismael/scripts/notif_action.sh", "screenshot", model.preview, model.app]
                                        } else {
                                            actionProcess.command = ["/home/ismael/scripts/notif_action.sh", "app", model.desktopEntry, model.app]
                                        }
                                        actionProcess.running = true
                                        panel.visible = false
                                    }
                                }

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.margins: 12
                                    spacing: 10

                                    Rectangle {
                                        width: model.preview !== "" ? 78 : 34
                                        height: model.preview !== "" ? 54 : 34
                                        radius: 9
                                        clip: true
                                        color: model.urgency === "high" ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.10)

                                        Image {
                                            anchors.fill: parent
                                            source: model.preview !== "" ? "file://" + model.preview : ""
                                            fillMode: Image.PreserveAspectCrop
                                            visible: model.preview !== ""
                                            asynchronous: true
                                        }

                                        Rectangle {
                                            anchors.fill: parent
                                            visible: model.preview !== ""
                                            border.color: Qt.rgba(1, 1, 1, 0.10)
                                            border.width: 1
                                            radius: parent.radius
                                        }

                                        Image {
                                            anchors.centerIn: parent
                                            width: 24; height: 24
                                            source: model.iconPath !== "" ? "file://" + model.iconPath : ""
                                            visible: model.preview === "" && model.iconPath !== ""
                                            fillMode: Image.PreserveAspectFit
                                            asynchronous: true
                                        }
                                        QsText {
                                            anchors.centerIn: parent
                                            text: panel.getAppIcon(model.desktopEntry, model.urgency)
                                            font.family: "Font Awesome 6 Free"
                                            font.pixelSize: 15
                                            color: model.urgency === "high" ? "#e06c6c" : panel.textPri
                                            visible: model.preview === "" && model.iconPath === ""
                                        }
                                    }

                                    Column {
                                        id: itemCol
                                        Layout.fillWidth: true
                                        spacing: 3

                                        QsText {
                                            text: model.app + (model.state === "now" ? "  Activa" : "")
                                            color: panel.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 10
                                            elide: Text.ElideRight
                                            width: parent.width
                                        }

                                        QsText {
                                            text: model.summary
                                            color: panel.textPri
                                            font.family: "Inter"
                                            font.pixelSize: 13
                                            font.weight: Font.DemiBold
                                            elide: Text.ElideRight
                                            width: parent.width
                                        }

                                        QsText {
                                            text: model.body
                                            visible: model.body !== ""
                                            color: panel.textSec
                                            font.family: "Inter"
                                            font.pixelSize: 11
                                            wrapMode: Text.WordWrap
                                            maximumLineCount: 2
                                            elide: Text.ElideRight
                                            width: parent.width
                                        }
                                    }
                                }
                            }
                        }

                        QsText {
                            visible: notifModel.count === 0
                            width: listCol.width
                            topPadding: 80
                            horizontalAlignment: Text.AlignHCenter
                            text: "Sin notificaciones recientes"
                            color: panel.textSec
                            font.family: "Inter"
                            font.pixelSize: 13
                        }
                    }
                }
            }
        }
    }
