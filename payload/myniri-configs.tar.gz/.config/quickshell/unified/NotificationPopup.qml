import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

PanelWindow {
    id: popupWindow

    WindowSettings { id: ws }

    anchors {
        top: true
        right: true
    }
    property int topMargin: 45
    margins.top: topMargin
    margins.right: 8

    implicitWidth: 380
    implicitHeight: contentColumn.implicitHeight

    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    WlrLayershell.exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "quickshell"

    color: "transparent"
    visible: activeNotifs.count > 0

    ListModel {
        id: activeNotifs
    }

    function showNotification(summary, body, app, urgency) {
        let id = Date.now()
        activeNotifs.append({
            notifId: id,
            summary: summary || "",
            body: body || "",
            app: app || "Sistema",
            urgency: urgency || "normal"
        })
    }

    ColumnLayout {
        id: contentColumn
        width: parent.width
        spacing: 8

        Repeater {
            model: activeNotifs
            delegate: Rectangle {
                id: card
                Layout.fillWidth: true
                implicitHeight: Math.max(74, textLayout.implicitHeight + 24)

                radius: ws.cornersEnabled ? ws.cornerRadius : 0

                color: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "light" ? Qt.rgba(1, 1, 1, 0.82) : Qt.rgba(0.098, 0.098, 0.098, 0.78)
                border.color: (shellRoot.themeConfig && shellRoot.themeConfig.border) || "#3a3a3a"
                border.width: 1

                // Animations
                x: popupWindow.width
                opacity: 0

                Component.onCompleted: {
                    if ((shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false) {
                        slideIn.start()
                        fadeIn.start()
                    } else {
                        x = 0
                        opacity = 1
                    }
                    dismissTimer.start()
                }

                NumberAnimation {
                    id: slideIn
                    target: card
                    property: "x"
                    from: popupWindow.width
                    to: 0
                    duration: 250
                    easing.type: Easing.OutCubic
                }
                NumberAnimation {
                    id: fadeIn
                    target: card
                    property: "opacity"
                    from: 0
                    to: 1
                    duration: 200
                    easing.type: Easing.OutQuad
                }

                function dismiss() {
                    if ((shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false) {
                        slideOut.start()
                        fadeOut.start()
                    } else {
                        removeThis()
                    }
                }

                function removeThis() {
                    for (let i = 0; i < activeNotifs.count; i++) {
                        if (activeNotifs.get(i).notifId === model.notifId) {
                            activeNotifs.remove(i)
                            break
                        }
                    }
                }

                NumberAnimation {
                    id: slideOut
                    target: card
                    property: "x"
                    to: popupWindow.width
                    duration: 220
                    easing.type: Easing.InCubic
                    onFinished: removeThis()
                }
                NumberAnimation {
                    id: fadeOut
                    target: card
                    property: "opacity"
                    to: 0
                    duration: 180
                    easing.type: Easing.OutQuad
                }

                Timer {
                    id: dismissTimer
                    interval: 5500
                    running: false
                    repeat: false
                    onTriggered: card.dismiss()
                }

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 12

                    // Icon Container
                    Rectangle {
                        width: 36
                        height: 36
                        radius: ws.cornersEnabled ? ws.cornerRadius : 0
                        color: {
                            if (model.urgency === "high") return Qt.rgba(0.88, 0.27, 0.27, 0.15);
                            let isLight = (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "light";
                            return isLight ? Qt.rgba(0, 0, 0, 0.06) : Qt.rgba(1, 1, 1, 0.08);
                        }

                        QsText {
                            anchors.centerIn: parent
                            text: popupWindow.getAppIcon(model.app, model.urgency)
                            font.family: "Font Awesome 6 Free"
                            font.pixelSize: 15
                            color: model.urgency === "high" ? "#e06c6c" : ((shellRoot.themeConfig && shellRoot.themeConfig.accent) || "#5aa7de")
                        }
                    }

                    // Texts Layout
                    ColumnLayout {
                        id: textLayout
                        Layout.fillWidth: true
                        spacing: 2

                        QsText {
                            text: model.app
                            font.family: "Inter"
                            font.pixelSize: 10
                            font.weight: Font.DemiBold
                            color: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
                            Layout.fillWidth: true
                        }

                        QsText {
                            text: model.summary
                            font.family: "Inter"
                            font.pixelSize: 12
                            font.weight: Font.Bold
                            color: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                        }

                        QsText {
                            text: model.body
                            font.family: "Inter"
                            font.pixelSize: 11
                            color: (shellRoot.themeConfig && shellRoot.themeConfig.textPri) || "#f0eee8"
                            wrapMode: Text.Wrap
                            maximumLineCount: 2
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                        }
                    }

                    // Close Button
                    QsText {
                        text: "\uf00d"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 12
                        color: (shellRoot.themeConfig && shellRoot.themeConfig.textSec) || "#918f88"
                        opacity: closeHover.hovered ? 0.9 : 0.5

                        Behavior on opacity {
                            enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
                            NumberAnimation { duration: 100 }
                        }

                        HoverHandler {
                            id: closeHover
                        }

                        TapHandler {
                            onTapped: card.dismiss()
                        }
                    }
                }
            }
        }
    }

    function getAppIcon(appId, urgency) {
        let id = (appId || "").toLowerCase()
        if (id.includes("discord")) return "\uf392"
        if (id.includes("telegram")) return "\uf2c6"
        if (id.includes("steam")) return "\uf1b6"
        if (id.includes("spotify")) return "\uf1bc"
        if (id.includes("pentablet") || id.includes("xppen")) return "\uf304"
        if (id.includes("firefox")) return "\uf269"
        if (id.includes("chrome")) return "\uf268"
        if (id.includes("mail")) return "\uf0e0"
        if (id.includes("terminal") || id.includes("kitty") || id.includes("alacritty")) return "\uf120"
        if (id.includes("github")) return "\uf09b"
        if (id.includes("slack")) return "\uf198"
        if (id.includes("youtube")) return "\uf167"
        if (id.includes("twitch")) return "\uf1e8"
        if (id.includes("captura") || id.includes("screenshot") || id.includes("grim") || id.includes("spectacle")) return "\uf030"
        return urgency === "high" ? "\uf071" : "\uf0f3"
    }
}
