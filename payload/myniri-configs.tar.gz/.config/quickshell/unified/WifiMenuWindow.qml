import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

BasePopup {
    id: window

    anchors {
        top: true
        left: true
        right: false
    }
    margins.top: 40
    margins.left: window.anchorMargin

    property int anchorMargin: 136

    onVisibleChanged: {
        if (visible) {
            shellRoot.updateMakoPosition("wifimenu", "open", Math.round(window.implicitHeight + 55).toString())
            content.forceActiveFocus(Qt.MouseFocusReason)
            networkList.refresh()
        } else {
            shellRoot.updateMakoPosition("wifimenu", "closed")
        }
    }





    implicitWidth: Math.min(380, Math.max(300, (window.screen ? window.screen.width : 1920) - 16))
    implicitHeight: Math.min(800, networkList.implicitHeight + 24)
    property int contentHeight: Math.min(800, networkList.implicitHeight + 24)

    readonly property color bgActive: Qt.rgba(window.accent.r, window.accent.g, window.accent.b, 0.12)

    function toggle(x) {
        if (visible) {
            visible = false
        } else {
            if (x !== undefined && x >= 0) {
                let screenW = window.screen ? window.screen.width : 1920
                window.anchorMargin = Math.max(8, Math.min(x - window.implicitWidth/2, screenW - window.implicitWidth - 8))
            }
            visible = true
        }
    }

    function close() {
        visible = false
    }

    Rectangle {
        id: content
        anchors.fill: parent
        color: window.bgMain
        radius: window.cornersEnabled ? window.cornerRadius : 0
        border.color: window.border
        border.width: 1
        focus: true

        Keys.onEscapePressed: window.visible = false

        PanelNetworkList {
            id: networkList
            anchors.fill: parent
            anchors.margins: 12
            bgCard: window.bgMain
            bgActive: window.bgActive
            border: "transparent"
            borderHi: window.border
            textPri: window.textPri
            textSec: window.textSec
            accentWf: window.accent
            
            onNetworkConnected: {
                window.visible = false
            }
        }
    }
}
