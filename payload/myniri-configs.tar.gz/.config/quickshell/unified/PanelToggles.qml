// PanelToggles.qml — Zona 6: Modo noche + Modo oscuro
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

Item {
    id: root

    WindowSettings { id: ws }
    implicitHeight: 48

    property color bgCard
    property color bgTile
    property color border
    property color textPri
    property color accent

    readonly property bool isDark: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode) === "dark"

    property bool nightMode: false
    property bool darkMode: true
    property bool panelVisible: false
    property bool dndMode: false
    
    Process {
        id: checkDndProcess
        command: ["bash", "-c", "makoctl mode 2>/dev/null | grep -q dnd && echo true || echo false"]
        stdout: SplitParser {
            onRead: data => {
                root.dndMode = data.trim() === "true"
            }
        }
    }

    Process {
        id: toggleDndProcess
        command: ["makoctl", "mode", "-t", "dnd"]
        onExited: {
            checkDndProcess.running = false
            checkDndProcess.running = true
        }
    }

    Process {
        id: checkNightProcess
        command: ["bash", "-c", "pgrep -x wlsunset &>/dev/null && echo true || echo false"]
        stdout: SplitParser {
            onRead: data => {
                root.nightMode = data.trim() === "true"
            }
        }
    }

    Process {
        id: checkDarkProcess
        command: ["bash", "-c", "gsettings get org.gnome.desktop.interface color-scheme 2>/dev/null | grep -q dark && echo true || echo false"]
        stdout: SplitParser {
            onRead: data => {
                root.darkMode = data.trim() === "true"
            }
        }
    }

    Timer {
        id: dndTimer
        interval: 1000
        repeat: true
        running: root.panelVisible
        onTriggered: {
            checkDndProcess.running = false
            checkDndProcess.running = true
            checkNightProcess.running = false
            checkNightProcess.running = true
            checkDarkProcess.running = false
            checkDarkProcess.running = true
        }
    }

    onPanelVisibleChanged: {
        if (panelVisible) {
            checkDndProcess.running = false
            checkDndProcess.running = true
            checkNightProcess.running = false
            checkNightProcess.running = true
            checkDarkProcess.running = false
            checkDarkProcess.running = true
        }
    }

    Component.onCompleted: {
        checkDndProcess.running = true
        checkNightProcess.running = true
        checkDarkProcess.running = true
    }

    RowLayout {
        anchors.fill: parent
        spacing: 8

        // Modo noche
        Rectangle {
            Layout.fillWidth: true
            height: 48
            radius: ws.cornersEnabled ? ws.cornerRadius : 0
            color: root.bgCard
            border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
            border.width: 1
            activeFocusOnTab: false
            focus: false

            RowLayout {
                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                spacing: 8

                Rectangle {
                    width: 28; height: 28; radius: 14
                    color: root.nightMode ? root.accent : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)
                    Layout.alignment: Qt.AlignVCenter

                    QsText {
                        anchors.centerIn: parent
                        text: "\uf186"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 12
                        color: root.nightMode ? "#ffffff" : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                    }
                }

                QsText {
                    text: "Modo noche"
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                    font.hintingPreference: Font.PreferNoHinting
                    renderType: Text.NativeRendering
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }
            }

            HoverHandler { id: nightHover }
            Rectangle { anchors.fill: parent; radius: parent.radius; color: nightHover.hovered ? Qt.rgba(1, 1, 1, 0.03) : "transparent" }

            TapHandler {
                onTapped: {
                    root.nightMode = !root.nightMode
                    let cmd = root.nightMode
                        ? ["bash", "-c", "wlsunset -l 19 -L -99 &>/dev/null & disown"]
                        : ["bash", "-c", "pkill wlsunset 2>/dev/null; true"]
                    Qt.createQmlObject(
                        'import Quickshell.Io; Process { command: ' +
                        JSON.stringify(cmd) + '; running: true }', root)
                }
            }
        }

        // Modo oscuro
        Rectangle {
            Layout.fillWidth: true
            height: 48
            radius: ws.cornersEnabled ? ws.cornerRadius : 0
            color: root.bgCard
            border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
            border.width: 1
            activeFocusOnTab: false
            focus: false

            RowLayout {
                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                spacing: 8

                Rectangle {
                    width: 28; height: 28; radius: 14
                    color: root.darkMode ? root.accent : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)
                    Layout.alignment: Qt.AlignVCenter

                    QsText {
                        anchors.centerIn: parent
                        text: "\uf042"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 12
                        color: root.darkMode ? "#ffffff" : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                    }
                }

                QsText {
                    text: "Modo oscuro"
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                    font.hintingPreference: Font.PreferNoHinting
                    renderType: Text.NativeRendering
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }
            }

            HoverHandler { id: darkHover }
            Rectangle { anchors.fill: parent; radius: parent.radius; color: darkHover.hovered ? Qt.rgba(1, 1, 1, 0.03) : "transparent" }

            TapHandler {
                onTapped: {
                    root.darkMode = !root.darkMode
                    let scheme = root.darkMode ? "prefer-dark" : "prefer-light"
                    let mode = root.darkMode ? "dark" : "light"
                    let cmd = ["bash", "-c",
                        "gsettings set org.gnome.desktop.interface color-scheme '" + scheme + "' 2>/dev/null; " +
                        "python3 /home/ismael/scripts/update_settings.py --mode " + mode + " 2>/dev/null; true"]
                    Qt.createQmlObject(
                        'import Quickshell.Io; Process { command: ' +
                        JSON.stringify(cmd) + '; running: true }', root)
                }
            }
        }

        // Modo concentración
        Rectangle {
            Layout.fillWidth: true
            height: 48
            radius: ws.cornersEnabled ? ws.cornerRadius : 0
            color: root.bgCard
            border.color: Qt.rgba(root.border.r, root.border.g, root.border.b, 0.35)
            border.width: 1
            activeFocusOnTab: false
            focus: false

            RowLayout {
                anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                spacing: 8

                Rectangle {
                    width: 28; height: 28; radius: 14
                    color: root.dndMode ? root.accent : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.06)
                    Layout.alignment: Qt.AlignVCenter

                    QsText {
                        anchors.centerIn: parent
                        text: "\uf1f6"
                        font.family: "Font Awesome 6 Free"
                        font.pixelSize: 12
                        color: root.dndMode ? "#ffffff" : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4)
                    }
                }

                QsText {
                    text: "Concentración"
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                    font.hintingPreference: Font.PreferNoHinting
                    renderType: Text.NativeRendering
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }
            }

            HoverHandler { id: dndHoverTgl }
            Rectangle { anchors.fill: parent; radius: parent.radius; color: dndHoverTgl.hovered ? Qt.rgba(1, 1, 1, 0.03) : "transparent" }

            TapHandler {
                onTapped: {
                    root.dndMode = !root.dndMode
                    toggleDndProcess.running = false
                    toggleDndProcess.running = true
                }
            }
        }
    }
}
