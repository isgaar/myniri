// WifiPasswordDialog.qml — Popup de contraseña para red WiFi
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

BasePopup {
    id: root

    WindowSettings { id: ws }

    anchors {
        top: false
        bottom: false
        left: false
        right: false
    }

    implicitWidth: 540
    implicitHeight: errorText.length > 0 ? 284 : 252

    property string ssid: ""
    property bool showPassword: false
    property bool connecting: false
    property string errorText: ""
    property var onFinishCallback: null

    readonly property color bgTile: (shellRoot.themeConfig && shellRoot.themeConfig.bgTile) || "#2a2a2a"





    function open(targetSsid, finishCallback) {
        root.ssid = targetSsid
        root.onFinishCallback = finishCallback
        root.showPassword = false
        root.connecting = false
        root.errorText = ""
        root.visible = true
    }

    function close() {
        root.visible = false
        root.ssid = ""
        root.errorText = ""
        if (root.onFinishCallback) {
            root.onFinishCallback(false)
            root.onFinishCallback = null
        }
    }

    function connect() {
        if (passwordField.text.length === 0 || root.connecting) return
        root.connecting = true
        connectProcess.running = true
    }

    Process {
        id: connectProcess
        command: ["bash", "/home/ismael/.config/quickshell/unified/connect_wifi.sh", root.ssid, passwordField.text]
        running: false
        onExited: (exitCode, exitStatus) => {
            root.connecting = false
            if (exitCode === 0) {
                let cb = root.onFinishCallback
                root.onFinishCallback = null // Limpiar callback para que close() no lo llame de nuevo
                root.visible = false
                root.ssid = ""
                if (cb) {
                    cb(true)
                }
            } else {
                root.errorText = "No se pudo autenticar. Revise la contraseña e intente de nuevo."
                passwordField.selectAll()
                passwordField.forceActiveFocus()
            }
        }
    }

    onVisibleChanged: {
        if (visible) {
            passwordField.text = ""
            root.errorText = ""
            passwordField.forceActiveFocus()
        }
    }

    // Sin backdrop fullscreen para evitar que toda la pantalla se vea con blur

    Rectangle {
        id: dialogBox
        anchors.fill: parent
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        
        color: {
            let base = Qt.color(root.bgCard)
            return Qt.rgba(base.r, base.g, base.b, 0.85)
        }
        border.color: root.border
        border.width: 1

        scale: 1.0
        Behavior on height {
            enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
            NumberAnimation { duration: 160; easing.type: Easing.OutCubic }
        }

        MouseArea {
            anchors.fill: parent
        }

        RowLayout {
            anchors { fill: parent; margins: 20 }
            spacing: 16

            Rectangle {
                Layout.alignment: Qt.AlignTop
                Layout.preferredWidth: 48
                Layout.preferredHeight: 48
                radius: 24
                color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.15)
                border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.3)
                border.width: 1

                QsText {
                    anchors.centerIn: parent
                    text: "\uf1eb" // Wi-Fi icon
                    font.family: "Font Awesome 6 Free"
                    font.pixelSize: 20
                    color: root.accent
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 12

                QsText {
                    text: "Autenticar " + root.ssid
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 15
                    font.weight: Font.DemiBold
                    font.hintingPreference: Font.PreferNoHinting
                    renderType: Text.NativeRendering
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }

                QsText {
                    text: "Introduzca la contraseña para la red Wi-Fi \"" + root.ssid + "\"."
                    color: root.textSec
                    font.family: "Inter"
                    font.pixelSize: 12
                    font.weight: Font.Normal
                    font.hintingPreference: Font.PreferNoHinting
                    renderType: Text.NativeRendering
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10
                    QsText {
                        text: "Contraseña:"
                        color: root.textPri
                        font.family: "Inter"
                        font.pixelSize: 12
                        font.weight: Font.Medium
                        Layout.preferredWidth: 86
                    }

                    TextField {
                        id: passwordField
                        echoMode: root.showPassword ? TextInput.Normal : TextInput.Password
                        color: root.textPri
                        selectedTextColor: "#111317"
                        selectionColor: root.accent
                        enabled: !root.connecting

                        background: Rectangle {
                            color: Qt.rgba(1, 1, 1, 0.04)
                            border.color: passwordField.activeFocus ? root.accent : root.border
                            border.width: 1
                            radius: 8
                        }

                        font.family: "Inter"
                        font.pixelSize: 13
                        Layout.fillWidth: true
                        Layout.preferredHeight: 34
                        leftPadding: 10
                        rightPadding: 10

                        Keys.onReturnPressed: root.connect()
                        Keys.onEscapePressed: {
                            if (!root.connecting) root.close()
                        }
                    }
                }

                RowLayout {
                    spacing: 10
                    Layout.fillWidth: true
                    enabled: !root.connecting

                    Rectangle {
                        width: 44
                        height: 24
                        radius: ws.cornersEnabled ? Math.min(10, ws.cornerRadius) : 0
                        color: root.showPassword ? root.accent : root.border
                        border.color: root.showPassword ? root.accent : root.border
                        border.width: 1

                        Rectangle {
                            width: 20
                            height: 20
                            radius: ws.cornersEnabled ? Math.min(10, Math.max(0, ws.cornerRadius - 2)) : 0
                            y: 2
                            x: root.showPassword ? parent.width - width - 2 : 2
                            color: "#ffffff"
                            Behavior on x {
                                enabled: (shellRoot.themeConfig && shellRoot.themeConfig.animationsEnabled) !== false
                                NumberAnimation { duration: 140; easing.type: Easing.OutQuad }
                            }
                        }

                        TapHandler { onTapped: root.showPassword = !root.showPassword }
                    }

                    QsText {
                        text: "Mostrar contraseña"
                        color: root.textSec
                        font.family: "Inter"
                        font.pixelSize: 11
                        font.hintingPreference: Font.PreferNoHinting
                        renderType: Text.NativeRendering
                        TapHandler { onTapped: root.showPassword = !root.showPassword }
                    }

                    Item { Layout.fillWidth: true }
                }

                QsText {
                    visible: root.errorText.length > 0
                    text: root.errorText
                    color: root.danger
                    font.family: "Inter"
                    font.pixelSize: 11
                    Layout.fillWidth: true
                    wrapMode: Text.WordWrap
                }

                Item { Layout.fillHeight: true }

                RowLayout {
                    spacing: 8
                    Layout.alignment: Qt.AlignRight

                    Rectangle {
                        width: 92
                        height: 32
                        radius: 6
                        color: "transparent"
                        border.color: root.border
                        border.width: 1
                        visible: !root.connecting

                        QsText {
                            anchors.centerIn: parent
                            text: "Cancelar"
                            color: root.textPri
                            font.family: "Inter"
                            font.pixelSize: 13
                            font.weight: Font.Medium
                        }

                        HoverHandler { id: cancelHover }
                        Rectangle {
                            anchors.fill: parent
                            radius: parent.radius
                            color: cancelHover.hovered ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
                        }

                        TapHandler { onTapped: root.close() }
                    }

                    Rectangle {
                        width: root.connecting ? 126 : 92
                        height: 32
                        radius: 6
                        color: root.connecting ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.6) : root.accent
                        border.width: 0

                        Row {
                            anchors.centerIn: parent
                            spacing: 7
                            QsText {
                                visible: root.connecting
                                text: "\uf110"
                                font.family: "Font Awesome 6 Free"
                                font.pixelSize: 12
                                color: "#ffffff"
                                RotationAnimator on rotation {
                                    from: 0; to: 360; duration: 1000; loops: Animation.Infinite; running: root.connecting
                                }
                            }
                            QsText {
                                text: root.connecting ? "Conectando..." : "Conectar"
                                color: "#ffffff"
                                font.family: "Inter"
                                font.pixelSize: 13
                                font.weight: Font.Medium
                                font.hintingPreference: Font.PreferNoHinting
                                renderType: Text.NativeRendering
                            }
                        }

                        HoverHandler { id: connectHover }
                        Rectangle {
                            anchors.fill: parent
                            radius: parent.radius
                            color: (connectHover.hovered && !root.connecting) ? Qt.rgba(1, 1, 1, 0.15) : "transparent"
                        }

                        TapHandler { onTapped: root.connect() }
                    }
                }
            }
        }
    }
}
