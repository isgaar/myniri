// PanelSliders.qml — Zona 2: sliders volumen + brillo
import Quickshell.Io
import QtQuick
import QtQuick.Layouts

Item {
    id: root

    WindowSettings { id: ws }
    implicitHeight: 52

    property color bgCard
    property color border
    property color textSec
    property color accent
    property bool panelVisible: false

    property int volume: 89
    property int brightness: 90
    property bool volMuted: false
    property int pendingVolume: volume
    property int pendingBrightness: brightness

    property int mic: 89
    property bool micMuted: false
    property int pendingMic: mic

    function refreshAudio() {
        audioRefresh.running = false
        Qt.callLater(() => audioRefresh.running = true)
    }

    function clamp(v, lo, hi) {
        return Math.max(lo, Math.min(hi, v))
    }

    function setVolumeFromX(x, width) {
        root.pendingVolume = Math.round(clamp(x / width, 0, 1) * 100)
        root.volume = root.pendingVolume
        if (root.volume > 0) root.volMuted = false
        volumeCommit.restart()
    }

    function setMicFromX(x, width) {
        root.pendingMic = Math.round(clamp(x / width, 0, 1) * 100)
        root.mic = root.pendingMic
        if (root.mic > 0) root.micMuted = false
        micCommit.restart()
    }

    function setBrightnessFromX(x, width) {
        root.pendingBrightness = Math.round(clamp(x / width, 0, 1) * 99) + 1
        root.brightness = root.pendingBrightness
        brightnessCommit.restart()
    }

    Timer {
        id: audioRefreshDelay
        interval: 250
        repeat: false
        onTriggered: root.refreshAudio()
    }

    Process { id: volumeSetterProcess }
    Timer {
        id: volumeCommit
        interval: 15
        repeat: false
        onTriggered: {
            volumeSetterProcess.running = false
            volumeSetterProcess.command = ["bash", "-c", "pactl set-sink-volume @DEFAULT_SINK@ " + root.pendingVolume + "%; pactl set-sink-mute @DEFAULT_SINK@ 0"]
            volumeSetterProcess.running = true
        }
    }

    Process { id: brightnessSetterProcess }
    Timer {
        id: brightnessCommit
        interval: 15
        repeat: false
        onTriggered: {
            brightnessSetterProcess.running = false
            brightnessSetterProcess.command = ["brightnessctl", "set", root.pendingBrightness + "%"]
            brightnessSetterProcess.running = true
        }
    }
    
    Process { id: muteProcess }

    Process { id: micSetterProcess }
    Timer {
        id: micCommit
        interval: 15
        repeat: false
        onTriggered: {
            micSetterProcess.running = false
            micSetterProcess.command = ["bash", "-c", "pactl set-source-volume @DEFAULT_SOURCE@ " + root.pendingMic + "%; pactl set-source-mute @DEFAULT_SOURCE@ 0"]
            micSetterProcess.running = true
        }
    }
    
    Process { id: micMuteProcess }

    Process {
        id: audioRefresh
        command: ["bash", "-c",
            "echo SINK_VOL:$(pactl get-sink-volume @DEFAULT_SINK@ | grep -oP '\\d+%' | head -1 | tr -d '%'); echo SINK_MUTE:$(pactl get-sink-mute @DEFAULT_SINK@ | awk '{print $2}'); echo SRC_VOL:$(pactl get-source-volume @DEFAULT_SOURCE@ | grep -oP '\\d+%' | head -1 | tr -d '%'); echo SRC_MUTE:$(pactl get-source-mute @DEFAULT_SOURCE@ | awk '{print $2}')"]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("SINK_MUTE:")) {
                    let val = line.substring(10).trim().toLowerCase()
                    root.volMuted = (val === "yes" || val === "sí" || val === "si")
                } else if (line.startsWith("SINK_VOL:")) {
                    let v = parseInt(line.substring(9))
                    if (!isNaN(v)) root.volume = Math.min(v, 100)
                } else if (line.startsWith("SRC_MUTE:")) {
                    let val = line.substring(9).trim().toLowerCase()
                    root.micMuted = (val === "yes" || val === "sí" || val === "si")
                } else if (line.startsWith("SRC_VOL:")) {
                    let v = parseInt(line.substring(8))
                    if (!isNaN(v)) root.mic = Math.min(v, 100)
                }
            }
        }
    }

    Process {
        command: ["bash", "-c",
            "echo SINK_VOL:$(pactl get-sink-volume @DEFAULT_SINK@ | grep -oP '\\d+%' | head -1 | tr -d '%'); echo SINK_MUTE:$(pactl get-sink-mute @DEFAULT_SINK@ | awk '{print $2}'); echo SRC_VOL:$(pactl get-source-volume @DEFAULT_SOURCE@ | grep -oP '\\d+%' | head -1 | tr -d '%'); echo SRC_MUTE:$(pactl get-source-mute @DEFAULT_SOURCE@ | awk '{print $2}')"]
        running: root.panelVisible
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line.startsWith("SINK_MUTE:")) {
                    let val = line.substring(10).trim().toLowerCase()
                    root.volMuted = (val === "yes" || val === "sí" || val === "si")
                } else if (line.startsWith("SINK_VOL:")) {
                    let v = parseInt(line.substring(9))
                    if (!isNaN(v)) root.volume = Math.min(v, 100)
                } else if (line.startsWith("SRC_MUTE:")) {
                    let val = line.substring(9).trim().toLowerCase()
                    root.micMuted = (val === "yes" || val === "sí" || val === "si")
                } else if (line.startsWith("SRC_VOL:")) {
                    let v = parseInt(line.substring(8))
                    if (!isNaN(v)) root.mic = Math.min(v, 100)
                }
            }
        }
    }

    Process {
        command: ["bash", "-c",
            "brightnessctl -m | cut -d, -f4 | tr -d '%' 2>/dev/null || echo 90"]
        running: root.panelVisible
        stdout: SplitParser {
            onRead: data => {
                let v = parseInt(data.trim())
                if (!isNaN(v)) root.brightness = v
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        color: root.bgCard
        radius: ws.cornersEnabled ? ws.cornerRadius : 0
        border.color: root.border
        border.width: 1
    }

    RowLayout {
        anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
        spacing: 16

        // Icono volumen FA
        QsText {
            text: root.volMuted ? "\uf6a9" : "\uf028"
            font.family: "Font Awesome 6 Free"
            font.weight: Font.Black
            font.pixelSize: 15
            color: root.volMuted ? "#e06c6c" : root.textSec
            MouseArea {
                anchors.fill: parent
                onClicked: {
                    muteProcess.running = false
                    muteProcess.command = ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"]
                    muteProcess.running = true
                    root.volMuted = !root.volMuted
                    audioRefreshDelay.restart()
                }
            }
        }

        Item {
            id: volSlider
            Layout.fillWidth: true
            height: 24

            Rectangle {
                id: volTrack
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                height: 8
                radius: 4
                color: root.border

                Rectangle {
                    width: (root.volume / 100) * parent.width
                    height: parent.height
                    radius: parent.radius
                    color: root.volMuted ? root.textSec : root.accent
                }

                Row {
                    anchors.fill: parent
                    anchors.leftMargin: parent.width / 10
                    anchors.rightMargin: parent.width / 10
                    spacing: (parent.width - (parent.width / 5)) / 10
                    Repeater {
                        model: 9
                        Rectangle {
                            width: 2; height: 2; radius: 1
                            color: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.15) : Qt.rgba(255, 255, 255, 0.15)
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                }
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onPressed: mouse => root.setVolumeFromX(mouse.x, width)
                onPositionChanged: mouse => {
                    if (pressed) root.setVolumeFromX(mouse.x, width)
                }
                onReleased: audioRefreshDelay.restart()
            }
        }

        Rectangle { width: 1; height: 20; color: root.border }

        // Icono Mic FA
        QsText {
            text: root.micMuted ? "\uf131" : "\uf130"
            font.family: "Font Awesome 6 Free"
            font.pixelSize: 15
            color: root.micMuted ? "#e06c6c" : root.textSec
            MouseArea {
                anchors.fill: parent
                onClicked: {
                    micMuteProcess.running = false
                    micMuteProcess.command = ["pactl", "set-source-mute", "@DEFAULT_SOURCE@", "toggle"]
                    micMuteProcess.running = true
                    root.micMuted = !root.micMuted
                    audioRefreshDelay.restart()
                }
            }
        }

        Item {
            id: micSlider
            Layout.fillWidth: true
            height: 24

            Rectangle {
                id: micTrack
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                height: 8
                radius: 4
                color: root.border

                Rectangle {
                    width: (root.mic / 100) * parent.width
                    height: parent.height
                    radius: parent.radius
                    color: root.micMuted ? root.textSec : root.accent
                }

                Row {
                    anchors.fill: parent
                    anchors.leftMargin: parent.width / 10
                    anchors.rightMargin: parent.width / 10
                    spacing: (parent.width - (parent.width / 5)) / 10
                    Repeater {
                        model: 9
                        Rectangle {
                            width: 2; height: 2; radius: 1
                            color: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.15) : Qt.rgba(255, 255, 255, 0.15)
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                }
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onPressed: mouse => root.setMicFromX(mouse.x, width)
                onPositionChanged: mouse => {
                    if (pressed) root.setMicFromX(mouse.x, width)
                }
                onReleased: audioRefreshDelay.restart()
            }
        }

        Rectangle { width: 1; height: 20; color: root.border }

        // Icono brillo FA
        QsText {
            text: "\uf185"
            font.family: "Font Awesome 6 Free"
            font.pixelSize: 15
            color: root.accent
        }

        Item {
            id: briSlider
            Layout.fillWidth: true
            height: 24

            Rectangle {
                id: briTrack
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                height: 8
                radius: 4
                color: root.border

                Rectangle {
                    width: ((root.brightness - 1) / 99) * parent.width
                    height: parent.height
                    radius: parent.radius
                    color: root.accent
                }

                Row {
                    anchors.fill: parent
                    anchors.leftMargin: parent.width / 10
                    anchors.rightMargin: parent.width / 10
                    spacing: (parent.width - (parent.width / 5)) / 10
                    Repeater {
                        model: 9
                        Rectangle {
                            width: 2; height: 2; radius: 1
                            color: (shellRoot.themeConfig && shellRoot.themeConfig.theme_mode === "light") ? Qt.rgba(0, 0, 0, 0.15) : Qt.rgba(255, 255, 255, 0.15)
                            anchors.verticalCenter: parent.verticalCenter
                        }
                    }
                }
            }

            MouseArea {
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onPressed: mouse => root.setBrightnessFromX(mouse.x, width)
                onPositionChanged: mouse => {
                    if (pressed) root.setBrightnessFromX(mouse.x, width)
                }
            }
        }
    }
}
