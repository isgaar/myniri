// PanelNetworkList.qml — Zona 4: Lista de redes con diseño premium tipo Apple
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Controls

Item {
    id: root
    implicitHeight: layoutCol.implicitHeight

    property color bgCard
    property color bgActive
    property color border
    property color borderHi
    property color textPri
    property color textSec
    property color accent
    property color accentWf

    property int activeTab: 1

    signal networkConnected(string ssid)
    signal closeRequested()

    ListModel { id: networkModel }
    property bool scanningNetworks: false
    property var seenNetworks: ({})

    // ── Estado de Wi-Fi ──────────────────────────────────────────
    property bool wifiEnabled: false
    Process {
        id: wifiStatePoller
        command: ["bash", "-c", "nmcli -t -f WIFI radio 2>/dev/null"]
        running: root.visible
        stdout: SplitParser {
            onRead: data => {
                let state = data.trim()
                root.wifiEnabled = (state === "enabled" || state === "activado")
                if (!root.wifiEnabled) {
                    networkModel.clear()
                    root.scanningNetworks = false
                }
            }
        }
    }
    Timer {
        interval: 5000
        repeat: true
        running: root.visible
        onTriggered: { wifiStatePoller.running = false; Qt.callLater(() => wifiStatePoller.running = true) }
    }

    function upsertNetwork(ssid, signal, security, active) {
        if (!ssid || ssid === "--") return
        root.seenNetworks[ssid] = true

        for (let i = 0; i < networkModel.count; i++) {
            let item = networkModel.get(i)
            if (item.ssid !== ssid) continue
            networkModel.setProperty(i, "signal", signal)
            networkModel.setProperty(i, "security", security)
            networkModel.setProperty(i, "active", active)
            return
        }

        networkModel.append({
            ssid: ssid,
            signal: signal,
            security: security,
            active: active
        })
    }

    function pruneUnseenNetworks() {
        for (let i = networkModel.count - 1; i >= 0; i--) {
            let item = networkModel.get(i)
            if (!root.seenNetworks[item.ssid] && !item.active)
                networkModel.remove(i)
        }
    }

    function finishConnectionAttempt() {
        root.connectingSsid = ""
        root.refresh()
    }

    function promptWifiPassword(ssid) {
        shellRoot.showWifiPasswordPrompt(ssid, (success) => {
            if (success) root.networkConnected(ssid)
            root.finishConnectionAttempt()
        })
    }

    function connectWifiDirect(ssid) {
        let cmd = ["bash", "/home/ismael/.config/quickshell/unified/connect_wifi.sh", ssid]
        Qt.createQmlObject(
            'import Quickshell.Io; Process {' +
            '  id: proc;' +
            '  command: ' + JSON.stringify(cmd) + ';' +
            '  running: true;' +
            '  onExited: (exitCode, exitStatus) => {' +
            '    if (exitCode === 0) {' +
            '      root.networkConnected(' + JSON.stringify(ssid) + ');' +
            '    } else if (exitCode === 2) {' +
            '      root.promptWifiPassword(' + JSON.stringify(ssid) + ');' +
            '    } else {' +
            '      root.finishConnectionAttempt();' +
            '    }' +
            '  }' +
            '}', root)
    }

    function connectWifiSecure(ssid) {
        let checkCmd = [
            "bash",
            "-c",
            "ssid=$1; while IFS=: read -r uuid type; do [ \"$type\" = \"802-11-wireless\" ] || continue; saved_ssid=$(nmcli --escape no -g 802-11-wireless.ssid connection show \"$uuid\" 2>/dev/null); [ \"$saved_ssid\" = \"$ssid\" ] && exit 0; done < <(nmcli -t -f UUID,TYPE connection show 2>/dev/null); exit 1",
            "qs-wifi-secret-check",
            ssid
        ]
        Qt.createQmlObject(
            'import Quickshell.Io; Process {' +
            '  id: checkProc;' +
            '  command: ' + JSON.stringify(checkCmd) + ';' +
            '  running: true;' +
            '  onExited: (exitCode, exitStatus) => {' +
            '    if (exitCode === 0) root.connectWifiDirect(' + JSON.stringify(ssid) + ');' +
            '    else root.promptWifiPassword(' + JSON.stringify(ssid) + ');' +
            '  }' +
            '}', root)
    }

    // ── Scanner de redes ─────
    Process {
        id: wifiScanner
        command: ["bash", "-c", [
            "echo BEGIN;",
            "nmcli --escape no -t -f active,ssid,signal,security dev wifi list --rescan no 2>/dev/null |",
            "awk -F: 'NF>=4 {act=$1; sec=$NF; sig=$(NF-1); ssid=\"\"; for(i=2;i<=NF-2;i++) ssid=ssid (i>2?\":\": \"\") $i; if(ssid != \"\" && ssid != \"--\") print ((act==\"yes\" || act==\"si\" || act==\"sí\") ? 0 : 1) \"|\" ssid \"|\" sig \"|\" sec}' |",
            "sort -t'|' -k1,1n -k3,3rn | awk -F'|' '!seen[$2]++' | head -15;",
            "echo END"
        ].join(" ")]
        running: root.visible
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line === "BEGIN") {
                    root.scanningNetworks = true
                    root.seenNetworks = ({})
                    return
                }
                if (line === "END") {
                    root.scanningNetworks = false
                    return
                }
                if (!line) return
                let parts = line.split("|")
                if (parts.length < 4) return
                let active   = parts[0] === "0"
                let ssid     = parts[1]
                let signal   = parseInt(parts[2]) || 0
                let security = parts[3] !== "--" && parts[3] !== ""
                root.upsertNetwork(ssid, signal, security, active)
            }
        }
    }

    Process {
        id: wifiRescanner
        command: ["bash", "-c", [
            "echo BEGIN_RESCAN;",
            "nmcli --escape no -t -f active,ssid,signal,security dev wifi list --rescan yes 2>/dev/null |",
            "awk -F: 'NF>=4 {act=$1; sec=$NF; sig=$(NF-1); ssid=\"\"; for(i=2;i<=NF-2;i++) ssid=ssid (i>2?\":\": \"\") $i; if(ssid != \"\" && ssid != \"--\") print ((act==\"yes\" || act==\"si\" || act==\"sí\") ? 0 : 1) \"|\" ssid \"|\" sig \"|\" sec}' |",
            "sort -t'|' -k1,1n -k3,3rn | awk -F'|' '!seen[$2]++' | head -15;",
            "echo END_RESCAN"
        ].join(" ")]
        running: false
        stdout: SplitParser {
            onRead: data => {
                let line = data.trim()
                if (line === "BEGIN_RESCAN") {
                    root.scanningNetworks = true
                    root.seenNetworks = ({})
                    return
                }
                if (line === "END_RESCAN") {
                    root.pruneUnseenNetworks()
                    root.scanningNetworks = false
                    return
                }
                if (!line) return
                let parts = line.split("|")
                if (parts.length < 4) return
                let active   = parts[0] === "0"
                let ssid     = parts[1]
                let signal   = parseInt(parts[2]) || 0
                let security = parts[3] !== "--" && parts[3] !== ""
                root.upsertNetwork(ssid, signal, security, active)
            }
        }
    }

    function refresh() {
        wifiScanner.running = false
        wifiRescanner.running = false
        Qt.callLater(() => {
            wifiScanner.running = true
            rescanDelay.restart()
        })
    }

    Timer {
        id: rescanDelay
        interval: 250
        repeat: false
        onTriggered: {
            if (root.visible)
                wifiRescanner.running = true
        }
    }

    property string connectingSsid: ""

    // Filtros de redes
    property var activeNetworks: []
    property var hotspotNetworks: []
    property var otherNetworks: []

    function updateNetworkLists() {
        let active = []
        let hotspot = []
        let other = []
        for (let i = 0; i < networkModel.count; i++) {
            let net = networkModel.get(i)
            let isHotspot = net.ssid.toLowerCase().includes("iphone") || net.ssid.toLowerCase().includes("android") || net.ssid.toLowerCase().includes("hotspot")
            if (net.active) {
                active.push(net)
            } else if (isHotspot) {
                hotspot.push(net)
            } else {
                other.push(net)
            }
        }
        root.activeNetworks = active
        root.hotspotNetworks = hotspot
        root.otherNetworks = other
    }

    Connections {
        target: networkModel
        function onCountChanged() { root.updateNetworkLists() }
        function onDataChanged() { root.updateNetworkLists() }
    }

    // Estilos
    readonly property color menuBg: root.bgCard
    readonly property color itemHoverBg: Qt.rgba(1, 1, 1, 0.05)
    readonly property color dividerColor: Qt.rgba(1, 1, 1, 0.08)

    component NetworkItem: Rectangle {
        id: delegateRoot
        width: parent.width
        height: 38
        color: "transparent"

        property string ssidText: ""
        property bool isActive: false
        property bool isSecure: false
        property int signalLvl: 0
        property bool hasTopBorder: false
        property bool isFirst: false
        property bool isLast: false

        // Borde superior opcional como separador
        Rectangle {
            visible: delegateRoot.hasTopBorder
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.leftMargin: 36
            height: 1
            color: root.dividerColor
        }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 12
            spacing: 12

            // Icono de estado (candado / check)
            Item {
                width: 16
                height: 16
                QsText {
                    anchors.centerIn: parent
                    text: delegateRoot.isActive ? "\uf00c" : (delegateRoot.isSecure ? "\uf023" : "")
                    font.family: "Font Awesome 6 Free"
                    font.pixelSize: delegateRoot.isActive ? 12 : 10
                    color: delegateRoot.isActive ? root.accentWf : root.textSec
                }
            }

            // SSID
            QsText {
                text: delegateRoot.ssidText
                color: root.textPri
                font.family: "Inter"
                font.pixelSize: 13
                font.weight: delegateRoot.isActive ? Font.Medium : Font.Normal
                elide: Text.ElideRight
                Layout.fillWidth: true
            }

            // Señal
            QsText {
                text: "\uf1eb"
                font.family: "Font Awesome 6 Free"
                font.pixelSize: 13
                color: delegateRoot.isActive
                     ? root.accentWf
                     : (delegateRoot.signalLvl >= 70 ? root.textPri
                          : delegateRoot.signalLvl >= 40 ? Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.7)
                          : Qt.rgba(root.textPri.r, root.textPri.g, root.textPri.b, 0.4))
            }
        }

        HoverHandler { id: hover }
        Rectangle {
            anchors.fill: parent
            radius: 8
            anchors.margins: 2
            color: hover.hovered ? root.itemHoverBg : "transparent"
        }

        TapHandler {
            onTapped: {
                if (!delegateRoot.isActive) {
                    root.connectingSsid = delegateRoot.ssidText
                    if (delegateRoot.isSecure) root.connectWifiSecure(delegateRoot.ssidText)
                    else root.connectWifiDirect(delegateRoot.ssidText)
                }
            }
        }
    }

    component SectionHeader: QsText {
        property string title: ""
        text: title
        color: root.textSec
        font.family: "Inter"
        font.pixelSize: 11
        font.weight: Font.Medium
        font.capitalization: Font.MixedCase
        leftPadding: 12
        topPadding: 16
        bottomPadding: 4
    }

    Column {
        id: layoutCol
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        spacing: 0

        // 1. Cabecera Wi-Fi Toggle
        Rectangle {
            width: parent.width
            height: 52
            color: "transparent"

            RowLayout {
                anchors.fill: parent
                anchors.leftMargin: 16
                anchors.rightMargin: 16
                spacing: 12

                QsText {
                    text: "Wi-Fi"
                    color: root.textPri
                    font.family: "Inter"
                    font.pixelSize: 14
                    font.weight: Font.Medium
                    Layout.fillWidth: true
                }

                // Switch Toggle UI
                Item {
                    width: 44; height: 24
                    Rectangle {
                        anchors.fill: parent
                        radius: 12
                        color: root.wifiEnabled ? root.accentWf : Qt.rgba(0.5, 0.5, 0.5, 0.2)
                        border.color: root.wifiEnabled ? root.accentWf : Qt.rgba(0.5, 0.5, 0.5, 0.3)
                        border.width: 1
                        Behavior on color { ColorAnimation { duration: 150 } }

                        Rectangle {
                            width: 20; height: 20
                            radius: 10
                            color: "white"
                            y: 2
                            x: root.wifiEnabled ? parent.width - width - 2 : 2
                            
                            Behavior on x {
                                NumberAnimation { duration: 150; easing.type: Easing.OutQuad }
                            }
                        }
                    }
                    TapHandler {
                        onTapped: {
                            let cmd = root.wifiEnabled
                                ? ["nmcli", "radio", "wifi", "off"]
                                : ["nmcli", "radio", "wifi", "on"]
                            Qt.createQmlObject(
                                'import Quickshell.Io; Process { command: ' +
                                JSON.stringify(cmd) + '; running: true }', root)
                            root.wifiEnabled = !root.wifiEnabled
                            wifiScanner.running = false
                            if (root.wifiEnabled) Qt.callLater(() => wifiScanner.running = true)
                        }
                    }
                }
            }
        }

        Rectangle {
            width: parent.width - 24
            anchors.horizontalCenter: parent.horizontalCenter
            height: 1
            color: root.dividerColor
            visible: root.wifiEnabled
        }

        // 2. Personal Hotspots
        Column {
            width: parent.width
            visible: root.wifiEnabled && root.hotspotNetworks.length > 0
            
            SectionHeader { title: "Puntos de acceso personales" }
            
            Repeater {
                model: root.hotspotNetworks
                delegate: NetworkItem {
                    ssidText: modelData.ssid
                    isActive: modelData.active
                    isSecure: modelData.security
                    signalLvl: modelData.signal
                    hasTopBorder: index > 0
                }
            }
        }

        // 3. Known Networks (Active network for now)
        Column {
            width: parent.width
            visible: root.wifiEnabled && root.activeNetworks.length > 0
            
            SectionHeader { title: "Red conocida" }
            
            Repeater {
                model: root.activeNetworks
                delegate: NetworkItem {
                    ssidText: modelData.ssid
                    isActive: modelData.active
                    isSecure: modelData.security
                    signalLvl: modelData.signal
                    hasTopBorder: index > 0
                }
            }
        }

        // 4. Other Networks
        Column {
            width: parent.width
            visible: root.wifiEnabled && root.otherNetworks.length > 0
            
            SectionHeader { title: "Otras redes" }
            
            Repeater {
                model: root.otherNetworks.slice(0, 5) // Limit to 5
                delegate: NetworkItem {
                    ssidText: modelData.ssid
                    isActive: modelData.active
                    isSecure: modelData.security
                    signalLvl: modelData.signal
                    hasTopBorder: index > 0
                }
            }
        }

        // 5. Spinner Buscando...
        Item {
            width: parent.width
            height: 40
            visible: root.wifiEnabled && root.scanningNetworks && root.otherNetworks.length === 0
            
            RowLayout {
                anchors.centerIn: parent
                spacing: 8
                QsText {
                    text: "\uf1ce"
                    font.family: "Font Awesome 6 Free"
                    font.pixelSize: 12
                    color: root.textSec
                    RotationAnimator on rotation {
                        from: 0; to: 360; duration: 1000; loops: Animation.Infinite; running: root.visible && root.scanningNetworks
                    }
                }
                QsText {
                    text: "Buscando redes..."
                    color: root.textSec
                    font.family: "Inter"
                    font.pixelSize: 12
                }
            }
        }

        // 6. Wi-Fi Settings button
        Item {
            width: parent.width
            height: 54
            
            Rectangle {
                anchors.fill: parent
                anchors.margins: 8
                anchors.topMargin: 12
                radius: 8
                color: settingsHover.hovered ? root.itemHoverBg : "transparent"

                RowLayout {
                    anchors.centerIn: parent
                    spacing: 8
                    QsText {
                        text: "Configuración de Wi-Fi..."
                        color: root.textPri
                        font.family: "Inter"
                        font.pixelSize: 13
                    }
                }

                HoverHandler { id: settingsHover }
                TapHandler {
                    onTapped: {
                        root.closeRequested()
                        Qt.createQmlObject('import Quickshell.Io; Process { command: ["bash", "-c", "nm-connection-editor || gnome-control-center wifi || kcmshell6 kcm_networkmanagement"]; running: true }', root)
                    }
                }
            }
        }
    }
}
