#!/bin/bash

resolve_swaysock() {
    local socket

    if [ -n "${SWAYSOCK:-}" ] && [ -S "$SWAYSOCK" ]; then
        return
    fi

    socket=$(sway --get-socketpath 2>/dev/null)
    if [ -z "$socket" ] || [ ! -S "$socket" ]; then
        socket=$(find "${XDG_RUNTIME_DIR:-/run/user/$(id -u)}" -maxdepth 1 -type s -name 'sway-ipc*.sock' -printf '%T@ %p\n' 2>/dev/null | sort -nr | awk 'NR == 1 {print $2}')
    fi

    if [ -n "$socket" ] && [ -S "$socket" ]; then
        export SWAYSOCK="$socket"
        export I3SOCK="$socket"
    fi
}

format_app_name() {
    local raw="${1:-}"
    local title="${2:-}"
    local value="${raw,,} ${title,,}"
    local title_lc="${title,,}"

    case "$value" in
        *kitty*) echo "Kitty" ;;
        *codium*|*"visual studio code"*) echo "VSCodium" ;;
        *firefox*) echo "Firefox" ;;
        *brave*) echo "Brave" ;;
        *zen*) echo "Zen" ;;
        *dolphin*) echo "Dolphin" ;;
        *discord*) echo "Discord" ;;
        *telegram*) echo "Telegram" ;;
        *spotify*) echo "Spotify" ;;
        *steam*) echo "Steam" ;;
        *okular*) echo "Okular" ;;
        *krita*) echo "Krita" ;;
        *konsole*) echo "Konsole" ;;
        *"antigravity"*) echo "Antigravity" ;;
        *)
            if [ -n "$title" ] && [ "$title" != "null" ] && [ "$title_lc" != "focused" ]; then
                printf '%s' "$title" | sed -E 's/[[:space:]]+-[[:space:]].*$//; s/[[:space:]]+—[[:space:]].*$//; s/[[:space:]]*\\|.*$//' | awk '{print toupper(substr($0,1,1)) substr($0,2)}'
            elif [ -n "$raw" ] && [ "$raw" != "null" ]; then
                printf '%s' "$raw" | awk '{print toupper(substr($0,1,1)) substr($0,2)}'
            else
                echo "Niri"
            fi
            ;;
    esac
}

emit_active_app() {
    local node app_id title name

    node=$(niri msg --json focused-window 2>/dev/null)
    if [ -z "$node" ] || [ "$node" = "null" ]; then
        jq -cn --arg text "Niri" --arg tooltip "Niri" '{text:$text, tooltip:$tooltip, class:"niri"}'
        return
    fi

    app_id=$(printf '%s' "$node" | jq -r '.app_id // empty')
    title=$(printf '%s' "$node" | jq -r '.title // empty')
    name=$(format_app_name "$app_id" "$title")

    [ -n "$name" ] || name="Niri"
    jq -cn --arg text "$name" --arg tooltip "${title:-$name}" '{text:$text, tooltip:$tooltip, class:"active"}'
}

emit_active_app
