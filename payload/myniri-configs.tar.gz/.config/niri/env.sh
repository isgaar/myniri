export QT_QPA_PLATFORMTHEME=kde
export QT_STYLE_OVERRIDE=Breeze
export GTK_THEME=Breeze-Dark
export XCURSOR_THEME=breeze_cursors
export XCURSOR_SIZE=24

# Evitar doble escalado en Wayland (Niri escala nativamente la UI)
export QT_AUTO_SCREEN_SCALE_FACTOR=0
export QT_ENABLE_HIGHDPI_SCALING=0
unset GDK_SCALE
unset QT_SCALE_FACTOR

# Forzar resolución de fuentes uniforme a 96 DPI reales (el escalado de pixels lo hace Wayland)
export QT_FONT_DPI=96
export GDK_DPI_SCALE=1

# Pre-cargar las librerías de Honey a nivel de sesión para evitar que el wrapper acceda a disco
HONEY_LIB_DIR="$HOME/.config/honey/lib"
if [ -d "$HONEY_LIB_DIR" ]; then
    export LD_LIBRARY_PATH="$HONEY_LIB_DIR:$LD_LIBRARY_PATH"
fi

export ELECTRON_USE_WAYLAND=1
export EDITOR=nano
export BROWSER=/opt/zen/zen
export TERMINAL=kitty
export NO_AT_BRIDGE=1
