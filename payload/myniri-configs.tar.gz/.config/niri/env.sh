export QT_QPA_PLATFORMTHEME=kde
export QT_STYLE_OVERRIDE=Breeze
export KDE_COLOR_SCHEME="Moonfly Dark"
export GTK_THEME=Breeze-Dark
export XCURSOR_THEME=breeze_cursors
export XCURSOR_SIZE=24
export FREETYPE_PROPERTIES="cff:no-stem-darkening=0 type1:no-stem-darkening=0 t1cid:no-stem-darkening=0 autofitter:no-stem-darkening=0 truetype:interpreter-version=40 cff:darkening-parameters=500,360,1000,240,1500,120,2000,0 autofitter:darkening-parameters=500,360,1000,240,1500,120,2000,0"

# Evitar doble escalado en Wayland: Niri escala la UI.
export QT_AUTO_SCREEN_SCALE_FACTOR=0
export QT_ENABLE_HIGHDPI_SCALING=0
unset GDK_SCALE
unset QT_SCALE_FACTOR
unset QT_WAYLAND_DECORATION

export QT_FONT_DPI=96
export GDK_DPI_SCALE=1

HONEY_LIB_DIR="$HOME/.config/honey/lib"
if [ -d "$HONEY_LIB_DIR" ]; then
    export LD_LIBRARY_PATH="$HONEY_LIB_DIR:$LD_LIBRARY_PATH"
fi

export ELECTRON_USE_WAYLAND=1
export EDITOR=nano
export BROWSER=/opt/zen/zen
export TERMINAL=kitty
export NO_AT_BRIDGE=1
export XDG_CONFIG_HOME="$HOME/.config/niri/xdg-config"
export XDG_MENU_PREFIX=plasma-
export XDG_DATA_DIRS="${XDG_DATA_DIRS:-$HOME/.local/share/flatpak/exports/share:/var/lib/flatpak/exports/share:/usr/local/share:/usr/share}"

export QT_QPA_PLATFORM=wayland-egl
export QML_FORCE_DISK_CACHE=1
export XCURSOR_PATH=$HOME/.local/share/icons:$HOME/.icons:/usr/share/icons
