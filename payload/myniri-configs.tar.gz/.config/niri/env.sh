export QT_QPA_PLATFORMTHEME=kde
export QT_STYLE_OVERRIDE=Breeze
export GTK_THEME=Breeze-Dark
export XCURSOR_THEME=breeze_cursors
export XCURSOR_SIZE=24
export GDK_DPI_SCALE=1
export QT_FONT_DPI=96
export KDED_FIRST_STARTUP=1
export QT_AUTO_SCREEN_SCALE_FACTOR=0
export QT_ENABLE_HIGHDPI_SCALING=0
export ELECTRON_USE_WAYLAND=1
export EDITOR=nano
export BROWSER=/opt/zen/zen
export TERMINAL=kitty
export NO_AT_BRIDGE=1

