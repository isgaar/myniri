# Bitácora de Renderizado (Estilo macOS)

En este documento registraremos todos los cambios realizados para alcanzar una renderización de fuentes fiel a la filosofía de macOS, así como sus impactos en las diferentes aplicaciones y entornos (Wayland, GTK, Qt).

| Fecha | Cambio realizado | Aplicación afectada | Observación (¿Se acerca a macOS?) |
| :--- | :--- | :--- | :--- |
| 2026-06-11 | Creado `fonts.conf` base con `hintstyle=hintnone` y `hinting=false` | Todo el sistema (fontconfig) | Se espera que el texto se vea más redondo y fiel al diseño original, con menos alineación artificial a la cuadrícula de píxeles. |
| 2026-06-11 | Activado `lcdfilter=lcdnone` y subpixel AA `rgba=none` | Todo el sistema (fontconfig) | Forzar escala de grises y desactivar el suavizado de subpíxeles (RGB) para mayor fidelidad a macOS. |
| 2026-06-11 | Forzado `font-antialiasing 'grayscale'` en gsettings | GTK/GNOME | Asegura que las aplicaciones GTK respeten la escala de grises. |
| 2026-06-11 | Agregada variable `FREETYPE_PROPERTIES="cff:no-stem-darkening=0 autofitter:no-stem-darkening=0"` | Todo el Entorno (environment.d) | Habilita el *Stem Darkening* de forma global para dar más cuerpo y peso a las letras (especialmente útil para fuentes como Inter). Anteriormente solo en Sway. |
| 2026-06-11 | Agregado `--disable-lcd-text` en `~/.config/*-flags.conf` | Chromium, Chrome, Electron | Fuerza explícitamente a navegadores basados en Chromium a usar escala de grises en vez de RGB (que a veces ignoran fontconfig). |
| 2026-06-11 | Revertido `fonts.conf` a `hinting=false` y `hintnone` | Todo el sistema (fontconfig) | EXPERIMENTO FALLIDO: El autohinter de FreeType deformaba el espaciado y altura de las letras en Chromium ("Wikipedi a"). Se prioriza la fidelidad de la forma sobre el engrosamiento artificial. |
| 2026-06-11 | Actualizadas variables `FREETYPE_PROPERTIES` con `type1` y `t1cid` | Todo el Entorno (environment.d) | Asegura que el engrosamiento se aplique a formatos nativos compatibles sin romper las TrueType. |

## Pasos para pruebas en tiempo real

- Para ver los cambios en navegadores, **es crucial reiniciar la sesión** (cerrar sesión y volver a entrar), ya que las variables de `environment.d` se cargan al inicio.
- Alternativamente, puedes lanzar el navegador desde la terminal así: `FREETYPE_PROPERTIES="cff:no-stem-darkening=0 autofitter:no-stem-darkening=0 type1:no-stem-darkening=0 t1cid:no-stem-darkening=0" brave`
- Usar `fc-match -s 'sans-serif'` para verificar qué fuente se renderiza.
- Probar lanzando aplicaciones en consola con `FC_DEBUG=4 alacritty` para auditar el proceso de fontconfig.
